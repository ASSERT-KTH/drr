import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 0, (double) 1.0f, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        java.awt.Paint paint5 = null;
        try {
            valueMarker1.setLabelPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker1.setLabelOffset(rectangleInsets4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets4.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0, (float) (byte) 0, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color1 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getColorComponents(floatArray4);
        try {
            float[] floatArray6 = color0.getComponents(colorSpace2, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str1.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.05d, (double) (byte) 10, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker1.setLabelOffset(rectangleInsets4);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean9 = valueMarker7.equals((java.lang.Object) 1L);
        java.lang.String str10 = valueMarker7.getLabel();
        java.awt.Stroke stroke11 = valueMarker7.getStroke();
        valueMarker1.setStroke(stroke11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray9, shapeArray10);
        try {
            java.awt.Stroke stroke12 = defaultDrawingSupplier11.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shapeArray10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER_RIGHT", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Object obj0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent(obj0, dataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0L, (double) 1.0f, 0.0d, (double) 12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font2 = valueMarker1.getLabelFont();
        valueMarker1.setValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        java.lang.Class class6 = null;
        try {
            java.util.EventListener[] eventListenerArray7 = valueMarker1.getListeners(class6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (byte) -1);
        double double4 = rectangleInsets0.extendHeight(8.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        java.lang.Class class4 = null;
        try {
            java.util.EventListener[] eventListenerArray5 = valueMarker1.getListeners(class4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray9, shapeArray10);
        try {
            java.awt.Shape shape12 = defaultDrawingSupplier11.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shapeArray10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Paint paint15 = xYPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets0.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str1.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        java.awt.Paint paint13 = null;
        try {
            xYPlot4.setRangeZeroBaselinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double2 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker10 = null;
        try {
            boolean boolean11 = xYPlot4.removeRangeMarker(marker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.05d, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0.05]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=0.05]"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-65536) + "'", int2 == (-65536));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis(0);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            xYPlot4.addDomainMarker(0, marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double2 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.util.Calendar calendar14 = null;
        try {
            day1.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        java.awt.Shape shape2 = numberAxis0.getUpArrow();
        boolean boolean3 = numberAxis0.isVerticalTickLabels();
        org.jfree.data.RangeType rangeType4 = null;
        try {
            numberAxis0.setRangeType(rangeType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        xYPlot4.axisChanged(axisChangeEvent11);
        xYPlot4.setBackgroundAlpha(0.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setRangeAxisLocation(10, axisLocation18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot4.setRenderer(xYItemRenderer20);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean5 = valueMarker3.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        java.lang.String str9 = color1.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str9.equals("java.awt.Color[r=128,g=128,b=0]"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setRangeAxisLocation(10, axisLocation18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot4.zoomRangeAxes((double) (byte) 1, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation25 = null;
        try {
            boolean boolean26 = xYPlot4.removeAnnotation(xYAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = rectangleInsets0.equals(obj2);
        double double5 = rectangleInsets0.calculateTopInset(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str1.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '4', 5, 100);
        int int4 = chartColor3.getBlue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        try {
            dateAxis0.setRange(date1, date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        categoryMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Stroke stroke11 = null;
        try {
            categoryMarker1.setStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(paintContext9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font19 = numberAxis18.getTickLabelFont();
        java.awt.Shape shape20 = numberAxis18.getUpArrow();
        boolean boolean21 = numberAxis18.isVerticalTickLabels();
        try {
            xYPlot4.setDomainAxis((-1), (org.jfree.chart.axis.ValueAxis) numberAxis18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray9, shapeArray10);
        java.awt.Stroke stroke12 = defaultDrawingSupplier11.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shapeArray10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis(0);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int3 = java.awt.Color.HSBtoRGB((float) 100L, (float) 128, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-32384) + "'", int3 == (-32384));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str1.equals("TextAnchor.HALF_ASCENT_LEFT"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = numberAxis4.getTickLabelFont();
        java.awt.Shape shape6 = numberAxis4.getUpArrow();
        numberAxis0.setDownArrow(shape6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot13.zoomDomainAxes((double) 100, plotRenderingInfo15, point2D16, false);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot13.setDataset((int) (short) 0, xYDataset20);
        xYPlot13.setRangeGridlinesVisible(false);
        xYPlot13.clearRangeAxes();
        java.lang.String str25 = xYPlot13.getPlotType();
        xYPlot13.configureRangeAxes();
        xYPlot13.setOutlineVisible(false);
        java.awt.Stroke stroke29 = xYPlot13.getRangeCrosshairStroke();
        xYPlot13.setRangeCrosshairVisible(false);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace35 = numberAxis0.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) xYPlot13, rectangle2D32, rectangleEdge33, axisSpace34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "XY Plot" + "'", str25.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = xYPlot4.getNoDataMessagePaint();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets13.getTop();
        double double15 = rectangleInsets13.getLeft();
        boolean boolean16 = day12.equals((java.lang.Object) rectangleInsets13);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot21.setFixedRangeAxisSpace(axisSpace22);
        int int24 = day12.compareTo((java.lang.Object) xYPlot21);
        xYPlot21.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean30 = valueMarker28.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker28);
        org.jfree.chart.plot.Marker marker32 = markerChangeEvent31.getMarker();
        java.lang.Object obj33 = markerChangeEvent31.getSource();
        xYPlot21.markerChanged(markerChangeEvent31);
        xYPlot4.markerChanged(markerChangeEvent31);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(marker32);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) (short) 100, (double) 6, (double) 100.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) textAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-32384), 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        java.util.Date date22 = null;
        java.util.Date date23 = null;
        try {
            dateAxis0.setRange(date22, date23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        double double17 = xYPlot4.getRangeCrosshairValue();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            xYPlot4.drawBackground(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.05d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent2.setChart(jFreeChart5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes((double) 100, plotRenderingInfo25, point2D26, false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot23.setDataset((int) (short) 0, xYDataset30);
        xYPlot23.setRangeGridlinesVisible(false);
        xYPlot23.clearRangeAxes();
        java.lang.String str35 = xYPlot23.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray36 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot23.setRenderers(xYItemRendererArray36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj39 = null;
        boolean boolean40 = axisLocation38.equals(obj39);
        xYPlot23.setDomainAxisLocation(axisLocation38, true);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace43, true);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color47, stroke48);
        categoryMarker49.setKey((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset52, valueAxis53, valueAxis54, xYItemRenderer55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        xYPlot56.zoomDomainAxes((double) 100, plotRenderingInfo58, point2D59, false);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        xYPlot56.setDataset((int) (short) 0, xYDataset63);
        xYPlot56.setRangeGridlinesVisible(false);
        xYPlot56.clearRangeAxes();
        java.lang.String str68 = xYPlot56.getPlotType();
        xYPlot56.configureRangeAxes();
        xYPlot56.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Point2D point2D74 = null;
        xYPlot56.zoomDomainAxes((double) 5, plotRenderingInfo73, point2D74, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color79 = java.awt.Color.WHITE;
        int int80 = color79.getBlue();
        java.awt.image.ColorModel colorModel81 = null;
        java.awt.Rectangle rectangle82 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        java.awt.geom.AffineTransform affineTransform84 = null;
        java.awt.RenderingHints renderingHints85 = null;
        java.awt.PaintContext paintContext86 = color79.createContext(colorModel81, rectangle82, rectangle2D83, affineTransform84, renderingHints85);
        categoryMarker78.setOutlinePaint((java.awt.Paint) color79);
        java.awt.Paint paint88 = categoryMarker78.getPaint();
        org.jfree.chart.util.Layer layer89 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean90 = xYPlot56.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker78, layer89);
        boolean boolean91 = xYPlot23.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker49, layer89);
        try {
            boolean boolean92 = xYPlot4.removeRangeMarker(128, marker18, layer89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "XY Plot" + "'", str35.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray36);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "XY Plot" + "'", str68.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 255 + "'", int80 == 255);
        org.junit.Assert.assertNotNull(paintContext86);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNotNull(layer89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean2 = day0.equals((java.lang.Object) rectangleAnchor1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) '4');
        double double3 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        try {
            java.awt.Color color1 = java.awt.Color.decode("TextAnchor.CENTER_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"TextAnchor.CENTER_RIGHT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        int int6 = day1.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day1.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 0.0d, (double) 10, (double) '#');
        double double7 = rectangleInsets5.trimHeight(100.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-10.0d) + "'", double7 == (-10.0d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color1 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomInset((double) (byte) -1);
        double double21 = rectangleInsets18.getBottom();
        xYPlot10.setInsets(rectangleInsets18, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation24 = null;
        try {
            boolean boolean25 = xYPlot10.removeAnnotation(xYAnnotation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot17.getRangeAxisLocation();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color20, stroke21);
        xYPlot17.setDomainCrosshairStroke(stroke21);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.util.List list26 = null;
        xYPlot17.drawRangeTickBands(graphics2D24, rectangle2D25, list26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets28.calculateBottomOutset((double) 0);
        xYPlot17.setInsets(rectangleInsets28);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str34 = axisLocation33.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str36 = plotOrientation35.toString();
        java.lang.String str37 = plotOrientation35.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation33, plotOrientation35);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace40 = numberAxis6.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) xYPlot17, rectangle2D32, rectangleEdge38, axisSpace39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str34.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str36.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str37.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        numberAxis6.setTickMarksVisible(true);
        try {
            numberAxis6.setRange((double) 100L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickLabelPaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean20 = valueMarker18.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker18.setStroke(stroke21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke21);
        numberAxis6.setLabelPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis(0);
        boolean boolean8 = xYPlot4.isDomainCrosshairLockedOnData();
        java.awt.Image image9 = null;
        xYPlot4.setBackgroundImage(image9);
        int int11 = xYPlot4.getDatasetCount();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Font font9 = numberAxis6.getTickLabelFont();
        numberAxis6.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(2019, (int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        numberAxis6.setTickMarksVisible(true);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str22 = plotOrientation21.toString();
        java.lang.String str23 = plotOrientation21.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation21);
        try {
            double double25 = numberAxis6.lengthToJava2D((-1.0d), rectangle2D18, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str22.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str23.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        java.lang.String str19 = rectangleInsets15.toString();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str19.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        int int6 = day1.getYear();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) int6);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray7 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray8 = color1.getColorComponents(colorSpace3, floatArray7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean12 = valueMarker10.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker10.setStroke(stroke13);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color1, stroke13);
        java.awt.Color color16 = java.awt.Color.BLACK;
        categoryMarker15.setOutlinePaint((java.awt.Paint) color16);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        try {
            categoryMarker15.setLabelOffsetType(lengthAdjustmentType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font24 = numberAxis23.getTickLabelFont();
        java.awt.Shape shape25 = numberAxis23.getUpArrow();
        numberAxis19.setDownArrow(shape25);
        org.jfree.data.Range range27 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        numberAxis19.zoomRange(1.0E-8d, 3.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot4.getAxisOffset();
        double double20 = rectangleInsets18.calculateLeftInset((double) 3);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        boolean boolean19 = xYPlot10.isRangeZoomable();
        java.awt.Paint paint20 = null;
        try {
            xYPlot10.setRangeGridlinePaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        numberAxis6.setTickMarksVisible(true);
        numberAxis6.resizeRange(2.0d);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        xYPlot4.zoom((double) 1.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        xYPlot4.setRenderer((int) (byte) 100, xYItemRenderer25, false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font24 = numberAxis23.getTickLabelFont();
        java.awt.Shape shape25 = numberAxis23.getUpArrow();
        numberAxis19.setDownArrow(shape25);
        org.jfree.data.Range range27 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        xYPlot4.clearDomainMarkers((int) '4');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Color color2 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", (int) (byte) 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.clearRangeAxes();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        double double7 = rectangleInsets2.trimHeight((double) (-8388608));
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-8388616.0d) + "'", double7 == (-8388616.0d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(100, (int) (byte) 1, 255);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        java.awt.Stroke stroke18 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot4.setRenderer(xYItemRenderer19);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        xYPlot4.setDataset((int) (byte) 10, xYDataset22);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        numberAxis0.setUpperBound((-8388616.0d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent4.getMarker();
        marker5.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes((double) 100, plotRenderingInfo14, point2D15, false);
        xYPlot12.clearAnnotations();
        xYPlot12.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color23 = java.awt.Color.WHITE;
        int int24 = color23.getBlue();
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color23.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        categoryMarker22.setOutlinePaint((java.awt.Paint) color23);
        xYPlot12.setNoDataMessagePaint((java.awt.Paint) color23);
        java.awt.Image image33 = null;
        xYPlot12.setBackgroundImage(image33);
        java.awt.Stroke stroke35 = xYPlot12.getRangeCrosshairStroke();
        marker5.setOutlineStroke(stroke35);
        java.lang.String str37 = marker5.getLabel();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str37.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        java.lang.String str4 = valueMarker1.getLabel();
        java.awt.Stroke stroke5 = valueMarker1.getStroke();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot10.zoomDomainAxes((double) 100, plotRenderingInfo12, point2D13, false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot10.setDataset((int) (short) 0, xYDataset17);
        xYPlot10.setRangeGridlinesVisible(false);
        xYPlot10.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        xYPlot10.removeChangeListener(plotChangeListener22);
        xYPlot10.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot30.getRangeAxisLocation();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color33, stroke34);
        xYPlot30.setDomainCrosshairStroke(stroke34);
        xYPlot10.setRangeCrosshairStroke(stroke34);
        valueMarker1.setOutlineStroke(stroke34);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleInsets39);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        int int19 = xYPlot10.getDatasetCount();
        boolean boolean20 = xYPlot10.isRangeCrosshairVisible();
        java.awt.Paint paint21 = xYPlot10.getBackgroundPaint();
        java.awt.Paint paint22 = null;
        try {
            xYPlot10.setRangeGridlinePaint(paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            xYPlot4.drawBackground(graphics2D21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = xYPlot4.getNoDataMessagePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            boolean boolean13 = xYPlot4.removeAnnotation(xYAnnotation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot11.zoomDomainAxes((double) 100, plotRenderingInfo13, point2D14, false);
        xYPlot11.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        xYPlot11.setRangeAxis(1, valueAxis19, false);
        java.awt.Color color22 = java.awt.Color.red;
        xYPlot11.setRangeTickBandPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot11.getDomainAxisEdge(500);
        try {
            double double26 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 12, (java.lang.Comparable) 10.0d, categoryDataset4, (double) 1, rectangle2D6, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-8388608));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot16.zoomDomainAxes((double) 100, plotRenderingInfo18, point2D19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot16.setDataset((int) (short) 0, xYDataset23);
        xYPlot16.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot16.getDomainAxis();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color31);
        xYPlot4.setDomainTickBandPaint((java.awt.Paint) color31);
        boolean boolean34 = xYPlot4.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot8.setDataset((int) (short) 0, xYDataset15);
        xYPlot8.setRangeGridlinesVisible(false);
        xYPlot8.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot8.removeChangeListener(plotChangeListener20);
        xYPlot8.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot28.getRangeAxisLocation();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color31, stroke32);
        xYPlot28.setDomainCrosshairStroke(stroke32);
        xYPlot8.setRangeCrosshairStroke(stroke32);
        java.awt.Color color38 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean42 = valueMarker40.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.Marker marker44 = markerChangeEvent43.getMarker();
        marker44.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot51.zoomDomainAxes((double) 100, plotRenderingInfo53, point2D54, false);
        xYPlot51.clearAnnotations();
        xYPlot51.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color62 = java.awt.Color.WHITE;
        int int63 = color62.getBlue();
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color62.createContext(colorModel64, rectangle65, rectangle2D66, affineTransform67, renderingHints68);
        categoryMarker61.setOutlinePaint((java.awt.Paint) color62);
        xYPlot51.setNoDataMessagePaint((java.awt.Paint) color62);
        java.awt.Image image72 = null;
        xYPlot51.setBackgroundImage(image72);
        java.awt.Stroke stroke74 = xYPlot51.getRangeCrosshairStroke();
        marker44.setOutlineStroke(stroke74);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) 2019, (java.awt.Paint) color2, stroke32, (java.awt.Paint) color38, stroke74, 0.0f);
        java.lang.Object obj78 = intervalMarker77.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(marker44);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(obj78);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        boolean boolean13 = numberAxis6.isInverted();
        numberAxis6.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        categoryMarker1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        try {
            categoryMarker1.setLabelAnchor(rectangleAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(paintContext9);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = rectangleInsets0.equals(obj2);
        java.lang.Class<?> wildcardClass4 = rectangleInsets0.getClass();
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone8);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str1.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray7 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray8 = color1.getColorComponents(colorSpace3, floatArray7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean12 = valueMarker10.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker10.setStroke(stroke13);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color1, stroke13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryMarker15.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets16.createOutsetRectangle(rectangle2D17, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean6 = valueMarker4.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setStroke(stroke7);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker4.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str22 = axisLocation21.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str24 = plotOrientation23.toString();
        java.lang.String str25 = plotOrientation23.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation21, plotOrientation23);
        try {
            java.util.List list27 = numberAxis6.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str22.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str24.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str25.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace21, true);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.Color color1 = color0.brighter();
        java.lang.String str2 = color1.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str2.equals("java.awt.Color[r=255,g=0,b=255]"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Comparable comparable1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font3 = numberAxis2.getTickLabelFont();
        try {
            categoryAxis0.setTickLabelFont(comparable1, font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean19 = valueMarker17.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        xYPlot10.markerChanged(markerChangeEvent20);
        xYPlot10.setWeight((int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot30.zoomDomainAxes((double) 100, plotRenderingInfo32, point2D33, false);
        xYPlot30.clearAnnotations();
        xYPlot30.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color41 = java.awt.Color.WHITE;
        int int42 = color41.getBlue();
        java.awt.image.ColorModel colorModel43 = null;
        java.awt.Rectangle rectangle44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = color41.createContext(colorModel43, rectangle44, rectangle2D45, affineTransform46, renderingHints47);
        categoryMarker40.setOutlinePaint((java.awt.Paint) color41);
        xYPlot30.setNoDataMessagePaint((java.awt.Paint) color41);
        java.awt.Image image51 = null;
        xYPlot30.setBackgroundImage(image51);
        java.awt.Stroke stroke53 = xYPlot30.getRangeCrosshairStroke();
        xYPlot10.setRangeGridlineStroke(stroke53);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 255 + "'", int42 == 255);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        numberAxis6.setLowerMargin((double) 10L);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot4.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets18.createInsetRectangle(rectangle2D19, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.lang.String str9 = numberAxis6.getLabelURL();
        numberAxis6.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (byte) -1);
        double double4 = rectangleInsets0.extendWidth(0.0d);
        java.lang.String str5 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str5.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, 1.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 4, (float) 7, (float) 12);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        int int20 = xYPlot4.getDomainAxisCount();
        xYPlot4.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Image image25 = null;
        xYPlot4.setBackgroundImage(image25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot4.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot4.getRangeAxis(5);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNull(valueAxis31);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace5);
        boolean boolean7 = xYPlot4.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot4.setDomainAxisLocation(axisLocation8, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot4.getAxisOffset();
        xYPlot4.setRangeCrosshairValue(7.0d, true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean19 = valueMarker17.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        xYPlot10.markerChanged(markerChangeEvent20);
        java.lang.String str24 = markerChangeEvent20.toString();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font14 = numberAxis13.getTickLabelFont();
        java.awt.Shape shape15 = numberAxis13.getUpArrow();
        numberAxis9.setDownArrow(shape15);
        numberAxis6.setDownArrow(shape15);
        numberAxis6.setInverted(false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot4.getRenderer((int) (byte) 1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = xYPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str11 = axisLocation10.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str13 = plotOrientation12.toString();
        java.lang.String str14 = plotOrientation12.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.axis.AxisState axisState17 = categoryAxis0.draw(graphics2D6, (double) (-8388608), rectangle2D8, rectangle2D9, rectangleEdge15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str11.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str14.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean19 = valueMarker17.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        xYPlot10.markerChanged(markerChangeEvent20);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = xYPlot10.getAxisOffset();
        double double26 = rectangleInsets24.calculateBottomOutset((double) 2);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker1.setStroke(stroke4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker1.getLabelOffsetType();
        float float7 = valueMarker1.getAlpha();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8f + "'", float7 == 0.8f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isHiddenValue(0L);
        boolean boolean5 = dateAxis0.isHiddenValue((long) ' ');
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER_RIGHT");
        try {
            dateAxis1.zoomRange((double) 1.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace5);
        int int7 = xYPlot4.getWeight();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        java.util.TimeZone timeZone8 = dateAxis6.getTimeZone();
        dateAxis0.setTimeZone(timeZone8);
        java.util.Date date10 = null;
        try {
            dateAxis0.setMaximumDate(date10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        double double15 = rectangleInsets14.getTop();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray2);
        int int4 = objectList0.indexOf((java.lang.Object) paintArray2);
        java.lang.Object obj6 = objectList0.get((int) ' ');
        java.lang.Object obj7 = objectList0.clone();
        int int8 = objectList0.size();
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.lang.String str9 = numberAxis6.getLabel();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        numberAxis6.setLabelInsets(rectangleInsets10);
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Image image25 = null;
        xYPlot4.setBackgroundImage(image25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot4.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace30 = xYPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNull(axisSpace30);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = xYPlot4.getRenderer(2019);
        xYPlot4.setBackgroundAlpha((float) (-8388608));
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(xYItemRenderer24);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Color color0 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getAlpha();
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color0.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray7 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray8 = color1.getColorComponents(colorSpace3, floatArray7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean12 = valueMarker10.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker10.setStroke(stroke13);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color1, stroke13);
        java.awt.Color color16 = java.awt.Color.BLACK;
        categoryMarker15.setOutlinePaint((java.awt.Paint) color16);
        java.lang.Comparable comparable18 = categoryMarker15.getKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 7.0d + "'", comparable18.equals(7.0d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomInset((double) (byte) -1);
        double double21 = rectangleInsets18.getBottom();
        xYPlot10.setInsets(rectangleInsets18, true);
        java.awt.geom.Point2D point2D24 = null;
        try {
            xYPlot10.setQuadrantOrigin(point2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot10.zoomDomainAxes((double) 100, plotRenderingInfo12, point2D13, false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot10.setDataset((int) (short) 0, xYDataset17);
        xYPlot10.setRangeGridlinesVisible(false);
        xYPlot10.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot10.setRangeAxisLocation(0, axisLocation23);
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot10);
        java.awt.geom.Point2D point2D26 = null;
        try {
            xYPlot10.setQuadrantOrigin(point2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        categoryMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Paint paint11 = categoryMarker1.getPaint();
        categoryMarker1.setKey((java.lang.Comparable) 100);
        java.lang.Comparable comparable14 = categoryMarker1.getKey();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 100 + "'", comparable14.equals(100));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        double double17 = xYPlot4.getRangeCrosshairValue();
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getTop();
        double double22 = rectangleInsets20.getLeft();
        boolean boolean23 = day19.equals((java.lang.Object) rectangleInsets20);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        xYPlot28.setFixedRangeAxisSpace(axisSpace29);
        int int31 = day19.compareTo((java.lang.Object) xYPlot28);
        boolean boolean32 = xYPlot4.equals((java.lang.Object) xYPlot28);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setLabelAngle((double) (short) 10);
        org.jfree.data.time.DateRange dateRange37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis34.setRangeWithMargins((org.jfree.data.Range) dateRange37, false, false);
        numberAxis34.setUpperBound((double) '#');
        xYPlot4.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) numberAxis34, true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateRange37);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = numberAxis4.getTickLabelFont();
        java.awt.Shape shape6 = numberAxis4.getUpArrow();
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = numberAxis8.getTickLabelFont();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        numberAxis0.setLeftArrow(shape10);
        numberAxis0.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke21, stroke22, stroke23, stroke24, stroke25, stroke26 };
        java.awt.Shape[] shapeArray28 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray19, strokeArray20, strokeArray27, shapeArray28);
        java.awt.Paint paint30 = defaultDrawingSupplier29.getNextPaint();
        xYPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot4.getDomainAxisForDataset(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 255 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot4.getDomainAxisEdge((int) (byte) 10);
        java.awt.Paint paint28 = null;
        try {
            xYPlot4.setQuadrantPaint(13, paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (13) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Image image25 = null;
        xYPlot4.setBackgroundImage(image25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace27);
        xYPlot4.clearRangeAxes();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getOutlineStroke();
        java.lang.Object obj6 = xYPlot4.clone();
        java.awt.Paint paint7 = xYPlot4.getRangeTickBandPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot4.datasetChanged(datasetChangeEvent8);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes((double) 100, plotRenderingInfo8, point2D9, false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot6.setDataset((int) (short) 0, xYDataset13);
        xYPlot6.setRangeGridlinesVisible(false);
        xYPlot6.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        xYPlot6.setRangeAxis(valueAxis18);
        objectList0.set(1, (java.lang.Object) xYPlot6);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean25 = valueMarker23.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker23.setLabelOffset(rectangleInsets26);
        java.awt.Stroke stroke28 = valueMarker23.getOutlineStroke();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean31 = xYPlot6.removeDomainMarker(6, (org.jfree.chart.plot.Marker) valueMarker23, layer29);
        java.awt.Paint paint32 = valueMarker23.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double2 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot22.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        int int25 = xYPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        numberAxis24.setAutoRangeMinimumSize((double) 2.0f, false);
        double double29 = numberAxis24.getUpperMargin();
        java.awt.Shape shape30 = numberAxis24.getRightArrow();
        java.awt.Stroke stroke31 = numberAxis24.getAxisLineStroke();
        xYPlot4.setRangeZeroBaselineStroke(stroke31);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 7.0d);
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot15.zoomDomainAxes((double) 100, plotRenderingInfo17, point2D18, false);
        xYPlot15.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        xYPlot15.setRangeAxis(1, valueAxis23, false);
        java.awt.Color color26 = java.awt.Color.red;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot15.getDomainAxisEdge(500);
        try {
            double double30 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor7, (-8388608), 1, rectangle2D10, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        int int20 = xYPlot4.getDomainAxisCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot4.addChangeListener(plotChangeListener21);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.lang.String str9 = numberAxis6.getLabelURL();
        double double10 = numberAxis6.getFixedAutoRange();
        boolean boolean11 = numberAxis6.isVisible();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        boolean boolean2 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setLabelToolTip("RectangleAnchor.BOTTOM");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomInset((double) (byte) -1);
        double double21 = rectangleInsets18.getBottom();
        xYPlot10.setInsets(rectangleInsets18, true);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean29 = valueMarker27.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker27.setStroke(stroke30);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color25, stroke30);
        xYPlot10.setDomainGridlineStroke(stroke30);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Color color0 = java.awt.Color.yellow;
        int int1 = color0.getRed();
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        java.awt.Color color3 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        float[] floatArray8 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray9 = color2.getColorComponents(colorSpace4, floatArray8);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray14 = null;
        float[] floatArray15 = color13.getColorComponents(floatArray14);
        float[] floatArray16 = null;
        float[] floatArray17 = color13.getRGBComponents(floatArray16);
        float[] floatArray18 = java.awt.Color.RGBtoHSB(0, (int) (byte) -1, (int) (short) 1, floatArray17);
        float[] floatArray19 = color0.getComponents(colorSpace4, floatArray18);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis7.getTickLabelInsets();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range16);
        dateAxis0.setRange(range16, true, true);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis0.java2DToValue(0.05d, rectangle2D22, rectangleEdge23);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset27, valueAxis28, valueAxis29, xYItemRenderer30);
        java.awt.Stroke stroke32 = xYPlot31.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYPlot31.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot31.getRangeAxisEdge();
        try {
            double double35 = dateAxis0.valueToJava2D((double) 12, rectangle2D26, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.223372036854776E18d + "'", double24 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 0.0d, (double) 10, (double) '#');
        java.lang.String str6 = unitType0.toString();
        java.lang.String str7 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 255, 0.0d, 0.0d, (double) 0.0f);
        java.lang.String str13 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnitType.ABSOLUTE" + "'", str13.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font24 = numberAxis23.getTickLabelFont();
        java.awt.Shape shape25 = numberAxis23.getUpArrow();
        numberAxis19.setDownArrow(shape25);
        org.jfree.data.Range range27 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        xYPlot4.drawBackgroundImage(graphics2D28, rectangle2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace31);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range27);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        int int3 = day1.compareTo((java.lang.Object) color2);
//        long long4 = day1.getMiddleMillisecond();
//        int int5 = day1.getDayOfMonth();
//        long long6 = day1.getFirstMillisecond();
//        int int7 = day1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setRangeAxisLocation(10, axisLocation18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font23 = valueMarker22.getLabelFont();
        java.awt.Font font24 = valueMarker22.getLabelFont();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot29.setDataset((int) (short) 0, xYDataset36);
        xYPlot29.setRangeGridlinesVisible(false);
        xYPlot29.clearRangeAxes();
        java.lang.String str41 = xYPlot29.getPlotType();
        xYPlot29.configureRangeAxes();
        xYPlot29.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot29.zoomDomainAxes((double) 5, plotRenderingInfo46, point2D47, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color52 = java.awt.Color.WHITE;
        int int53 = color52.getBlue();
        java.awt.image.ColorModel colorModel54 = null;
        java.awt.Rectangle rectangle55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = color52.createContext(colorModel54, rectangle55, rectangle2D56, affineTransform57, renderingHints58);
        categoryMarker51.setOutlinePaint((java.awt.Paint) color52);
        java.awt.Paint paint61 = categoryMarker51.getPaint();
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean63 = xYPlot29.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker51, layer62);
        xYPlot4.addRangeMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker22, layer62);
        java.lang.String str65 = layer62.toString();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "XY Plot" + "'", str41.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 255 + "'", int53 == 255);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Layer.BACKGROUND" + "'", str65.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.JFreeChart jFreeChart5 = markerChangeEvent4.getChart();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getOutlineStroke();
        xYPlot4.zoom((double) 1.0f);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        try {
            boolean boolean9 = xYPlot4.removeAnnotation(xYAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        numberAxis6.setTickLabelsVisible(false);
        double double20 = numberAxis6.getLowerBound();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray7 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray8 = color1.getColorComponents(colorSpace3, floatArray7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean12 = valueMarker10.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker10.setStroke(stroke13);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color1, stroke13);
        java.awt.Color color16 = java.awt.Color.BLACK;
        categoryMarker15.setOutlinePaint((java.awt.Paint) color16);
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color16.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintContext23);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        boolean boolean16 = numberAxis6.isPositiveArrowVisible();
        numberAxis6.resizeRange((double) (short) -1, (double) 1560452399999L);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray9, shapeArray10);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font14 = valueMarker13.getLabelFont();
        valueMarker13.setValue((double) (-1.0f));
        float float17 = valueMarker13.getAlpha();
        java.lang.Object obj18 = valueMarker13.clone();
        boolean boolean19 = defaultDrawingSupplier11.equals((java.lang.Object) valueMarker13);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot24.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        int int27 = xYPlot24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis26);
        java.awt.Font font28 = numberAxis26.getLabelFont();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisState axisState30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        java.util.List list33 = numberAxis26.refreshTicks(graphics2D29, axisState30, rectangle2D31, rectangleEdge32);
        numberAxis26.setAutoRangeStickyZero(true);
        java.lang.String str36 = numberAxis26.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font39 = valueMarker38.getLabelFont();
        java.awt.Font font40 = valueMarker38.getLabelFont();
        numberAxis26.setLabelFont(font40);
        java.awt.Stroke stroke42 = numberAxis26.getTickMarkStroke();
        valueMarker13.setStroke(stroke42);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shapeArray10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.8f + "'", float17 == 0.8f);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(stroke42);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis0.setCategoryMargin((double) (-32384));
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        int int6 = day4.compareTo((java.lang.Object) color5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
//        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) regularTimePeriod7);
//        long long9 = regularTimePeriod7.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(paint8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560538799999L + "'", long9 == 1560538799999L);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", color1);
        boolean boolean4 = color1.equals((java.lang.Object) "");
        float[] floatArray5 = null;
        float[] floatArray6 = color1.getRGBColorComponents(floatArray5);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj20 = null;
        boolean boolean21 = axisLocation19.equals(obj20);
        xYPlot4.setDomainAxisLocation(axisLocation19, true);
        xYPlot4.setBackgroundAlpha((float) 10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        numberAxis6.setTickLabelsVisible(false);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        java.awt.Stroke stroke27 = xYPlot26.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYPlot26.rendererChanged(rendererChangeEvent28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color31, stroke32);
        boolean boolean34 = categoryMarker33.getDrawAsLine();
        java.awt.Paint paint35 = categoryMarker33.getPaint();
        xYPlot26.setRangeTickBandPaint(paint35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot26.getDomainAxisEdge(13);
        try {
            double double39 = numberAxis6.valueToJava2D((double) 255, rectangle2D21, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot8.setDataset((int) (short) 0, xYDataset15);
        xYPlot8.setRangeGridlinesVisible(false);
        xYPlot8.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot8.removeChangeListener(plotChangeListener20);
        xYPlot8.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot28.getRangeAxisLocation();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color31, stroke32);
        xYPlot28.setDomainCrosshairStroke(stroke32);
        xYPlot8.setRangeCrosshairStroke(stroke32);
        java.awt.Color color38 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean42 = valueMarker40.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.Marker marker44 = markerChangeEvent43.getMarker();
        marker44.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot51.zoomDomainAxes((double) 100, plotRenderingInfo53, point2D54, false);
        xYPlot51.clearAnnotations();
        xYPlot51.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color62 = java.awt.Color.WHITE;
        int int63 = color62.getBlue();
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color62.createContext(colorModel64, rectangle65, rectangle2D66, affineTransform67, renderingHints68);
        categoryMarker61.setOutlinePaint((java.awt.Paint) color62);
        xYPlot51.setNoDataMessagePaint((java.awt.Paint) color62);
        java.awt.Image image72 = null;
        xYPlot51.setBackgroundImage(image72);
        java.awt.Stroke stroke74 = xYPlot51.getRangeCrosshairStroke();
        marker44.setOutlineStroke(stroke74);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) 2019, (java.awt.Paint) color2, stroke32, (java.awt.Paint) color38, stroke74, 0.0f);
        intervalMarker77.setStartValue((double) (short) -1);
        java.lang.Object obj80 = intervalMarker77.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(marker44);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(obj80);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        int int4 = color3.getGreen();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot10.zoomDomainAxes((double) 100, plotRenderingInfo12, point2D13, false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot10.setDataset((int) (short) 0, xYDataset17);
        xYPlot10.setRangeGridlinesVisible(false);
        xYPlot10.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot10.setRangeAxisLocation(0, axisLocation23);
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot10);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot30.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        int int33 = xYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis32);
        java.awt.Font font34 = numberAxis32.getLabelFont();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.AxisState axisState36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        java.util.List list39 = numberAxis32.refreshTicks(graphics2D35, axisState36, rectangle2D37, rectangleEdge38);
        java.awt.Paint paint40 = numberAxis32.getTickMarkPaint();
        valueMarker1.setLabelPaint(paint40);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            xYPlot4.handleClick((-1), (int) (short) 1, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNull(axisSpace18);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot12.zoomDomainAxes((double) 100, plotRenderingInfo14, point2D15, false);
        xYPlot12.clearAnnotations();
        xYPlot12.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color23 = java.awt.Color.WHITE;
        int int24 = color23.getBlue();
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color23.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        categoryMarker22.setOutlinePaint((java.awt.Paint) color23);
        xYPlot12.setNoDataMessagePaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot12.getDomainAxisEdge((int) (byte) 10);
        try {
            double double35 = categoryAxis0.getCategoryMiddle((int) (short) 1, 128, rectangle2D7, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes((double) 100, plotRenderingInfo25, point2D26, false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot23.setDataset((int) (short) 0, xYDataset30);
        xYPlot23.setRangeGridlinesVisible(false);
        xYPlot23.clearRangeAxes();
        java.lang.String str35 = xYPlot23.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray36 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot23.setRenderers(xYItemRendererArray36);
        xYPlot10.setRenderers(xYItemRendererArray36);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "XY Plot" + "'", str35.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray36);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot4.zoomDomainAxes((double) 5, plotRenderingInfo21, point2D22, true);
        java.awt.Font font25 = xYPlot4.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getRangeZeroBaselineStroke();
        java.awt.Paint paint6 = null;
        try {
            xYPlot4.setRangeZeroBaselinePaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot13.zoomDomainAxes((double) 100, plotRenderingInfo15, point2D16, false);
        xYPlot13.clearAnnotations();
        xYPlot13.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color24 = java.awt.Color.WHITE;
        int int25 = color24.getBlue();
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color24.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        categoryMarker23.setOutlinePaint((java.awt.Paint) color24);
        xYPlot13.setNoDataMessagePaint((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot13.getDomainAxisEdge((int) (byte) 10);
        try {
            double double36 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 13, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", categoryDataset6, (double) 100, rectangle2D8, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) ' ', (double) (short) 100, (double) (short) 1);
        double double5 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets4.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double25 = rectangleInsets24.getTop();
        double double26 = rectangleInsets24.getLeft();
        boolean boolean27 = day23.equals((java.lang.Object) rectangleInsets24);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot32.setFixedRangeAxisSpace(axisSpace33);
        int int35 = day23.compareTo((java.lang.Object) xYPlot32);
        xYPlot32.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean41 = valueMarker39.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker39);
        org.jfree.chart.plot.Marker marker43 = markerChangeEvent42.getMarker();
        java.lang.Object obj44 = markerChangeEvent42.getSource();
        xYPlot32.markerChanged(markerChangeEvent42);
        java.awt.Image image46 = xYPlot32.getBackgroundImage();
        boolean boolean47 = dateAxis0.hasListener((java.util.EventListener) xYPlot32);
        java.util.TimeZone timeZone48 = dateAxis0.getTimeZone();
        java.util.Date date49 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        dateAxis0.setMinimumDate(date49);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(marker43);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNull(image46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        boolean boolean21 = xYPlot4.isRangeGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color24 = java.awt.Color.WHITE;
        int int25 = color24.getBlue();
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color24.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        categoryMarker23.setOutlinePaint((java.awt.Paint) color24);
        java.awt.Paint paint33 = categoryMarker23.getPaint();
        java.awt.Color color34 = java.awt.Color.WHITE;
        int int35 = color34.getBlue();
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color34.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        categoryMarker23.setLabelPaint((java.awt.Paint) color34);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, valueAxis45, xYItemRenderer46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot47.zoomDomainAxes((double) 100, plotRenderingInfo49, point2D50, false);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot47.setDataset((int) (short) 0, xYDataset54);
        xYPlot47.setRangeGridlinesVisible(false);
        xYPlot47.clearRangeAxes();
        int int59 = xYPlot47.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        xYPlot47.setFixedDomainAxisSpace(axisSpace60);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis();
        numberAxis62.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font67 = numberAxis66.getTickLabelFont();
        java.awt.Shape shape68 = numberAxis66.getUpArrow();
        numberAxis62.setDownArrow(shape68);
        org.jfree.data.Range range70 = xYPlot47.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis62);
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection72 = xYPlot47.getDomainMarkers(layer71);
        boolean boolean73 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23, layer71);
        java.lang.String str74 = categoryMarker23.getLabel();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(str74);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
//        double double3 = rectangleInsets2.getTop();
//        double double4 = rectangleInsets2.getLeft();
//        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
//        org.jfree.data.xy.XYDataset xYDataset6 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
//        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
//        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
//        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
//        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
//        long long14 = day1.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(rectangleInsets2);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        double double13 = numberAxis6.getUpperBound();
        boolean boolean14 = numberAxis6.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        numberAxis6.setTickLabelInsets(rectangleInsets15);
        numberAxis6.setVisible(false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        double double2 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        java.awt.Stroke stroke12 = xYPlot11.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYPlot11.rendererChanged(rendererChangeEvent13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color16, stroke17);
        boolean boolean19 = categoryMarker18.getDrawAsLine();
        java.awt.Paint paint20 = categoryMarker18.getPaint();
        xYPlot11.setRangeTickBandPaint(paint20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot11.getDomainAxisEdge(13);
        try {
            java.util.List list24 = numberAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isHiddenValue(0L);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.Stroke stroke13 = xYPlot12.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = xYPlot12.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot12.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.axis.AxisState axisState17 = dateAxis0.draw(graphics2D4, 4.0d, rectangle2D6, rectangle2D7, rectangleEdge15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYPlot4.getFixedLegendItems();
        java.awt.Paint paint7 = null;
        try {
            xYPlot4.setDomainGridlinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int14 = color13.getRGB();
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        try {
            xYPlot4.setRangeAxisLocation(axisLocation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-8388608) + "'", int14 == (-8388608));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = color1.darker();
        java.awt.Color color3 = java.awt.Color.DARK_GRAY;
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        float[] floatArray9 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray10 = color3.getColorComponents(colorSpace5, floatArray9);
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        java.awt.Color color12 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        float[] floatArray17 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray18 = color11.getColorComponents(colorSpace13, floatArray17);
        try {
            float[] floatArray19 = color2.getComponents(colorSpace5, floatArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        boolean boolean3 = dateAxis0.isInverted();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        numberAxis6.setFixedAutoRange((double) 0);
        double double18 = numberAxis6.getFixedDimension();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        numberAxis6.setTickMarksVisible(true);
        boolean boolean17 = numberAxis6.isAxisLineVisible();
        numberAxis6.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot9.zoomDomainAxes((double) 100, plotRenderingInfo11, point2D12, false);
        xYPlot9.clearAnnotations();
        xYPlot9.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color20 = java.awt.Color.WHITE;
        int int21 = color20.getBlue();
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color20.createContext(colorModel22, rectangle23, rectangle2D24, affineTransform25, renderingHints26);
        categoryMarker19.setOutlinePaint((java.awt.Paint) color20);
        xYPlot9.setNoDataMessagePaint((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot9.getDomainAxisEdge((int) (byte) 10);
        try {
            double double32 = categoryAxis0.getCategoryStart((int) (byte) 0, 2, rectangle2D4, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertNotNull(paintContext27);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color1 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = xYPlot4.getNoDataMessagePaint();
        xYPlot4.clearRangeMarkers();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot16.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        int int19 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        numberAxis18.setAutoRangeMinimumSize((double) 2.0f, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.calculateTopInset((double) 10);
        numberAxis18.setLabelInsets(rectangleInsets23);
        xYPlot4.setInsets(rectangleInsets23);
        java.awt.Stroke stroke28 = xYPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        java.lang.String str2 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str2.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = xYPlot4.getNoDataMessagePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setKey((java.lang.Comparable) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker14);
        xYPlot4.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.Marker marker19 = markerChangeEvent17.getMarker();
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(marker19);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Paint paint15 = xYPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot4.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font15 = valueMarker14.getLabelFont();
        java.awt.Font font16 = valueMarker14.getLabelFont();
        numberAxis6.setLabelFont(font16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Stroke stroke26 = xYPlot25.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = xYPlot25.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot25.getRangeAxisEdge();
        try {
            java.util.List list29 = numberAxis6.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYPlot4.drawOutline(graphics2D21, rectangle2D22);
        xYPlot4.clearDomainMarkers(2019);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        categoryMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Paint paint11 = categoryMarker1.getPaint();
        categoryMarker1.setKey((java.lang.Comparable) 100);
        boolean boolean14 = categoryMarker1.getDrawAsLine();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot7.zoomDomainAxes((double) 100, plotRenderingInfo9, point2D10, false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot7.setDataset((int) (short) 0, xYDataset14);
        xYPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot7.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot7.getDataset();
        objectList0.set((int) (byte) 1, (java.lang.Object) xYDataset19);
        java.lang.Object obj22 = objectList0.get((int) (short) 1);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(obj22);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str1 = layer0.toString();
        java.lang.String str2 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.FOREGROUND" + "'", str1.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Layer.FOREGROUND" + "'", str2.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getOutlineStroke();
        java.lang.Object obj6 = xYPlot4.clone();
        java.awt.Paint paint7 = xYPlot4.getRangeTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot4.getLegendItems();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            xYPlot4.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font2 = valueMarker1.getLabelFont();
        valueMarker1.setValue((double) (-1.0f));
        float float5 = valueMarker1.getAlpha();
        java.lang.Object obj6 = valueMarker1.clone();
        java.lang.String str7 = valueMarker1.getLabel();
        float float8 = valueMarker1.getAlpha();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.8f + "'", float8 == 0.8f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean3 = objectList1.equals((java.lang.Object) paintArray2);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        java.util.TimeZone timeZone2 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.Timeline timeline3 = dateAxis0.getTimeline();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(timeline3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Font font13 = numberAxis11.getLabelFont();
        java.awt.Font font14 = numberAxis11.getTickLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font14);
        double double16 = categoryAxis0.getCategoryMargin();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Stroke stroke26 = xYPlot25.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = xYPlot25.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot25.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            org.jfree.chart.axis.AxisState axisState30 = categoryAxis0.draw(graphics2D17, (double) 2.0f, rectangle2D19, rectangle2D20, rectangleEdge28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 500, (float) (-8388608));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        double double18 = numberAxis6.getUpperBound();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes((double) 100, plotRenderingInfo8, point2D9, false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot6.setDataset((int) (short) 0, xYDataset13);
        xYPlot6.setRangeGridlinesVisible(false);
        xYPlot6.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        xYPlot6.setRangeAxis(valueAxis18);
        objectList0.set(1, (java.lang.Object) xYPlot6);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean25 = valueMarker23.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker23.setLabelOffset(rectangleInsets26);
        java.awt.Stroke stroke28 = valueMarker23.getOutlineStroke();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean31 = xYPlot6.removeDomainMarker(6, (org.jfree.chart.plot.Marker) valueMarker23, layer29);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot36.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        int int39 = xYPlot36.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        java.awt.Font font40 = numberAxis38.getLabelFont();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.AxisState axisState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        java.util.List list45 = numberAxis38.refreshTicks(graphics2D41, axisState42, rectangle2D43, rectangleEdge44);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = numberAxis38.getTickLabelInsets();
        org.jfree.data.Range range47 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis38.setRange(range47);
        java.awt.Shape shape49 = numberAxis38.getRightArrow();
        org.jfree.data.Range range50 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis38);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNull(range50);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double25 = rectangleInsets24.getTop();
        double double26 = rectangleInsets24.getLeft();
        boolean boolean27 = day23.equals((java.lang.Object) rectangleInsets24);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot32.setFixedRangeAxisSpace(axisSpace33);
        int int35 = day23.compareTo((java.lang.Object) xYPlot32);
        xYPlot32.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean41 = valueMarker39.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker39);
        org.jfree.chart.plot.Marker marker43 = markerChangeEvent42.getMarker();
        java.lang.Object obj44 = markerChangeEvent42.getSource();
        xYPlot32.markerChanged(markerChangeEvent42);
        java.awt.Image image46 = xYPlot32.getBackgroundImage();
        boolean boolean47 = dateAxis0.hasListener((java.util.EventListener) xYPlot32);
        java.util.TimeZone timeZone48 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone50 = dateAxis49.getTimeZone();
        dateAxis0.setTimeZone(timeZone50);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(marker43);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNull(image46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(timeZone50);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot8.setDataset((int) (short) 0, xYDataset15);
        xYPlot8.setRangeGridlinesVisible(false);
        xYPlot8.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot8.removeChangeListener(plotChangeListener20);
        xYPlot8.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot28.getRangeAxisLocation();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color31, stroke32);
        xYPlot28.setDomainCrosshairStroke(stroke32);
        xYPlot8.setRangeCrosshairStroke(stroke32);
        java.awt.Color color38 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean42 = valueMarker40.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.Marker marker44 = markerChangeEvent43.getMarker();
        marker44.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot51.zoomDomainAxes((double) 100, plotRenderingInfo53, point2D54, false);
        xYPlot51.clearAnnotations();
        xYPlot51.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color62 = java.awt.Color.WHITE;
        int int63 = color62.getBlue();
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color62.createContext(colorModel64, rectangle65, rectangle2D66, affineTransform67, renderingHints68);
        categoryMarker61.setOutlinePaint((java.awt.Paint) color62);
        xYPlot51.setNoDataMessagePaint((java.awt.Paint) color62);
        java.awt.Image image72 = null;
        xYPlot51.setBackgroundImage(image72);
        java.awt.Stroke stroke74 = xYPlot51.getRangeCrosshairStroke();
        marker44.setOutlineStroke(stroke74);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) 2019, (java.awt.Paint) color2, stroke32, (java.awt.Paint) color38, stroke74, 0.0f);
        java.awt.Font font78 = intervalMarker77.getLabelFont();
        java.lang.Object obj79 = intervalMarker77.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(marker44);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertNotNull(obj79);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker1.setStroke(stroke4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker1.getLabelOffsetType();
        java.awt.Font font7 = valueMarker1.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickLabelPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        java.awt.Stroke stroke11 = xYPlot10.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot10.rendererChanged(rendererChangeEvent12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = categoryMarker17.getDrawAsLine();
        java.awt.Paint paint19 = categoryMarker17.getPaint();
        xYPlot10.setRangeTickBandPaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot10.getDomainAxisEdge(13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            org.jfree.chart.axis.AxisState axisState24 = categoryAxis0.draw(graphics2D2, (double) (-32384), rectangle2D4, rectangle2D5, rectangleEdge22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setWeight(0);
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets25.getTop();
        double double27 = rectangleInsets25.getLeft();
        boolean boolean28 = day24.equals((java.lang.Object) rectangleInsets25);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        xYPlot33.setFixedRangeAxisSpace(axisSpace34);
        int int36 = day24.compareTo((java.lang.Object) xYPlot33);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        xYPlot33.drawAnnotations(graphics2D37, rectangle2D38, plotRenderingInfo39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean43 = axisLocation41.equals((java.lang.Object) lengthAdjustmentType42);
        xYPlot33.setRangeAxisLocation(axisLocation41);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot33);
        java.awt.Stroke stroke46 = xYPlot33.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 8.0d + "'", double27 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = numberAxis4.getTickLabelFont();
        java.awt.Shape shape6 = numberAxis4.getUpArrow();
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = numberAxis8.getTickLabelFont();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        numberAxis0.setLeftArrow(shape10);
        numberAxis0.resizeRange((double) (-32384), (double) 1560452399999L);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot15.getDomainAxis(4);
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        xYPlot15.setBackgroundPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot15.zoomDomainAxes((double) 4, plotRenderingInfo21, point2D22);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot32.zoomDomainAxes((double) 100, plotRenderingInfo34, point2D35, false);
        xYPlot32.clearAnnotations();
        xYPlot32.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color43 = java.awt.Color.WHITE;
        int int44 = color43.getBlue();
        java.awt.image.ColorModel colorModel45 = null;
        java.awt.Rectangle rectangle46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.geom.AffineTransform affineTransform48 = null;
        java.awt.RenderingHints renderingHints49 = null;
        java.awt.PaintContext paintContext50 = color43.createContext(colorModel45, rectangle46, rectangle2D47, affineTransform48, renderingHints49);
        categoryMarker42.setOutlinePaint((java.awt.Paint) color43);
        xYPlot32.setNoDataMessagePaint((java.awt.Paint) color43);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot32.getDomainAxisEdge((int) (byte) 10);
        try {
            java.util.List list55 = numberAxis0.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
        org.junit.Assert.assertNotNull(paintContext50);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double4 = rectangleInsets3.getTop();
        double double5 = rectangleInsets3.getLeft();
        boolean boolean6 = day2.equals((java.lang.Object) rectangleInsets3);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot11.setFixedRangeAxisSpace(axisSpace12);
        int int14 = day2.compareTo((java.lang.Object) xYPlot11);
        xYPlot11.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean20 = valueMarker18.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.plot.Marker marker22 = markerChangeEvent21.getMarker();
        java.lang.Object obj23 = markerChangeEvent21.getSource();
        xYPlot11.markerChanged(markerChangeEvent21);
        java.awt.Image image25 = xYPlot11.getBackgroundImage();
        java.awt.Image image26 = null;
        xYPlot11.setBackgroundImage(image26);
        boolean boolean28 = defaultDrawingSupplier0.equals((java.lang.Object) xYPlot11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(marker22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(image25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str27 = axisLocation26.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str29 = plotOrientation28.toString();
        java.lang.String str30 = plotOrientation28.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation26, plotOrientation28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            org.jfree.chart.axis.AxisState axisState33 = dateAxis0.draw(graphics2D22, (double) (short) -1, rectangle2D24, rectangle2D25, rectangleEdge31, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str27.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str29.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str30.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot8.setDataset((int) (short) 0, xYDataset15);
        xYPlot8.setRangeGridlinesVisible(false);
        xYPlot8.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot8.removeChangeListener(plotChangeListener20);
        xYPlot8.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot28.getRangeAxisLocation();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color31, stroke32);
        xYPlot28.setDomainCrosshairStroke(stroke32);
        xYPlot8.setRangeCrosshairStroke(stroke32);
        java.awt.Color color38 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean42 = valueMarker40.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.Marker marker44 = markerChangeEvent43.getMarker();
        marker44.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot51.zoomDomainAxes((double) 100, plotRenderingInfo53, point2D54, false);
        xYPlot51.clearAnnotations();
        xYPlot51.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color62 = java.awt.Color.WHITE;
        int int63 = color62.getBlue();
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color62.createContext(colorModel64, rectangle65, rectangle2D66, affineTransform67, renderingHints68);
        categoryMarker61.setOutlinePaint((java.awt.Paint) color62);
        xYPlot51.setNoDataMessagePaint((java.awt.Paint) color62);
        java.awt.Image image72 = null;
        xYPlot51.setBackgroundImage(image72);
        java.awt.Stroke stroke74 = xYPlot51.getRangeCrosshairStroke();
        marker44.setOutlineStroke(stroke74);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) 2019, (java.awt.Paint) color2, stroke32, (java.awt.Paint) color38, stroke74, 0.0f);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer78 = intervalMarker77.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(marker44);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNull(gradientPaintTransformer78);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke5, stroke6, stroke7, stroke8, stroke9, stroke10 };
        java.awt.Shape[] shapeArray12 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, strokeArray4, strokeArray11, shapeArray12);
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font21 = numberAxis20.getTickLabelFont();
        java.awt.Shape shape22 = numberAxis20.getUpArrow();
        numberAxis16.setDownArrow(shape22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font25 = numberAxis24.getTickLabelFont();
        java.awt.Shape shape26 = numberAxis24.getUpArrow();
        numberAxis16.setLeftArrow(shape26);
        numberAxis16.resizeRange((double) (-32384), (double) 1560452399999L);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, valueAxis33, xYItemRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot35.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        int int38 = xYPlot35.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis37);
        numberAxis37.setAutoRangeMinimumSize((double) 2.0f, false);
        double double42 = numberAxis37.getUpperMargin();
        java.awt.Shape shape43 = numberAxis37.getRightArrow();
        numberAxis16.setLeftArrow(shape43);
        java.awt.Shape[] shapeArray45 = new java.awt.Shape[] { shape43 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray3, strokeArray14, strokeArray15, shapeArray45);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shapeArray45);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0);
        java.lang.String str3 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str3.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str11 = axisLocation10.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str13 = plotOrientation12.toString();
        java.lang.String str14 = plotOrientation12.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.axis.AxisState axisState17 = categoryAxis0.draw(graphics2D6, (double) (short) 100, rectangle2D8, rectangle2D9, rectangleEdge15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str11.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str14.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace5);
        boolean boolean7 = xYPlot4.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot4.zoomRangeAxes((-10.0d), 4.0d, plotRenderingInfo10, point2D11);
        org.jfree.chart.plot.Plot plot13 = xYPlot4.getParent();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(plot13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        double double19 = xYPlot4.getRangeCrosshairValue();
        java.awt.Paint paint20 = null;
        try {
            xYPlot4.setRangeGridlinePaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYPlot4.drawOutline(graphics2D21, rectangle2D22);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font26 = valueMarker25.getLabelFont();
        valueMarker25.setValue((double) (-1.0f));
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        valueMarker25.setPaint((java.awt.Paint) color29);
        xYPlot4.setRangeGridlinePaint((java.awt.Paint) color29);
        xYPlot4.setWeight((-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean19 = valueMarker17.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        xYPlot10.markerChanged(markerChangeEvent20);
        org.jfree.chart.plot.Marker marker24 = markerChangeEvent20.getMarker();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(marker24);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        boolean boolean2 = dateAxis0.isAutoRange();
        java.util.Date date3 = dateAxis0.getMinimumDate();
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.05d, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent2.setChart(jFreeChart3);
        java.lang.String str5 = chartChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0.05]" + "'", str5.equals("org.jfree.chart.event.ChartChangeEvent[source=0.05]"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot4.getDomainAxisEdge(500);
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) '4', 0.0f, (float) 0L);
        xYPlot4.setOutlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot4.getDataset();
        java.awt.Color color19 = java.awt.Color.WHITE;
        int int20 = color19.getBlue();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        xYPlot25.zoomDomainAxes((double) 100, plotRenderingInfo27, point2D28, false);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot25.setDataset((int) (short) 0, xYDataset32);
        xYPlot25.setRangeGridlinesVisible(false);
        xYPlot25.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        xYPlot25.removeChangeListener(plotChangeListener37);
        xYPlot25.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset41, valueAxis42, valueAxis43, xYItemRenderer44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot45.getRangeAxisLocation();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color48, stroke49);
        xYPlot45.setDomainCrosshairStroke(stroke49);
        xYPlot25.setRangeCrosshairStroke(stroke49);
        java.awt.Color color55 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean59 = valueMarker57.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent60 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker57);
        org.jfree.chart.plot.Marker marker61 = markerChangeEvent60.getMarker();
        marker61.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset64, valueAxis65, valueAxis66, xYItemRenderer67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        java.awt.geom.Point2D point2D71 = null;
        xYPlot68.zoomDomainAxes((double) 100, plotRenderingInfo70, point2D71, false);
        xYPlot68.clearAnnotations();
        xYPlot68.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color79 = java.awt.Color.WHITE;
        int int80 = color79.getBlue();
        java.awt.image.ColorModel colorModel81 = null;
        java.awt.Rectangle rectangle82 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        java.awt.geom.AffineTransform affineTransform84 = null;
        java.awt.RenderingHints renderingHints85 = null;
        java.awt.PaintContext paintContext86 = color79.createContext(colorModel81, rectangle82, rectangle2D83, affineTransform84, renderingHints85);
        categoryMarker78.setOutlinePaint((java.awt.Paint) color79);
        xYPlot68.setNoDataMessagePaint((java.awt.Paint) color79);
        java.awt.Image image89 = null;
        xYPlot68.setBackgroundImage(image89);
        java.awt.Stroke stroke91 = xYPlot68.getRangeCrosshairStroke();
        marker61.setOutlineStroke(stroke91);
        org.jfree.chart.plot.IntervalMarker intervalMarker94 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) 2019, (java.awt.Paint) color19, stroke49, (java.awt.Paint) color55, stroke91, 0.0f);
        xYPlot4.setDomainGridlinePaint((java.awt.Paint) color19);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(marker61);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 255 + "'", int80 == 255);
        org.junit.Assert.assertNotNull(paintContext86);
        org.junit.Assert.assertNotNull(stroke91);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        int int20 = xYPlot4.getDomainAxisCount();
        java.awt.geom.Point2D point2D21 = null;
        try {
            xYPlot4.setQuadrantOrigin(point2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot4.zoomDomainAxes((double) 5, plotRenderingInfo21, point2D22, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color27 = java.awt.Color.WHITE;
        int int28 = color27.getBlue();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        categoryMarker26.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint36 = categoryMarker26.getPaint();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer37);
        org.jfree.chart.text.TextAnchor textAnchor39 = categoryMarker26.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor40 = categoryMarker26.getLabelTextAnchor();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset41, valueAxis42, valueAxis43, xYItemRenderer44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        xYPlot45.zoomDomainAxes((double) 100, plotRenderingInfo47, point2D48, false);
        xYPlot45.clearAnnotations();
        xYPlot45.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color56 = java.awt.Color.WHITE;
        int int57 = color56.getBlue();
        java.awt.image.ColorModel colorModel58 = null;
        java.awt.Rectangle rectangle59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        java.awt.geom.AffineTransform affineTransform61 = null;
        java.awt.RenderingHints renderingHints62 = null;
        java.awt.PaintContext paintContext63 = color56.createContext(colorModel58, rectangle59, rectangle2D60, affineTransform61, renderingHints62);
        categoryMarker55.setOutlinePaint((java.awt.Paint) color56);
        xYPlot45.setNoDataMessagePaint((java.awt.Paint) color56);
        java.awt.Image image66 = null;
        xYPlot45.setBackgroundImage(image66);
        xYPlot45.setNoDataMessage("XY Plot");
        java.awt.Image image70 = xYPlot45.getBackgroundImage();
        boolean boolean71 = categoryMarker26.equals((java.lang.Object) image70);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 255 + "'", int57 == 255);
        org.junit.Assert.assertNotNull(paintContext63);
        org.junit.Assert.assertNull(image70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        double double2 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot7.zoomDomainAxes((double) 100, plotRenderingInfo9, point2D10, false);
        xYPlot7.clearAnnotations();
        xYPlot7.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color18 = java.awt.Color.WHITE;
        int int19 = color18.getBlue();
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color18.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        categoryMarker17.setOutlinePaint((java.awt.Paint) color18);
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color18);
        java.awt.Image image28 = null;
        xYPlot7.setBackgroundImage(image28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot7.setFixedRangeAxisSpace(axisSpace30);
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot7.getDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        xYPlot7.rendererChanged(rendererChangeEvent33);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot7.getRangeAxis((int) '#');
        boolean boolean37 = objectList0.equals((java.lang.Object) valueAxis36);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(xYItemRenderer6);
        xYPlot4.setDomainCrosshairValue(0.0d, false);
        int int11 = xYPlot4.getSeriesCount();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        try {
            dateAxis0.setMaximumDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
//        long long3 = regularTimePeriod2.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        numberAxis6.setRangeWithMargins((double) (-32384), 0.2d);
        numberAxis6.setAutoRangeIncludesZero(false);
        double double23 = numberAxis6.getFixedDimension();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis7.getTickLabelInsets();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range16);
        dateAxis0.setRange(range16, true, true);
        boolean boolean21 = dateAxis0.isAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.configure();
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
        dateAxis22.setMaximumDate(date24);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone29 = dateAxis28.getTimeZone();
        boolean boolean30 = dateAxis28.isAutoRange();
        java.util.Date date31 = dateAxis28.getMinimumDate();
        try {
            dateAxis0.setRange(date24, date31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean2 = day0.equals((java.lang.Object) rectangleAnchor1);
        java.awt.Paint paint3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot8.setDataset((int) (short) 0, xYDataset15);
        xYPlot8.setRangeGridlinesVisible(false);
        java.awt.Paint paint19 = xYPlot8.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke20 = xYPlot8.getRangeGridlineStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int22 = color21.getRed();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot27.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        int int30 = xYPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis29);
        numberAxis29.setAutoRangeMinimumSize((double) 2.0f, false);
        double double34 = numberAxis29.getUpperMargin();
        java.awt.Shape shape35 = numberAxis29.getRightArrow();
        java.awt.Stroke stroke36 = numberAxis29.getAxisLineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) boolean2, paint3, stroke20, (java.awt.Paint) color21, stroke36, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 128 + "'", int22 == 128);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = xYPlot4.equals(obj16);
        java.awt.Stroke stroke18 = xYPlot4.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        double double17 = xYPlot4.getRangeCrosshairValue();
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getTop();
        double double22 = rectangleInsets20.getLeft();
        boolean boolean23 = day19.equals((java.lang.Object) rectangleInsets20);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        xYPlot28.setFixedRangeAxisSpace(axisSpace29);
        int int31 = day19.compareTo((java.lang.Object) xYPlot28);
        boolean boolean32 = xYPlot4.equals((java.lang.Object) xYPlot28);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        xYPlot39.zoomDomainAxes((double) 100, plotRenderingInfo41, point2D42, false);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        xYPlot39.setDataset((int) (short) 0, xYDataset46);
        xYPlot39.setRangeGridlinesVisible(false);
        xYPlot39.clearRangeAxes();
        java.lang.String str51 = xYPlot39.getPlotType();
        xYPlot39.configureRangeAxes();
        java.awt.Paint[] paintArray53 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray54 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray55 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke56 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke61 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray62 = new java.awt.Stroke[] { stroke56, stroke57, stroke58, stroke59, stroke60, stroke61 };
        java.awt.Shape[] shapeArray63 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier64 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray53, paintArray54, strokeArray55, strokeArray62, shapeArray63);
        java.awt.Paint paint65 = defaultDrawingSupplier64.getNextPaint();
        xYPlot39.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier64);
        java.awt.Graphics2D graphics2D67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = null;
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot(xYDataset69, valueAxis70, valueAxis71, xYItemRenderer72);
        org.jfree.chart.axis.AxisLocation axisLocation74 = xYPlot73.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis();
        int int76 = xYPlot73.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis75);
        java.awt.Font font77 = numberAxis75.getLabelFont();
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.axis.AxisState axisState79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        java.util.List list82 = numberAxis75.refreshTicks(graphics2D78, axisState79, rectangle2D80, rectangleEdge81);
        xYPlot39.drawDomainTickBands(graphics2D67, rectangle2D68, list82);
        xYPlot28.drawDomainTickBands(graphics2D33, rectangle2D34, list82);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis86 = xYPlot28.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "XY Plot" + "'", str51.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray53);
        org.junit.Assert.assertNotNull(paintArray54);
        org.junit.Assert.assertNotNull(strokeArray55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(shapeArray63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(list82);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        xYPlot4.configureRangeAxes();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot4.getDomainAxisForDataset((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font24 = numberAxis23.getTickLabelFont();
        java.awt.Shape shape25 = numberAxis23.getUpArrow();
        numberAxis19.setDownArrow(shape25);
        org.jfree.data.Range range27 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.axis.AxisState axisState29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str32 = axisLocation31.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str34 = plotOrientation33.toString();
        java.lang.String str35 = plotOrientation33.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation33);
        try {
            java.util.List list37 = numberAxis19.refreshTicks(graphics2D28, axisState29, rectangle2D30, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str32.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str34.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str35.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis7.getTickLabelInsets();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range16);
        dateAxis0.setRange(range16, true, true);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis0.java2DToValue(0.05d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat26 = dateAxis25.getDateFormatOverride();
        java.util.TimeZone timeZone27 = dateAxis25.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone27);
        dateAxis0.setTimeZone(timeZone27);
        boolean boolean31 = dateAxis0.isHiddenValue((long) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.223372036854776E18d + "'", double24 == 9.223372036854776E18d);
        org.junit.Assert.assertNull(dateFormat26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot4.getDomainAxisEdge(500);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color20, stroke21);
        xYPlot4.setDomainGridlineStroke(stroke21);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot29.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        int int32 = xYPlot29.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.awt.Font font33 = numberAxis31.getLabelFont();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.axis.AxisState axisState35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        java.util.List list38 = numberAxis31.refreshTicks(graphics2D34, axisState35, rectangle2D36, rectangleEdge37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = numberAxis31.getTickLabelInsets();
        numberAxis31.setAxisLineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, valueAxis44, xYItemRenderer45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        xYPlot46.zoomDomainAxes((double) 100, plotRenderingInfo48, point2D49, false);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        xYPlot46.setDataset((int) (short) 0, xYDataset53);
        xYPlot46.setRangeGridlinesVisible(false);
        xYPlot46.clearRangeAxes();
        int int58 = xYPlot46.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        xYPlot46.setFixedDomainAxisSpace(axisSpace59);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        numberAxis61.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font66 = numberAxis65.getTickLabelFont();
        java.awt.Shape shape67 = numberAxis65.getUpArrow();
        numberAxis61.setDownArrow(shape67);
        org.jfree.data.Range range69 = xYPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis61);
        numberAxis61.resizeRange(0.0d, 1.0E-8d);
        org.jfree.data.Range range73 = numberAxis61.getRange();
        numberAxis31.setRangeWithMargins(range73);
        xYPlot4.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis31, true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNull(range69);
        org.junit.Assert.assertNotNull(range73);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot4.getDataset();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot22.zoomDomainAxes((double) 100, plotRenderingInfo24, point2D25, false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot22.setDataset((int) (short) 0, xYDataset29);
        xYPlot22.setRangeGridlinesVisible(false);
        xYPlot22.clearRangeAxes();
        int int34 = xYPlot22.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot22.setRangeAxisLocation(10, axisLocation36);
        xYPlot4.setRangeAxisLocation(8, axisLocation36);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Color color0 = java.awt.Color.RED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            categoryPlot0.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        xYPlot4.setDrawingSupplier(drawingSupplier22);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot29.setDataset((int) (short) 0, xYDataset36);
        xYPlot29.setRangeGridlinesVisible(false);
        xYPlot29.clearRangeAxes();
        int int41 = xYPlot29.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot29.setRangeAxisLocation(10, axisLocation43);
        xYPlot4.setRangeAxisLocation((int) (short) 0, axisLocation43);
        double double46 = xYPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) '4');
        double double4 = rectangleInsets0.extendHeight((double) 1.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) 0, (double) '#', (double) 2.0f, (double) 1560365999999L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.0d + "'", double4 == 9.0d);
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getDomainAxis(4);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        xYPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot0.zoomDomainAxes((double) 4, plotRenderingInfo6, point2D7);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot14.zoomDomainAxes((double) 100, plotRenderingInfo16, point2D17, false);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot14.setDataset((int) (short) 0, xYDataset21);
        xYPlot14.setRangeGridlinesVisible(false);
        xYPlot14.clearRangeAxes();
        java.lang.String str26 = xYPlot14.getPlotType();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot14);
        xYPlot14.setForegroundAlpha(2.0f);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double37 = rectangleInsets36.getTop();
        double double38 = rectangleInsets36.getLeft();
        boolean boolean39 = day35.equals((java.lang.Object) rectangleInsets36);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset40, valueAxis41, valueAxis42, xYItemRenderer43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        xYPlot44.setFixedRangeAxisSpace(axisSpace45);
        int int47 = day35.compareTo((java.lang.Object) xYPlot44);
        xYPlot44.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean53 = valueMarker51.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent54 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker51);
        org.jfree.chart.plot.Marker marker55 = markerChangeEvent54.getMarker();
        java.lang.Object obj56 = markerChangeEvent54.getSource();
        xYPlot44.markerChanged(markerChangeEvent54);
        org.jfree.chart.axis.AxisLocation axisLocation58 = xYPlot44.getDomainAxisLocation();
        xYPlot14.setDomainAxisLocation(axisLocation58);
        try {
            xYPlot0.setDomainAxisLocation((-8388608), axisLocation58, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 8.0d + "'", double38 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(marker55);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNotNull(axisLocation58);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot4.getDataset();
        xYPlot4.setNoDataMessage("");
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        xYPlot4.axisChanged(axisChangeEvent19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot4.zoomRangeAxes(7.0d, (double) 1560538799999L, plotRenderingInfo23, point2D24);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(xYDataset16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot4.getDatasetRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot26.zoomDomainAxes((double) 100, plotRenderingInfo28, point2D29, false);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        xYPlot26.setDataset((int) (short) 0, xYDataset33);
        xYPlot26.setRangeGridlinesVisible(false);
        xYPlot26.clearRangeAxes();
        java.lang.String str38 = xYPlot26.getPlotType();
        xYPlot26.configureRangeAxes();
        xYPlot26.setOutlineVisible(false);
        java.awt.Stroke stroke42 = xYPlot26.getRangeCrosshairStroke();
        boolean boolean43 = xYPlot26.isRangeGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color46 = java.awt.Color.WHITE;
        int int47 = color46.getBlue();
        java.awt.image.ColorModel colorModel48 = null;
        java.awt.Rectangle rectangle49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        java.awt.geom.AffineTransform affineTransform51 = null;
        java.awt.RenderingHints renderingHints52 = null;
        java.awt.PaintContext paintContext53 = color46.createContext(colorModel48, rectangle49, rectangle2D50, affineTransform51, renderingHints52);
        categoryMarker45.setOutlinePaint((java.awt.Paint) color46);
        java.awt.Paint paint55 = categoryMarker45.getPaint();
        java.awt.Color color56 = java.awt.Color.WHITE;
        int int57 = color56.getBlue();
        java.awt.image.ColorModel colorModel58 = null;
        java.awt.Rectangle rectangle59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        java.awt.geom.AffineTransform affineTransform61 = null;
        java.awt.RenderingHints renderingHints62 = null;
        java.awt.PaintContext paintContext63 = color56.createContext(colorModel58, rectangle59, rectangle2D60, affineTransform61, renderingHints62);
        categoryMarker45.setLabelPaint((java.awt.Paint) color56);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset65, valueAxis66, valueAxis67, xYItemRenderer68);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        java.awt.geom.Point2D point2D72 = null;
        xYPlot69.zoomDomainAxes((double) 100, plotRenderingInfo71, point2D72, false);
        org.jfree.data.xy.XYDataset xYDataset76 = null;
        xYPlot69.setDataset((int) (short) 0, xYDataset76);
        xYPlot69.setRangeGridlinesVisible(false);
        xYPlot69.clearRangeAxes();
        int int81 = xYPlot69.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace82 = null;
        xYPlot69.setFixedDomainAxisSpace(axisSpace82);
        org.jfree.chart.axis.NumberAxis numberAxis84 = new org.jfree.chart.axis.NumberAxis();
        numberAxis84.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis88 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font89 = numberAxis88.getTickLabelFont();
        java.awt.Shape shape90 = numberAxis88.getUpArrow();
        numberAxis84.setDownArrow(shape90);
        org.jfree.data.Range range92 = xYPlot69.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis84);
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection94 = xYPlot69.getDomainMarkers(layer93);
        boolean boolean95 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker45, layer93);
        java.lang.String str96 = layer93.toString();
        java.util.Collection collection97 = xYPlot4.getRangeMarkers(11, layer93);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "XY Plot" + "'", str38.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 255 + "'", int47 == 255);
        org.junit.Assert.assertNotNull(paintContext53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 255 + "'", int57 == 255);
        org.junit.Assert.assertNotNull(paintContext63);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(font89);
        org.junit.Assert.assertNotNull(shape90);
        org.junit.Assert.assertNull(range92);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertNull(collection94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "Layer.FOREGROUND" + "'", str96.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection97);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.mapDatasetToRangeAxis(3, (-65536));
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        xYPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot4.zoomDomainAxes((double) (-1.0f), plotRenderingInfo11, point2D12, false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList();
        objectList1.clear();
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray3);
        int int5 = objectList1.indexOf((java.lang.Object) paintArray3);
        java.lang.Object obj7 = objectList1.get((int) ' ');
        objectList1.clear();
        boolean boolean9 = sortOrder0.equals((java.lang.Object) objectList1);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot4.rendererChanged(rendererChangeEvent8);
        int int10 = xYPlot4.getDomainAxisCount();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        java.awt.Color color12 = java.awt.Color.WHITE;
        int int13 = color12.getBlue();
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color12.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        xYPlot4.setDomainZeroBaselinePaint((java.awt.Paint) color12);
        int int21 = xYPlot4.getRangeAxisCount();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot28.zoomDomainAxes((double) 100, plotRenderingInfo30, point2D31, false);
        xYPlot28.clearAnnotations();
        xYPlot28.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color39 = java.awt.Color.WHITE;
        int int40 = color39.getBlue();
        java.awt.image.ColorModel colorModel41 = null;
        java.awt.Rectangle rectangle42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.awt.geom.AffineTransform affineTransform44 = null;
        java.awt.RenderingHints renderingHints45 = null;
        java.awt.PaintContext paintContext46 = color39.createContext(colorModel41, rectangle42, rectangle2D43, affineTransform44, renderingHints45);
        categoryMarker38.setOutlinePaint((java.awt.Paint) color39);
        xYPlot28.setNoDataMessagePaint((java.awt.Paint) color39);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot28.getDomainAxisEdge((int) (byte) 10);
        try {
            double double51 = numberAxis6.valueToJava2D((double) 0L, rectangle2D23, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertNotNull(paintContext46);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("java.awt.Color[r=255,g=0,b=255]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        xYPlot4.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot4.getRenderer((int) ' ');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(xYItemRenderer20);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot5.rendererChanged(rendererChangeEvent9);
        org.jfree.data.general.DatasetGroup datasetGroup11 = xYPlot5.getDatasetGroup();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline16 = dateAxis15.getTimeline();
        boolean boolean17 = layer14.equals((java.lang.Object) timeline16);
        xYPlot5.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker13, layer14);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace19, false);
        java.awt.Color color23 = java.awt.Color.DARK_GRAY;
        java.awt.Color color24 = java.awt.Color.getColor("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", color23);
        boolean boolean26 = color23.equals((java.lang.Object) "");
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color23);
        boolean boolean28 = lengthAdjustmentType0.equals((java.lang.Object) xYPlot5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertNotNull(timeline16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        double double13 = numberAxis6.getUpperBound();
        numberAxis6.setUpperMargin((double) (-1));
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.Plot plot17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        java.awt.Stroke stroke24 = xYPlot23.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        xYPlot23.rendererChanged(rendererChangeEvent25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color28, stroke29);
        boolean boolean31 = categoryMarker30.getDrawAsLine();
        java.awt.Paint paint32 = categoryMarker30.getPaint();
        xYPlot23.setRangeTickBandPaint(paint32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot23.getDomainAxisEdge(13);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace37 = numberAxis6.reserveSpace(graphics2D16, plot17, rectangle2D18, rectangleEdge35, axisSpace36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke21, stroke22, stroke23, stroke24, stroke25, stroke26 };
        java.awt.Shape[] shapeArray28 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray19, strokeArray20, strokeArray27, shapeArray28);
        java.awt.Paint paint30 = defaultDrawingSupplier29.getNextPaint();
        xYPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29);
        java.lang.Object obj32 = defaultDrawingSupplier29.clone();
        try {
            java.awt.Shape shape33 = defaultDrawingSupplier29.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        int int20 = xYPlot4.getDomainAxisCount();
        java.awt.Stroke stroke21 = xYPlot4.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(xYItemRenderer6);
        xYPlot4.setNoDataMessage("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            xYPlot4.drawBackground(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        xYPlot4.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot4.getAxisOffset();
        double double20 = rectangleInsets18.extendHeight(2.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        numberAxis0.setRangeWithMargins((double) 3, 4.0d);
        numberAxis0.setAxisLineVisible(true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        boolean boolean13 = numberAxis6.isInverted();
        numberAxis6.setFixedDimension((double) 0L);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font17 = numberAxis16.getTickLabelFont();
        java.awt.Shape shape18 = numberAxis16.getUpArrow();
        numberAxis12.setDownArrow(shape18);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font21 = numberAxis20.getTickLabelFont();
        java.awt.Shape shape22 = numberAxis20.getUpArrow();
        numberAxis12.setLeftArrow(shape22);
        numberAxis6.setLeftArrow(shape22);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.chart.plot.Plot plot12 = plotChangeEvent11.getPlot();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        plotChangeEvent11.setChart(jFreeChart12);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean20 = axisLocation18.equals((java.lang.Object) lengthAdjustmentType19);
        xYPlot10.setRangeAxisLocation(axisLocation18);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str23 = plotOrientation22.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation18, plotOrientation22);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str23.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        xYPlot4.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font25 = valueMarker24.getLabelFont();
        valueMarker24.setValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker24.getLabelOffset();
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color9, stroke10);
        boolean boolean12 = categoryMarker11.getDrawAsLine();
        java.awt.Paint paint13 = categoryMarker11.getPaint();
        xYPlot4.setRangeTickBandPaint(paint13);
        xYPlot4.configureDomainAxes();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = xYPlot4.equals(obj16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        xYPlot4.setDomainAxisLocation(4, axisLocation19, true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        try {
            dateAxis0.setMinimumDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setRangeAxisLocation(10, axisLocation18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font23 = valueMarker22.getLabelFont();
        java.awt.Font font24 = valueMarker22.getLabelFont();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot29.setDataset((int) (short) 0, xYDataset36);
        xYPlot29.setRangeGridlinesVisible(false);
        xYPlot29.clearRangeAxes();
        java.lang.String str41 = xYPlot29.getPlotType();
        xYPlot29.configureRangeAxes();
        xYPlot29.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot29.zoomDomainAxes((double) 5, plotRenderingInfo46, point2D47, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color52 = java.awt.Color.WHITE;
        int int53 = color52.getBlue();
        java.awt.image.ColorModel colorModel54 = null;
        java.awt.Rectangle rectangle55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = color52.createContext(colorModel54, rectangle55, rectangle2D56, affineTransform57, renderingHints58);
        categoryMarker51.setOutlinePaint((java.awt.Paint) color52);
        java.awt.Paint paint61 = categoryMarker51.getPaint();
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean63 = xYPlot29.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker51, layer62);
        xYPlot4.addRangeMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker22, layer62);
        valueMarker22.setValue((double) (-1));
        double double67 = valueMarker22.getValue();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "XY Plot" + "'", str41.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 255 + "'", int53 == 255);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + (-1.0d) + "'", double67 == (-1.0d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font15 = valueMarker14.getLabelFont();
        java.awt.Font font16 = valueMarker14.getLabelFont();
        numberAxis6.setLabelFont(font16);
        numberAxis6.setAutoRangeMinimumSize((double) 10.0f);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot24.zoomDomainAxes((double) 100, plotRenderingInfo26, point2D27, false);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        xYPlot24.setDataset((int) (short) 0, xYDataset31);
        xYPlot24.setRangeGridlinesVisible(false);
        xYPlot24.clearRangeAxes();
        java.lang.String str36 = xYPlot24.getPlotType();
        xYPlot24.configureRangeAxes();
        xYPlot24.setOutlineVisible(false);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        xYPlot24.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot24.getRangeAxisLocation(7);
        numberAxis6.setPlot((org.jfree.chart.plot.Plot) xYPlot24);
        org.jfree.chart.plot.Plot plot46 = xYPlot24.getRootPlot();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "XY Plot" + "'", str36.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(plot46);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        xYPlot4.axisChanged(axisChangeEvent11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot4.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection13);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.jfree.chart.plot.Plot plot19 = xYPlot4.getParent();
        java.awt.Paint paint20 = xYPlot4.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYPlot4.getFixedLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot4.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        try {
            xYPlot4.setRenderer((-1), xYItemRenderer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        java.awt.Stroke stroke13 = numberAxis6.getAxisLineStroke();
        numberAxis6.setLabelURL("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelAngle((double) (short) 10);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange3, false, false);
        numberAxis0.setLabel("java.awt.Color[r=255,g=0,b=255]");
        org.junit.Assert.assertNotNull(dateRange3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = dateAxis0.getTimeline();
        org.jfree.chart.util.Layer layer2 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline4 = dateAxis3.getTimeline();
        boolean boolean5 = layer2.equals((java.lang.Object) timeline4);
        dateAxis0.setTimeline(timeline4);
        org.junit.Assert.assertNotNull(timeline1);
        org.junit.Assert.assertNotNull(layer2);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Paint paint15 = xYPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            xYPlot4.handleClick((int) (short) 100, 500, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font2 = valueMarker1.getLabelFont();
        valueMarker1.setValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        double double7 = rectangleInsets5.calculateRightInset((double) 1.0f);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, 0.2d, (double) 0L, (double) (byte) 10);
        double double6 = rectangleInsets5.getBottom();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray7 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray8 = color1.getColorComponents(colorSpace3, floatArray7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean12 = valueMarker10.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker10.setStroke(stroke13);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color1, stroke13);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color17 = java.awt.Color.BLACK;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray19 = null;
        float[] floatArray20 = color18.getColorComponents(floatArray19);
        float[] floatArray21 = null;
        float[] floatArray22 = color18.getRGBComponents(floatArray21);
        float[] floatArray23 = color17.getComponents(floatArray21);
        float[] floatArray24 = color16.getComponents(floatArray21);
        float[] floatArray25 = color1.getColorComponents(floatArray24);
        int int26 = color1.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 64 + "'", int26 == 64);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        xYPlot4.configureDomainAxes();
        xYPlot4.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setDomainCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        xYPlot4.setForegroundAlpha(2.0f);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot4.getDomainAxis();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=255]"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.clearDomainAxes();
        java.awt.Paint paint20 = xYPlot4.getQuadrantPaint(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot4.getAxisOffset();
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        boolean boolean14 = numberAxis6.isVisible();
        numberAxis6.setLabelToolTip("SortOrder.DESCENDING");
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation(0);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getLeft();
        boolean boolean9 = day5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace15);
        int int17 = day5.compareTo((java.lang.Object) xYPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot14.drawAnnotations(graphics2D18, rectangle2D19, plotRenderingInfo20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) lengthAdjustmentType23);
        xYPlot14.setRangeAxisLocation(axisLocation22);
        xYPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot33.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        int int36 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Font font37 = numberAxis35.getLabelFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis35.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis35.getStandardTickUnits();
        boolean boolean45 = numberAxis35.isPositiveArrowVisible();
        xYPlot14.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot0.zoomDomainAxes((double) (byte) -1, plotRenderingInfo52, point2D53);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer50);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis7.getTickLabelInsets();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range16);
        dateAxis0.setRange(range16, true, true);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis0.java2DToValue(0.05d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat26 = dateAxis25.getDateFormatOverride();
        java.util.TimeZone timeZone27 = dateAxis25.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone27);
        dateAxis0.setTimeZone(timeZone27);
        org.jfree.data.Range range30 = null;
        try {
            dateAxis0.setRange(range30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.223372036854776E18d + "'", double24 == 9.223372036854776E18d);
        org.junit.Assert.assertNull(dateFormat26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(tickUnitSource28);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        numberAxis6.setFixedAutoRange((double) 0);
        boolean boolean18 = numberAxis6.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis1.getTimeline();
        boolean boolean3 = layer0.equals((java.lang.Object) timeline2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot8.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Font font12 = numberAxis10.getLabelFont();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.util.List list17 = numberAxis10.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis10.getTickLabelInsets();
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis10.setRange(range19);
        boolean boolean21 = layer0.equals((java.lang.Object) range19);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace5);
        boolean boolean7 = xYPlot4.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot4.setRenderer(xYItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        xYPlot4.addChangeListener(plotChangeListener6);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.Class<?> wildcardClass1 = categoryAnchor0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize(class2);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLabelAngle();
        boolean boolean2 = numberAxis0.isVerticalTickLabels();
        numberAxis0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke16 = xYPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.Marker marker17 = null;
        boolean boolean18 = xYPlot4.removeDomainMarker(marker17);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double6 = rectangleInsets5.getTop();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = day4.equals((java.lang.Object) rectangleInsets5);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace14);
        int int16 = day4.compareTo((java.lang.Object) xYPlot13);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        xYPlot13.drawAnnotations(graphics2D17, rectangle2D18, plotRenderingInfo19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean23 = axisLocation21.equals((java.lang.Object) lengthAdjustmentType22);
        xYPlot13.setRangeAxisLocation(axisLocation21);
        categoryPlot0.setRangeAxisLocation(13, axisLocation21, true);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot0.render(graphics2D27, rectangle2D28, 64, plotRenderingInfo30);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.clearRangeMarkers((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat4 = dateAxis3.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis3.setTickUnit(dateTickUnit5, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot14.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        int int17 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis16);
        java.awt.Font font18 = numberAxis16.getLabelFont();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        java.util.List list23 = numberAxis16.refreshTicks(graphics2D19, axisState20, rectangle2D21, rectangleEdge22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis16.getTickLabelInsets();
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis16.setRange(range25);
        dateAxis9.setRange(range25, true, true);
        dateAxis3.setRange(range25);
        dateAxis0.setRange(range25, false, true);
        dateAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleAnchor.BOTTOM");
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        xYPlot4.setRangeAxisLocation((int) (short) 1, axisLocation16);
        double double18 = xYPlot4.getRangeCrosshairValue();
        org.jfree.chart.util.ObjectList objectList19 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        xYPlot25.zoomDomainAxes((double) 100, plotRenderingInfo27, point2D28, false);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot25.setDataset((int) (short) 0, xYDataset32);
        xYPlot25.setRangeGridlinesVisible(false);
        xYPlot25.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        xYPlot25.setRangeAxis(valueAxis37);
        objectList19.set(1, (java.lang.Object) xYPlot25);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean44 = valueMarker42.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker42.setLabelOffset(rectangleInsets45);
        java.awt.Stroke stroke47 = valueMarker42.getOutlineStroke();
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str49 = layer48.toString();
        boolean boolean50 = xYPlot25.removeDomainMarker(6, (org.jfree.chart.plot.Marker) valueMarker42, layer48);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset51, valueAxis52, valueAxis53, xYItemRenderer54);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Point2D point2D58 = null;
        xYPlot55.zoomDomainAxes((double) 100, plotRenderingInfo57, point2D58, false);
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        xYPlot55.setDataset((int) (short) 0, xYDataset62);
        xYPlot55.setRangeGridlinesVisible(false);
        xYPlot55.clearRangeAxes();
        java.lang.String str67 = xYPlot55.getPlotType();
        xYPlot55.configureRangeAxes();
        java.awt.Paint[] paintArray69 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray70 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray71 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke72 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke73 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke75 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray78 = new java.awt.Stroke[] { stroke72, stroke73, stroke74, stroke75, stroke76, stroke77 };
        java.awt.Shape[] shapeArray79 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier80 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray69, paintArray70, strokeArray71, strokeArray78, shapeArray79);
        java.awt.Paint paint81 = defaultDrawingSupplier80.getNextPaint();
        xYPlot55.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier80);
        org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor85 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        valueMarker84.setLabelTextAnchor(textAnchor85);
        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot55.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker84, layer87);
        boolean boolean89 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker42, layer87);
        int int90 = xYPlot4.getRangeAxisCount();
        xYPlot4.setDomainCrosshairValue((double) 13, true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Layer.FOREGROUND" + "'", str49.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "XY Plot" + "'", str67.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray69);
        org.junit.Assert.assertNotNull(paintArray70);
        org.junit.Assert.assertNotNull(strokeArray71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(strokeArray78);
        org.junit.Assert.assertNotNull(shapeArray79);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(textAnchor85);
        org.junit.Assert.assertNotNull(layer87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 2 + "'", int90 == 2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        int int19 = xYPlot10.getDatasetCount();
        boolean boolean20 = xYPlot10.isRangeCrosshairVisible();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot25.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        int int28 = xYPlot25.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis27);
        numberAxis27.setAutoRangeMinimumSize((double) 2.0f, false);
        double double32 = numberAxis27.getUpperMargin();
        java.awt.Shape shape33 = numberAxis27.getRightArrow();
        java.awt.Stroke stroke34 = numberAxis27.getAxisLineStroke();
        xYPlot10.setDomainZeroBaselineStroke(stroke34);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 0);
        double double3 = intervalMarker2.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(gradientPaintTransformer4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(0, axisLocation9, false);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(true);
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double8 = rectangleInsets7.getTop();
        double double9 = rectangleInsets7.getLeft();
        boolean boolean10 = day6.equals((java.lang.Object) rectangleInsets7);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace16);
        int int18 = day6.compareTo((java.lang.Object) xYPlot15);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        xYPlot15.drawAnnotations(graphics2D19, rectangle2D20, plotRenderingInfo21);
        java.awt.Paint paint23 = xYPlot15.getDomainCrosshairPaint();
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) (-1L), paint23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot32.zoomDomainAxes((double) 100, plotRenderingInfo34, point2D35, false);
        xYPlot32.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        xYPlot32.setRangeAxis(1, valueAxis40, false);
        java.awt.Color color43 = java.awt.Color.red;
        xYPlot32.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot32.getDomainAxisEdge(500);
        try {
            java.util.List list47 = categoryAxis0.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis(0);
        java.awt.Stroke stroke8 = xYPlot4.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        categoryPlot0.setDataset((int) (short) 10, categoryDataset3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font11 = numberAxis10.getTickLabelFont();
        java.awt.Shape shape12 = numberAxis10.getUpArrow();
        numberAxis6.setDownArrow(shape12);
        categoryPlot0.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis6, false);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(categoryAnchor1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        org.jfree.data.general.DatasetGroup datasetGroup18 = xYPlot4.getDatasetGroup();
        org.junit.Assert.assertNull(datasetGroup18);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
//        double double3 = rectangleInsets2.getTop();
//        double double4 = rectangleInsets2.getLeft();
//        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
//        int int6 = day1.getYear();
//        int int7 = day1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(rectangleInsets2);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent4.getMarker();
        marker5.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Object obj8 = marker5.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        java.awt.Stroke stroke22 = numberAxis6.getTickMarkStroke();
        java.text.NumberFormat numberFormat23 = numberAxis6.getNumberFormatOverride();
        double double24 = numberAxis6.getLowerBound();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(numberFormat23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset(xYDataset11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot17.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        int int20 = xYPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        numberAxis19.setAutoRangeMinimumSize((double) 2.0f, false);
        double double24 = numberAxis19.getUpperMargin();
        java.awt.Shape shape25 = numberAxis19.getRightArrow();
        boolean boolean26 = numberAxis19.isInverted();
        java.lang.String str27 = numberAxis19.getLabel();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.axis.AxisState axisState29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        java.util.List list32 = numberAxis19.refreshTicks(graphics2D28, axisState29, rectangle2D30, rectangleEdge31);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone34 = dateAxis33.getTimeZone();
        boolean boolean35 = dateAxis33.isAutoRange();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { numberAxis19, dateAxis33 };
        xYPlot4.setRangeAxes(valueAxisArray36);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(valueAxisArray36);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        numberAxis6.setRangeWithMargins((double) 0.8f, (double) 10);
        java.awt.Color color25 = java.awt.Color.DARK_GRAY;
        numberAxis6.setAxisLinePaint((java.awt.Paint) color25);
        double double27 = numberAxis6.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0E-8d + "'", double27 == 1.0E-8d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines(1);
        boolean boolean3 = categoryAxis0.isTickMarksVisible();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 0.05d, (java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 0.0d, (double) 10, (double) '#');
        java.lang.String str6 = unitType0.toString();
        java.lang.String str7 = unitType0.toString();
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) unitType0, dataset8);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day1.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean6 = valueMarker4.equals((java.lang.Object) 1L);
        java.lang.String str7 = valueMarker4.getLabel();
        java.awt.Stroke stroke8 = valueMarker4.getStroke();
        dateAxis0.setTickMarkStroke(stroke8);
        java.lang.Object obj10 = dateAxis0.clone();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Font font13 = numberAxis11.getLabelFont();
        java.awt.Font font14 = numberAxis11.getTickLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font14);
        double double16 = categoryAxis0.getCategoryMargin();
        categoryAxis0.clearCategoryLabelToolTips();
        int int18 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean5 = valueMarker3.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        org.jfree.chart.text.TextAnchor textAnchor9 = valueMarker8.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        double double2 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color12, stroke13);
        xYPlot9.setDomainCrosshairStroke(stroke13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        xYPlot9.drawRangeTickBands(graphics2D16, rectangle2D17, list18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj22 = null;
        boolean boolean23 = axisLocation21.equals(obj22);
        xYPlot9.setRangeAxisLocation((int) 'a', axisLocation21, true);
        try {
            categoryPlot0.setRangeAxisLocation((int) (byte) -1, axisLocation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getDomainAxisLocation((-1));
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        java.awt.Stroke stroke33 = null;
        try {
            categoryPlot32.setRangeGridlineStroke(stroke33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font29 = numberAxis28.getTickLabelFont();
        java.awt.Shape shape30 = numberAxis28.getUpArrow();
        numberAxis24.setDownArrow(shape30);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font33 = numberAxis32.getTickLabelFont();
        java.awt.Shape shape34 = numberAxis32.getUpArrow();
        numberAxis24.setLeftArrow(shape34);
        numberAxis24.resizeRange((double) (-32384), (double) 1560452399999L);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot39.getDomainAxis(4);
        java.awt.Color color42 = java.awt.Color.MAGENTA;
        xYPlot39.setBackgroundPaint((java.awt.Paint) color42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        xYPlot39.zoomDomainAxes((double) 4, plotRenderingInfo45, point2D46);
        numberAxis24.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot39);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot39.getDomainAxisEdge(0);
        try {
            double double51 = dateAxis0.lengthToJava2D((double) 11, rectangle2D23, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        dateAxis0.setMaximumDate(date2);
        boolean boolean6 = dateAxis0.isVisible();
        double double7 = dateAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot28.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot28.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        numberAxis30.setAutoRangeMinimumSize((double) 2.0f, false);
        double double35 = numberAxis30.getUpperMargin();
        xYPlot4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis30);
        numberAxis30.setTickMarkOutsideLength((float) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset41, valueAxis42, valueAxis43, xYItemRenderer44);
        java.awt.Stroke stroke46 = xYPlot45.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent47 = null;
        xYPlot45.rendererChanged(rendererChangeEvent47);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color50, stroke51);
        boolean boolean53 = categoryMarker52.getDrawAsLine();
        java.awt.Paint paint54 = categoryMarker52.getPaint();
        xYPlot45.setRangeTickBandPaint(paint54);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = xYPlot45.getDomainAxisEdge(13);
        try {
            double double58 = numberAxis30.valueToJava2D((double) 100, rectangle2D40, rectangleEdge57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) '#');
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        java.util.TimeZone timeZone3 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeGridlinePaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot4.getDatasetRenderingOrder();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray23 = null;
        float[] floatArray24 = color22.getColorComponents(floatArray23);
        int int25 = color22.getRed();
        xYPlot4.setQuadrantPaint(0, (java.awt.Paint) color22);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot32.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        int int35 = xYPlot32.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Font font36 = numberAxis34.getLabelFont();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.axis.AxisState axisState38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        java.util.List list41 = numberAxis34.refreshTicks(graphics2D37, axisState38, rectangle2D39, rectangleEdge40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = numberAxis34.getTickLabelInsets();
        xYPlot4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis34);
        numberAxis34.setUpperMargin(8.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Font font13 = numberAxis11.getLabelFont();
        java.awt.Font font14 = numberAxis11.getTickLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font14);
        double double16 = categoryAxis0.getCategoryMargin();
        double double17 = categoryAxis0.getFixedDimension();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset((int) (short) 0);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getBlue();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        float[] floatArray8 = null;
        float[] floatArray9 = color0.getComponents(floatArray8);
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color0.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(paintContext15);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) ' ', (double) (short) 100, (double) (short) 1);
        double double5 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets4.createInsetRectangle(rectangle2D6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setWeight(0);
        int int23 = xYPlot4.getDatasetCount();
        int int24 = xYPlot4.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        java.awt.Stroke stroke22 = numberAxis6.getTickMarkStroke();
        boolean boolean23 = numberAxis6.isVisible();
        float float24 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setLabelToolTip("SortOrder.DESCENDING");
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) (-32384));
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int6 = day4.compareTo((java.lang.Object) color5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) regularTimePeriod7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = regularTimePeriod7.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Font font9 = numberAxis6.getTickLabelFont();
        try {
            numberAxis6.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        numberAxis6.setRangeWithMargins((double) 0.8f, (double) 10);
        java.awt.Color color25 = java.awt.Color.DARK_GRAY;
        numberAxis6.setAxisLinePaint((java.awt.Paint) color25);
        numberAxis6.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.lang.Comparable comparable2 = categoryMarker1.getKey();
        boolean boolean3 = categoryMarker1.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0L + "'", comparable2.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = null;
        try {
            xYPlot4.setInsets(rectangleInsets20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        numberAxis0.setRangeWithMargins((double) 3, 4.0d);
        numberAxis0.setLabelToolTip("TextAnchor.CENTER_RIGHT");
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis0.setLabelFont(font9);
        boolean boolean11 = numberAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        numberAxis0.setLabel("");
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateRange12);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot4.setRenderer((int) (short) 0, xYItemRenderer7, true);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Image image25 = null;
        xYPlot4.setBackgroundImage(image25);
        java.lang.String str27 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        try {
            xYPlot4.setRenderer((-8388608), xYItemRenderer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "XY Plot" + "'", str27.equals("XY Plot"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Font font13 = numberAxis11.getLabelFont();
        java.awt.Font font14 = numberAxis11.getTickLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font14);
        double double16 = categoryAxis0.getCategoryMargin();
        double double17 = categoryAxis0.getFixedDimension();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateTopOutset((double) (byte) -1);
        double double22 = rectangleInsets18.extendWidth(0.0d);
        double double23 = rectangleInsets18.getRight();
        double double25 = rectangleInsets18.trimHeight((double) 100L);
        categoryAxis0.setLabelInsets(rectangleInsets18);
        double double28 = rectangleInsets18.calculateTopInset((double) 1L);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Stroke[] strokeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) strokeArray1);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(strokeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double25 = rectangleInsets24.getTop();
        double double26 = rectangleInsets24.getLeft();
        boolean boolean27 = day23.equals((java.lang.Object) rectangleInsets24);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot32.setFixedRangeAxisSpace(axisSpace33);
        int int35 = day23.compareTo((java.lang.Object) xYPlot32);
        xYPlot32.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean41 = valueMarker39.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker39);
        org.jfree.chart.plot.Marker marker43 = markerChangeEvent42.getMarker();
        java.lang.Object obj44 = markerChangeEvent42.getSource();
        xYPlot32.markerChanged(markerChangeEvent42);
        java.awt.Image image46 = xYPlot32.getBackgroundImage();
        boolean boolean47 = dateAxis0.hasListener((java.util.EventListener) xYPlot32);
        java.util.TimeZone timeZone48 = dateAxis0.getTimeZone();
        dateAxis0.setTickLabelsVisible(true);
        dateAxis0.zoomRange((double) 0, 0.0d);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(marker43);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNull(image46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(timeZone48);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        numberAxis6.setRangeWithMargins((double) 0.8f, (double) 10);
        java.awt.Color color25 = java.awt.Color.DARK_GRAY;
        numberAxis6.setAxisLinePaint((java.awt.Paint) color25);
        java.awt.Stroke stroke27 = numberAxis6.getAxisLineStroke();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        java.awt.Stroke stroke18 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot4.setRenderer(xYItemRenderer19);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        try {
            boolean boolean22 = xYPlot4.removeAnnotation(xYAnnotation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color13, stroke14);
        xYPlot10.setDomainCrosshairStroke(stroke14);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = xYPlot10.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection17);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font22 = valueMarker21.getLabelFont();
        valueMarker21.setValue((double) (-1.0f));
        float float25 = valueMarker21.getAlpha();
        java.lang.Object obj26 = valueMarker21.clone();
        java.lang.String str27 = valueMarker21.getLabel();
        valueMarker21.setValue(0.0d);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, valueAxis32, xYItemRenderer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot34.zoomDomainAxes((double) 100, plotRenderingInfo36, point2D37, false);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        xYPlot34.setDataset((int) (short) 0, xYDataset41);
        xYPlot34.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot34.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset46 = xYPlot34.getDataset();
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset48, valueAxis49, valueAxis50, xYItemRenderer51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot52.zoomDomainAxes((double) 100, plotRenderingInfo54, point2D55, false);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        xYPlot52.setDataset((int) (short) 0, xYDataset59);
        xYPlot52.setRangeGridlinesVisible(false);
        xYPlot52.clearRangeAxes();
        java.lang.String str64 = xYPlot52.getPlotType();
        xYPlot52.configureRangeAxes();
        xYPlot52.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        java.awt.geom.Point2D point2D70 = null;
        xYPlot52.zoomDomainAxes((double) 5, plotRenderingInfo69, point2D70, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker74 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color75 = java.awt.Color.WHITE;
        int int76 = color75.getBlue();
        java.awt.image.ColorModel colorModel77 = null;
        java.awt.Rectangle rectangle78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color75.createContext(colorModel77, rectangle78, rectangle2D79, affineTransform80, renderingHints81);
        categoryMarker74.setOutlinePaint((java.awt.Paint) color75);
        java.awt.Paint paint84 = categoryMarker74.getPaint();
        org.jfree.chart.util.Layer layer85 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean86 = xYPlot52.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker74, layer85);
        java.util.Collection collection87 = xYPlot34.getRangeMarkers(0, layer85);
        boolean boolean89 = categoryPlot0.removeRangeMarker(64, (org.jfree.chart.plot.Marker) valueMarker21, layer85, true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.8f + "'", float25 == 0.8f);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNull(xYDataset46);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "XY Plot" + "'", str64.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 255 + "'", int76 == 255);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(layer85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNull(collection87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot4.zoomDomainAxes((double) 5, plotRenderingInfo21, point2D22, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color27 = java.awt.Color.WHITE;
        int int28 = color27.getBlue();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        categoryMarker26.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint36 = categoryMarker26.getPaint();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer37);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        numberAxis40.setAutoTickUnitSelection(true, false);
        numberAxis40.setRangeWithMargins((double) 3, 4.0d);
        numberAxis40.setPositiveArrowVisible(false);
        numberAxis40.setRangeAboutValue((double) 'a', (double) 255);
        xYPlot4.setDomainAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis40, false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        numberAxis0.setRangeWithMargins((double) 3, 4.0d);
        numberAxis0.setLabelToolTip("TextAnchor.CENTER_RIGHT");
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis0.setLabelFont(font9);
        boolean boolean11 = numberAxis0.isPositiveArrowVisible();
        java.lang.String str12 = numberAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint8 = categoryAxis7.getTickLabelPaint();
        try {
            categoryPlot0.setDomainAxis((-8388608), categoryAxis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, 0.2d, (double) 0L, (double) (byte) 10);
        double double7 = rectangleInsets5.calculateBottomInset((double) 100L);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        numberAxis11.setAutoRangeMinimumSize((double) 2.0f, false);
        double double16 = numberAxis11.getUpperMargin();
        java.awt.Shape shape17 = numberAxis11.getRightArrow();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font20 = valueMarker19.getLabelFont();
        java.awt.Font font21 = valueMarker19.getLabelFont();
        numberAxis11.setLabelFont(font21);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "SortOrder.DESCENDING", font21);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean30 = valueMarker28.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker28);
        org.jfree.chart.plot.Marker marker32 = markerChangeEvent31.getMarker();
        marker32.setAlpha((float) 0);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        marker32.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot39);
        int int41 = xYPlot39.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot39.setRangeAxes(valueAxisArray42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot39.getRangeAxisEdge(500);
        try {
            double double46 = categoryAxis0.getCategoryStart((int) (byte) -1, 500, rectangle2D26, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(marker32);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setDomainCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        float float22 = xYPlot4.getForegroundAlpha();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot4.setRenderer((int) (short) 10, xYItemRenderer24, false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = axisLocation19.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        boolean boolean16 = numberAxis6.getAutoRangeIncludesZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = numberAxis6.getStandardTickUnits();
        boolean boolean18 = numberAxis6.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot16.zoomDomainAxes((double) 100, plotRenderingInfo18, point2D19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot16.setDataset((int) (short) 0, xYDataset23);
        xYPlot16.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot16.getDomainAxis();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color31);
        xYPlot4.setDomainTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot4.zoomRangeAxes((double) (byte) 10, plotRenderingInfo35, point2D36, true);
        int int39 = xYPlot4.getSeriesCount();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot4.getRenderer((int) '#');
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(xYItemRenderer22);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot4.setOutlineStroke(stroke20);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (byte) -1);
        double double4 = rectangleInsets0.extendWidth(0.0d);
        double double5 = rectangleInsets0.getRight();
        double double7 = rectangleInsets0.trimHeight((double) 100L);
        double double9 = rectangleInsets0.calculateLeftOutset((double) 7);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        java.awt.Color color6 = java.awt.Color.getColor("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", color5);
        java.awt.Color color7 = java.awt.Color.DARK_GRAY;
        java.awt.Color color8 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        float[] floatArray13 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray14 = color7.getColorComponents(colorSpace9, floatArray13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray17 = null;
        float[] floatArray18 = color16.getColorComponents(floatArray17);
        float[] floatArray19 = null;
        float[] floatArray20 = color16.getRGBComponents(floatArray19);
        float[] floatArray21 = color15.getComponents(floatArray19);
        float[] floatArray22 = color6.getComponents(colorSpace9, floatArray21);
        float[] floatArray23 = color1.getColorComponents(colorSpace3, floatArray21);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }
}

