import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        int int3 = color2.getAlpha();
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray7 = null;
        float[] floatArray8 = color6.getColorComponents(floatArray7);
        float[] floatArray9 = color2.getColorComponents(colorSpace5, floatArray8);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setWeight(0);
        int int23 = xYPlot4.getDatasetCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 0);
        double double28 = intervalMarker27.getEndValue();
        org.jfree.chart.util.Layer layer29 = null;
        try {
            xYPlot4.addDomainMarker((-32384), (org.jfree.chart.plot.Marker) intervalMarker27, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getDomainAxisLocation(0);
        categoryPlot0.setDomainAxisLocation(255, axisLocation5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        int int10 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        try {
            categoryPlot0.zoom((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxis9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot22.zoomDomainAxes((double) 100, plotRenderingInfo24, point2D25, false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot22.setDataset((int) (short) 0, xYDataset29);
        xYPlot22.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot22.getDomainAxis();
        java.awt.Color color37 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot22.setRangeZeroBaselinePaint((java.awt.Paint) color37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot22.getRenderer((int) '#');
        int int41 = xYPlot22.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection42 = xYPlot22.getLegendItems();
        xYPlot4.setFixedLegendItems(legendItemCollection42);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNull(xYItemRenderer40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection42);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getRangeZeroBaselineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot11.zoomDomainAxes((double) 100, plotRenderingInfo13, point2D14, false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        xYPlot11.setDataset((int) (short) 0, xYDataset18);
        xYPlot11.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot11.getDomainAxis();
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot11.setRangeZeroBaselinePaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot11.getRenderer((int) '#');
        int int30 = xYPlot11.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = xYPlot11.getLegendItems();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font35 = valueMarker34.getLabelFont();
        valueMarker34.setValue((double) (-1.0f));
        float float38 = valueMarker34.getAlpha();
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double42 = rectangleInsets41.getTop();
        double double43 = rectangleInsets41.getLeft();
        boolean boolean44 = day40.equals((java.lang.Object) rectangleInsets41);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset45, valueAxis46, valueAxis47, xYItemRenderer48);
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        xYPlot49.setFixedRangeAxisSpace(axisSpace50);
        int int52 = day40.compareTo((java.lang.Object) xYPlot49);
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        xYPlot49.drawAnnotations(graphics2D53, rectangle2D54, plotRenderingInfo55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double59 = rectangleInsets57.calculateBottomInset((double) (byte) -1);
        double double60 = rectangleInsets57.getBottom();
        xYPlot49.setInsets(rectangleInsets57, true);
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset64, valueAxis65, valueAxis66, xYItemRenderer67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        java.awt.geom.Point2D point2D71 = null;
        xYPlot68.zoomDomainAxes((double) 100, plotRenderingInfo70, point2D71, false);
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        xYPlot68.setDataset((int) (short) 0, xYDataset75);
        xYPlot68.setRangeGridlinesVisible(false);
        xYPlot68.clearRangeAxes();
        int int80 = xYPlot68.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace81 = null;
        xYPlot68.setFixedDomainAxisSpace(axisSpace81);
        org.jfree.chart.axis.NumberAxis numberAxis83 = new org.jfree.chart.axis.NumberAxis();
        numberAxis83.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis87 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font88 = numberAxis87.getTickLabelFont();
        java.awt.Shape shape89 = numberAxis87.getUpArrow();
        numberAxis83.setDownArrow(shape89);
        org.jfree.data.Range range91 = xYPlot68.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis83);
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection93 = xYPlot68.getDomainMarkers(layer92);
        java.util.Collection collection94 = xYPlot49.getRangeMarkers(0, layer92);
        xYPlot11.addDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker34, layer92);
        java.util.Collection collection96 = xYPlot4.getRangeMarkers((-65536), layer92);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.8f + "'", float38 == 0.8f);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 8.0d + "'", double43 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(font88);
        org.junit.Assert.assertNotNull(shape89);
        org.junit.Assert.assertNull(range91);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertNull(collection93);
        org.junit.Assert.assertNull(collection94);
        org.junit.Assert.assertNull(collection96);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Paint paint6 = null;
        xYPlot4.setOutlinePaint(paint6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot9.getDomainAxis(4);
        java.awt.Color color13 = java.awt.Color.DARK_GRAY;
        java.awt.Color color14 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace15 = color14.getColorSpace();
        float[] floatArray19 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray20 = color13.getColorComponents(colorSpace15, floatArray19);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean24 = valueMarker22.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker22.setStroke(stroke25);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color13, stroke25);
        boolean boolean28 = xYPlot9.equals((java.lang.Object) categoryMarker27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot4.removeDomainMarker((-1), (org.jfree.chart.plot.Marker) categoryMarker27, layer29);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes(100.0d, plotRenderingInfo12, point2D13, true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot4.getDomainAxis((int) (short) 10);
        boolean boolean18 = xYPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font24 = numberAxis23.getTickLabelFont();
        java.awt.Shape shape25 = numberAxis23.getUpArrow();
        numberAxis19.setDownArrow(shape25);
        org.jfree.data.Range range27 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        numberAxis19.resizeRange(0.0d, 1.0E-8d);
        java.awt.Paint paint31 = numberAxis19.getTickLabelPaint();
        java.awt.Paint paint32 = numberAxis19.getLabelPaint();
        try {
            numberAxis19.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        boolean boolean21 = xYPlot4.isRangeGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color24 = java.awt.Color.WHITE;
        int int25 = color24.getBlue();
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color24.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        categoryMarker23.setOutlinePaint((java.awt.Paint) color24);
        java.awt.Paint paint33 = categoryMarker23.getPaint();
        java.awt.Color color34 = java.awt.Color.WHITE;
        int int35 = color34.getBlue();
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color34.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        categoryMarker23.setLabelPaint((java.awt.Paint) color34);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, valueAxis45, xYItemRenderer46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot47.zoomDomainAxes((double) 100, plotRenderingInfo49, point2D50, false);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot47.setDataset((int) (short) 0, xYDataset54);
        xYPlot47.setRangeGridlinesVisible(false);
        xYPlot47.clearRangeAxes();
        int int59 = xYPlot47.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        xYPlot47.setFixedDomainAxisSpace(axisSpace60);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis();
        numberAxis62.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font67 = numberAxis66.getTickLabelFont();
        java.awt.Shape shape68 = numberAxis66.getUpArrow();
        numberAxis62.setDownArrow(shape68);
        org.jfree.data.Range range70 = xYPlot47.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis62);
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection72 = xYPlot47.getDomainMarkers(layer71);
        boolean boolean73 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23, layer71);
        categoryMarker23.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        dateAxis0.setMaximumDate(date2);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        boolean boolean8 = dateAxis6.isAutoRange();
        java.util.Date date9 = dateAxis6.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat11 = dateAxis10.getDateFormatOverride();
        java.util.TimeZone timeZone12 = dateAxis10.getTimeZone();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date9, timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date2, timeZone12);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes(100.0d, plotRenderingInfo12, point2D13, true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoTickUnitSelection(true, false);
        int int20 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            xYPlot4.handleClick(5, (int) (short) 1, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double2 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.getRight();
        double double5 = rectangleInsets0.calculateRightOutset((double) 9);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        boolean boolean16 = numberAxis6.isPositiveArrowVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis6.getTickUnit();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer4);
        categoryAxis2.setTickMarkInsideLength((float) (short) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        xYPlot4.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = xYPlot4.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.clearCategoryLabelToolTips();
        categoryAxis25.setTickLabelsVisible(true);
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double33 = rectangleInsets32.getTop();
        double double34 = rectangleInsets32.getLeft();
        boolean boolean35 = day31.equals((java.lang.Object) rectangleInsets32);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        xYPlot40.setFixedRangeAxisSpace(axisSpace41);
        int int43 = day31.compareTo((java.lang.Object) xYPlot40);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        xYPlot40.drawAnnotations(graphics2D44, rectangle2D45, plotRenderingInfo46);
        java.awt.Paint paint48 = xYPlot40.getDomainCrosshairPaint();
        categoryAxis25.setTickLabelPaint((java.lang.Comparable) (-1L), paint48);
        xYPlot4.setRangeTickBandPaint(paint48);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 8.0d + "'", double34 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.configure();
        org.junit.Assert.assertNull(dateFormat2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font2 = valueMarker1.getLabelFont();
        valueMarker1.setValue((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = valueMarker1.getLabelOffset();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean9 = valueMarker7.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker7.setLabelOffset(rectangleInsets10);
        java.awt.Stroke stroke12 = valueMarker7.getOutlineStroke();
        valueMarker1.setOutlineStroke(stroke12);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj20 = null;
        boolean boolean21 = axisLocation19.equals(obj20);
        xYPlot4.setDomainAxisLocation(axisLocation19, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace24, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color28, stroke29);
        categoryMarker30.setKey((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        xYPlot37.zoomDomainAxes((double) 100, plotRenderingInfo39, point2D40, false);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        xYPlot37.setDataset((int) (short) 0, xYDataset44);
        xYPlot37.setRangeGridlinesVisible(false);
        xYPlot37.clearRangeAxes();
        java.lang.String str49 = xYPlot37.getPlotType();
        xYPlot37.configureRangeAxes();
        xYPlot37.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot37.zoomDomainAxes((double) 5, plotRenderingInfo54, point2D55, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color60 = java.awt.Color.WHITE;
        int int61 = color60.getBlue();
        java.awt.image.ColorModel colorModel62 = null;
        java.awt.Rectangle rectangle63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        java.awt.geom.AffineTransform affineTransform65 = null;
        java.awt.RenderingHints renderingHints66 = null;
        java.awt.PaintContext paintContext67 = color60.createContext(colorModel62, rectangle63, rectangle2D64, affineTransform65, renderingHints66);
        categoryMarker59.setOutlinePaint((java.awt.Paint) color60);
        java.awt.Paint paint69 = categoryMarker59.getPaint();
        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean71 = xYPlot37.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker59, layer70);
        boolean boolean72 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30, layer70);
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer76 = null;
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot(xYDataset73, valueAxis74, valueAxis75, xYItemRenderer76);
        org.jfree.chart.axis.AxisLocation axisLocation78 = xYPlot77.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis();
        int int80 = xYPlot77.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis79);
        numberAxis79.setAutoRangeMinimumSize((double) 2.0f, false);
        double double84 = numberAxis79.getUpperMargin();
        java.awt.Shape shape85 = numberAxis79.getRightArrow();
        org.jfree.chart.plot.ValueMarker valueMarker87 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font88 = valueMarker87.getLabelFont();
        java.awt.Font font89 = valueMarker87.getLabelFont();
        numberAxis79.setLabelFont(font89);
        numberAxis79.setAutoRangeMinimumSize((double) 10.0f);
        xYPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis79);
        org.jfree.chart.util.RectangleEdge rectangleEdge94 = xYPlot4.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "XY Plot" + "'", str49.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 255 + "'", int61 == 255);
        org.junit.Assert.assertNotNull(paintContext67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(layer70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(axisLocation78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.05d + "'", double84 == 0.05d);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(font88);
        org.junit.Assert.assertNotNull(font89);
        org.junit.Assert.assertNotNull(rectangleEdge94);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot10.zoomDomainAxes((double) 100, plotRenderingInfo12, point2D13, false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot10.setDataset((int) (short) 0, xYDataset17);
        xYPlot10.setRangeGridlinesVisible(false);
        xYPlot10.clearRangeAxes();
        java.lang.String str22 = xYPlot10.getPlotType();
        xYPlot10.configureRangeAxes();
        xYPlot10.setOutlineVisible(false);
        java.awt.Stroke stroke26 = xYPlot10.getRangeCrosshairStroke();
        xYPlot10.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot10.getRangeAxisLocation(7);
        categoryPlot5.setDomainAxisLocation(axisLocation30, false);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot5.getDomainAxisLocation(13);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        dateAxis0.zoomRange(10.0d, (double) 100L);
        java.util.Date date25 = dateAxis0.getMaximumDate();
        dateAxis0.setUpperMargin((double) (-32384));
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        boolean boolean16 = numberAxis6.getAutoRangeIncludesZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = numberAxis6.getStandardTickUnits();
        numberAxis6.setTickMarksVisible(false);
        org.jfree.data.Range range20 = numberAxis6.getRange();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setDomainCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = xYPlot4.getOrientation();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(plotOrientation22);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean19 = valueMarker17.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        xYPlot10.markerChanged(markerChangeEvent20);
        xYPlot10.setWeight((int) (short) 10);
        xYPlot10.clearAnnotations();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace23, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        int int27 = xYPlot4.getIndexOf(xYItemRenderer26);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setRangeAxisLocation(10, axisLocation18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font23 = valueMarker22.getLabelFont();
        java.awt.Font font24 = valueMarker22.getLabelFont();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot29.setDataset((int) (short) 0, xYDataset36);
        xYPlot29.setRangeGridlinesVisible(false);
        xYPlot29.clearRangeAxes();
        java.lang.String str41 = xYPlot29.getPlotType();
        xYPlot29.configureRangeAxes();
        xYPlot29.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot29.zoomDomainAxes((double) 5, plotRenderingInfo46, point2D47, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color52 = java.awt.Color.WHITE;
        int int53 = color52.getBlue();
        java.awt.image.ColorModel colorModel54 = null;
        java.awt.Rectangle rectangle55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = color52.createContext(colorModel54, rectangle55, rectangle2D56, affineTransform57, renderingHints58);
        categoryMarker51.setOutlinePaint((java.awt.Paint) color52);
        java.awt.Paint paint61 = categoryMarker51.getPaint();
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean63 = xYPlot29.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker51, layer62);
        xYPlot4.addRangeMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker22, layer62);
        boolean boolean65 = xYPlot4.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "XY Plot" + "'", str41.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 255 + "'", int53 == 255);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomInset((double) (byte) -1);
        double double21 = rectangleInsets18.getBottom();
        xYPlot10.setInsets(rectangleInsets18, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot29.setDataset((int) (short) 0, xYDataset36);
        xYPlot29.setRangeGridlinesVisible(false);
        xYPlot29.clearRangeAxes();
        int int41 = xYPlot29.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        xYPlot29.setFixedDomainAxisSpace(axisSpace42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font49 = numberAxis48.getTickLabelFont();
        java.awt.Shape shape50 = numberAxis48.getUpArrow();
        numberAxis44.setDownArrow(shape50);
        org.jfree.data.Range range52 = xYPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis44);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection54 = xYPlot29.getDomainMarkers(layer53);
        java.util.Collection collection55 = xYPlot10.getRangeMarkers(0, layer53);
        xYPlot10.mapDatasetToRangeAxis((int) (short) 1, (int) (short) -1);
        java.awt.Font font59 = xYPlot10.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.setDomainCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot4.getDomainAxisLocation(5);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color8 = java.awt.Color.WHITE;
        int int9 = color8.getBlue();
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color8.createContext(colorModel10, rectangle11, rectangle2D12, affineTransform13, renderingHints14);
        categoryMarker7.setOutlinePaint((java.awt.Paint) color8);
        java.awt.Paint paint17 = categoryMarker7.getPaint();
        boolean boolean18 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker7);
        java.util.List list19 = xYPlot4.getAnnotations();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = xYPlot4.getInsets();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(paintContext15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            org.jfree.chart.axis.AxisState axisState20 = numberAxis6.draw(graphics2D14, 0.0d, rectangle2D16, rectangle2D17, rectangleEdge18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Font font13 = numberAxis11.getLabelFont();
        java.awt.Font font14 = numberAxis11.getTickLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes((double) 100, plotRenderingInfo25, point2D26, false);
        xYPlot23.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        xYPlot23.setRangeAxis(1, valueAxis31, false);
        java.awt.Color color34 = java.awt.Color.red;
        xYPlot23.setRangeTickBandPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot23.getDomainAxisEdge(500);
        try {
            double double38 = categoryAxis0.getCategoryMiddle(3, (int) ' ', rectangle2D18, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairVisible(false);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot0.getDomainAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot19.zoomDomainAxes((double) 100, plotRenderingInfo21, point2D22, false);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset((int) (short) 0, xYDataset26);
        xYPlot19.setRangeGridlinesVisible(false);
        xYPlot19.clearRangeAxes();
        java.lang.String str31 = xYPlot19.getPlotType();
        xYPlot19.configureRangeAxes();
        xYPlot19.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot19.zoomDomainAxes((double) 5, plotRenderingInfo36, point2D37, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color42 = java.awt.Color.WHITE;
        int int43 = color42.getBlue();
        java.awt.image.ColorModel colorModel44 = null;
        java.awt.Rectangle rectangle45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.geom.AffineTransform affineTransform47 = null;
        java.awt.RenderingHints renderingHints48 = null;
        java.awt.PaintContext paintContext49 = color42.createContext(colorModel44, rectangle45, rectangle2D46, affineTransform47, renderingHints48);
        categoryMarker41.setOutlinePaint((java.awt.Paint) color42);
        java.awt.Paint paint51 = categoryMarker41.getPaint();
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean53 = xYPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker41, layer52);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset54, valueAxis55, valueAxis56, xYItemRenderer57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.awt.geom.Point2D point2D61 = null;
        xYPlot58.zoomDomainAxes((double) 100, plotRenderingInfo60, point2D61, false);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        xYPlot58.setDataset((int) (short) 0, xYDataset65);
        xYPlot58.setRangeGridlinesVisible(false);
        xYPlot58.clearRangeAxes();
        java.lang.String str70 = xYPlot58.getPlotType();
        xYPlot58.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = xYPlot58.getAxisOffset();
        categoryMarker41.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot58);
        java.awt.Paint paint74 = categoryMarker41.getOutlinePaint();
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean76 = categoryPlot0.removeDomainMarker((-65536), (org.jfree.chart.plot.Marker) categoryMarker41, layer75);
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone78 = dateAxis77.getTimeZone();
        boolean boolean79 = dateAxis77.isAutoRange();
        java.util.Date date80 = dateAxis77.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat82 = dateAxis81.getDateFormatOverride();
        java.util.TimeZone timeZone83 = dateAxis81.getTimeZone();
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date80, timeZone83);
        categoryMarker41.setKey((java.lang.Comparable) date80);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "XY Plot" + "'", str31.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertNotNull(paintContext49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "XY Plot" + "'", str70.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNull(dateFormat82);
        org.junit.Assert.assertNotNull(timeZone83);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Font font13 = numberAxis11.getLabelFont();
        java.awt.Font font14 = numberAxis11.getTickLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font14);
        double double16 = categoryAxis0.getCategoryMargin();
        double double17 = categoryAxis0.getFixedDimension();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateTopOutset((double) (byte) -1);
        double double22 = rectangleInsets18.extendWidth(0.0d);
        double double23 = rectangleInsets18.getRight();
        double double25 = rectangleInsets18.trimHeight((double) 100L);
        categoryAxis0.setLabelInsets(rectangleInsets18);
        double double28 = rectangleInsets18.trimWidth((double) 0.8f);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.800000011920929d + "'", double28 == 0.800000011920929d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        boolean boolean19 = xYPlot10.isRangeZoomable();
        java.awt.Paint paint20 = xYPlot10.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) (-32384));
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int6 = day4.compareTo((java.lang.Object) color5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) regularTimePeriod7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        java.util.Date date2 = dateAxis0.getMinimumDate();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart3);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        int int2 = objectList1.size();
        objectList1.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomInset((double) (byte) -1);
        double double21 = rectangleInsets18.getBottom();
        xYPlot10.setInsets(rectangleInsets18, true);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets18.createOutsetRectangle(rectangle2D24, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        xYPlot4.configureDomainAxes();
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets12.getTop();
        double double14 = rectangleInsets12.getLeft();
        boolean boolean15 = day11.equals((java.lang.Object) rectangleInsets12);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot20.setFixedRangeAxisSpace(axisSpace21);
        int int23 = day11.compareTo((java.lang.Object) xYPlot20);
        xYPlot20.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean29 = valueMarker27.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker27);
        org.jfree.chart.plot.Marker marker31 = markerChangeEvent30.getMarker();
        java.lang.Object obj32 = markerChangeEvent30.getSource();
        xYPlot20.markerChanged(markerChangeEvent30);
        java.awt.Image image34 = xYPlot20.getBackgroundImage();
        java.awt.Image image35 = null;
        xYPlot20.setBackgroundImage(image35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = xYPlot20.getInsets();
        categoryPlot0.setAxisOffset(rectangleInsets37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(marker31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = xYPlot10.getDatasetRenderingOrder();
        boolean boolean22 = xYPlot10.isRangeZoomable();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot4.getFixedDomainAxisSpace();
        xYPlot4.configureRangeAxes();
        boolean boolean20 = xYPlot4.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getDomainAxis(4);
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        xYPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot0.zoomDomainAxes((double) 4, plotRenderingInfo6, point2D7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot13.zoomDomainAxes((double) 100, plotRenderingInfo15, point2D16, false);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot13.setDataset((int) (short) 0, xYDataset20);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot13.getDomainAxis();
        java.awt.Color color28 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot13.setRangeZeroBaselinePaint((java.awt.Paint) color28);
        xYPlot0.setOutlinePaint((java.awt.Paint) color28);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Paint paint15 = xYPlot4.getRangeGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot20.zoomDomainAxes((double) 100, plotRenderingInfo22, point2D23, false);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset((int) (short) 0, xYDataset27);
        xYPlot20.setRangeGridlinesVisible(false);
        xYPlot20.clearRangeAxes();
        java.lang.String str32 = xYPlot20.getPlotType();
        xYPlot20.configureRangeAxes();
        xYPlot20.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = xYPlot20.getDatasetRenderingOrder();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray39 = null;
        float[] floatArray40 = color38.getColorComponents(floatArray39);
        int int41 = color38.getRed();
        xYPlot20.setQuadrantPaint(0, (java.awt.Paint) color38);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset44, valueAxis45, valueAxis46, xYItemRenderer47);
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot48.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        int int51 = xYPlot48.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis50);
        java.awt.Font font52 = numberAxis50.getLabelFont();
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.axis.AxisState axisState54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        java.util.List list57 = numberAxis50.refreshTicks(graphics2D53, axisState54, rectangle2D55, rectangleEdge56);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = numberAxis50.getTickLabelInsets();
        xYPlot20.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis50);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset61, valueAxis62, valueAxis63, xYItemRenderer64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Point2D point2D68 = null;
        xYPlot65.zoomDomainAxes((double) 100, plotRenderingInfo67, point2D68, false);
        org.jfree.data.xy.XYDataset xYDataset72 = null;
        xYPlot65.setDataset((int) (short) 0, xYDataset72);
        xYPlot65.setRangeGridlinesVisible(false);
        xYPlot65.clearRangeAxes();
        int int77 = xYPlot65.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot65.setRangeAxisLocation(10, axisLocation79);
        org.jfree.chart.axis.AxisLocation axisLocation81 = axisLocation79.getOpposite();
        xYPlot20.setRangeAxisLocation(12, axisLocation81);
        xYPlot4.setDomainAxisLocation(axisLocation81);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "XY Plot" + "'", str32.equals("XY Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 255 + "'", int41 == 255);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(axisLocation81);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        boolean boolean16 = xYPlot4.isRangeGridlinesVisible();
        java.awt.Paint paint17 = xYPlot4.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        xYPlot4.setRangeCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes((double) 100, plotRenderingInfo25, point2D26, false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot23.setDataset((int) (short) 0, xYDataset30);
        xYPlot23.setRangeGridlinesVisible(false);
        xYPlot23.clearRangeAxes();
        java.lang.String str35 = xYPlot23.getPlotType();
        xYPlot23.configureRangeAxes();
        xYPlot23.setOutlineVisible(false);
        java.awt.Stroke stroke39 = xYPlot23.getRangeCrosshairStroke();
        xYPlot4.setRangeGridlineStroke(stroke39);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "XY Plot" + "'", str35.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        numberAxis11.setAutoRangeMinimumSize((double) 2.0f, false);
        double double16 = numberAxis11.getUpperMargin();
        java.awt.Shape shape17 = numberAxis11.getRightArrow();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font20 = valueMarker19.getLabelFont();
        java.awt.Font font21 = valueMarker19.getLabelFont();
        numberAxis11.setLabelFont(font21);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "SortOrder.DESCENDING", font21);
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double27 = rectangleInsets26.getTop();
        double double28 = rectangleInsets26.getLeft();
        boolean boolean29 = day25.equals((java.lang.Object) rectangleInsets26);
        java.lang.String str30 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) boolean29);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 8.0d + "'", double28 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        categoryPlot32.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        xYPlot39.zoomDomainAxes((double) 100, plotRenderingInfo41, point2D42, false);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        xYPlot39.setDataset((int) (short) 0, xYDataset46);
        xYPlot39.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot39.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset51 = xYPlot39.getDataset();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset53, valueAxis54, valueAxis55, xYItemRenderer56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        xYPlot57.zoomDomainAxes((double) 100, plotRenderingInfo59, point2D60, false);
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        xYPlot57.setDataset((int) (short) 0, xYDataset64);
        xYPlot57.setRangeGridlinesVisible(false);
        xYPlot57.clearRangeAxes();
        java.lang.String str69 = xYPlot57.getPlotType();
        xYPlot57.configureRangeAxes();
        xYPlot57.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        java.awt.geom.Point2D point2D75 = null;
        xYPlot57.zoomDomainAxes((double) 5, plotRenderingInfo74, point2D75, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color80 = java.awt.Color.WHITE;
        int int81 = color80.getBlue();
        java.awt.image.ColorModel colorModel82 = null;
        java.awt.Rectangle rectangle83 = null;
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        java.awt.geom.AffineTransform affineTransform85 = null;
        java.awt.RenderingHints renderingHints86 = null;
        java.awt.PaintContext paintContext87 = color80.createContext(colorModel82, rectangle83, rectangle2D84, affineTransform85, renderingHints86);
        categoryMarker79.setOutlinePaint((java.awt.Paint) color80);
        java.awt.Paint paint89 = categoryMarker79.getPaint();
        org.jfree.chart.util.Layer layer90 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean91 = xYPlot57.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker79, layer90);
        java.util.Collection collection92 = xYPlot39.getRangeMarkers(0, layer90);
        java.util.Collection collection93 = categoryPlot32.getDomainMarkers(layer90);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(valueAxis50);
        org.junit.Assert.assertNull(xYDataset51);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "XY Plot" + "'", str69.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 255 + "'", int81 == 255);
        org.junit.Assert.assertNotNull(paintContext87);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(layer90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(collection92);
        org.junit.Assert.assertNull(collection93);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis7.getTickLabelInsets();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range16);
        dateAxis0.setRange(range16, true, true);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis0.java2DToValue(0.05d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat26 = dateAxis25.getDateFormatOverride();
        java.util.TimeZone timeZone27 = dateAxis25.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone27);
        dateAxis0.setTimeZone(timeZone27);
        boolean boolean31 = dateAxis0.isHiddenValue((long) 3);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.223372036854776E18d + "'", double24 == 9.223372036854776E18d);
        org.junit.Assert.assertNull(dateFormat26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot7.zoomDomainAxes((double) 100, plotRenderingInfo9, point2D10, false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot7.setDataset((int) (short) 0, xYDataset14);
        xYPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot7.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot7.getDataset();
        objectList0.set((int) (byte) 1, (java.lang.Object) xYDataset19);
        java.lang.Object obj22 = objectList0.get((int) (byte) 1);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(obj22);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setKey((java.lang.Comparable) 100L);
        java.awt.Paint paint6 = categoryMarker3.getOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        dateAxis0.zoomRange(10.0d, (double) 100L);
        float float25 = dateAxis0.getTickMarkInsideLength();
        boolean boolean26 = dateAxis0.isAutoRange();
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray2);
        int int4 = objectList0.indexOf((java.lang.Object) paintArray2);
        java.lang.Object obj6 = objectList0.get((int) ' ');
        java.lang.Object obj7 = objectList0.clone();
        java.lang.Object obj8 = objectList0.clone();
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = plotOrientation0.equals(obj2);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setDomainCrosshairVisible(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot4);
        java.awt.Stroke stroke24 = xYPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double6 = rectangleInsets5.getTop();
        double double7 = rectangleInsets5.getLeft();
        boolean boolean8 = day4.equals((java.lang.Object) rectangleInsets5);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace14);
        int int16 = day4.compareTo((java.lang.Object) xYPlot13);
        java.awt.Paint paint17 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) day4);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getColorComponents(floatArray22);
        float[] floatArray24 = null;
        float[] floatArray25 = color21.getRGBComponents(floatArray24);
        float[] floatArray26 = java.awt.Color.RGBtoHSB(0, (int) (byte) -1, (int) (short) 1, floatArray25);
        boolean boolean27 = categoryAxis0.equals((java.lang.Object) floatArray26);
        java.lang.Object obj28 = categoryAxis0.clone();
        java.awt.Paint paint29 = categoryAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        xYPlot4.axisChanged(axisChangeEvent11);
        float float13 = xYPlot4.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        double double2 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes(100.0d, plotRenderingInfo12, point2D13, true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.addChangeListener(plotChangeListener16);
        java.awt.Paint paint18 = null;
        try {
            xYPlot4.setRangeZeroBaselinePaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairVisible(false);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color13 = color12.darker();
        int int14 = color12.getGreen();
        boolean boolean15 = categoryPlot0.equals((java.lang.Object) int14);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 0);
        double double3 = intervalMarker2.getStartValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean6 = rectangleAnchor4.equals((java.lang.Object) 100L);
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) 100L);
        java.lang.Object obj8 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray7 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray8 = color1.getColorComponents(colorSpace3, floatArray7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean12 = valueMarker10.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker10.setStroke(stroke13);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color1, stroke13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        categoryMarker15.setLabelAnchor(rectangleAnchor16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setDomainCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        xYPlot4.setForegroundAlpha(2.0f);
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double27 = rectangleInsets26.getTop();
        double double28 = rectangleInsets26.getLeft();
        boolean boolean29 = day25.equals((java.lang.Object) rectangleInsets26);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, valueAxis32, xYItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot34.setFixedRangeAxisSpace(axisSpace35);
        int int37 = day25.compareTo((java.lang.Object) xYPlot34);
        xYPlot34.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean43 = valueMarker41.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker41);
        org.jfree.chart.plot.Marker marker45 = markerChangeEvent44.getMarker();
        java.lang.Object obj46 = markerChangeEvent44.getSource();
        xYPlot34.markerChanged(markerChangeEvent44);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot34.getDomainAxisLocation();
        xYPlot4.setDomainAxisLocation(axisLocation48);
        java.awt.Paint paint50 = null;
        try {
            xYPlot4.setDomainCrosshairPaint(paint50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 8.0d + "'", double28 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(marker45);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(axisLocation48);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot20.getRangeAxisLocation();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color23, stroke24);
        xYPlot20.setDomainCrosshairStroke(stroke24);
        numberAxis6.setAxisLineStroke(stroke24);
        java.awt.Paint paint28 = numberAxis6.getAxisLinePaint();
        boolean boolean29 = numberAxis6.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        categoryMarker1.setOutlinePaint((java.awt.Paint) color2);
        int int11 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        numberAxis6.setRangeWithMargins((double) (-32384), 0.2d);
        numberAxis6.setAutoRangeIncludesZero(false);
        double double23 = numberAxis6.getFixedAutoRange();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        int int19 = xYPlot10.getDatasetCount();
        boolean boolean20 = xYPlot10.isRangeCrosshairVisible();
        boolean boolean21 = xYPlot10.isDomainZoomable();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        int int3 = day1.compareTo((java.lang.Object) color2);
//        long long4 = day1.getMiddleMillisecond();
//        int int5 = day1.getDayOfMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day1.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1);
        java.lang.String str6 = chartChangeEvent5.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        int int2 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        java.util.TimeZone timeZone8 = dateAxis6.getTimeZone();
        dateAxis0.setTimeZone(timeZone8);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit10, false, false);
        boolean boolean15 = dateAxis0.isHiddenValue(0L);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot4.zoomDomainAxes((double) 5, plotRenderingInfo21, point2D22, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color27 = java.awt.Color.WHITE;
        int int28 = color27.getBlue();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        categoryMarker26.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint36 = categoryMarker26.getPaint();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer37);
        org.jfree.chart.text.TextAnchor textAnchor39 = categoryMarker26.getLabelTextAnchor();
        java.lang.Comparable comparable40 = categoryMarker26.getKey();
        java.awt.Color color42 = java.awt.Color.DARK_GRAY;
        java.awt.Color color43 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace44 = color43.getColorSpace();
        float[] floatArray48 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray49 = color42.getColorComponents(colorSpace44, floatArray48);
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean53 = valueMarker51.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker51.setStroke(stroke54);
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color42, stroke54);
        java.awt.Color color57 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color58 = java.awt.Color.BLACK;
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray60 = null;
        float[] floatArray61 = color59.getColorComponents(floatArray60);
        float[] floatArray62 = null;
        float[] floatArray63 = color59.getRGBComponents(floatArray62);
        float[] floatArray64 = color58.getComponents(floatArray62);
        float[] floatArray65 = color57.getComponents(floatArray62);
        float[] floatArray66 = color42.getColorComponents(floatArray65);
        categoryMarker26.setPaint((java.awt.Paint) color42);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + 0L + "'", comparable40.equals(0L));
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(colorSpace44);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot4.getAxisOffset();
        double double17 = rectangleInsets15.extendHeight((double) 'a');
        double double19 = rectangleInsets15.extendHeight(2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 105.0d + "'", double17 == 105.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int3 = day1.compareTo((java.lang.Object) color2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        boolean boolean6 = dateAxis4.isAutoRange();
        java.util.Date date7 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat9 = dateAxis8.getDateFormatOverride();
        java.util.TimeZone timeZone10 = dateAxis8.getTimeZone();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7, timeZone10);
        int int12 = day1.compareTo((java.lang.Object) date7);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot4.getRenderer((int) '#');
        int int23 = xYPlot4.getDatasetCount();
        int int24 = xYPlot4.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot29.setDataset((int) (short) 0, xYDataset36);
        xYPlot29.setRangeGridlinesVisible(false);
        xYPlot29.clearRangeAxes();
        java.lang.String str41 = xYPlot29.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray42 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot29.setRenderers(xYItemRendererArray42);
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj45 = null;
        boolean boolean46 = axisLocation44.equals(obj45);
        xYPlot29.setDomainAxisLocation(axisLocation44, true);
        xYPlot4.setRangeAxisLocation(axisLocation44, true);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "XY Plot" + "'", str41.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray42);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent4.getMarker();
        marker5.setAlpha((float) 0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        marker5.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot12);
        int int14 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot12.setRangeAxes(valueAxisArray15);
        xYPlot12.clearDomainMarkers(4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) '4');
        double double4 = rectangleInsets0.extendWidth((double) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 26.0d + "'", double4 == 26.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets12.getTop();
        double double14 = rectangleInsets12.getLeft();
        boolean boolean15 = day11.equals((java.lang.Object) rectangleInsets12);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot20.setFixedRangeAxisSpace(axisSpace21);
        int int23 = day11.compareTo((java.lang.Object) xYPlot20);
        xYPlot20.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean29 = valueMarker27.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker27);
        org.jfree.chart.plot.Marker marker31 = markerChangeEvent30.getMarker();
        java.lang.Object obj32 = markerChangeEvent30.getSource();
        xYPlot20.markerChanged(markerChangeEvent30);
        java.awt.Image image34 = xYPlot20.getBackgroundImage();
        java.awt.Image image35 = null;
        xYPlot20.setBackgroundImage(image35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = xYPlot20.getInsets();
        categoryPlot0.setAxisOffset(rectangleInsets37);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets37.createInsetRectangle(rectangle2D39, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(marker31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        java.awt.Stroke stroke22 = numberAxis6.getTickMarkStroke();
        boolean boolean23 = numberAxis6.isVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat25 = dateAxis24.getDateFormatOverride();
        java.util.TimeZone timeZone26 = dateAxis24.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone26);
        numberAxis6.setStandardTickUnits(tickUnitSource27);
        java.awt.Shape shape29 = numberAxis6.getRightArrow();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(dateFormat25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis4.clearCategoryLabelToolTips();
//        categoryAxis4.setTickLabelsVisible(true);
//        categoryPlot3.setDomainAxis(categoryAxis4);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
//        categoryPlot3.rendererChanged(rendererChangeEvent9);
//        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot3.getRangeAxisForDataset((int) (byte) 0);
//        boolean boolean13 = day0.equals((java.lang.Object) (byte) 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNull(valueAxis12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font24 = numberAxis23.getTickLabelFont();
        java.awt.Shape shape25 = numberAxis23.getUpArrow();
        numberAxis19.setDownArrow(shape25);
        org.jfree.data.Range range27 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        xYPlot4.setDomainCrosshairValue((double) 2.0f);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray2);
        int int4 = objectList0.indexOf((java.lang.Object) paintArray2);
        java.lang.Object obj6 = objectList0.get((int) ' ');
        java.lang.Object obj7 = objectList0.clone();
        objectList0.clear();
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot4.rendererChanged(rendererChangeEvent8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = xYPlot4.getDatasetGroup();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline15 = dateAxis14.getTimeline();
        boolean boolean16 = layer13.equals((java.lang.Object) timeline15);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12, layer13);
        xYPlot4.mapDatasetToRangeAxis(12, (int) (short) 100);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertNotNull(timeline15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryMargin((double) (-32384));
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int7 = day5.compareTo((java.lang.Object) color6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        java.awt.Paint paint9 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) regularTimePeriod8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setMaximumCategoryLabelLines(1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        double double14 = categoryAxis13.getUpperMargin();
        int int15 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis13.getCategoryLabelPositions();
        categoryAxis10.setCategoryLabelPositions(categoryLabelPositions16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot27.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        int int30 = xYPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis29);
        java.awt.Font font31 = numberAxis29.getLabelFont();
        java.awt.Font font32 = numberAxis29.getTickLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 3, font32);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray34 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis1, categoryAxis10, categoryAxis18 };
        categoryPlot0.setDomainAxes(categoryAxisArray34);
        int int36 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot0.zoomRangeAxes((double) 100L, plotRenderingInfo38, point2D39);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(categoryAxisArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        boolean boolean2 = dateAxis0.isAutoRange();
        java.util.Date date3 = dateAxis0.getMinimumDate();
        java.util.TimeZone timeZone4 = null;
        try {
            dateAxis0.setTimeZone(timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getDomainAxisLocation(0);
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets16.getTop();
        double double18 = rectangleInsets16.getLeft();
        boolean boolean19 = day15.equals((java.lang.Object) rectangleInsets16);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        xYPlot24.setFixedRangeAxisSpace(axisSpace25);
        int int27 = day15.compareTo((java.lang.Object) xYPlot24);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot24.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean34 = axisLocation32.equals((java.lang.Object) lengthAdjustmentType33);
        xYPlot24.setRangeAxisLocation(axisLocation32);
        xYPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset39, valueAxis40, valueAxis41, xYItemRenderer42);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot43.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        int int46 = xYPlot43.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis45);
        java.awt.Font font47 = numberAxis45.getLabelFont();
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.axis.AxisState axisState49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        java.util.List list52 = numberAxis45.refreshTicks(graphics2D48, axisState49, rectangle2D50, rectangleEdge51);
        java.awt.Paint paint53 = numberAxis45.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource54 = numberAxis45.getStandardTickUnits();
        boolean boolean55 = numberAxis45.isPositiveArrowVisible();
        xYPlot24.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis45, false);
        categoryPlot10.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis45, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = categoryPlot10.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis61.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font66 = categoryAxis61.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.lang.String str67 = categoryAxis61.getLabelToolTip();
        int int68 = categoryPlot10.getDomainAxisIndex(categoryAxis61);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = categoryPlot10.getDomainAxisEdge((-8388608));
        try {
            double double71 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 2.0f, (java.lang.Comparable) regularTimePeriod6, categoryDataset7, (double) 5, rectangle2D9, rectangleEdge70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(tickUnitSource54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(categoryItemRenderer60);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis7.getTickLabelInsets();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range16);
        dateAxis0.setRange(range16, true, true);
        boolean boolean21 = dateAxis0.isAutoRange();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot26.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        int int29 = xYPlot26.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, valueAxis32, xYItemRenderer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot34.zoomDomainAxes((double) 100, plotRenderingInfo36, point2D37, false);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        xYPlot34.setDataset((int) (short) 0, xYDataset41);
        xYPlot34.setRangeGridlinesVisible(false);
        xYPlot34.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        xYPlot34.removeChangeListener(plotChangeListener46);
        xYPlot34.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset50, valueAxis51, valueAxis52, xYItemRenderer53);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot54.getRangeAxisLocation();
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color57, stroke58);
        xYPlot54.setDomainCrosshairStroke(stroke58);
        xYPlot34.setRangeCrosshairStroke(stroke58);
        boolean boolean62 = xYPlot26.equals((java.lang.Object) xYPlot34);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot26);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation(0);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getLeft();
        boolean boolean9 = day5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace15);
        int int17 = day5.compareTo((java.lang.Object) xYPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot14.drawAnnotations(graphics2D18, rectangle2D19, plotRenderingInfo20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) lengthAdjustmentType23);
        xYPlot14.setRangeAxisLocation(axisLocation22);
        xYPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot33.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        int int36 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Font font37 = numberAxis35.getLabelFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis35.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis35.getStandardTickUnits();
        boolean boolean45 = numberAxis35.isPositiveArrowVisible();
        xYPlot14.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str51 = layer50.toString();
        java.util.Collection collection52 = categoryPlot0.getRangeMarkers(layer50);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Layer.FOREGROUND" + "'", str51.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        java.awt.Shape shape2 = numberAxis0.getUpArrow();
        boolean boolean3 = numberAxis0.isVerticalTickLabels();
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis0.setTickLabelFont(font4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis0.getTickLabelInsets();
        numberAxis0.setLabelToolTip("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER_RIGHT");
        java.awt.Color color2 = java.awt.Color.CYAN;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot11.zoomDomainAxes((double) 100, plotRenderingInfo13, point2D14, false);
        xYPlot11.clearAnnotations();
        xYPlot11.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color22 = java.awt.Color.WHITE;
        int int23 = color22.getBlue();
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color22.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        categoryMarker21.setOutlinePaint((java.awt.Paint) color22);
        xYPlot11.setNoDataMessagePaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot11.getDomainAxisEdge((int) (byte) 10);
        try {
            java.util.List list34 = dateAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        numberAxis6.setTickMarksVisible(true);
        boolean boolean24 = numberAxis6.getAutoRangeIncludesZero();
        boolean boolean25 = numberAxis6.isInverted();
        org.jfree.data.Range range26 = numberAxis6.getRange();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
//        org.jfree.data.xy.XYDataset xYDataset2 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
//        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
//        java.awt.geom.Point2D point2D9 = null;
//        xYPlot6.zoomDomainAxes((double) 100, plotRenderingInfo8, point2D9, false);
//        org.jfree.data.xy.XYDataset xYDataset13 = null;
//        xYPlot6.setDataset((int) (short) 0, xYDataset13);
//        xYPlot6.setRangeGridlinesVisible(false);
//        xYPlot6.clearRangeAxes();
//        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
//        xYPlot6.setRangeAxis(valueAxis18);
//        objectList0.set(1, (java.lang.Object) xYPlot6);
//        int int21 = objectList0.size();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
//        long long24 = day22.getFirstMillisecond();
//        org.jfree.data.xy.XYDataset xYDataset25 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
//        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
//        java.awt.geom.Point2D point2D32 = null;
//        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
//        org.jfree.data.xy.XYDataset xYDataset36 = null;
//        xYPlot29.setDataset((int) (short) 0, xYDataset36);
//        xYPlot29.setRangeGridlinesVisible(false);
//        java.awt.Paint paint40 = xYPlot29.getDomainZeroBaselinePaint();
//        int int41 = day22.compareTo((java.lang.Object) xYPlot29);
//        boolean boolean42 = objectList0.equals((java.lang.Object) xYPlot29);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(paint40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        categoryPlot0.setWeight(0);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot14.zoomDomainAxes((double) 100, plotRenderingInfo16, point2D17, false);
        xYPlot14.clearAnnotations();
        xYPlot14.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color25 = java.awt.Color.WHITE;
        int int26 = color25.getBlue();
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color25.createContext(colorModel27, rectangle28, rectangle2D29, affineTransform30, renderingHints31);
        categoryMarker24.setOutlinePaint((java.awt.Paint) color25);
        xYPlot14.setNoDataMessagePaint((java.awt.Paint) color25);
        java.awt.Image image35 = null;
        xYPlot14.setBackgroundImage(image35);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace37);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot14.getDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        xYPlot14.rendererChanged(rendererChangeEvent40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, valueAxis44, xYItemRenderer45);
        java.awt.Stroke stroke47 = xYPlot46.getOutlineStroke();
        org.jfree.data.general.Dataset dataset48 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent49 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stroke47, dataset48);
        xYPlot14.datasetChanged(datasetChangeEvent49);
        categoryPlot0.datasetChanged(datasetChangeEvent49);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color13, stroke14);
        xYPlot10.setDomainCrosshairStroke(stroke14);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = xYPlot10.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection17);
        double double19 = categoryPlot0.getRangeCrosshairValue();
        boolean boolean20 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot7.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot7.setRenderer(xYItemRenderer9);
        xYPlot7.setNoDataMessage("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        xYPlot7.setDomainGridlinesVisible(true);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot20.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color24 = java.awt.Color.WHITE;
        int int25 = color24.getBlue();
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color24.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        categoryMarker23.setOutlinePaint((java.awt.Paint) color24);
        java.awt.Paint paint33 = categoryMarker23.getPaint();
        boolean boolean34 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot20.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace37 = numberAxis0.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) xYPlot7, rectangle2D15, rectangleEdge35, axisSpace36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        float float5 = xYPlot4.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font2 = valueMarker1.getLabelFont();
        java.awt.Font font3 = valueMarker1.getLabelFont();
        java.awt.Font font4 = valueMarker1.getLabelFont();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYPlot9.rendererChanged(rendererChangeEvent13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = xYPlot9.getDatasetGroup();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline20 = dateAxis19.getTimeline();
        boolean boolean21 = layer18.equals((java.lang.Object) timeline20);
        xYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker17, layer18);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace23, false);
        java.awt.Color color27 = java.awt.Color.DARK_GRAY;
        java.awt.Color color28 = java.awt.Color.getColor("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", color27);
        boolean boolean30 = color27.equals((java.lang.Object) "");
        xYPlot9.setDomainGridlinePaint((java.awt.Paint) color27);
        valueMarker1.setLabelPaint((java.awt.Paint) color27);
        int int33 = color27.getGreen();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNotNull(timeline20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 64 + "'", int33 == 64);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        java.util.TimeZone timeZone8 = dateAxis6.getTimeZone();
        dateAxis0.setTimeZone(timeZone8);
        dateAxis0.setFixedAutoRange((double) 2.0f);
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        dateAxis0.setMinimumDate(date12);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date12);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent4.getMarker();
        marker5.setAlpha((float) 0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        marker5.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot18.getRangeAxisLocation();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color21, stroke22);
        xYPlot18.setDomainCrosshairStroke(stroke22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot18);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot30.zoomDomainAxes((double) 100, plotRenderingInfo32, point2D33, false);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot30.setDataset((int) (short) 0, xYDataset37);
        xYPlot30.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot30.getDomainAxis();
        java.awt.Color color45 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot30.setRangeZeroBaselinePaint((java.awt.Paint) color45);
        xYPlot18.setDomainTickBandPaint((java.awt.Paint) color45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot18.zoomRangeAxes((double) (byte) 10, plotRenderingInfo49, point2D50, true);
        marker5.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        java.lang.String str5 = valueMarker1.getLabel();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        java.awt.Stroke stroke17 = xYPlot4.getRangeCrosshairStroke();
        java.awt.Paint paint18 = xYPlot4.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        boolean boolean19 = xYPlot10.isRangeZoomable();
        java.lang.String str20 = xYPlot10.getNoDataMessage();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot16.zoomDomainAxes((double) 100, plotRenderingInfo18, point2D19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot16.setDataset((int) (short) 0, xYDataset23);
        xYPlot16.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot16.getDomainAxis();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color31);
        xYPlot4.setDomainTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot4.zoomRangeAxes((double) (byte) 10, plotRenderingInfo35, point2D36, true);
        java.util.List list39 = xYPlot4.getAnnotations();
        java.awt.Paint paint40 = xYPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(axisSpace41);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) (-32384));
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int6 = day4.compareTo((java.lang.Object) color5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) regularTimePeriod7);
        java.lang.Comparable comparable10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot14.getDomainAxisLocation(0);
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getTop();
        double double22 = rectangleInsets20.getLeft();
        boolean boolean23 = day19.equals((java.lang.Object) rectangleInsets20);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        xYPlot28.setFixedRangeAxisSpace(axisSpace29);
        int int31 = day19.compareTo((java.lang.Object) xYPlot28);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        xYPlot28.drawAnnotations(graphics2D32, rectangle2D33, plotRenderingInfo34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean38 = axisLocation36.equals((java.lang.Object) lengthAdjustmentType37);
        xYPlot28.setRangeAxisLocation(axisLocation36);
        xYPlot28.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, valueAxis45, xYItemRenderer46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot47.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        int int50 = xYPlot47.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis49);
        java.awt.Font font51 = numberAxis49.getLabelFont();
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.AxisState axisState53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        java.util.List list56 = numberAxis49.refreshTicks(graphics2D52, axisState53, rectangle2D54, rectangleEdge55);
        java.awt.Paint paint57 = numberAxis49.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource58 = numberAxis49.getStandardTickUnits();
        boolean boolean59 = numberAxis49.isPositiveArrowVisible();
        xYPlot28.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis49, false);
        categoryPlot14.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis49, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = categoryPlot14.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis65.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font70 = categoryAxis65.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.lang.String str71 = categoryAxis65.getLabelToolTip();
        int int72 = categoryPlot14.getDomainAxisIndex(categoryAxis65);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot14.getDomainAxisEdge((-8388608));
        try {
            double double75 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 26.0d, comparable10, categoryDataset11, (double) 15, rectangle2D13, rectangleEdge74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(tickUnitSource58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(categoryItemRenderer64);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge74);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        int int20 = xYPlot4.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        xYPlot4.rendererChanged(rendererChangeEvent21);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setTickLabelFont(font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean20 = axisLocation18.equals((java.lang.Object) lengthAdjustmentType19);
        xYPlot10.setRangeAxisLocation(axisLocation18);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str23 = plotOrientation22.toString();
        java.lang.String str24 = plotOrientation22.toString();
        java.lang.String str25 = plotOrientation22.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation22);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str23.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str24.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str25.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        java.util.TimeZone timeZone2 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat4 = dateAxis3.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis3.setTickUnit(dateTickUnit5, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat10 = dateAxis9.getDateFormatOverride();
        java.util.TimeZone timeZone11 = dateAxis9.getTimeZone();
        dateAxis3.setTimeZone(timeZone11);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis3.setTickUnit(dateTickUnit13, false, false);
        java.util.Date date17 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit13);
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        numberAxis6.setAxisLineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomDomainAxes((double) 100, plotRenderingInfo23, point2D24, false);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot21.setDataset((int) (short) 0, xYDataset28);
        xYPlot21.setRangeGridlinesVisible(false);
        xYPlot21.clearRangeAxes();
        int int33 = xYPlot21.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        xYPlot21.setFixedDomainAxisSpace(axisSpace34);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font41 = numberAxis40.getTickLabelFont();
        java.awt.Shape shape42 = numberAxis40.getUpArrow();
        numberAxis36.setDownArrow(shape42);
        org.jfree.data.Range range44 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis36);
        numberAxis36.resizeRange(0.0d, 1.0E-8d);
        org.jfree.data.Range range48 = numberAxis36.getRange();
        numberAxis6.setRangeWithMargins(range48);
        java.awt.Shape shape50 = numberAxis6.getLeftArrow();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.Object obj1 = null;
        boolean boolean2 = unitType0.equals(obj1);
        boolean boolean4 = unitType0.equals((java.lang.Object) 1560409200000L);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        xYPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot4.getRangeAxisLocation(7);
        java.lang.Object obj25 = xYPlot4.clone();
        xYPlot4.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        java.awt.Stroke stroke22 = numberAxis6.getTickMarkStroke();
        boolean boolean23 = numberAxis6.isVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat25 = dateAxis24.getDateFormatOverride();
        java.util.TimeZone timeZone26 = dateAxis24.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone26);
        numberAxis6.setStandardTickUnits(tickUnitSource27);
        numberAxis6.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(dateFormat25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(tickUnitSource27);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryMargin((double) (-32384));
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int7 = day5.compareTo((java.lang.Object) color6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        java.awt.Paint paint9 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) regularTimePeriod8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setMaximumCategoryLabelLines(1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        double double14 = categoryAxis13.getUpperMargin();
        int int15 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis13.getCategoryLabelPositions();
        categoryAxis10.setCategoryLabelPositions(categoryLabelPositions16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot27.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        int int30 = xYPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis29);
        java.awt.Font font31 = numberAxis29.getLabelFont();
        java.awt.Font font32 = numberAxis29.getTickLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 3, font32);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray34 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis1, categoryAxis10, categoryAxis18 };
        categoryPlot0.setDomainAxes(categoryAxisArray34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent37 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(categoryAxisArray34);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        categoryPlot0.setDataset((int) (short) 10, categoryDataset3);
        java.awt.Paint paint5 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot12.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        java.awt.Font font16 = numberAxis14.getLabelFont();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis14.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis14.setRange((org.jfree.data.Range) dateRange22, true, true);
        dateAxis7.setRange((org.jfree.data.Range) dateRange22, false, true);
        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double32 = rectangleInsets31.getTop();
        double double33 = rectangleInsets31.getLeft();
        boolean boolean34 = day30.equals((java.lang.Object) rectangleInsets31);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        xYPlot39.setFixedRangeAxisSpace(axisSpace40);
        int int42 = day30.compareTo((java.lang.Object) xYPlot39);
        xYPlot39.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean48 = valueMarker46.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker46);
        org.jfree.chart.plot.Marker marker50 = markerChangeEvent49.getMarker();
        java.lang.Object obj51 = markerChangeEvent49.getSource();
        xYPlot39.markerChanged(markerChangeEvent49);
        java.awt.Image image53 = xYPlot39.getBackgroundImage();
        boolean boolean54 = dateAxis7.hasListener((java.util.EventListener) xYPlot39);
        double double55 = dateAxis7.getLowerBound();
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) dateAxis7, true);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(marker50);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNull(image53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setWeight(0);
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets25.getTop();
        double double27 = rectangleInsets25.getLeft();
        boolean boolean28 = day24.equals((java.lang.Object) rectangleInsets25);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        xYPlot33.setFixedRangeAxisSpace(axisSpace34);
        int int36 = day24.compareTo((java.lang.Object) xYPlot33);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        xYPlot33.drawAnnotations(graphics2D37, rectangle2D38, plotRenderingInfo39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean43 = axisLocation41.equals((java.lang.Object) lengthAdjustmentType42);
        xYPlot33.setRangeAxisLocation(axisLocation41);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot33);
        xYPlot33.configureDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 8.0d + "'", double27 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation(0);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getLeft();
        boolean boolean9 = day5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace15);
        int int17 = day5.compareTo((java.lang.Object) xYPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot14.drawAnnotations(graphics2D18, rectangle2D19, plotRenderingInfo20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) lengthAdjustmentType23);
        xYPlot14.setRangeAxisLocation(axisLocation22);
        xYPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot33.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        int int36 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Font font37 = numberAxis35.getLabelFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis35.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis35.getStandardTickUnits();
        boolean boolean45 = numberAxis35.isPositiveArrowVisible();
        xYPlot14.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis51.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font56 = categoryAxis51.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.lang.String str57 = categoryAxis51.getLabelToolTip();
        int int58 = categoryPlot0.getDomainAxisIndex(categoryAxis51);
        java.awt.Color color61 = java.awt.Color.DARK_GRAY;
        java.awt.Color color62 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace63 = color62.getColorSpace();
        float[] floatArray67 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray68 = color61.getColorComponents(colorSpace63, floatArray67);
        org.jfree.chart.plot.ValueMarker valueMarker70 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean72 = valueMarker70.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker70.setStroke(stroke73);
        org.jfree.chart.plot.CategoryMarker categoryMarker75 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color61, stroke73);
        org.jfree.chart.util.Layer layer76 = null;
        categoryPlot0.addRangeMarker((int) (short) 0, (org.jfree.chart.plot.Marker) categoryMarker75, layer76, false);
        categoryPlot0.setBackgroundAlpha((float) 15);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer50);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(colorSpace63);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.HALF_ASCENT_LEFT");
        categoryAxis1.setLowerMargin((double) 12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        xYPlot4.zoom((double) 1.0f);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font25 = numberAxis24.getTickLabelFont();
        java.awt.Shape shape26 = numberAxis24.getUpArrow();
        boolean boolean27 = numberAxis24.isAutoTickUnitSelection();
        int int28 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot4.setDomainAxisLocation(100, axisLocation30, true);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot4.getDomainAxis((int) (short) 0);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNull(valueAxis34);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent4.getMarker();
        marker5.setAlpha((float) 0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        marker5.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot12);
        int int14 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot12.getDomainAxisLocation((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        dateAxis0.setMaximumDate(date2);
        boolean boolean6 = dateAxis0.isVisible();
        java.lang.Object obj7 = null;
        boolean boolean8 = dateAxis0.equals(obj7);
        try {
            dateAxis0.setRange(4.0d, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        valueMarker1.setOutlinePaint(paint3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, 0.2d, (double) 100, 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairVisible(false);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray22 = new java.awt.Stroke[] { stroke16, stroke17, stroke18, stroke19, stroke20, stroke21 };
        java.awt.Shape[] shapeArray23 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray14, strokeArray15, strokeArray22, shapeArray23);
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextPaint();
        java.awt.Stroke stroke26 = defaultDrawingSupplier24.getNextOutlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke26);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0);
        org.jfree.data.general.Dataset dataset3 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 0, dataset3);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes((double) 100, plotRenderingInfo8, point2D9, false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot6.setDataset((int) (short) 0, xYDataset13);
        xYPlot6.setRangeGridlinesVisible(false);
        xYPlot6.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        xYPlot6.setRangeAxis(valueAxis18);
        objectList0.set(1, (java.lang.Object) xYPlot6);
        int int21 = objectList0.size();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int24 = color23.getRGB();
        objectList0.set(64, (java.lang.Object) int24);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-8388608) + "'", int24 == (-8388608));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 7.0d);
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setMaximumCategoryLabelLines(1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getUpperMargin();
        int int12 = categoryAxis10.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = categoryAxis10.getCategoryLabelPositions();
        categoryAxis7.setCategoryLabelPositions(categoryLabelPositions13);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickLabelPaint();
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.RIGHT" + "'", str1.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRange((org.jfree.data.Range) dateRange15, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange15, false, true);
        dateAxis0.zoomRange(10.0d, (double) 100L);
        float float25 = dateAxis0.getTickMarkInsideLength();
        java.text.DateFormat dateFormat26 = null;
        dateAxis0.setDateFormatOverride(dateFormat26);
        boolean boolean29 = dateAxis0.isHiddenValue((long) (short) -1);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (byte) -1);
        double double4 = rectangleInsets0.extendHeight(8.0d);
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double8 = rectangleInsets7.getTop();
        double double9 = rectangleInsets7.getLeft();
        boolean boolean10 = day6.equals((java.lang.Object) rectangleInsets7);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace16);
        int int18 = day6.compareTo((java.lang.Object) xYPlot15);
        xYPlot15.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean24 = valueMarker22.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker22);
        org.jfree.chart.plot.Marker marker26 = markerChangeEvent25.getMarker();
        java.lang.Object obj27 = markerChangeEvent25.getSource();
        xYPlot15.markerChanged(markerChangeEvent25);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = xYPlot15.getAxisOffset();
        boolean boolean30 = rectangleInsets0.equals((java.lang.Object) rectangleInsets29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline32 = dateAxis31.getTimeline();
        boolean boolean33 = rectangleInsets29.equals((java.lang.Object) timeline32);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(marker26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeline32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        java.util.TimeZone timeZone8 = dateAxis6.getTimeZone();
        dateAxis0.setTimeZone(timeZone8);
        dateAxis0.setFixedAutoRange((double) 2.0f);
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        dateAxis0.setMinimumDate(date12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat17 = dateAxis16.getDateFormatOverride();
        java.util.TimeZone timeZone18 = dateAxis16.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat20 = dateAxis19.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis19.setTickUnit(dateTickUnit21, false, true);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat26 = dateAxis25.getDateFormatOverride();
        java.util.TimeZone timeZone27 = dateAxis25.getTimeZone();
        dateAxis19.setTimeZone(timeZone27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis19.setTickUnit(dateTickUnit29, false, false);
        java.util.Date date33 = dateAxis16.calculateLowestVisibleTickValue(dateTickUnit29);
        dateAxis0.setTickUnit(dateTickUnit29, false, false);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(dateTickUnit15);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(dateFormat20);
        org.junit.Assert.assertNull(dateFormat26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation(0);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getLeft();
        boolean boolean9 = day5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace15);
        int int17 = day5.compareTo((java.lang.Object) xYPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot14.drawAnnotations(graphics2D18, rectangle2D19, plotRenderingInfo20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) lengthAdjustmentType23);
        xYPlot14.setRangeAxisLocation(axisLocation22);
        xYPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot33.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        int int36 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Font font37 = numberAxis35.getLabelFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis35.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis35.getStandardTickUnits();
        boolean boolean45 = numberAxis35.isPositiveArrowVisible();
        xYPlot14.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot0.getRangeAxisForDataset(10);
        org.jfree.chart.plot.Marker marker53 = null;
        try {
            categoryPlot0.addRangeMarker(marker53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer50);
        org.junit.Assert.assertNotNull(valueAxis52);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        java.awt.Shape shape2 = numberAxis0.getUpArrow();
        boolean boolean3 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoTickUnitSelection(false, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit9);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(numberTickUnit9);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        categoryPlot0.clearAnnotations();
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        dateAxis0.setMaximumDate(date2);
        java.awt.Shape shape6 = dateAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        xYPlot4.setDomainCrosshairVisible(true);
        java.awt.Paint paint19 = xYPlot4.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getDomainAxis(4);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat4 = dateAxis3.getDateFormatOverride();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        java.util.TimeZone timeZone2 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat4 = dateAxis3.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis3.setTickUnit(dateTickUnit5, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat10 = dateAxis9.getDateFormatOverride();
        java.util.TimeZone timeZone11 = dateAxis9.getTimeZone();
        dateAxis3.setTimeZone(timeZone11);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis3.setTickUnit(dateTickUnit13, false, false);
        java.util.Date date17 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit13);
        org.jfree.data.general.Dataset dataset18 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) date17, dataset18);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot0.getDataset();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot10.zoomDomainAxes((double) 100, plotRenderingInfo12, point2D13, false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot10.setDataset((int) (short) 0, xYDataset17);
        xYPlot10.setRangeGridlinesVisible(false);
        xYPlot10.clearRangeAxes();
        java.lang.String str22 = xYPlot10.getPlotType();
        xYPlot10.configureRangeAxes();
        xYPlot10.setOutlineVisible(false);
        java.awt.Stroke stroke26 = xYPlot10.getRangeCrosshairStroke();
        xYPlot10.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot10.getRangeAxisLocation(7);
        categoryPlot5.setDomainAxisLocation(axisLocation30, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset38, valueAxis39, valueAxis40, xYItemRenderer41);
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot42.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        int int45 = xYPlot42.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis44);
        java.awt.Font font46 = numberAxis44.getLabelFont();
        java.awt.Font font47 = numberAxis44.getTickLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 3, font47);
        double double49 = categoryAxis33.getCategoryMargin();
        categoryAxis33.clearCategoryLabelToolTips();
        categoryPlot5.setDomainAxis(categoryAxis33);
        org.jfree.data.category.CategoryDataset categoryDataset53 = categoryPlot5.getDataset((-65536));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.2d + "'", double49 == 0.2d);
        org.junit.Assert.assertNull(categoryDataset53);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = numberAxis4.getTickLabelFont();
        java.awt.Shape shape6 = numberAxis4.getUpArrow();
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = numberAxis8.getTickLabelFont();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        numberAxis0.setLeftArrow(shape10);
        numberAxis0.resizeRange((double) (-32384), (double) 1560452399999L);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot19.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        int int22 = xYPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis21);
        numberAxis21.setAutoRangeMinimumSize((double) 2.0f, false);
        double double26 = numberAxis21.getUpperMargin();
        java.awt.Shape shape27 = numberAxis21.getRightArrow();
        numberAxis0.setLeftArrow(shape27);
        java.awt.Paint paint29 = numberAxis0.getLabelPaint();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        java.util.List list10 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        double double2 = categoryAxis0.getCategoryMargin();
        double double3 = categoryAxis0.getFixedDimension();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot11.zoomDomainAxes((double) 100, plotRenderingInfo13, point2D14, false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        xYPlot11.setDataset((int) (short) 0, xYDataset18);
        xYPlot11.setRangeGridlinesVisible(false);
        xYPlot11.clearRangeAxes();
        int int23 = xYPlot11.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot11.setRangeAxisLocation(10, axisLocation25);
        xYPlot11.setForegroundAlpha(0.8f);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot11.getDomainAxisEdge();
        try {
            java.util.List list30 = categoryAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        java.awt.Stroke stroke18 = xYPlot4.getDomainZeroBaselineStroke();
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets21.getTop();
        double double23 = rectangleInsets21.getLeft();
        boolean boolean24 = day20.equals((java.lang.Object) rectangleInsets21);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot29.setFixedRangeAxisSpace(axisSpace30);
        int int32 = day20.compareTo((java.lang.Object) xYPlot29);
        xYPlot29.setBackgroundImageAlpha(0.0f);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        xYPlot4.setRenderer(xYItemRenderer36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double40 = rectangleInsets38.calculateBottomOutset((double) '4');
        double double42 = rectangleInsets38.extendHeight((double) 1.0f);
        org.jfree.chart.util.UnitType unitType43 = rectangleInsets38.getUnitType();
        xYPlot4.setInsets(rectangleInsets38, false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 9.0d + "'", double42 == 9.0d);
        org.junit.Assert.assertNotNull(unitType43);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot10.getDataset((int) '#');
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(xYDataset22);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopInset((double) 10);
        numberAxis6.setLabelInsets(rectangleInsets11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        double double16 = numberAxis6.getLowerMargin();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Image image25 = null;
        xYPlot4.setBackgroundImage(image25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot4.getDomainAxis();
        xYPlot4.setForegroundAlpha((float) (-1));
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray32 = null;
        try {
            xYPlot4.setRenderers(xYItemRendererArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Paint paint15 = xYPlot4.getRangeGridlinePaint();
        java.awt.Paint paint16 = xYPlot4.getBackgroundPaint();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean20 = valueMarker18.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.plot.Marker marker22 = markerChangeEvent21.getMarker();
        marker22.setAlpha((float) 0);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        marker22.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot29);
        int int31 = xYPlot29.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot29.setRangeAxes(valueAxisArray32);
        xYPlot4.setDomainAxes(valueAxisArray32);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(marker22);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray32);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        java.lang.String str4 = valueMarker1.getLabel();
        java.awt.Stroke stroke5 = valueMarker1.getStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        markerChangeEvent8.setType(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        double double13 = numberAxis6.getUpperBound();
        boolean boolean14 = numberAxis6.isTickLabelsVisible();
        java.text.NumberFormat numberFormat15 = null;
        numberAxis6.setNumberFormatOverride(numberFormat15);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker1.setStroke(stroke4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker1.getLabelOffsetType();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean8 = lengthAdjustmentType6.equals((java.lang.Object) shape7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot4.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getRangeMarkers(11, layer34);
        java.awt.Color color36 = java.awt.Color.MAGENTA;
        java.awt.Color color37 = color36.brighter();
        java.awt.Color color38 = color37.darker();
        categoryPlot32.setRangeCrosshairPaint((java.awt.Paint) color38);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = xYPlot4.getNoDataMessagePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color12, stroke13);
        categoryMarker14.setKey((java.lang.Comparable) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker14);
        xYPlot4.markerChanged(markerChangeEvent17);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot4.getRangeAxisForDataset(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 8 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        xYPlot4.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getDomainAxisLocation(0);
        categoryPlot0.setAnchorValue((double) 2019, false);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis6.setTickUnit(dateTickUnit8, false, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat13 = dateAxis12.getDateFormatOverride();
        java.util.TimeZone timeZone14 = dateAxis12.getTimeZone();
        dateAxis6.setTimeZone(timeZone14);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit16, false, false);
        boolean boolean20 = categoryPlot0.equals((java.lang.Object) dateAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot0.getFixedRangeAxisSpace();
        java.util.List list22 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNull(dateFormat13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        double double2 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        java.lang.String str4 = categoryAnchor3.toString();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str4.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj20 = null;
        boolean boolean21 = axisLocation19.equals(obj20);
        xYPlot4.setDomainAxisLocation(axisLocation19, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace24, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color28, stroke29);
        categoryMarker30.setKey((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        xYPlot37.zoomDomainAxes((double) 100, plotRenderingInfo39, point2D40, false);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        xYPlot37.setDataset((int) (short) 0, xYDataset44);
        xYPlot37.setRangeGridlinesVisible(false);
        xYPlot37.clearRangeAxes();
        java.lang.String str49 = xYPlot37.getPlotType();
        xYPlot37.configureRangeAxes();
        xYPlot37.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot37.zoomDomainAxes((double) 5, plotRenderingInfo54, point2D55, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color60 = java.awt.Color.WHITE;
        int int61 = color60.getBlue();
        java.awt.image.ColorModel colorModel62 = null;
        java.awt.Rectangle rectangle63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        java.awt.geom.AffineTransform affineTransform65 = null;
        java.awt.RenderingHints renderingHints66 = null;
        java.awt.PaintContext paintContext67 = color60.createContext(colorModel62, rectangle63, rectangle2D64, affineTransform65, renderingHints66);
        categoryMarker59.setOutlinePaint((java.awt.Paint) color60);
        java.awt.Paint paint69 = categoryMarker59.getPaint();
        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean71 = xYPlot37.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker59, layer70);
        boolean boolean72 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30, layer70);
        java.awt.Paint paint73 = categoryMarker30.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "XY Plot" + "'", str49.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 255 + "'", int61 == 255);
        org.junit.Assert.assertNotNull(paintContext67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(layer70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(paint73);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getDomainAxisLocation(0);
        categoryPlot0.setDomainAxisLocation(255, axisLocation5, true);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        xYPlot4.setDomainCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot4.getAxisOffset();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double2 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getDomainAxisLocation(0);
        categoryPlot0.setDomainAxisLocation(255, axisLocation5, true);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            categoryPlot0.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryMargin((double) (-32384));
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int6 = day4.compareTo((java.lang.Object) color5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) regularTimePeriod7);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) regularTimePeriod7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        double double13 = numberAxis6.getUpperBound();
        numberAxis6.setUpperMargin((double) (-1));
        numberAxis6.setUpperBound((double) (-8388608));
        numberAxis6.configure();
        java.awt.Paint paint19 = numberAxis6.getLabelPaint();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot8.setDataset((int) (short) 0, xYDataset15);
        xYPlot8.setRangeGridlinesVisible(false);
        xYPlot8.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot8.removeChangeListener(plotChangeListener20);
        xYPlot8.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot28.getRangeAxisLocation();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color31, stroke32);
        xYPlot28.setDomainCrosshairStroke(stroke32);
        xYPlot8.setRangeCrosshairStroke(stroke32);
        java.awt.Color color38 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean42 = valueMarker40.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.Marker marker44 = markerChangeEvent43.getMarker();
        marker44.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot51.zoomDomainAxes((double) 100, plotRenderingInfo53, point2D54, false);
        xYPlot51.clearAnnotations();
        xYPlot51.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color62 = java.awt.Color.WHITE;
        int int63 = color62.getBlue();
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color62.createContext(colorModel64, rectangle65, rectangle2D66, affineTransform67, renderingHints68);
        categoryMarker61.setOutlinePaint((java.awt.Paint) color62);
        xYPlot51.setNoDataMessagePaint((java.awt.Paint) color62);
        java.awt.Image image72 = null;
        xYPlot51.setBackgroundImage(image72);
        java.awt.Stroke stroke74 = xYPlot51.getRangeCrosshairStroke();
        marker44.setOutlineStroke(stroke74);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) 2019, (java.awt.Paint) color2, stroke32, (java.awt.Paint) color38, stroke74, 0.0f);
        java.awt.Font font78 = intervalMarker77.getLabelFont();
        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean82 = valueMarker80.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke83 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker80.setStroke(stroke83);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = valueMarker80.getLabelOffsetType();
        intervalMarker77.setLabelOffsetType(lengthAdjustmentType85);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent87 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker77);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer88 = null;
        intervalMarker77.setGradientPaintTransformer(gradientPaintTransformer88);
        java.lang.String str90 = intervalMarker77.getLabel();
        try {
            intervalMarker77.setAlpha((float) (-65536));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(marker44);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(lengthAdjustmentType85);
        org.junit.Assert.assertNull(str90);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopInset((double) 10);
        numberAxis6.setLabelInsets(rectangleInsets11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = null;
        try {
            numberAxis6.setTickLabelInsets(rectangleInsets16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        java.lang.String str3 = color2.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=0,b=32]" + "'", str3.equals("java.awt.Color[r=0,g=0,b=32]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot16.zoomDomainAxes((double) 100, plotRenderingInfo18, point2D19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot16.setDataset((int) (short) 0, xYDataset23);
        xYPlot16.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot16.getDomainAxis();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color31);
        xYPlot4.setDomainTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot4.zoomRangeAxes((double) (byte) 10, plotRenderingInfo35, point2D36, true);
        java.util.List list39 = xYPlot4.getAnnotations();
        java.awt.Paint paint40 = xYPlot4.getNoDataMessagePaint();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean45 = valueMarker43.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker43);
        org.jfree.chart.plot.Marker marker47 = markerChangeEvent46.getMarker();
        marker47.setAlpha((float) 0);
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset50, valueAxis51, valueAxis52, xYItemRenderer53);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Point2D point2D57 = null;
        xYPlot54.zoomDomainAxes((double) 100, plotRenderingInfo56, point2D57, false);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        xYPlot54.setDataset((int) (short) 0, xYDataset61);
        xYPlot54.setRangeGridlinesVisible(false);
        xYPlot54.clearRangeAxes();
        int int66 = xYPlot54.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace67 = null;
        xYPlot54.setFixedDomainAxisSpace(axisSpace67);
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis();
        numberAxis69.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font74 = numberAxis73.getTickLabelFont();
        java.awt.Shape shape75 = numberAxis73.getUpArrow();
        numberAxis69.setDownArrow(shape75);
        org.jfree.data.Range range77 = xYPlot54.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis69);
        org.jfree.chart.util.Layer layer78 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection79 = xYPlot54.getDomainMarkers(layer78);
        xYPlot4.addRangeMarker((int) (short) 100, marker47, layer78, true);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType82 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean83 = layer78.equals((java.lang.Object) lengthAdjustmentType82);
        java.lang.String str84 = lengthAdjustmentType82.toString();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(marker47);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertNull(range77);
        org.junit.Assert.assertNotNull(layer78);
        org.junit.Assert.assertNull(collection79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "EXPAND" + "'", str84.equals("EXPAND"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        dateAxis0.setMaximumDate(date2);
        boolean boolean6 = dateAxis0.isVisible();
        java.lang.Object obj7 = null;
        boolean boolean8 = dateAxis0.equals(obj7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot13.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        int int16 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        java.awt.Font font17 = numberAxis15.getLabelFont();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        java.util.List list22 = numberAxis15.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = numberAxis15.getTickLabelInsets();
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis15.setRange(range24);
        dateAxis0.setRange(range24, true, false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot4.rendererChanged(rendererChangeEvent8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = xYPlot4.getDatasetGroup();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline15 = dateAxis14.getTimeline();
        boolean boolean16 = layer13.equals((java.lang.Object) timeline15);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12, layer13);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace18, false);
        boolean boolean21 = xYPlot4.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertNotNull(timeline15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setWeight(0);
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double26 = rectangleInsets25.getTop();
        double double27 = rectangleInsets25.getLeft();
        boolean boolean28 = day24.equals((java.lang.Object) rectangleInsets25);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        xYPlot33.setFixedRangeAxisSpace(axisSpace34);
        int int36 = day24.compareTo((java.lang.Object) xYPlot33);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        xYPlot33.drawAnnotations(graphics2D37, rectangle2D38, plotRenderingInfo39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean43 = axisLocation41.equals((java.lang.Object) lengthAdjustmentType42);
        xYPlot33.setRangeAxisLocation(axisLocation41);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        xYPlot33.setRenderer((int) 'a', xYItemRenderer47, true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 8.0d + "'", double27 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font24 = numberAxis23.getTickLabelFont();
        java.awt.Shape shape25 = numberAxis23.getUpArrow();
        numberAxis19.setDownArrow(shape25);
        org.jfree.data.Range range27 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        numberAxis19.resizeRange(0.0d, 1.0E-8d);
        boolean boolean31 = numberAxis19.isVerticalTickLabels();
        numberAxis19.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = numberAxis4.getTickLabelFont();
        java.awt.Shape shape6 = numberAxis4.getUpArrow();
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = numberAxis8.getTickLabelFont();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        numberAxis0.setLeftArrow(shape10);
        numberAxis0.setRangeWithMargins(2.0d, (double) 7);
        numberAxis0.setTickMarksVisible(false);
        numberAxis0.setLowerMargin(0.0d);
        java.awt.Shape shape19 = numberAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        xYPlot4.clearRangeMarkers(0);
        java.awt.Stroke stroke13 = xYPlot4.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        boolean boolean7 = dateAxis0.isHiddenValue(0L);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean7, jFreeChart8, chartChangeEventType9);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        categoryPlot0.setWeight(0);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot17.zoomDomainAxes((double) 100, plotRenderingInfo19, point2D20, false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot17.setDataset((int) (short) 0, xYDataset24);
        xYPlot17.setRangeGridlinesVisible(false);
        xYPlot17.clearRangeAxes();
        java.lang.String str29 = xYPlot17.getPlotType();
        xYPlot17.configureRangeAxes();
        xYPlot17.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot17.zoomDomainAxes((double) 5, plotRenderingInfo34, point2D35, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color40 = java.awt.Color.WHITE;
        int int41 = color40.getBlue();
        java.awt.image.ColorModel colorModel42 = null;
        java.awt.Rectangle rectangle43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color40.createContext(colorModel42, rectangle43, rectangle2D44, affineTransform45, renderingHints46);
        categoryMarker39.setOutlinePaint((java.awt.Paint) color40);
        java.awt.Paint paint49 = categoryMarker39.getPaint();
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean51 = xYPlot17.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker39, layer50);
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset52, valueAxis53, valueAxis54, xYItemRenderer55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        xYPlot56.zoomDomainAxes((double) 100, plotRenderingInfo58, point2D59, false);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        xYPlot56.setDataset((int) (short) 0, xYDataset63);
        xYPlot56.setRangeGridlinesVisible(false);
        xYPlot56.clearRangeAxes();
        java.lang.String str68 = xYPlot56.getPlotType();
        xYPlot56.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = xYPlot56.getAxisOffset();
        categoryMarker39.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot56);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis();
        double double73 = categoryAxis72.getUpperMargin();
        java.awt.Stroke stroke74 = categoryAxis72.getAxisLineStroke();
        categoryMarker39.setStroke(stroke74);
        categoryPlot0.addDomainMarker(categoryMarker39);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "XY Plot" + "'", str29.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 255 + "'", int41 == 255);
        org.junit.Assert.assertNotNull(paintContext47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "XY Plot" + "'", str68.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.05d + "'", double73 == 0.05d);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        xYPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot4.getRangeAxisLocation(7);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot29.setDataset((int) (short) 0, xYDataset36);
        xYPlot29.setRangeGridlinesVisible(false);
        xYPlot29.clearRangeAxes();
        java.lang.String str41 = xYPlot29.getPlotType();
        xYPlot29.configureRangeAxes();
        java.awt.Paint[] paintArray43 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray44 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray45 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray52 = new java.awt.Stroke[] { stroke46, stroke47, stroke48, stroke49, stroke50, stroke51 };
        java.awt.Shape[] shapeArray53 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier54 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray43, paintArray44, strokeArray45, strokeArray52, shapeArray53);
        java.awt.Paint paint55 = defaultDrawingSupplier54.getNextPaint();
        xYPlot29.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier54);
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor59 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        valueMarker58.setLabelTextAnchor(textAnchor59);
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot29.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker58, layer61);
        boolean boolean63 = axisLocation24.equals((java.lang.Object) valueMarker58);
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset64, valueAxis65, valueAxis66, xYItemRenderer67);
        org.jfree.chart.axis.AxisLocation axisLocation69 = xYPlot68.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        xYPlot68.setRenderer(xYItemRenderer70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Point2D point2D74 = null;
        xYPlot68.zoomDomainAxes(0.0d, plotRenderingInfo73, point2D74);
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str77 = axisLocation76.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation78 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str79 = plotOrientation78.toString();
        java.lang.String str80 = plotOrientation78.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation76, plotOrientation78);
        java.lang.String str82 = plotOrientation78.toString();
        xYPlot68.setOrientation(plotOrientation78);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation24, plotOrientation78);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "XY Plot" + "'", str41.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(paintArray44);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(strokeArray52);
        org.junit.Assert.assertNotNull(shapeArray53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(textAnchor59);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str77.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str79.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str80.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str82.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge84);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        boolean boolean2 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setAutoRange(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot4.zoomDomainAxes((double) 5, plotRenderingInfo21, point2D22, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color27 = java.awt.Color.WHITE;
        int int28 = color27.getBlue();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        categoryMarker26.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint36 = categoryMarker26.getPaint();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer37);
        org.jfree.chart.text.TextAnchor textAnchor39 = categoryMarker26.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor40 = categoryMarker26.getLabelTextAnchor();
        java.awt.Paint paint41 = categoryMarker26.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 500);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot16.zoomDomainAxes((double) 100, plotRenderingInfo18, point2D19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot16.setDataset((int) (short) 0, xYDataset23);
        xYPlot16.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot16.getDomainAxis();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color31);
        xYPlot4.setDomainTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot4.zoomRangeAxes((double) (byte) 10, plotRenderingInfo35, point2D36, true);
        xYPlot4.clearDomainMarkers(7);
        java.awt.Paint paint41 = xYPlot4.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        double double17 = xYPlot4.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color20 = java.awt.Color.WHITE;
        int int21 = color20.getBlue();
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color20.createContext(colorModel22, rectangle23, rectangle2D24, affineTransform25, renderingHints26);
        categoryMarker19.setOutlinePaint((java.awt.Paint) color20);
        java.awt.Paint paint29 = categoryMarker19.getPaint();
        categoryMarker19.setKey((java.lang.Comparable) 100);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = categoryMarker19.getLabelOffsetType();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertNotNull(paintContext27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker1.setStroke(stroke4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker1.getLabelOffsetType();
        java.lang.String str7 = lengthAdjustmentType6.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CONTRACT" + "'", str7.equals("CONTRACT"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Image image25 = null;
        xYPlot4.setBackgroundImage(image25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot4.getDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        xYPlot4.rendererChanged(rendererChangeEvent30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        java.awt.Stroke stroke37 = xYPlot36.getOutlineStroke();
        org.jfree.data.general.Dataset dataset38 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stroke37, dataset38);
        xYPlot4.datasetChanged(datasetChangeEvent39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        xYPlot4.zoomDomainAxes(1.0E-8d, (double) 'a', plotRenderingInfo43, point2D44);
        xYPlot4.setBackgroundImageAlignment(12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean19 = valueMarker17.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        xYPlot10.markerChanged(markerChangeEvent20);
        java.awt.Image image24 = xYPlot10.getBackgroundImage();
        java.awt.Image image25 = null;
        xYPlot10.setBackgroundImage(image25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = xYPlot10.getInsets();
        double double29 = rectangleInsets27.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        java.util.TimeZone timeZone8 = dateAxis6.getTimeZone();
        dateAxis0.setTimeZone(timeZone8);
        dateAxis0.setInverted(true);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        int int19 = xYPlot10.getDatasetCount();
        boolean boolean20 = xYPlot10.isRangeCrosshairVisible();
        java.awt.Paint paint21 = xYPlot10.getBackgroundPaint();
        xYPlot10.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 0.0d, (double) 10, (double) '#');
        java.lang.String str6 = unitType0.toString();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        boolean boolean8 = unitType0.equals((java.lang.Object) color7);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        java.awt.Stroke stroke18 = xYPlot4.getDomainZeroBaselineStroke();
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double22 = rectangleInsets21.getTop();
        double double23 = rectangleInsets21.getLeft();
        boolean boolean24 = day20.equals((java.lang.Object) rectangleInsets21);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot29.setFixedRangeAxisSpace(axisSpace30);
        int int32 = day20.compareTo((java.lang.Object) xYPlot29);
        xYPlot29.setBackgroundImageAlpha(0.0f);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot29);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = xYPlot29.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot29.getDomainAxisEdge(0);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = xYPlot29.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.0d + "'", double23 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(legendItemCollection39);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        double double17 = xYPlot4.getRangeCrosshairValue();
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getTop();
        double double22 = rectangleInsets20.getLeft();
        boolean boolean23 = day19.equals((java.lang.Object) rectangleInsets20);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        xYPlot28.setFixedRangeAxisSpace(axisSpace29);
        int int31 = day19.compareTo((java.lang.Object) xYPlot28);
        boolean boolean32 = xYPlot4.equals((java.lang.Object) xYPlot28);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot28.getDataset();
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot28, jFreeChart34, chartChangeEventType35);
        xYPlot28.clearDomainMarkers();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(xYDataset33);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        java.awt.Paint paint33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot32.setRangeCrosshairPaint(paint33);
        int int35 = categoryPlot32.getDatasetCount();
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        numberAxis6.setTickMarksVisible(true);
        boolean boolean17 = numberAxis6.isAxisLineVisible();
        java.awt.Paint paint18 = numberAxis6.getTickMarkPaint();
        numberAxis6.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        categoryPlot0.setWeight(0);
        try {
            categoryPlot0.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj20 = null;
        boolean boolean21 = axisLocation19.equals(obj20);
        xYPlot4.setDomainAxisLocation(axisLocation19, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace24, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color28, stroke29);
        categoryMarker30.setKey((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        xYPlot37.zoomDomainAxes((double) 100, plotRenderingInfo39, point2D40, false);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        xYPlot37.setDataset((int) (short) 0, xYDataset44);
        xYPlot37.setRangeGridlinesVisible(false);
        xYPlot37.clearRangeAxes();
        java.lang.String str49 = xYPlot37.getPlotType();
        xYPlot37.configureRangeAxes();
        xYPlot37.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot37.zoomDomainAxes((double) 5, plotRenderingInfo54, point2D55, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color60 = java.awt.Color.WHITE;
        int int61 = color60.getBlue();
        java.awt.image.ColorModel colorModel62 = null;
        java.awt.Rectangle rectangle63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        java.awt.geom.AffineTransform affineTransform65 = null;
        java.awt.RenderingHints renderingHints66 = null;
        java.awt.PaintContext paintContext67 = color60.createContext(colorModel62, rectangle63, rectangle2D64, affineTransform65, renderingHints66);
        categoryMarker59.setOutlinePaint((java.awt.Paint) color60);
        java.awt.Paint paint69 = categoryMarker59.getPaint();
        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean71 = xYPlot37.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker59, layer70);
        boolean boolean72 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30, layer70);
        xYPlot4.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "XY Plot" + "'", str49.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 255 + "'", int61 == 255);
        org.junit.Assert.assertNotNull(paintContext67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(layer70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot4.rendererChanged(rendererChangeEvent8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = xYPlot4.getDatasetGroup();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline15 = dateAxis14.getTimeline();
        boolean boolean16 = layer13.equals((java.lang.Object) timeline15);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker12, layer13);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace18, false);
        java.awt.Stroke stroke21 = xYPlot4.getDomainCrosshairStroke();
        xYPlot4.setWeight(7);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertNotNull(timeline15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        org.jfree.chart.util.ObjectList objectList11 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot17.zoomDomainAxes((double) 100, plotRenderingInfo19, point2D20, false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot17.setDataset((int) (short) 0, xYDataset24);
        xYPlot17.setRangeGridlinesVisible(false);
        xYPlot17.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        xYPlot17.setRangeAxis(valueAxis29);
        objectList11.set(1, (java.lang.Object) xYPlot17);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean36 = valueMarker34.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker34.setLabelOffset(rectangleInsets37);
        java.awt.Stroke stroke39 = valueMarker34.getOutlineStroke();
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str41 = layer40.toString();
        boolean boolean42 = xYPlot17.removeDomainMarker(6, (org.jfree.chart.plot.Marker) valueMarker34, layer40);
        java.util.Collection collection43 = categoryPlot0.getDomainMarkers(500, layer40);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Layer.FOREGROUND" + "'", str41.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(collection43);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        xYPlot4.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot4.getRangeAxisLocation(7);
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot4.getDataset(7);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(xYDataset26);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Font font13 = numberAxis11.getLabelFont();
        java.awt.Font font14 = numberAxis11.getTickLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font14);
        categoryAxis0.setLowerMargin((double) (short) 10);
        double double18 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getOutlineStroke();
        xYPlot4.zoom((double) 1.0f);
        boolean boolean8 = xYPlot4.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setDomainCrosshairVisible(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot4);
        xYPlot4.clearDomainMarkers();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getRangeMarkers(11, layer34);
        categoryPlot32.clearRangeMarkers((-1));
        java.awt.Paint paint38 = categoryPlot32.getRangeCrosshairPaint();
        categoryPlot32.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        int int19 = xYPlot10.getDatasetCount();
        boolean boolean20 = xYPlot10.isRangeCrosshairVisible();
        java.awt.Paint paint21 = xYPlot10.getBackgroundPaint();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot26.zoomDomainAxes((double) 100, plotRenderingInfo28, point2D29, false);
        xYPlot26.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        xYPlot26.setRangeAxis(1, valueAxis34, false);
        java.awt.Color color37 = java.awt.Color.red;
        xYPlot26.setRangeTickBandPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot26.getDomainAxisEdge(500);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color42, stroke43);
        xYPlot26.setDomainGridlineStroke(stroke43);
        xYPlot10.setDomainCrosshairStroke(stroke43);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot10.notifyListeners(plotChangeEvent16);
        java.awt.Paint paint18 = xYPlot10.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot10.getAxisOffset();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot26.zoomDomainAxes((double) 100, plotRenderingInfo28, point2D29, false);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        xYPlot26.setDataset((int) (short) 0, xYDataset33);
        xYPlot26.setRangeGridlinesVisible(false);
        xYPlot26.clearRangeAxes();
        java.lang.String str38 = xYPlot26.getPlotType();
        xYPlot26.configureRangeAxes();
        java.awt.Paint[] paintArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray49 = new java.awt.Stroke[] { stroke43, stroke44, stroke45, stroke46, stroke47, stroke48 };
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray40, paintArray41, strokeArray42, strokeArray49, shapeArray50);
        java.awt.Paint paint52 = defaultDrawingSupplier51.getNextPaint();
        xYPlot26.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        valueMarker55.setLabelTextAnchor(textAnchor56);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot26.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker55, layer58);
        java.util.Collection collection60 = xYPlot10.getRangeMarkers(layer58);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "XY Plot" + "'", str38.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(paintArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(strokeArray49);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection60);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat4 = dateAxis3.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis3.setTickUnit(dateTickUnit5, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot14.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        int int17 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis16);
        java.awt.Font font18 = numberAxis16.getLabelFont();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        java.util.List list23 = numberAxis16.refreshTicks(graphics2D19, axisState20, rectangle2D21, rectangleEdge22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis16.getTickLabelInsets();
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis16.setRange(range25);
        dateAxis9.setRange(range25, true, true);
        dateAxis3.setRange(range25);
        dateAxis0.setRange(range25, false, true);
        java.awt.Font font34 = dateAxis0.getLabelFont();
        dateAxis0.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setDomainCrosshairVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot4.setDatasetRenderingOrder(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        xYPlot4.setRangeAxisLocation((int) (short) 1, axisLocation16);
        double double18 = xYPlot4.getRangeCrosshairValue();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabelAngle((double) (short) 10);
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis20.setRangeWithMargins((org.jfree.data.Range) dateRange23, false, false);
        numberAxis20.setUpperBound((double) '#');
        numberAxis20.setLabelAngle(0.0d);
        java.awt.Font font31 = numberAxis20.getLabelFont();
        xYPlot4.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis20, false);
        java.awt.Stroke stroke34 = xYPlot4.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        double double2 = categoryPlot0.getAnchorValue();
        double double3 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        numberAxis6.setTickMarksVisible(true);
        numberAxis6.setLowerMargin((double) 100.0f);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.lang.Object obj2 = null;
        boolean boolean3 = dateAxis0.equals(obj2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat5 = dateAxis4.getDateFormatOverride();
        boolean boolean7 = dateAxis4.isHiddenValue(0L);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis4.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getDomainAxisLocation(0);
        categoryPlot0.setDomainAxisLocation(255, axisLocation5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        try {
            dateAxis0.setRange((double) (short) 1, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.awt.Color color0 = java.awt.Color.blue;
        java.awt.Color color3 = java.awt.Color.getColor("Layer.FOREGROUND", 500);
        boolean boolean4 = color0.equals((java.lang.Object) color3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace5);
        boolean boolean7 = xYPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        xYPlot4.drawAnnotations(graphics2D8, rectangle2D9, plotRenderingInfo10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 0);
        double double3 = intervalMarker2.getStartValue();
        double double4 = intervalMarker2.getStartValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.plot.Marker marker6 = markerChangeEvent5.getMarker();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertNotNull(marker6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairVisible(false);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(2019, categoryItemRenderer14);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes((double) 100, plotRenderingInfo25, point2D26, false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot23.setDataset((int) (short) 0, xYDataset30);
        xYPlot23.setRangeGridlinesVisible(false);
        xYPlot23.clearRangeAxes();
        int int35 = xYPlot23.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot23.setFixedDomainAxisSpace(axisSpace36);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font43 = numberAxis42.getTickLabelFont();
        java.awt.Shape shape44 = numberAxis42.getUpArrow();
        numberAxis38.setDownArrow(shape44);
        org.jfree.data.Range range46 = xYPlot23.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis38);
        numberAxis38.resizeRange(0.0d, 1.0E-8d);
        boolean boolean50 = numberAxis38.getAutoRangeIncludesZero();
        numberAxis38.centerRange(0.05d);
        xYPlot4.setDomainAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis38);
        boolean boolean54 = xYPlot4.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = xYPlot4.getNoDataMessagePaint();
        xYPlot4.clearRangeMarkers();
        xYPlot4.zoom((double) '#');
        xYPlot4.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot8.setDataset((int) (short) 0, xYDataset15);
        xYPlot8.setRangeGridlinesVisible(false);
        xYPlot8.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot8.removeChangeListener(plotChangeListener20);
        xYPlot8.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot28.getRangeAxisLocation();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color31, stroke32);
        xYPlot28.setDomainCrosshairStroke(stroke32);
        xYPlot8.setRangeCrosshairStroke(stroke32);
        java.awt.Color color38 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean42 = valueMarker40.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.Marker marker44 = markerChangeEvent43.getMarker();
        marker44.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot51.zoomDomainAxes((double) 100, plotRenderingInfo53, point2D54, false);
        xYPlot51.clearAnnotations();
        xYPlot51.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color62 = java.awt.Color.WHITE;
        int int63 = color62.getBlue();
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color62.createContext(colorModel64, rectangle65, rectangle2D66, affineTransform67, renderingHints68);
        categoryMarker61.setOutlinePaint((java.awt.Paint) color62);
        xYPlot51.setNoDataMessagePaint((java.awt.Paint) color62);
        java.awt.Image image72 = null;
        xYPlot51.setBackgroundImage(image72);
        java.awt.Stroke stroke74 = xYPlot51.getRangeCrosshairStroke();
        marker44.setOutlineStroke(stroke74);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) 2019, (java.awt.Paint) color2, stroke32, (java.awt.Paint) color38, stroke74, 0.0f);
        java.awt.Font font78 = intervalMarker77.getLabelFont();
        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean82 = valueMarker80.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke83 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker80.setStroke(stroke83);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = valueMarker80.getLabelOffsetType();
        intervalMarker77.setLabelOffsetType(lengthAdjustmentType85);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent87 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker77);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer88 = null;
        intervalMarker77.setGradientPaintTransformer(gradientPaintTransformer88);
        java.lang.String str90 = intervalMarker77.getLabel();
        intervalMarker77.setStartValue((double) 500);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(marker44);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(lengthAdjustmentType85);
        org.junit.Assert.assertNull(str90);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        boolean boolean2 = dateAxis0.isAutoRange();
        java.util.Date date3 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat5 = dateAxis4.getDateFormatOverride();
        java.util.TimeZone timeZone6 = dateAxis4.getTimeZone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3, timeZone6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot13.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        int int16 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        java.awt.Font font17 = numberAxis15.getLabelFont();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        java.util.List list22 = numberAxis15.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge21);
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis15.setRange((org.jfree.data.Range) dateRange23, true, true);
        dateAxis8.setRange((org.jfree.data.Range) dateRange23, false, true);
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double33 = rectangleInsets32.getTop();
        double double34 = rectangleInsets32.getLeft();
        boolean boolean35 = day31.equals((java.lang.Object) rectangleInsets32);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        xYPlot40.setFixedRangeAxisSpace(axisSpace41);
        int int43 = day31.compareTo((java.lang.Object) xYPlot40);
        xYPlot40.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean49 = valueMarker47.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker47);
        org.jfree.chart.plot.Marker marker51 = markerChangeEvent50.getMarker();
        java.lang.Object obj52 = markerChangeEvent50.getSource();
        xYPlot40.markerChanged(markerChangeEvent50);
        java.awt.Image image54 = xYPlot40.getBackgroundImage();
        boolean boolean55 = dateAxis8.hasListener((java.util.EventListener) xYPlot40);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat57 = dateAxis56.getDateFormatOverride();
        java.util.TimeZone timeZone58 = dateAxis56.getTimeZone();
        dateAxis8.setTimeZone(timeZone58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date3, timeZone58);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(dateFormat5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 8.0d + "'", double34 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(marker51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNull(image54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(dateFormat57);
        org.junit.Assert.assertNotNull(timeZone58);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke21, stroke22, stroke23, stroke24, stroke25, stroke26 };
        java.awt.Shape[] shapeArray28 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray19, strokeArray20, strokeArray27, shapeArray28);
        java.awt.Paint paint30 = defaultDrawingSupplier29.getNextPaint();
        xYPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        valueMarker33.setLabelTextAnchor(textAnchor34);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker33, layer36);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.chart.plot.Plot plot39 = plotChangeEvent38.getPlot();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNotNull(plot39);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        java.awt.Stroke stroke18 = xYPlot4.getDomainZeroBaselineStroke();
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Color color22 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        boolean boolean23 = color19.equals((java.lang.Object) ' ');
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot29.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        int int32 = xYPlot29.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.awt.Font font33 = numberAxis31.getLabelFont();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.axis.AxisState axisState35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        java.util.List list38 = numberAxis31.refreshTicks(graphics2D34, axisState35, rectangle2D36, rectangleEdge37);
        numberAxis31.setAutoRangeStickyZero(true);
        java.lang.String str41 = numberAxis31.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font44 = valueMarker43.getLabelFont();
        java.awt.Font font45 = valueMarker43.getLabelFont();
        numberAxis31.setLabelFont(font45);
        java.awt.Stroke stroke47 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        numberAxis48.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font53 = numberAxis52.getTickLabelFont();
        java.awt.Shape shape54 = numberAxis52.getUpArrow();
        numberAxis48.setDownArrow(shape54);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font57 = numberAxis56.getTickLabelFont();
        java.awt.Shape shape58 = numberAxis56.getUpArrow();
        numberAxis48.setLeftArrow(shape58);
        numberAxis31.setUpArrow(shape58);
        boolean boolean61 = numberAxis31.isVerticalTickLabels();
        int int62 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        int int63 = xYPlot4.getDomainAxisCount();
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        numberAxis6.setTickLabelsVisible(false);
        org.jfree.data.RangeType rangeType20 = numberAxis6.getRangeType();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(rangeType20);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        java.awt.Stroke stroke30 = xYPlot29.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = xYPlot29.getFixedLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = xYPlot29.getLegendItems();
        xYPlot4.setFixedLegendItems(legendItemCollection32);
        java.awt.Paint paint34 = xYPlot4.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener2 = null;
        valueMarker1.removeChangeListener(markerChangeListener2);
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color6 = java.awt.Color.WHITE;
        int int7 = color6.getBlue();
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color6.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        categoryMarker5.setOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint15 = categoryMarker5.getPaint();
        valueMarker1.setPaint(paint15);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        java.awt.Font font21 = valueMarker18.getLabelFont();
        valueMarker1.setLabelFont(font21);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = xYPlot4.getRangeZeroBaselinePaint();
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot17.getRangeAxisLocation();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color20, stroke21);
        xYPlot17.setDomainCrosshairStroke(stroke21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot17);
        xYPlot4.notifyListeners(plotChangeEvent24);
        try {
            xYPlot4.setBackgroundImageAlpha((float) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setRangeAxisLocation(10, axisLocation18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.CrosshairState crosshairState24 = null;
        boolean boolean25 = xYPlot4.render(graphics2D20, rectangle2D21, (int) ' ', plotRenderingInfo23, crosshairState24);
        xYPlot4.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
//        boolean boolean2 = day0.equals((java.lang.Object) rectangleAnchor1);
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(rectangleAnchor1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
//        boolean boolean2 = day0.equals((java.lang.Object) rectangleAnchor1);
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(rectangleAnchor1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.lang.String str20 = xYPlot4.getPlotType();
        xYPlot4.setDomainCrosshairLockedOnData(true);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 0);
        double double27 = intervalMarker26.getStartValue();
        double double28 = intervalMarker26.getStartValue();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot33.zoomDomainAxes((double) 100, plotRenderingInfo35, point2D36, false);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot33.setDataset((int) (short) 0, xYDataset40);
        xYPlot33.setRangeGridlinesVisible(false);
        xYPlot33.clearRangeAxes();
        java.lang.String str45 = xYPlot33.getPlotType();
        xYPlot33.configureRangeAxes();
        xYPlot33.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        java.awt.geom.Point2D point2D51 = null;
        xYPlot33.zoomDomainAxes((double) 5, plotRenderingInfo50, point2D51, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color56 = java.awt.Color.WHITE;
        int int57 = color56.getBlue();
        java.awt.image.ColorModel colorModel58 = null;
        java.awt.Rectangle rectangle59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        java.awt.geom.AffineTransform affineTransform61 = null;
        java.awt.RenderingHints renderingHints62 = null;
        java.awt.PaintContext paintContext63 = color56.createContext(colorModel58, rectangle59, rectangle2D60, affineTransform61, renderingHints62);
        categoryMarker55.setOutlinePaint((java.awt.Paint) color56);
        java.awt.Paint paint65 = categoryMarker55.getPaint();
        org.jfree.chart.util.Layer layer66 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean67 = xYPlot33.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker55, layer66);
        boolean boolean68 = xYPlot4.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker26, layer66);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "XY Plot" + "'", str20.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "XY Plot" + "'", str45.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 255 + "'", int57 == 255);
        org.junit.Assert.assertNotNull(paintContext63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(layer66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        int int15 = xYPlot4.getDomainAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean20 = valueMarker18.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker18.setStroke(stroke21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = valueMarker18.getLabelOffsetType();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot28.zoomDomainAxes((double) 100, plotRenderingInfo30, point2D31, false);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        xYPlot28.setDataset((int) (short) 0, xYDataset35);
        xYPlot28.setRangeGridlinesVisible(false);
        xYPlot28.clearRangeAxes();
        java.lang.String str40 = xYPlot28.getPlotType();
        xYPlot28.configureRangeAxes();
        java.awt.Paint[] paintArray42 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray43 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray44 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray51 = new java.awt.Stroke[] { stroke45, stroke46, stroke47, stroke48, stroke49, stroke50 };
        java.awt.Shape[] shapeArray52 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier53 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray42, paintArray43, strokeArray44, strokeArray51, shapeArray52);
        java.awt.Paint paint54 = defaultDrawingSupplier53.getNextPaint();
        xYPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier53);
        java.awt.Paint paint56 = defaultDrawingSupplier53.getNextFillPaint();
        valueMarker18.setLabelPaint(paint56);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis59.clearCategoryLabelToolTips();
        categoryAxis59.setTickLabelsVisible(true);
        categoryPlot58.setDomainAxis(categoryAxis59);
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat65 = dateAxis64.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = null;
        dateAxis64.setTickUnit(dateTickUnit66, false, true);
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat71 = dateAxis70.getDateFormatOverride();
        java.util.TimeZone timeZone72 = dateAxis70.getTimeZone();
        dateAxis64.setTimeZone(timeZone72);
        org.jfree.chart.axis.DateTickUnit dateTickUnit74 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis64.setTickUnit(dateTickUnit74, false, false);
        boolean boolean78 = categoryPlot58.equals((java.lang.Object) dateAxis64);
        org.jfree.chart.axis.AxisSpace axisSpace79 = categoryPlot58.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryMarker categoryMarker82 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker84 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color85 = java.awt.Color.WHITE;
        int int86 = color85.getBlue();
        java.awt.image.ColorModel colorModel87 = null;
        java.awt.Rectangle rectangle88 = null;
        java.awt.geom.Rectangle2D rectangle2D89 = null;
        java.awt.geom.AffineTransform affineTransform90 = null;
        java.awt.RenderingHints renderingHints91 = null;
        java.awt.PaintContext paintContext92 = color85.createContext(colorModel87, rectangle88, rectangle2D89, affineTransform90, renderingHints91);
        categoryMarker84.setOutlinePaint((java.awt.Paint) color85);
        java.awt.Paint paint94 = categoryMarker84.getPaint();
        org.jfree.chart.util.Layer layer95 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean96 = categoryMarker84.equals((java.lang.Object) layer95);
        boolean boolean97 = categoryPlot58.removeDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker82, layer95);
        xYPlot4.addRangeMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker18, layer95, true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "XY Plot" + "'", str40.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(strokeArray44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(strokeArray51);
        org.junit.Assert.assertNotNull(shapeArray52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNull(dateFormat65);
        org.junit.Assert.assertNull(dateFormat71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNotNull(dateTickUnit74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(axisSpace79);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 255 + "'", int86 == 255);
        org.junit.Assert.assertNotNull(paintContext92);
        org.junit.Assert.assertNotNull(paint94);
        org.junit.Assert.assertNotNull(layer95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean5 = valueMarker3.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker3.setLabelOffset(rectangleInsets6);
        java.awt.Stroke stroke8 = valueMarker3.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot5.zoomDomainAxes((double) 100, plotRenderingInfo7, point2D8, false);
        java.awt.Paint paint11 = xYPlot5.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.cyan;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color16 = java.awt.Color.WHITE;
        int int17 = color16.getBlue();
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color16.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        categoryMarker15.setOutlinePaint((java.awt.Paint) color16);
        java.lang.String str25 = categoryMarker15.getLabel();
        java.awt.Paint[] paintArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray28 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] { stroke29, stroke30, stroke31, stroke32, stroke33, stroke34 };
        java.awt.Shape[] shapeArray36 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray27, strokeArray28, strokeArray35, shapeArray36);
        java.awt.Paint paint38 = defaultDrawingSupplier37.getNextPaint();
        java.awt.Stroke stroke39 = defaultDrawingSupplier37.getNextOutlineStroke();
        categoryMarker15.setOutlineStroke(stroke39);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 128, paint11, stroke12, (java.awt.Paint) color13, stroke39, (float) 1L);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shapeArray36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        java.util.TimeZone timeZone2 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot8.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        int int11 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Font font12 = numberAxis10.getLabelFont();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.util.List list17 = numberAxis10.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis10.getTickLabelInsets();
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis10.setRange(range19);
        dateAxis3.setRange(range19, true, true);
        dateAxis0.setDefaultAutoRange(range19);
        boolean boolean25 = dateAxis0.isAutoRange();
        dateAxis0.setRange((double) (short) -1, (double) 100L);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Image image25 = null;
        xYPlot4.setBackgroundImage(image25);
        java.awt.Stroke stroke27 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        xYPlot4.drawAnnotations(graphics2D30, rectangle2D31, plotRenderingInfo32);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = xYPlot4.getOrientation();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(plotOrientation34);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double12 = rectangleInsets11.getTop();
        double double13 = rectangleInsets11.getLeft();
        boolean boolean14 = day10.equals((java.lang.Object) rectangleInsets11);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot19.setFixedRangeAxisSpace(axisSpace20);
        int int22 = day10.compareTo((java.lang.Object) xYPlot19);
        xYPlot19.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = null;
        xYPlot19.notifyListeners(plotChangeEvent25);
        java.awt.Paint paint27 = xYPlot19.getDomainZeroBaselinePaint();
        java.awt.Font font28 = xYPlot19.getNoDataMessageFont();
        numberAxis6.setTickLabelFont(font28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, valueAxis32, xYItemRenderer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot34.zoomDomainAxes((double) 100, plotRenderingInfo36, point2D37, false);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        xYPlot34.setDataset((int) (short) 0, xYDataset41);
        xYPlot34.setRangeGridlinesVisible(false);
        java.awt.Paint paint45 = xYPlot34.getDomainZeroBaselinePaint();
        java.util.List list46 = xYPlot34.getAnnotations();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot34.setRangeGridlinePaint((java.awt.Paint) color47);
        boolean boolean49 = numberAxis6.hasListener((java.util.EventListener) xYPlot34);
        numberAxis6.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        numberAxis6.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str24 = axisLocation23.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str26 = plotOrientation25.toString();
        java.lang.String str27 = plotOrientation25.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation25);
        try {
            java.util.List list29 = numberAxis6.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str24.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str26.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str27.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        java.util.List list16 = xYPlot4.getAnnotations();
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot4.getDatasetGroup();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot4.zoomDomainAxes((double) 1, (double) (-32384), plotRenderingInfo20, point2D21);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(datasetGroup17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        java.awt.Paint[] paintArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke21, stroke22, stroke23, stroke24, stroke25, stroke26 };
        java.awt.Shape[] shapeArray28 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray19, strokeArray20, strokeArray27, shapeArray28);
        java.awt.Paint paint30 = defaultDrawingSupplier29.getNextPaint();
        xYPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29);
        java.awt.Paint paint32 = defaultDrawingSupplier29.getNextFillPaint();
        java.awt.Paint paint33 = defaultDrawingSupplier29.getNextFillPaint();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot4.getRangeAxisForDataset(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double19 = rectangleInsets17.calculateBottomInset((double) (byte) -1);
        double double20 = rectangleInsets17.getBottom();
        xYPlot4.setInsets(rectangleInsets17, true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines(1);
        boolean boolean3 = categoryAxis0.isTickMarksVisible();
        float float4 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color9, stroke10);
        boolean boolean12 = categoryMarker11.getDrawAsLine();
        java.awt.Paint paint13 = categoryMarker11.getPaint();
        xYPlot4.setRangeTickBandPaint(paint13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot4.getDomainAxisEdge(13);
        org.jfree.data.general.Dataset dataset17 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleEdge16, dataset17);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(xYItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        boolean boolean12 = xYPlot4.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot4.getDomainAxis();
        xYPlot4.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        java.awt.Stroke stroke13 = numberAxis6.getAxisLineStroke();
        numberAxis6.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation(0);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getLeft();
        boolean boolean9 = day5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace15);
        int int17 = day5.compareTo((java.lang.Object) xYPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot14.drawAnnotations(graphics2D18, rectangle2D19, plotRenderingInfo20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) lengthAdjustmentType23);
        xYPlot14.setRangeAxisLocation(axisLocation22);
        xYPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot33.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        int int36 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Font font37 = numberAxis35.getLabelFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis35.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis35.getStandardTickUnits();
        boolean boolean45 = numberAxis35.isPositiveArrowVisible();
        xYPlot14.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot0.getRenderer();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer50);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setRangeAxisLocation(10, axisLocation18);
        xYPlot4.setForegroundAlpha(0.8f);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot4.getDomainAxisEdge();
        int int23 = xYPlot4.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace5);
        boolean boolean7 = xYPlot4.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot4.zoomDomainAxes((double) 100, (double) (short) 0, plotRenderingInfo10, point2D11);
        java.awt.Color color13 = java.awt.Color.green;
        java.awt.Color color16 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        boolean boolean17 = color13.equals((java.lang.Object) ' ');
        xYPlot4.setOutlinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getRangeZeroBaselineStroke();
        xYPlot4.clearRangeAxes();
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        numberAxis0.setRangeWithMargins((double) 3, 4.0d);
        numberAxis0.setPositiveArrowVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat10 = null;
        dateAxis9.setDateFormatOverride(dateFormat10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat13 = dateAxis12.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = null;
        dateAxis12.setTickUnit(dateTickUnit14, false, true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot23.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        int int26 = xYPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis25);
        java.awt.Font font27 = numberAxis25.getLabelFont();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.axis.AxisState axisState29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        java.util.List list32 = numberAxis25.refreshTicks(graphics2D28, axisState29, rectangle2D30, rectangleEdge31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = numberAxis25.getTickLabelInsets();
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis25.setRange(range34);
        dateAxis18.setRange(range34, true, true);
        dateAxis12.setRange(range34);
        dateAxis9.setRange(range34, false, true);
        java.awt.Font font43 = dateAxis9.getLabelFont();
        numberAxis0.setLabelFont(font43);
        org.junit.Assert.assertNull(dateFormat13);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot16.zoomDomainAxes((double) 100, plotRenderingInfo18, point2D19, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot16.setDataset((int) (short) 0, xYDataset23);
        xYPlot16.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot16.getDomainAxis();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color31);
        xYPlot4.setDomainTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot4.zoomRangeAxes((double) (byte) 10, plotRenderingInfo35, point2D36, true);
        java.util.List list39 = xYPlot4.getAnnotations();
        int int40 = xYPlot4.getSeriesCount();
        java.awt.geom.Point2D point2D41 = null;
        try {
            xYPlot4.setQuadrantOrigin(point2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        double double13 = numberAxis6.getUpperBound();
        boolean boolean14 = numberAxis6.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        numberAxis6.setTickLabelInsets(rectangleInsets15);
        numberAxis6.resizeRange((double) 9, (double) (-1));
        numberAxis6.setLowerBound((double) 1560365999999L);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = xYPlot4.equals(obj16);
        xYPlot4.mapDatasetToDomainAxis(0, 500);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset(xYDataset11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot17.zoomDomainAxes((double) 100, plotRenderingInfo19, point2D20, false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot17.setDataset((int) (short) 0, xYDataset24);
        xYPlot17.setRangeGridlinesVisible(false);
        xYPlot17.clearRangeAxes();
        int int29 = xYPlot17.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot17.setFixedDomainAxisSpace(axisSpace30);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font37 = numberAxis36.getTickLabelFont();
        java.awt.Shape shape38 = numberAxis36.getUpArrow();
        numberAxis32.setDownArrow(shape38);
        org.jfree.data.Range range40 = xYPlot17.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis32);
        numberAxis32.resizeRange(0.0d, 1.0E-8d);
        java.awt.Paint paint44 = numberAxis32.getTickLabelPaint();
        numberAxis32.setAutoRangeMinimumSize(0.05d, false);
        boolean boolean48 = numberAxis32.isNegativeArrowVisible();
        xYPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis32);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairVisible(false);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot0.getDomainAxisEdge(3);
        java.awt.Color color16 = java.awt.Color.MAGENTA;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets12.getTop();
        double double14 = rectangleInsets12.getLeft();
        boolean boolean15 = day11.equals((java.lang.Object) rectangleInsets12);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot20.setFixedRangeAxisSpace(axisSpace21);
        int int23 = day11.compareTo((java.lang.Object) xYPlot20);
        xYPlot20.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean29 = valueMarker27.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker27);
        org.jfree.chart.plot.Marker marker31 = markerChangeEvent30.getMarker();
        java.lang.Object obj32 = markerChangeEvent30.getSource();
        xYPlot20.markerChanged(markerChangeEvent30);
        java.awt.Image image34 = xYPlot20.getBackgroundImage();
        java.awt.Image image35 = null;
        xYPlot20.setBackgroundImage(image35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = xYPlot20.getInsets();
        categoryPlot0.setAxisOffset(rectangleInsets37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray40 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer39 };
        categoryPlot0.setRenderers(categoryItemRendererArray40);
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot0.getRowRenderingOrder();
        java.lang.String str43 = sortOrder42.toString();
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(marker31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(categoryItemRendererArray40);
        org.junit.Assert.assertNotNull(sortOrder42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "SortOrder.ASCENDING" + "'", str43.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        xYPlot4.setDrawingSupplier(drawingSupplier22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot28.zoomDomainAxes((double) 100, plotRenderingInfo30, point2D31, false);
        java.awt.Paint paint34 = xYPlot28.getNoDataMessagePaint();
        xYPlot4.setNoDataMessagePaint(paint34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font38 = valueMarker37.getLabelFont();
        valueMarker37.setValue((double) (-1.0f));
        float float41 = valueMarker37.getAlpha();
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker37, layer42);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.8f + "'", float41 == 0.8f);
        org.junit.Assert.assertNotNull(layer42);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomInset((double) (byte) -1);
        double double21 = rectangleInsets18.getBottom();
        xYPlot10.setInsets(rectangleInsets18, true);
        boolean boolean24 = xYPlot10.isDomainZoomable();
        boolean boolean25 = xYPlot10.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        xYPlot4.zoom((double) 1.0f);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font25 = numberAxis24.getTickLabelFont();
        java.awt.Shape shape26 = numberAxis24.getUpArrow();
        boolean boolean27 = numberAxis24.isAutoTickUnitSelection();
        int int28 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot4.setDomainAxisLocation(100, axisLocation30, true);
        xYPlot4.clearRangeMarkers((int) (short) 0);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setRangeAxisLocation(10, axisLocation18);
        xYPlot4.setForegroundAlpha(0.8f);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color23 = color22.darker();
        int int24 = color22.getGreen();
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        xYPlot4.setDrawingSupplier(drawingSupplier22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot28.zoomDomainAxes((double) 100, plotRenderingInfo30, point2D31, false);
        java.awt.Paint paint34 = xYPlot28.getNoDataMessagePaint();
        xYPlot4.setNoDataMessagePaint(paint34);
        java.awt.Stroke stroke36 = xYPlot4.getRangeGridlineStroke();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            xYPlot4.drawOutline(graphics2D37, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        boolean boolean23 = xYPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot18.zoomDomainAxes((double) 100, plotRenderingInfo20, point2D21, false);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot18.setDataset((int) (short) 0, xYDataset25);
        xYPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot18.getDomainAxis();
        java.awt.Color color33 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot18.setRangeZeroBaselinePaint((java.awt.Paint) color33);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot18.getRangeMarkers(layer35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = xYPlot18.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = xYPlot4.getDatasetGroup();
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(datasetGroup21);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        double double2 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearDomainMarkers((int) (short) 100);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot4.getDatasetRenderingOrder();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot4.getRangeMarkers(layer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot4.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNull(collection22);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        int int3 = day1.compareTo((java.lang.Object) color2);
//        long long4 = day1.getMiddleMillisecond();
//        int int5 = day1.getDayOfMonth();
//        long long6 = day1.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(xYItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10);
        boolean boolean12 = xYPlot4.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot4.getDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        xYPlot4.addChangeListener(plotChangeListener14);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        java.awt.Stroke stroke3 = dateAxis0.getTickMarkStroke();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        java.awt.Stroke stroke22 = numberAxis6.getTickMarkStroke();
        boolean boolean23 = numberAxis6.isVisible();
        float float24 = numberAxis6.getTickMarkInsideLength();
        numberAxis6.setVerticalTickLabels(false);
        numberAxis6.setVisible(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font24 = numberAxis23.getTickLabelFont();
        java.awt.Shape shape25 = numberAxis23.getUpArrow();
        numberAxis19.setDownArrow(shape25);
        org.jfree.data.Range range27 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot4.getRangeAxis((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(valueAxis29);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        java.awt.Color color2 = java.awt.Color.WHITE;
//        int int3 = color2.getBlue();
//        java.awt.image.ColorModel colorModel4 = null;
//        java.awt.Rectangle rectangle5 = null;
//        java.awt.geom.Rectangle2D rectangle2D6 = null;
//        java.awt.geom.AffineTransform affineTransform7 = null;
//        java.awt.RenderingHints renderingHints8 = null;
//        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
//        int int10 = day1.compareTo((java.lang.Object) colorModel4);
//        long long11 = day1.getSerialIndex();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
//        org.junit.Assert.assertNotNull(paintContext9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot32.zoomDomainAxes((double) (byte) -1, (double) 10L, plotRenderingInfo35, point2D36);
        categoryPlot32.setRangeCrosshairValue((double) 0);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot32.getDataset();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            categoryPlot32.drawBackground(graphics2D41, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(categoryDataset40);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        xYPlot4.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot25.getRangeAxisLocation();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color28, stroke29);
        xYPlot25.setDomainCrosshairStroke(stroke29);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot25.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj38 = null;
        boolean boolean39 = axisLocation37.equals(obj38);
        xYPlot25.setRangeAxisLocation((int) 'a', axisLocation37, true);
        xYPlot25.setWeight(0);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font46 = valueMarker45.getLabelFont();
        valueMarker45.setValue((double) (-1.0f));
        float float49 = valueMarker45.getAlpha();
        java.lang.Object obj50 = valueMarker45.clone();
        java.lang.String str51 = valueMarker45.getLabel();
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset52, valueAxis53, valueAxis54, xYItemRenderer55);
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot56.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        int int59 = xYPlot56.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis58);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent60 = null;
        xYPlot56.rendererChanged(rendererChangeEvent60);
        org.jfree.data.general.DatasetGroup datasetGroup62 = xYPlot56.getDatasetGroup();
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) 0);
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline67 = dateAxis66.getTimeline();
        boolean boolean68 = layer65.equals((java.lang.Object) timeline67);
        xYPlot56.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker64, layer65);
        xYPlot25.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker45, layer65);
        try {
            xYPlot4.addDomainMarker((int) (byte) 100, marker20, layer65, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.8f + "'", float49 == 0.8f);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNull(datasetGroup62);
        org.junit.Assert.assertNotNull(layer65);
        org.junit.Assert.assertNotNull(timeline67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean5 = valueMarker3.equals((java.lang.Object) 1L);
        java.lang.String str6 = valueMarker3.getLabel();
        java.awt.Stroke stroke7 = valueMarker3.getStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker3.setLabelAnchor(rectangleAnchor8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        markerChangeEvent10.setType(chartChangeEventType11);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        xYPlot4.setDrawingSupplier(drawingSupplier22);
        xYPlot4.clearRangeMarkers(11);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        double double13 = numberAxis6.getUpperBound();
        numberAxis6.setRangeWithMargins(0.0d, (double) 1560452399999L);
        numberAxis6.resizeRange((double) 7);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.lang.Object obj6 = categoryAxis0.clone();
        double double7 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        int int20 = xYPlot4.getDomainAxisCount();
        java.awt.Font font21 = xYPlot4.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot2.getDomainGridlinePosition();
        double double4 = categoryPlot2.getAnchorValue();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot2.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot2.zoomRangeAxes((double) (short) 0, plotRenderingInfo7, point2D8);
        java.awt.Stroke stroke10 = categoryPlot2.getRangeCrosshairStroke();
        categoryPlot0.setRangeGridlineStroke(stroke10);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot24.getRangeAxisLocation();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color27, stroke28);
        xYPlot24.setDomainCrosshairStroke(stroke28);
        xYPlot4.setRangeCrosshairStroke(stroke28);
        java.awt.Paint paint32 = xYPlot4.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        numberAxis0.setRangeWithMargins((double) 3, 4.0d);
        numberAxis0.setLabelToolTip("TextAnchor.CENTER_RIGHT");
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis0.setLabelFont(font9);
        boolean boolean11 = numberAxis0.isPositiveArrowVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(markerAxisBand12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis6.setTickUnit(dateTickUnit8, false, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat13 = dateAxis12.getDateFormatOverride();
        java.util.TimeZone timeZone14 = dateAxis12.getTimeZone();
        dateAxis6.setTimeZone(timeZone14);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit16, false, false);
        boolean boolean20 = categoryPlot0.equals((java.lang.Object) dateAxis6);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis21.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot30.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        int int33 = xYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis32);
        java.awt.Font font34 = numberAxis32.getLabelFont();
        java.awt.Font font35 = numberAxis32.getTickLabelFont();
        categoryAxis21.setTickLabelFont((java.lang.Comparable) 3, font35);
        double double37 = categoryAxis21.getCategoryMargin();
        double double38 = categoryAxis21.getFixedDimension();
        categoryPlot0.setDomainAxis(categoryAxis21);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNull(dateFormat13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.2d + "'", double37 == 0.2d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        numberAxis6.setAutoRangeStickyZero(true);
        java.lang.String str16 = numberAxis6.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font19 = valueMarker18.getLabelFont();
        java.awt.Font font20 = valueMarker18.getLabelFont();
        numberAxis6.setLabelFont(font20);
        java.awt.Stroke stroke22 = numberAxis6.getTickMarkStroke();
        numberAxis6.setUpperBound((double) (byte) 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true);
        double double3 = numberAxis0.getLowerBound();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        xYPlot4.configureRangeAxes();
        xYPlot4.clearDomainMarkers((int) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot24.zoomDomainAxes((double) 100, plotRenderingInfo26, point2D27, false);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        xYPlot24.setDataset((int) (short) 0, xYDataset31);
        xYPlot24.setRangeGridlinesVisible(false);
        xYPlot24.clearRangeAxes();
        java.lang.String str36 = xYPlot24.getPlotType();
        xYPlot24.configureRangeAxes();
        xYPlot24.setOutlineVisible(false);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        boolean boolean41 = xYPlot24.isRangeGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color44 = java.awt.Color.WHITE;
        int int45 = color44.getBlue();
        java.awt.image.ColorModel colorModel46 = null;
        java.awt.Rectangle rectangle47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color44.createContext(colorModel46, rectangle47, rectangle2D48, affineTransform49, renderingHints50);
        categoryMarker43.setOutlinePaint((java.awt.Paint) color44);
        java.awt.Paint paint53 = categoryMarker43.getPaint();
        java.awt.Color color54 = java.awt.Color.WHITE;
        int int55 = color54.getBlue();
        java.awt.image.ColorModel colorModel56 = null;
        java.awt.Rectangle rectangle57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.AffineTransform affineTransform59 = null;
        java.awt.RenderingHints renderingHints60 = null;
        java.awt.PaintContext paintContext61 = color54.createContext(colorModel56, rectangle57, rectangle2D58, affineTransform59, renderingHints60);
        categoryMarker43.setLabelPaint((java.awt.Paint) color54);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset63, valueAxis64, valueAxis65, xYItemRenderer66);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        java.awt.geom.Point2D point2D70 = null;
        xYPlot67.zoomDomainAxes((double) 100, plotRenderingInfo69, point2D70, false);
        org.jfree.data.xy.XYDataset xYDataset74 = null;
        xYPlot67.setDataset((int) (short) 0, xYDataset74);
        xYPlot67.setRangeGridlinesVisible(false);
        xYPlot67.clearRangeAxes();
        int int79 = xYPlot67.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace80 = null;
        xYPlot67.setFixedDomainAxisSpace(axisSpace80);
        org.jfree.chart.axis.NumberAxis numberAxis82 = new org.jfree.chart.axis.NumberAxis();
        numberAxis82.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis86 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font87 = numberAxis86.getTickLabelFont();
        java.awt.Shape shape88 = numberAxis86.getUpArrow();
        numberAxis82.setDownArrow(shape88);
        org.jfree.data.Range range90 = xYPlot67.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis82);
        org.jfree.chart.util.Layer layer91 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection92 = xYPlot67.getDomainMarkers(layer91);
        boolean boolean93 = xYPlot24.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker43, layer91);
        java.lang.String str94 = layer91.toString();
        java.util.Collection collection95 = xYPlot4.getDomainMarkers((int) (byte) 100, layer91);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "XY Plot" + "'", str36.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 255 + "'", int45 == 255);
        org.junit.Assert.assertNotNull(paintContext51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 255 + "'", int55 == 255);
        org.junit.Assert.assertNotNull(paintContext61);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(font87);
        org.junit.Assert.assertNotNull(shape88);
        org.junit.Assert.assertNull(range90);
        org.junit.Assert.assertNotNull(layer91);
        org.junit.Assert.assertNull(collection92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "Layer.FOREGROUND" + "'", str94.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection95);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        int int10 = xYPlot4.getWeight();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.text.DateFormat dateFormat2 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER_RIGHT");
        java.awt.Color color5 = java.awt.Color.CYAN;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot12.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        java.awt.Font font16 = numberAxis14.getLabelFont();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis14.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis14.getTickLabelInsets();
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis14.setRange(range23);
        dateAxis7.setRange(range23, true, true);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = dateAxis7.java2DToValue(0.05d, rectangle2D29, rectangleEdge30);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat33 = dateAxis32.getDateFormatOverride();
        java.util.TimeZone timeZone34 = dateAxis32.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone34);
        dateAxis7.setTimeZone(timeZone34);
        dateAxis4.setTimeZone(timeZone34);
        dateAxis0.setTimeZone(timeZone34);
        dateAxis0.setRange(9.0d, (double) 255);
        dateAxis0.resizeRange((double) 255, 105.0d);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 9.223372036854776E18d + "'", double31 == 9.223372036854776E18d);
        org.junit.Assert.assertNull(dateFormat33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(tickUnitSource35);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYPlot4.drawOutline(graphics2D21, rectangle2D22);
        boolean boolean24 = xYPlot4.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis5.setTickUnit(dateTickUnit33);
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis5.getTickUnit();
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(dateTickUnit35);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        double double13 = numberAxis6.getLowerMargin();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        int int15 = xYPlot4.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font17 = numberAxis16.getTickLabelFont();
        java.awt.Shape shape18 = numberAxis16.getUpArrow();
        boolean boolean19 = numberAxis16.isVerticalTickLabels();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis16.setTickLabelFont(font20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = numberAxis16.getTickLabelInsets();
        xYPlot4.setInsets(rectangleInsets22, false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(xYItemRenderer6);
        xYPlot4.setNoDataMessage("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        java.lang.String str12 = xYPlot4.getNoDataMessage();
        java.awt.Color color15 = java.awt.Color.DARK_GRAY;
        java.awt.Color color16 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        float[] floatArray21 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray22 = color15.getColorComponents(colorSpace17, floatArray21);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean26 = valueMarker24.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker24.setStroke(stroke27);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color15, stroke27);
        java.awt.Paint paint30 = categoryMarker29.getPaint();
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean32 = xYPlot4.removeDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker29, layer31);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str12.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=128,g=128,b=255]");
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) 100L, 0.0d, (double) 10, (double) '#');
        boolean boolean8 = dateAxis1.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj20 = null;
        boolean boolean21 = axisLocation19.equals(obj20);
        xYPlot4.setDomainAxisLocation(axisLocation19, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace24, true);
        java.awt.Paint paint27 = xYPlot4.getRangeGridlinePaint();
        xYPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = xYPlot4.getAxisOffset();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getYear();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, 0.2d, (double) 0L, (double) (byte) 10);
        double double7 = rectangleInsets5.trimHeight((double) 1L);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot9.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        int int12 = xYPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.awt.Font font13 = numberAxis11.getLabelFont();
        java.awt.Font font14 = numberAxis11.getTickLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 3, font14);
        double double16 = categoryAxis0.getCategoryMargin();
        double double17 = categoryAxis0.getFixedDimension();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateTopOutset((double) (byte) -1);
        double double22 = rectangleInsets18.extendWidth(0.0d);
        double double23 = rectangleInsets18.getRight();
        double double25 = rectangleInsets18.trimHeight((double) 100L);
        categoryAxis0.setLabelInsets(rectangleInsets18);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setMaximumCategoryLabelLines(1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        double double31 = categoryAxis30.getUpperMargin();
        int int32 = categoryAxis30.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions33 = categoryAxis30.getCategoryLabelPositions();
        categoryAxis27.setCategoryLabelPositions(categoryLabelPositions33);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions33);
        java.lang.Object obj36 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions33);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = numberAxis4.getTickLabelFont();
        java.awt.Shape shape6 = numberAxis4.getUpArrow();
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = numberAxis8.getTickLabelFont();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        numberAxis0.setLeftArrow(shape10);
        boolean boolean12 = numberAxis0.isPositiveArrowVisible();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot17.zoomDomainAxes((double) 100, plotRenderingInfo19, point2D20, false);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot17.setDataset((int) (short) 0, xYDataset24);
        xYPlot17.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot17.getDomainAxis();
        java.awt.Color color32 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot17.setRangeZeroBaselinePaint((java.awt.Paint) color32);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot17.getRangeMarkers(layer34);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, valueAxis39, xYItemRenderer40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = xYPlot41.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        int int44 = xYPlot41.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis43);
        numberAxis43.setAutoRangeMinimumSize((double) 2.0f, false);
        double double48 = numberAxis43.getUpperMargin();
        xYPlot17.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis43);
        numberAxis43.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset52, valueAxis53, valueAxis54, xYItemRenderer55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        xYPlot56.zoomDomainAxes((double) 100, plotRenderingInfo58, point2D59, false);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        xYPlot56.setDataset((int) (short) 0, xYDataset63);
        xYPlot56.setRangeGridlinesVisible(false);
        xYPlot56.clearRangeAxes();
        int int68 = xYPlot56.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        xYPlot56.setFixedDomainAxisSpace(axisSpace69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        java.awt.geom.Point2D point2D73 = null;
        xYPlot56.zoomDomainAxes((double) 100L, plotRenderingInfo72, point2D73, true);
        java.util.Date date76 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date76);
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double79 = rectangleInsets78.getTop();
        double double80 = rectangleInsets78.getLeft();
        boolean boolean81 = day77.equals((java.lang.Object) rectangleInsets78);
        org.jfree.data.xy.XYDataset xYDataset82 = null;
        org.jfree.chart.axis.ValueAxis valueAxis83 = null;
        org.jfree.chart.axis.ValueAxis valueAxis84 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset82, valueAxis83, valueAxis84, xYItemRenderer85);
        org.jfree.chart.axis.AxisSpace axisSpace87 = null;
        xYPlot86.setFixedRangeAxisSpace(axisSpace87);
        int int89 = day77.compareTo((java.lang.Object) xYPlot86);
        xYPlot86.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent92 = null;
        xYPlot86.notifyListeners(plotChangeEvent92);
        java.awt.Paint paint94 = xYPlot86.getDomainZeroBaselinePaint();
        xYPlot56.setDomainGridlinePaint(paint94);
        numberAxis43.setPlot((org.jfree.chart.plot.Plot) xYPlot56);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot56);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(rectangleInsets78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 4.0d + "'", double79 == 4.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 8.0d + "'", double80 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertNotNull(paint94);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation(0);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getLeft();
        boolean boolean9 = day5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace15);
        int int17 = day5.compareTo((java.lang.Object) xYPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot14.drawAnnotations(graphics2D18, rectangle2D19, plotRenderingInfo20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) lengthAdjustmentType23);
        xYPlot14.setRangeAxisLocation(axisLocation22);
        xYPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot33.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        int int36 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Font font37 = numberAxis35.getLabelFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis35.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis35.getStandardTickUnits();
        boolean boolean45 = numberAxis35.isPositiveArrowVisible();
        xYPlot14.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis51.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font56 = categoryAxis51.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.lang.String str57 = categoryAxis51.getLabelToolTip();
        int int58 = categoryPlot0.getDomainAxisIndex(categoryAxis51);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot0.getDomainAxisEdge((-8388608));
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder61 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder61);
        java.lang.String str63 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer50);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(datasetRenderingOrder61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Category Plot" + "'", str63.equals("Category Plot"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Color color2 = java.awt.Color.WHITE;
        int int3 = color2.getBlue();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot8.setDataset((int) (short) 0, xYDataset15);
        xYPlot8.setRangeGridlinesVisible(false);
        xYPlot8.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot8.removeChangeListener(plotChangeListener20);
        xYPlot8.setDomainCrosshairValue((-1.0d));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot28.getRangeAxisLocation();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color31, stroke32);
        xYPlot28.setDomainCrosshairStroke(stroke32);
        xYPlot8.setRangeCrosshairStroke(stroke32);
        java.awt.Color color38 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean42 = valueMarker40.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker40);
        org.jfree.chart.plot.Marker marker44 = markerChangeEvent43.getMarker();
        marker44.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset47, valueAxis48, valueAxis49, xYItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        xYPlot51.zoomDomainAxes((double) 100, plotRenderingInfo53, point2D54, false);
        xYPlot51.clearAnnotations();
        xYPlot51.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color62 = java.awt.Color.WHITE;
        int int63 = color62.getBlue();
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color62.createContext(colorModel64, rectangle65, rectangle2D66, affineTransform67, renderingHints68);
        categoryMarker61.setOutlinePaint((java.awt.Paint) color62);
        xYPlot51.setNoDataMessagePaint((java.awt.Paint) color62);
        java.awt.Image image72 = null;
        xYPlot51.setBackgroundImage(image72);
        java.awt.Stroke stroke74 = xYPlot51.getRangeCrosshairStroke();
        marker44.setOutlineStroke(stroke74);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) 2019, (java.awt.Paint) color2, stroke32, (java.awt.Paint) color38, stroke74, 0.0f);
        java.awt.Font font78 = intervalMarker77.getLabelFont();
        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean82 = valueMarker80.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke83 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker80.setStroke(stroke83);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = valueMarker80.getLabelOffsetType();
        intervalMarker77.setLabelOffsetType(lengthAdjustmentType85);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent87 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker77);
        org.jfree.chart.JFreeChart jFreeChart88 = null;
        markerChangeEvent87.setChart(jFreeChart88);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(marker44);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(lengthAdjustmentType85);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        numberAxis0.setRangeWithMargins((double) 3, 4.0d);
        numberAxis0.setLabelToolTip("TextAnchor.CENTER_RIGHT");
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis0.setLabelFont(font9);
        boolean boolean11 = numberAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color17 = java.awt.Color.WHITE;
        int int18 = color17.getBlue();
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color17.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        categoryMarker16.setOutlinePaint((java.awt.Paint) color17);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str28 = chartChangeEventType27.toString();
        markerChangeEvent26.setType(chartChangeEventType27);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateRange12, jFreeChart14, chartChangeEventType27);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(chartChangeEventType27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str28.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getColorComponents(floatArray2);
        float[] floatArray4 = null;
        float[] floatArray5 = color1.getRGBComponents(floatArray4);
        float[] floatArray6 = color0.getComponents(floatArray4);
        int int7 = color0.getAlpha();
        java.awt.Color color9 = java.awt.Color.DARK_GRAY;
        java.awt.Color color10 = java.awt.Color.getColor("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", color9);
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        java.awt.Color color12 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        float[] floatArray17 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray18 = color11.getColorComponents(colorSpace13, floatArray17);
        java.awt.Color color19 = java.awt.Color.BLACK;
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray21 = null;
        float[] floatArray22 = color20.getColorComponents(floatArray21);
        float[] floatArray23 = null;
        float[] floatArray24 = color20.getRGBComponents(floatArray23);
        float[] floatArray25 = color19.getComponents(floatArray23);
        float[] floatArray26 = color10.getComponents(colorSpace13, floatArray25);
        float[] floatArray27 = color0.getRGBComponents(floatArray25);
        int int28 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-16777216) + "'", int28 == (-16777216));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        int int17 = color15.getBlue();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        boolean boolean2 = dateAxis0.isAutoRange();
        java.util.Date date3 = dateAxis0.getMinimumDate();
        boolean boolean5 = dateAxis0.isHiddenValue((long) (-32384));
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.lang.String str6 = categoryAxis0.getLabelToolTip();
        java.awt.Paint paint7 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean19 = valueMarker17.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        xYPlot10.markerChanged(markerChangeEvent20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot10.getRenderer(13);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(xYItemRenderer25);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        java.awt.Stroke stroke18 = xYPlot4.getDomainZeroBaselineStroke();
        java.awt.Color color19 = java.awt.Color.green;
        java.awt.Color color22 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", (int) ' ');
        boolean boolean23 = color19.equals((java.lang.Object) ' ');
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot29.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        int int32 = xYPlot29.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.awt.Font font33 = numberAxis31.getLabelFont();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.axis.AxisState axisState35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        java.util.List list38 = numberAxis31.refreshTicks(graphics2D34, axisState35, rectangle2D36, rectangleEdge37);
        numberAxis31.setAutoRangeStickyZero(true);
        java.lang.String str41 = numberAxis31.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font44 = valueMarker43.getLabelFont();
        java.awt.Font font45 = valueMarker43.getLabelFont();
        numberAxis31.setLabelFont(font45);
        java.awt.Stroke stroke47 = numberAxis31.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        numberAxis48.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font53 = numberAxis52.getTickLabelFont();
        java.awt.Shape shape54 = numberAxis52.getUpArrow();
        numberAxis48.setDownArrow(shape54);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font57 = numberAxis56.getTickLabelFont();
        java.awt.Shape shape58 = numberAxis56.getUpArrow();
        numberAxis48.setLeftArrow(shape58);
        numberAxis31.setUpArrow(shape58);
        boolean boolean61 = numberAxis31.isVerticalTickLabels();
        int int62 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        xYPlot4.zoomDomainAxes(0.0d, 0.800000011920929d, plotRenderingInfo65, point2D66);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean12 = valueMarker10.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.chart.plot.Marker marker14 = markerChangeEvent13.getMarker();
        marker14.setAlpha((float) 0);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        marker14.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot21);
        int int23 = xYPlot21.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot21.setRangeAxes(valueAxisArray24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getRangeAxisEdge(500);
        try {
            double double28 = categoryAxis0.getCategoryStart(1, (-32384), rectangle2D8, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(marker14);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairVisible(false);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot0.getDomainAxisEdge(3);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot20.zoomDomainAxes((double) 100, plotRenderingInfo22, point2D23, false);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot20.setDataset((int) (short) 0, xYDataset27);
        xYPlot20.setRangeGridlinesVisible(false);
        xYPlot20.clearRangeAxes();
        java.lang.String str32 = xYPlot20.getPlotType();
        xYPlot20.configureRangeAxes();
        xYPlot20.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        xYPlot20.zoomDomainAxes((double) 5, plotRenderingInfo37, point2D38, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color43 = java.awt.Color.WHITE;
        int int44 = color43.getBlue();
        java.awt.image.ColorModel colorModel45 = null;
        java.awt.Rectangle rectangle46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.awt.geom.AffineTransform affineTransform48 = null;
        java.awt.RenderingHints renderingHints49 = null;
        java.awt.PaintContext paintContext50 = color43.createContext(colorModel45, rectangle46, rectangle2D47, affineTransform48, renderingHints49);
        categoryMarker42.setOutlinePaint((java.awt.Paint) color43);
        java.awt.Paint paint52 = categoryMarker42.getPaint();
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean54 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker42, layer53);
        boolean boolean55 = categoryMarker42.getDrawAsLine();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        categoryPlot0.zoomRangeAxes(0.800000011920929d, plotRenderingInfo58, point2D59, false);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "XY Plot" + "'", str32.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
        org.junit.Assert.assertNotNull(paintContext50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis(0);
        boolean boolean8 = xYPlot4.isDomainCrosshairLockedOnData();
        java.awt.Image image9 = null;
        xYPlot4.setBackgroundImage(image9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = xYPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.RIGHT");
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot4.getRenderer((int) (byte) 1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        xYPlot4.notifyListeners(plotChangeEvent13);
        java.awt.Stroke stroke15 = xYPlot4.getOutlineStroke();
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        numberAxis6.setAxisLineVisible(false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        xYPlot21.zoomDomainAxes((double) 100, plotRenderingInfo23, point2D24, false);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        xYPlot21.setDataset((int) (short) 0, xYDataset28);
        xYPlot21.setRangeGridlinesVisible(false);
        xYPlot21.clearRangeAxes();
        int int33 = xYPlot21.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        xYPlot21.setFixedDomainAxisSpace(axisSpace34);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font41 = numberAxis40.getTickLabelFont();
        java.awt.Shape shape42 = numberAxis40.getUpArrow();
        numberAxis36.setDownArrow(shape42);
        org.jfree.data.Range range44 = xYPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis36);
        numberAxis36.resizeRange(0.0d, 1.0E-8d);
        org.jfree.data.Range range48 = numberAxis36.getRange();
        numberAxis6.setRangeWithMargins(range48);
        float float50 = numberAxis6.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 2.0f + "'", float50 == 2.0f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        int int16 = xYPlot4.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace17);
        double double19 = xYPlot4.getDomainCrosshairValue();
        int int20 = xYPlot4.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font3 = valueMarker2.getLabelFont();
        valueMarker2.setValue((double) (-1.0f));
        float float6 = valueMarker2.getAlpha();
        java.lang.Object obj7 = valueMarker2.clone();
        boolean boolean8 = seriesRenderingOrder0.equals(obj7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.8f + "'", float6 == 0.8f);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj20 = null;
        boolean boolean21 = axisLocation19.equals(obj20);
        xYPlot4.setDomainAxisLocation(axisLocation19, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace24, true);
        xYPlot4.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot33.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        int int36 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Font font37 = numberAxis35.getLabelFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis35.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        numberAxis35.setAutoRangeStickyZero(true);
        java.lang.String str45 = numberAxis35.getLabel();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font48 = valueMarker47.getLabelFont();
        java.awt.Font font49 = valueMarker47.getLabelFont();
        numberAxis35.setLabelFont(font49);
        java.awt.Stroke stroke51 = numberAxis35.getTickMarkStroke();
        xYPlot4.setRangeGridlineStroke(stroke51);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.clearDomainAxes();
        java.awt.Paint paint20 = xYPlot4.getQuadrantPaint(0);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot25.getRangeAxisLocation();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color28, stroke29);
        xYPlot25.setDomainCrosshairStroke(stroke29);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Color color33 = java.awt.Color.WHITE;
        int int34 = color33.getBlue();
        java.awt.image.ColorModel colorModel35 = null;
        java.awt.Rectangle rectangle36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.AffineTransform affineTransform38 = null;
        java.awt.RenderingHints renderingHints39 = null;
        java.awt.PaintContext paintContext40 = color33.createContext(colorModel35, rectangle36, rectangle2D37, affineTransform38, renderingHints39);
        xYPlot25.setDomainZeroBaselinePaint((java.awt.Paint) color33);
        boolean boolean42 = xYPlot4.equals((java.lang.Object) color33);
        xYPlot4.mapDatasetToRangeAxis(11, (int) (short) 100);
        org.jfree.chart.plot.Plot plot46 = xYPlot4.getParent();
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertNotNull(paintContext40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(plot46);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(9.0d, (double) 3, (-8388616.0d), (double) 1560495599999L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot4.getRenderer((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot17.zoomDomainAxes((double) 100, plotRenderingInfo19, point2D20, false);
        xYPlot17.clearAnnotations();
        xYPlot17.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color28 = java.awt.Color.WHITE;
        int int29 = color28.getBlue();
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color28.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        categoryMarker27.setOutlinePaint((java.awt.Paint) color28);
        xYPlot17.setNoDataMessagePaint((java.awt.Paint) color28);
        java.awt.Image image38 = null;
        xYPlot17.setBackgroundImage(image38);
        java.awt.Stroke stroke40 = xYPlot17.getRangeCrosshairStroke();
        xYPlot4.setRangeCrosshairStroke(stroke40);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot5.zoomDomainAxes((double) 100, plotRenderingInfo7, point2D8, false);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot5.setDataset((int) (short) 0, xYDataset12);
        xYPlot5.setRangeGridlinesVisible(false);
        xYPlot5.clearRangeAxes();
        java.lang.String str17 = xYPlot5.getPlotType();
        xYPlot5.configureRangeAxes();
        xYPlot5.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = xYPlot5.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        int int8 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.awt.Font font9 = numberAxis7.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis7.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis7.getTickLabelInsets();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis7.setRange(range16);
        dateAxis0.setRange(range16, true, true);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis0.java2DToValue(0.05d, rectangle2D22, rectangleEdge23);
        org.jfree.chart.plot.Plot plot25 = null;
        dateAxis0.setPlot(plot25);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.223372036854776E18d + "'", double24 == 9.223372036854776E18d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Paint paint15 = xYPlot4.getRangeGridlinePaint();
        java.awt.Paint paint16 = xYPlot4.getBackgroundPaint();
        java.awt.Image image17 = xYPlot4.getBackgroundImage();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(image17);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot4.setDomainGridlinePaint(paint16);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot4.getRenderer((int) '#');
        int int23 = xYPlot4.getDatasetCount();
        int int24 = xYPlot4.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.Point2D point2D27 = null;
        org.jfree.chart.plot.PlotState plotState28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            xYPlot4.draw(graphics2D25, rectangle2D26, point2D27, plotState28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        categoryPlot0.setDataset((int) (short) 10, categoryDataset3);
        boolean boolean5 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes((double) 100, plotRenderingInfo8, point2D9, false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot6.setDataset((int) (short) 0, xYDataset13);
        xYPlot6.setRangeGridlinesVisible(false);
        xYPlot6.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        xYPlot6.setRangeAxis(valueAxis18);
        objectList0.set(1, (java.lang.Object) xYPlot6);
        java.awt.Paint paint21 = xYPlot6.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SortOrder.ASCENDING");
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setAutoTickUnitSelection(true, false);
        numberAxis1.setRangeWithMargins((double) 3, 4.0d);
        numberAxis1.setLabelToolTip("TextAnchor.CENTER_RIGHT");
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis1.setLabelFont(font10);
        java.awt.Paint paint12 = numberAxis1.getLabelPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        double double14 = categoryAxis13.getUpperMargin();
        java.awt.Stroke stroke15 = categoryAxis13.getAxisLineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "Layer.FOREGROUND", paint12, stroke15);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = numberAxis4.getTickLabelFont();
        java.awt.Shape shape6 = numberAxis4.getUpArrow();
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font9 = numberAxis8.getTickLabelFont();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        numberAxis0.setLeftArrow(shape10);
        numberAxis0.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        categoryPlot0.setAnchorValue((double) 'a', false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, plotRenderingInfo8, point2D9);
        org.junit.Assert.assertNotNull(categoryAnchor1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot10.drawAnnotations(graphics2D14, rectangle2D15, plotRenderingInfo16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomInset((double) (byte) -1);
        double double21 = rectangleInsets18.getBottom();
        xYPlot10.setInsets(rectangleInsets18, true);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot29.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        xYPlot29.setDataset((int) (short) 0, xYDataset36);
        xYPlot29.setRangeGridlinesVisible(false);
        xYPlot29.clearRangeAxes();
        int int41 = xYPlot29.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        xYPlot29.setFixedDomainAxisSpace(axisSpace42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font49 = numberAxis48.getTickLabelFont();
        java.awt.Shape shape50 = numberAxis48.getUpArrow();
        numberAxis44.setDownArrow(shape50);
        org.jfree.data.Range range52 = xYPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis44);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection54 = xYPlot29.getDomainMarkers(layer53);
        java.util.Collection collection55 = xYPlot10.getRangeMarkers(0, layer53);
        java.awt.Paint paint56 = xYPlot10.getDomainZeroBaselinePaint();
        boolean boolean57 = xYPlot10.isSubplot();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        xYPlot4.setDataset(xYDataset22);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot4.getDatasetRenderingOrder();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray23 = null;
        float[] floatArray24 = color22.getColorComponents(floatArray23);
        int int25 = color22.getRed();
        xYPlot4.setQuadrantPaint(0, (java.awt.Paint) color22);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot32.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        int int35 = xYPlot32.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Font font36 = numberAxis34.getLabelFont();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.axis.AxisState axisState38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        java.util.List list41 = numberAxis34.refreshTicks(graphics2D37, axisState38, rectangle2D39, rectangleEdge40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = numberAxis34.getTickLabelInsets();
        xYPlot4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.lang.Object obj44 = numberAxis34.clone();
        java.lang.String str45 = numberAxis34.getLabelToolTip();
        java.lang.Object obj46 = numberAxis34.clone();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        numberAxis6.setRangeWithMargins((double) (-32384), 0.2d);
        double double21 = numberAxis6.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-8d + "'", double21 == 1.0E-8d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double3 = rectangleInsets2.getTop();
        double double4 = rectangleInsets2.getLeft();
        boolean boolean5 = day1.equals((java.lang.Object) rectangleInsets2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace11);
        int int13 = day1.compareTo((java.lang.Object) xYPlot10);
        xYPlot10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean19 = valueMarker17.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        xYPlot10.markerChanged(markerChangeEvent20);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = xYPlot10.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        xYPlot10.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset27, valueAxis28, valueAxis29, xYItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot31.zoomDomainAxes((double) 100, plotRenderingInfo33, point2D34, false);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot31.setDataset((int) (short) 0, xYDataset38);
        xYPlot31.setRangeGridlinesVisible(false);
        xYPlot31.clearRangeAxes();
        java.lang.String str43 = xYPlot31.getPlotType();
        xYPlot31.configureRangeAxes();
        xYPlot31.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        xYPlot31.zoomDomainAxes((double) 5, plotRenderingInfo48, point2D49, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color54 = java.awt.Color.WHITE;
        int int55 = color54.getBlue();
        java.awt.image.ColorModel colorModel56 = null;
        java.awt.Rectangle rectangle57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.awt.geom.AffineTransform affineTransform59 = null;
        java.awt.RenderingHints renderingHints60 = null;
        java.awt.PaintContext paintContext61 = color54.createContext(colorModel56, rectangle57, rectangle2D58, affineTransform59, renderingHints60);
        categoryMarker53.setOutlinePaint((java.awt.Paint) color54);
        java.awt.Paint paint63 = categoryMarker53.getPaint();
        org.jfree.chart.util.Layer layer64 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean65 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker53, layer64);
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset66, valueAxis67, valueAxis68, xYItemRenderer69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        java.awt.geom.Point2D point2D73 = null;
        xYPlot70.zoomDomainAxes((double) 100, plotRenderingInfo72, point2D73, false);
        org.jfree.data.xy.XYDataset xYDataset77 = null;
        xYPlot70.setDataset((int) (short) 0, xYDataset77);
        xYPlot70.setRangeGridlinesVisible(false);
        xYPlot70.clearRangeAxes();
        java.lang.String str82 = xYPlot70.getPlotType();
        xYPlot70.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets84 = xYPlot70.getAxisOffset();
        categoryMarker53.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot70);
        org.jfree.chart.axis.CategoryAxis categoryAxis86 = new org.jfree.chart.axis.CategoryAxis();
        double double87 = categoryAxis86.getUpperMargin();
        java.awt.Stroke stroke88 = categoryAxis86.getAxisLineStroke();
        categoryMarker53.setStroke(stroke88);
        xYPlot10.setRangeZeroBaselineStroke(stroke88);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "XY Plot" + "'", str43.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 255 + "'", int55 == 255);
        org.junit.Assert.assertNotNull(paintContext61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(layer64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "XY Plot" + "'", str82.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets84);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.05d + "'", double87 == 0.05d);
        org.junit.Assert.assertNotNull(stroke88);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairVisible(false);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot0.getDomainAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot19.zoomDomainAxes((double) 100, plotRenderingInfo21, point2D22, false);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot19.setDataset((int) (short) 0, xYDataset26);
        xYPlot19.setRangeGridlinesVisible(false);
        xYPlot19.clearRangeAxes();
        java.lang.String str31 = xYPlot19.getPlotType();
        xYPlot19.configureRangeAxes();
        xYPlot19.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot19.zoomDomainAxes((double) 5, plotRenderingInfo36, point2D37, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color42 = java.awt.Color.WHITE;
        int int43 = color42.getBlue();
        java.awt.image.ColorModel colorModel44 = null;
        java.awt.Rectangle rectangle45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.geom.AffineTransform affineTransform47 = null;
        java.awt.RenderingHints renderingHints48 = null;
        java.awt.PaintContext paintContext49 = color42.createContext(colorModel44, rectangle45, rectangle2D46, affineTransform47, renderingHints48);
        categoryMarker41.setOutlinePaint((java.awt.Paint) color42);
        java.awt.Paint paint51 = categoryMarker41.getPaint();
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean53 = xYPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker41, layer52);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset54, valueAxis55, valueAxis56, xYItemRenderer57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.awt.geom.Point2D point2D61 = null;
        xYPlot58.zoomDomainAxes((double) 100, plotRenderingInfo60, point2D61, false);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        xYPlot58.setDataset((int) (short) 0, xYDataset65);
        xYPlot58.setRangeGridlinesVisible(false);
        xYPlot58.clearRangeAxes();
        java.lang.String str70 = xYPlot58.getPlotType();
        xYPlot58.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = xYPlot58.getAxisOffset();
        categoryMarker41.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot58);
        java.awt.Paint paint74 = categoryMarker41.getOutlinePaint();
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean76 = categoryPlot0.removeDomainMarker((-65536), (org.jfree.chart.plot.Marker) categoryMarker41, layer75);
        org.jfree.chart.plot.ValueMarker valueMarker78 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean80 = valueMarker78.equals((java.lang.Object) 1L);
        java.lang.String str81 = valueMarker78.getLabel();
        java.awt.Stroke stroke82 = valueMarker78.getStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke82);
        org.junit.Assert.assertNotNull(categoryAxis9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "XY Plot" + "'", str31.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertNotNull(paintContext49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "XY Plot" + "'", str70.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNotNull(stroke82);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setMaximumCategoryLabelLines(1);
        boolean boolean12 = categoryAxis9.isTickMarksVisible();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) 0.05d, (java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        categoryAxis18.setTickMarkInsideLength((float) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        double double27 = categoryAxis26.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray28 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9, categoryAxis18, categoryAxis25, categoryAxis26 };
        categoryPlot0.setDomainAxes(categoryAxisArray28);
        double double30 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(categoryAxisArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis6.setTickUnit(dateTickUnit8, false, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat13 = dateAxis12.getDateFormatOverride();
        java.util.TimeZone timeZone14 = dateAxis12.getTimeZone();
        dateAxis6.setTimeZone(timeZone14);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit16, false, false);
        boolean boolean20 = categoryPlot0.equals((java.lang.Object) dateAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color27 = java.awt.Color.WHITE;
        int int28 = color27.getBlue();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        categoryMarker26.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint36 = categoryMarker26.getPaint();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = categoryMarker26.equals((java.lang.Object) layer37);
        boolean boolean39 = categoryPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker24, layer37);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        categoryPlot0.setRangeAxis(valueAxis40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        categoryPlot0.setRenderer(categoryItemRenderer42, false);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNull(dateFormat13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getOutlineStroke();
        java.lang.Object obj6 = xYPlot4.clone();
        java.awt.Paint paint7 = xYPlot4.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = null;
        try {
            xYPlot4.setOrientation(plotOrientation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot32.zoomDomainAxes((double) (byte) -1, (double) 10L, plotRenderingInfo35, point2D36);
        categoryPlot32.setRangeCrosshairValue((double) 0);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot32.getDataset();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot32.getLegendItems();
        categoryPlot32.mapDatasetToDomainAxis(5, 3);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(categoryDataset40);
        org.junit.Assert.assertNotNull(legendItemCollection41);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot4.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot4.getRangeAxisEdge();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color9, stroke10);
        xYPlot4.setDomainCrosshairStroke(stroke10);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0L, (double) 100L, 26.0d, 26.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getDomainAxisLocation(0);
        categoryPlot0.setDomainAxisLocation(255, axisLocation5, true);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getRangeAxisEdge((-65536));
        java.awt.Stroke stroke12 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot32.zoomDomainAxes((double) (byte) -1, (double) 10L, plotRenderingInfo35, point2D36);
        int int38 = categoryPlot32.getRangeAxisCount();
        java.lang.String str39 = categoryPlot32.getPlotType();
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Category Plot" + "'", str39.equals("Category Plot"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font1 = numberAxis0.getTickLabelFont();
        java.awt.Shape shape2 = numberAxis0.getUpArrow();
        boolean boolean3 = numberAxis0.isVerticalTickLabels();
        numberAxis0.setVisible(false);
        boolean boolean6 = numberAxis0.isAutoRange();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        xYPlot4.clearDomainAxes();
        java.awt.Paint paint20 = xYPlot4.getQuadrantPaint(0);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        xYPlot4.setDataset((int) ' ', xYDataset22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot4.zoomDomainAxes((double) (-32384), plotRenderingInfo25, point2D26, false);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis6.setRange((org.jfree.data.Range) dateRange14, true, true);
        numberAxis6.setTickLabelsVisible(false);
        boolean boolean20 = numberAxis6.getAutoRangeIncludesZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = null;
        numberAxis6.setStandardTickUnits(tickUnitSource21);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopInset((double) 10);
        numberAxis6.setLabelInsets(rectangleInsets11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        numberAxis6.setVisible(false);
        numberAxis6.setLabelToolTip("SortOrder.ASCENDING");
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes(100.0d, plotRenderingInfo12, point2D13, true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoTickUnitSelection(true, false);
        int int20 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis16);
        double double21 = numberAxis16.getLowerMargin();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot4.getRenderer((int) '#');
        int int23 = xYPlot4.getDatasetCount();
        int int24 = xYPlot4.getBackgroundImageAlignment();
        boolean boolean25 = xYPlot4.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
        numberAxis0.setRangeWithMargins((double) 3, 4.0d);
        numberAxis0.setLabelToolTip("TextAnchor.CENTER_RIGHT");
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis0.setLabelFont(font9);
        boolean boolean11 = numberAxis0.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange12);
        boolean boolean14 = numberAxis0.isInverted();
        numberAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 0);
        double double3 = intervalMarker2.getEndValue();
        intervalMarker2.setEndValue((double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryMargin((double) (-32384));
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int7 = day5.compareTo((java.lang.Object) color6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        java.awt.Paint paint9 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) regularTimePeriod8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setMaximumCategoryLabelLines(1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        double double14 = categoryAxis13.getUpperMargin();
        int int15 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis13.getCategoryLabelPositions();
        categoryAxis10.setCategoryLabelPositions(categoryLabelPositions16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot27.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        int int30 = xYPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis29);
        java.awt.Font font31 = numberAxis29.getLabelFont();
        java.awt.Font font32 = numberAxis29.getTickLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 3, font32);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray34 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis1, categoryAxis10, categoryAxis18 };
        categoryPlot0.setDomainAxes(categoryAxisArray34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot40.getRangeAxisLocation();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color43, stroke44);
        xYPlot40.setDomainCrosshairStroke(stroke44);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.util.List list49 = null;
        xYPlot40.drawRangeTickBands(graphics2D47, rectangle2D48, list49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double53 = rectangleInsets51.calculateBottomOutset((double) 0);
        xYPlot40.setInsets(rectangleInsets51);
        org.jfree.chart.axis.AxisLocation axisLocation55 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str56 = axisLocation55.toString();
        xYPlot40.setRangeAxisLocation(axisLocation55);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier58 = null;
        xYPlot40.setDrawingSupplier(drawingSupplier58);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset61, valueAxis62, valueAxis63, xYItemRenderer64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Point2D point2D68 = null;
        xYPlot65.zoomDomainAxes((double) 100, plotRenderingInfo67, point2D68, false);
        org.jfree.data.xy.XYDataset xYDataset72 = null;
        xYPlot65.setDataset((int) (short) 0, xYDataset72);
        xYPlot65.setRangeGridlinesVisible(false);
        xYPlot65.clearRangeAxes();
        int int77 = xYPlot65.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot65.setRangeAxisLocation(10, axisLocation79);
        xYPlot40.setRangeAxisLocation((int) (short) 0, axisLocation79);
        categoryPlot0.setRangeAxisLocation(axisLocation79);
        org.jfree.chart.plot.IntervalMarker intervalMarker85 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) 0);
        double double86 = intervalMarker85.getStartValue();
        double double87 = intervalMarker85.getStartValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent88 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker85);
        categoryPlot0.markerChanged(markerChangeEvent88);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(categoryAxisArray34);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 3.0d + "'", double53 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str56.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 2.0d + "'", double86 == 2.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 2.0d + "'", double87 == 2.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis6.setTickUnit(dateTickUnit8, false, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat13 = dateAxis12.getDateFormatOverride();
        java.util.TimeZone timeZone14 = dateAxis12.getTimeZone();
        dateAxis6.setTimeZone(timeZone14);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit16, false, false);
        boolean boolean20 = categoryPlot0.equals((java.lang.Object) dateAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean26 = valueMarker24.equals((java.lang.Object) 1L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = valueMarker24.getLabelOffsetType();
        float float28 = valueMarker24.getAlpha();
        java.awt.Stroke stroke29 = valueMarker24.getOutlineStroke();
        java.awt.Paint paint30 = valueMarker24.getPaint();
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str32 = layer31.toString();
        boolean boolean33 = categoryPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker24, layer31);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNull(dateFormat13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.8f + "'", float28 == 0.8f);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Layer.FOREGROUND" + "'", str32.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        xYPlot4.setWeight((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color15 = java.awt.Color.WHITE;
        int int16 = color15.getBlue();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color15);
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color15);
        java.awt.Image image25 = null;
        xYPlot4.setBackgroundImage(image25);
        java.awt.Image image27 = xYPlot4.getBackgroundImage();
        java.lang.String str28 = xYPlot4.getPlotType();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "XY Plot" + "'", str28.equals("XY Plot"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot4.getDatasetRenderingOrder();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray23 = null;
        float[] floatArray24 = color22.getColorComponents(floatArray23);
        int int25 = color22.getRed();
        xYPlot4.setQuadrantPaint(0, (java.awt.Paint) color22);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot32.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        int int35 = xYPlot32.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Font font36 = numberAxis34.getLabelFont();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.axis.AxisState axisState38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        java.util.List list41 = numberAxis34.refreshTicks(graphics2D37, axisState38, rectangle2D39, rectangleEdge40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = numberAxis34.getTickLabelInsets();
        xYPlot4.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.lang.Object obj44 = numberAxis34.clone();
        java.lang.String str45 = numberAxis34.getLabelToolTip();
        numberAxis34.setRange(0.0d, (double) 10);
        org.jfree.data.Range range49 = numberAxis34.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes(100.0d, plotRenderingInfo12, point2D13, true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoTickUnitSelection(true, false);
        int int20 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        numberAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setDomainCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        xYPlot4.clearRangeAxes();
        xYPlot4.setForegroundAlpha((float) '#');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        xYPlot4.rendererChanged(rendererChangeEvent25);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        java.awt.Stroke stroke20 = xYPlot4.getRangeCrosshairStroke();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYPlot4.drawOutline(graphics2D21, rectangle2D22);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot4.getDomainAxisForDataset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 35 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot4.zoomRangeAxes(100.0d, plotRenderingInfo12, point2D13, true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setAutoTickUnitSelection(true, false);
        int int20 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot26.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        int int29 = xYPlot26.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis28);
        java.awt.Font font30 = numberAxis28.getLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font36 = numberAxis35.getTickLabelFont();
        java.awt.Shape shape37 = numberAxis35.getUpArrow();
        numberAxis31.setDownArrow(shape37);
        numberAxis28.setDownArrow(shape37);
        numberAxis28.setTickLabelsVisible(false);
        xYPlot4.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis28);
        numberAxis28.setAutoRangeMinimumSize(1.0E-8d);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot6.zoomDomainAxes((double) 100, plotRenderingInfo8, point2D9, false);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot6.setDataset((int) (short) 0, xYDataset13);
        xYPlot6.setRangeGridlinesVisible(false);
        xYPlot6.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        xYPlot6.setRangeAxis(valueAxis18);
        objectList0.set(1, (java.lang.Object) xYPlot6);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean25 = valueMarker23.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker23.setLabelOffset(rectangleInsets26);
        java.awt.Stroke stroke28 = valueMarker23.getOutlineStroke();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean31 = xYPlot6.removeDomainMarker(6, (org.jfree.chart.plot.Marker) valueMarker23, layer29);
        xYPlot6.clearDomainMarkers(255);
        double double34 = xYPlot6.getRangeCrosshairValue();
        java.util.List list35 = xYPlot6.getAnnotations();
        float float36 = xYPlot6.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color13, stroke14);
        xYPlot10.setDomainCrosshairStroke(stroke14);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = xYPlot10.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection17);
        java.awt.Paint paint19 = categoryPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        boolean boolean24 = categoryPlot0.render(graphics2D20, rectangle2D21, 2, plotRenderingInfo23);
        java.awt.Paint paint25 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(categoryAnchor26);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = dateAxis0.getTimeZone();
        java.lang.Object obj2 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat7 = dateAxis6.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis6.setTickUnit(dateTickUnit8, false, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat13 = dateAxis12.getDateFormatOverride();
        java.util.TimeZone timeZone14 = dateAxis12.getTimeZone();
        dateAxis6.setTimeZone(timeZone14);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis6.setTickUnit(dateTickUnit16, false, false);
        boolean boolean20 = categoryPlot0.equals((java.lang.Object) dateAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color27 = java.awt.Color.WHITE;
        int int28 = color27.getBlue();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        categoryMarker26.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint36 = categoryMarker26.getPaint();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = categoryMarker26.equals((java.lang.Object) layer37);
        boolean boolean39 = categoryPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker24, layer37);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        categoryPlot0.setRangeAxis(valueAxis40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, valueAxis44, xYItemRenderer45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        xYPlot46.zoomDomainAxes((double) 100, plotRenderingInfo48, point2D49, false);
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        xYPlot46.setDataset((int) (short) 0, xYDataset53);
        xYPlot46.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot46.getDomainAxis();
        java.awt.Color color61 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot46.setRangeZeroBaselinePaint((java.awt.Paint) color61);
        org.jfree.chart.util.Layer layer63 = null;
        java.util.Collection collection64 = xYPlot46.getRangeMarkers(layer63);
        xYPlot46.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = xYPlot46.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets66, true);
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = null;
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot(xYDataset69, valueAxis70, valueAxis71, xYItemRenderer72);
        org.jfree.chart.axis.AxisLocation axisLocation74 = xYPlot73.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis();
        int int76 = xYPlot73.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis75);
        numberAxis75.setAutoRangeMinimumSize((double) 2.0f, false);
        double double80 = numberAxis75.getUpperMargin();
        java.awt.Shape shape81 = numberAxis75.getRightArrow();
        double double82 = numberAxis75.getUpperBound();
        boolean boolean83 = numberAxis75.isTickLabelsVisible();
        numberAxis75.setTickMarkInsideLength((float) 1560538799999L);
        org.jfree.data.Range range86 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis75);
        org.junit.Assert.assertNull(dateFormat7);
        org.junit.Assert.assertNull(dateFormat13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.05d + "'", double80 == 0.05d);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNull(range86);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font5 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 7.0d);
        categoryAxis0.configure();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Stroke stroke16 = xYPlot15.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        xYPlot15.rendererChanged(rendererChangeEvent17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color20, stroke21);
        boolean boolean23 = categoryMarker22.getDrawAsLine();
        java.awt.Paint paint24 = categoryMarker22.getPaint();
        xYPlot15.setRangeTickBandPaint(paint24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot15.getDomainAxisEdge(13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.axis.AxisState axisState29 = categoryAxis0.draw(graphics2D7, 9.223372036854776E18d, rectangle2D9, rectangle2D10, rectangleEdge27, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryMargin((double) (-32384));
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int7 = day5.compareTo((java.lang.Object) color6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        java.awt.Paint paint9 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) regularTimePeriod8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setMaximumCategoryLabelLines(1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        double double14 = categoryAxis13.getUpperMargin();
        int int15 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis13.getCategoryLabelPositions();
        categoryAxis10.setCategoryLabelPositions(categoryLabelPositions16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot27.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        int int30 = xYPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis29);
        java.awt.Font font31 = numberAxis29.getLabelFont();
        java.awt.Font font32 = numberAxis29.getTickLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 3, font32);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray34 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis1, categoryAxis10, categoryAxis18 };
        categoryPlot0.setDomainAxes(categoryAxisArray34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot0.getRangeAxisLocation();
        java.util.List list37 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(categoryAxisArray34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNull(list37);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot4.getDataset();
        xYPlot4.setNoDataMessage("");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        xYPlot4.rendererChanged(rendererChangeEvent19);
        xYPlot4.clearDomainMarkers();
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(xYDataset16);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot7.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        int int10 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Font font11 = numberAxis9.getLabelFont();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis9.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis9.getTickLabelInsets();
        numberAxis9.setTickMarksVisible(true);
        boolean boolean20 = numberAxis9.isAxisLineVisible();
        java.awt.Paint paint21 = numberAxis9.getTickMarkPaint();
        categoryPlot0.setRangeCrosshairPaint(paint21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(axisSpace23);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        java.awt.Paint paint3 = valueMarker1.getPaint();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot8.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11, false);
        java.awt.Paint paint14 = xYPlot8.getNoDataMessagePaint();
        valueMarker1.setPaint(paint14);
        org.jfree.chart.text.TextAnchor textAnchor16 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        double double13 = numberAxis6.getUpperBound();
        boolean boolean14 = numberAxis6.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        numberAxis6.setTickLabelInsets(rectangleInsets15);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis6.getTickUnit();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryMargin((double) (-32384));
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int7 = day5.compareTo((java.lang.Object) color6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        java.awt.Paint paint9 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) regularTimePeriod8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setMaximumCategoryLabelLines(1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        double double14 = categoryAxis13.getUpperMargin();
        int int15 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis13.getCategoryLabelPositions();
        categoryAxis10.setCategoryLabelPositions(categoryLabelPositions16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot27.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        int int30 = xYPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis29);
        java.awt.Font font31 = numberAxis29.getLabelFont();
        java.awt.Font font32 = numberAxis29.getTickLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 3, font32);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray34 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis1, categoryAxis10, categoryAxis18 };
        categoryPlot0.setDomainAxes(categoryAxisArray34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot40.getRangeAxisLocation();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color43, stroke44);
        xYPlot40.setDomainCrosshairStroke(stroke44);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.util.List list49 = null;
        xYPlot40.drawRangeTickBands(graphics2D47, rectangle2D48, list49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double53 = rectangleInsets51.calculateBottomOutset((double) 0);
        xYPlot40.setInsets(rectangleInsets51);
        org.jfree.chart.axis.AxisLocation axisLocation55 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str56 = axisLocation55.toString();
        xYPlot40.setRangeAxisLocation(axisLocation55);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier58 = null;
        xYPlot40.setDrawingSupplier(drawingSupplier58);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset61, valueAxis62, valueAxis63, xYItemRenderer64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Point2D point2D68 = null;
        xYPlot65.zoomDomainAxes((double) 100, plotRenderingInfo67, point2D68, false);
        org.jfree.data.xy.XYDataset xYDataset72 = null;
        xYPlot65.setDataset((int) (short) 0, xYDataset72);
        xYPlot65.setRangeGridlinesVisible(false);
        xYPlot65.clearRangeAxes();
        int int77 = xYPlot65.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot65.setRangeAxisLocation(10, axisLocation79);
        xYPlot40.setRangeAxisLocation((int) (short) 0, axisLocation79);
        categoryPlot0.setRangeAxisLocation(axisLocation79);
        int int83 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(categoryAxisArray34);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 3.0d + "'", double53 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str56.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeMinimumSize((double) 2.0f, false);
        double double11 = numberAxis6.getUpperMargin();
        java.awt.Shape shape12 = numberAxis6.getRightArrow();
        boolean boolean13 = numberAxis6.isInverted();
        java.lang.String str14 = numberAxis6.getLabel();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis6.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        java.lang.String str20 = numberAxis6.getLabelToolTip();
        numberAxis6.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot5.zoomDomainAxes((double) 100, plotRenderingInfo7, point2D8, false);
        xYPlot5.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        xYPlot5.setRangeAxis(1, valueAxis13, false);
        java.awt.Color color16 = java.awt.Color.red;
        xYPlot5.setRangeTickBandPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot5.getDomainAxisEdge(500);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color21, stroke22);
        xYPlot5.setDomainGridlineStroke(stroke22);
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot5.setRangeZeroBaselinePaint(paint25);
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        xYPlot5.setRangeZeroBaselinePaint(paint27);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, valueAxis33, xYItemRenderer34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        xYPlot35.zoomDomainAxes((double) 100, plotRenderingInfo37, point2D38, false);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot35.setDataset((int) (short) 0, xYDataset42);
        xYPlot35.setRangeGridlinesVisible(false);
        xYPlot35.clearRangeAxes();
        int int47 = xYPlot35.getWeight();
        java.awt.Stroke stroke48 = xYPlot35.getRangeCrosshairStroke();
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        boolean boolean51 = textAnchor49.equals((java.lang.Object) stroke50);
        xYPlot35.setRangeGridlineStroke(stroke50);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, paint27, stroke29, paint30, stroke50, (float) 1560538799999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.axis.Timeline timeline33 = dateAxis5.getTimeline();
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeline33);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.configureRangeAxes();
        xYPlot4.setOutlineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot4.zoomDomainAxes((double) 5, plotRenderingInfo21, point2D22, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color27 = java.awt.Color.WHITE;
        int int28 = color27.getBlue();
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color27.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        categoryMarker26.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Paint paint36 = categoryMarker26.getPaint();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot4.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot5.zoomDomainAxes((double) 100, plotRenderingInfo7, point2D8, false);
        xYPlot5.clearAnnotations();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        xYPlot5.axisChanged(axisChangeEvent12);
        xYPlot5.setDomainCrosshairLockedOnData(true);
        java.awt.Color color16 = java.awt.Color.BLUE;
        java.awt.Color color17 = color16.brighter();
        xYPlot5.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes((double) 100, plotRenderingInfo25, point2D26, false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot23.setDataset((int) (short) 0, xYDataset30);
        xYPlot23.setRangeGridlinesVisible(false);
        xYPlot23.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        xYPlot23.setRangeAxis(valueAxis35);
        java.awt.Stroke stroke37 = xYPlot23.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke37);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray17);
        org.jfree.chart.plot.Plot plot19 = xYPlot4.getParent();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = plotChangeEvent20.getType();
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNotNull(xYItemRendererArray17);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickLabelPaint();
        numberAxis6.setLabelAngle((double) 128);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setAutoTickUnitSelection(true, false);
        numberAxis17.setRangeWithMargins((double) 3, 4.0d);
        numberAxis17.setLabelToolTip("TextAnchor.CENTER_RIGHT");
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis17.setLabelFont(font26);
        boolean boolean28 = numberAxis17.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis17.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        org.jfree.data.RangeType rangeType31 = numberAxis17.getRangeType();
        numberAxis6.setRangeType(rangeType31);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(rangeType31);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getDomainAxisLocation(0);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets6.getTop();
        double double8 = rectangleInsets6.getLeft();
        boolean boolean9 = day5.equals((java.lang.Object) rectangleInsets6);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace15);
        int int17 = day5.compareTo((java.lang.Object) xYPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot14.drawAnnotations(graphics2D18, rectangle2D19, plotRenderingInfo20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) lengthAdjustmentType23);
        xYPlot14.setRangeAxisLocation(axisLocation22);
        xYPlot14.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot33.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        int int36 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Font font37 = numberAxis35.getLabelFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = numberAxis35.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickLabelPaint();
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis35.getStandardTickUnits();
        boolean boolean45 = numberAxis35.isPositiveArrowVisible();
        xYPlot14.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis35, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis51.addCategoryLabelToolTip((java.lang.Comparable) (-10.0d), "org.jfree.chart.event.ChartChangeEvent[source=0.05]");
        java.awt.Font font56 = categoryAxis51.getTickLabelFont((java.lang.Comparable) 7.0d);
        java.lang.String str57 = categoryAxis51.getLabelToolTip();
        int int58 = categoryPlot0.getDomainAxisIndex(categoryAxis51);
        java.awt.Color color61 = java.awt.Color.DARK_GRAY;
        java.awt.Color color62 = java.awt.Color.red;
        java.awt.color.ColorSpace colorSpace63 = color62.getColorSpace();
        float[] floatArray67 = new float[] { 'a', (short) -1, 100.0f };
        float[] floatArray68 = color61.getColorComponents(colorSpace63, floatArray67);
        org.jfree.chart.plot.ValueMarker valueMarker70 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean72 = valueMarker70.equals((java.lang.Object) 1L);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker70.setStroke(stroke73);
        org.jfree.chart.plot.CategoryMarker categoryMarker75 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 7.0d, (java.awt.Paint) color61, stroke73);
        org.jfree.chart.util.Layer layer76 = null;
        categoryPlot0.addRangeMarker((int) (short) 0, (org.jfree.chart.plot.Marker) categoryMarker75, layer76, false);
        int int79 = categoryPlot0.getDomainAxisCount();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation82 = categoryPlot0.getDomainAxisLocation((int) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer50);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(colorSpace63);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(axisLocation82);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color13, stroke14);
        xYPlot10.setDomainCrosshairStroke(stroke14);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = xYPlot10.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection17);
        java.awt.Paint paint19 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline23 = dateAxis22.getTimeline();
        boolean boolean24 = layer21.equals((java.lang.Object) timeline23);
        java.util.Collection collection25 = categoryPlot0.getRangeMarkers(0, layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge(0);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(timeline23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0);
        double double4 = rectangleInsets0.calculateLeftOutset(7.0d);
        double double6 = rectangleInsets0.trimHeight(10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        java.lang.String str16 = xYPlot4.getPlotType();
        xYPlot4.setDomainCrosshairVisible(false);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.Point2D point2D21 = null;
        org.jfree.chart.plot.PlotState plotState22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            xYPlot4.draw(graphics2D19, rectangle2D20, point2D21, plotState22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test407");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0);
//        int int3 = day2.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getRangeMarkers(11, layer34);
        categoryPlot32.clearRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(collection35);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        double double17 = xYPlot4.getRangeCrosshairValue();
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double21 = rectangleInsets20.getTop();
        double double22 = rectangleInsets20.getLeft();
        boolean boolean23 = day19.equals((java.lang.Object) rectangleInsets20);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        xYPlot28.setFixedRangeAxisSpace(axisSpace29);
        int int31 = day19.compareTo((java.lang.Object) xYPlot28);
        boolean boolean32 = xYPlot4.equals((java.lang.Object) xYPlot28);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (byte) -1);
        double double37 = rectangleInsets33.extendHeight(8.0d);
        double double39 = rectangleInsets33.calculateLeftInset((double) (-1));
        xYPlot4.setAxisOffset(rectangleInsets33);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 8.0d + "'", double22 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 8.0d + "'", double37 == 8.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = numberAxis6.getTickLabelInsets();
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRange(range15);
        java.awt.Shape shape17 = numberAxis6.getRightArrow();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color19 = color18.brighter();
        numberAxis6.setTickMarkPaint((java.awt.Paint) color18);
        java.awt.color.ColorSpace colorSpace21 = color18.getColorSpace();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace21);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        int int7 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.awt.Font font8 = numberAxis6.getLabelFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = numberAxis6.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font15 = numberAxis14.getTickLabelFont();
        java.awt.Shape shape16 = numberAxis14.getUpArrow();
        boolean boolean17 = numberAxis14.isAutoTickUnitSelection();
        numberAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis14.setTickUnit(numberTickUnit21);
        numberAxis6.setTickUnit(numberTickUnit21, true, false);
        org.jfree.data.Range range26 = null;
        try {
            numberAxis6.setDefaultAutoRange(range26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(numberTickUnit21);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot4.getDataset();
        xYPlot4.setNoDataMessage("");
        xYPlot4.setRangeCrosshairValue((double) (-65536), true);
        float float22 = xYPlot4.getForegroundAlpha();
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = xYPlot4.getNoDataMessagePaint();
        xYPlot4.clearRangeMarkers();
        xYPlot4.zoom((double) '#');
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot4.getOrientation();
        boolean boolean15 = xYPlot4.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        java.awt.Paint paint21 = xYPlot4.getDomainTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace22);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        double double2 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(128);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj17 = null;
        boolean boolean18 = axisLocation16.equals(obj17);
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation16, true);
        xYPlot4.setDomainCrosshairVisible(false);
        boolean boolean23 = xYPlot4.isSubplot();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Paint paint15 = xYPlot4.getDomainZeroBaselinePaint();
        java.util.List list16 = xYPlot4.getAnnotations();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot4.setRangeGridlinePaint((java.awt.Paint) color17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot23.zoomDomainAxes((double) 100, plotRenderingInfo25, point2D26, false);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot23.setDataset((int) (short) 0, xYDataset30);
        xYPlot23.setRangeGridlinesVisible(false);
        xYPlot23.clearRangeAxes();
        int int35 = xYPlot23.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot23.setFixedDomainAxisSpace(axisSpace36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        xYPlot23.zoomDomainAxes((double) 100L, plotRenderingInfo39, point2D40, true);
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double46 = rectangleInsets45.getTop();
        double double47 = rectangleInsets45.getLeft();
        boolean boolean48 = day44.equals((java.lang.Object) rectangleInsets45);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset49, valueAxis50, valueAxis51, xYItemRenderer52);
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        xYPlot53.setFixedRangeAxisSpace(axisSpace54);
        int int56 = day44.compareTo((java.lang.Object) xYPlot53);
        xYPlot53.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent59 = null;
        xYPlot53.notifyListeners(plotChangeEvent59);
        java.awt.Paint paint61 = xYPlot53.getDomainZeroBaselinePaint();
        xYPlot23.setDomainGridlinePaint(paint61);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder63 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot23.setSeriesRenderingOrder(seriesRenderingOrder63);
        xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder63);
        java.lang.Object obj66 = null;
        boolean boolean67 = seriesRenderingOrder63.equals(obj66);
        java.lang.String str68 = seriesRenderingOrder63.toString();
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.0d + "'", double46 == 4.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 8.0d + "'", double47 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(seriesRenderingOrder63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str68.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot4);
        java.awt.Color color12 = java.awt.Color.WHITE;
        int int13 = color12.getBlue();
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color12.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        xYPlot4.setDomainZeroBaselinePaint((java.awt.Paint) color12);
        int int21 = color12.getBlue();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean5 = rectangleAnchor3.equals((java.lang.Object) 100L);
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 100L, (double) 128, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot4.getAxisOffset();
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L);
        java.awt.Color color18 = java.awt.Color.WHITE;
        int int19 = color18.getBlue();
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color18.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        categoryMarker17.setOutlinePaint((java.awt.Paint) color18);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset27, valueAxis28, valueAxis29, xYItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot31.zoomDomainAxes((double) 100, plotRenderingInfo33, point2D34, false);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot31.setDataset((int) (short) 0, xYDataset38);
        xYPlot31.setRangeGridlinesVisible(false);
        xYPlot31.clearRangeAxes();
        java.lang.String str43 = xYPlot31.getPlotType();
        xYPlot31.configureRangeAxes();
        java.awt.Paint[] paintArray45 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray47 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray54 = new java.awt.Stroke[] { stroke48, stroke49, stroke50, stroke51, stroke52, stroke53 };
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray45, paintArray46, strokeArray47, strokeArray54, shapeArray55);
        java.awt.Paint paint57 = defaultDrawingSupplier56.getNextPaint();
        xYPlot31.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier56);
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor61 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        valueMarker60.setLabelTextAnchor(textAnchor61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot31.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker60, layer63);
        java.lang.String str65 = layer63.toString();
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer63);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "XY Plot" + "'", str43.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(paintArray46);
        org.junit.Assert.assertNotNull(strokeArray47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(textAnchor61);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Layer.BACKGROUND" + "'", str65.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        int int13 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Font font14 = numberAxis12.getLabelFont();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis12.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis12.setRange((org.jfree.data.Range) dateRange20, true, true);
        dateAxis5.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis5.zoomRange(10.0d, (double) 100L);
        java.util.Date date30 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot32.zoomDomainAxes((double) (byte) -1, (double) 10L, plotRenderingInfo35, point2D36);
        categoryPlot32.setRangeCrosshairValue((double) 0);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot32.getDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        double double42 = categoryAxis41.getUpperMargin();
        double double43 = categoryAxis41.getCategoryMargin();
        double double44 = categoryAxis41.getFixedDimension();
        java.util.List list45 = categoryPlot32.getCategoriesForAxis(categoryAxis41);
        java.awt.Font font46 = null;
        try {
            categoryPlot32.setNoDataMessageFont(font46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 0.0d, (double) 10, (double) '#');
        java.lang.String str6 = unitType0.toString();
        java.lang.String str7 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 255, 0.0d, 0.0d, (double) 0.0f);
        double double14 = rectangleInsets12.calculateLeftInset((double) 100);
        double double16 = rectangleInsets12.calculateTopOutset((double) 12);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 255.0d + "'", double16 == 255.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.HALF_ASCENT_LEFT");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot10.zoomDomainAxes((double) 100, plotRenderingInfo12, point2D13, false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot10.setDataset((int) (short) 0, xYDataset17);
        xYPlot10.setRangeGridlinesVisible(false);
        xYPlot10.clearRangeAxes();
        java.lang.String str22 = xYPlot10.getPlotType();
        xYPlot10.configureRangeAxes();
        xYPlot10.setOutlineVisible(false);
        java.awt.Stroke stroke26 = xYPlot10.getRangeCrosshairStroke();
        xYPlot10.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot10.getRangeAxisLocation(7);
        categoryPlot5.setDomainAxisLocation(axisLocation30, false);
        int int33 = categoryPlot5.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XY Plot" + "'", str22.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot4.getRangeAxisLocation();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color7, stroke8);
        xYPlot4.setDomainCrosshairStroke(stroke8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot4.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomOutset((double) 0);
        xYPlot4.setInsets(rectangleInsets15);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str20 = axisLocation19.toString();
        xYPlot4.setRangeAxisLocation(axisLocation19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        xYPlot4.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot4.setRenderer(xYItemRenderer24);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        xYPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        xYPlot4.setRangeAxis(valueAxis16);
        boolean boolean18 = xYPlot4.isRangeCrosshairVisible();
        java.awt.Paint paint19 = xYPlot4.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean24 = valueMarker22.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker22);
        org.jfree.chart.plot.Marker marker26 = markerChangeEvent25.getMarker();
        marker26.setAlpha((float) 0);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        marker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot33);
        int int35 = xYPlot33.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot33.setRangeAxes(valueAxisArray36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot33.getRangeAxisEdge(500);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str42 = axisLocation41.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str44 = plotOrientation43.toString();
        java.lang.String str45 = plotOrientation43.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation41, plotOrientation43);
        xYPlot33.setRangeAxisLocation(13, axisLocation41, true);
        xYPlot4.setDomainAxisLocation(3, axisLocation41);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(marker26);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str42.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str44.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str45.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot4.getDomainAxisEdge(500);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color20, stroke21);
        xYPlot4.setDomainGridlineStroke(stroke21);
        boolean boolean24 = xYPlot4.isSubplot();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        xYPlot4.setRangeAxisLocation((int) (short) 1, axisLocation16);
        double double18 = xYPlot4.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot4.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(valueAxis19);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        xYPlot4.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot4.setRangeAxis(1, valueAxis12, false);
        java.awt.Color color15 = java.awt.Color.red;
        xYPlot4.setRangeTickBandPaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot4.getDomainAxisEdge(500);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot4.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(true);
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((int) (byte) 0);
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets12.getTop();
        double double14 = rectangleInsets12.getLeft();
        boolean boolean15 = day11.equals((java.lang.Object) rectangleInsets12);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot20.setFixedRangeAxisSpace(axisSpace21);
        int int23 = day11.compareTo((java.lang.Object) xYPlot20);
        xYPlot20.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean29 = valueMarker27.equals((java.lang.Object) 1L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker27);
        org.jfree.chart.plot.Marker marker31 = markerChangeEvent30.getMarker();
        java.lang.Object obj32 = markerChangeEvent30.getSource();
        xYPlot20.markerChanged(markerChangeEvent30);
        java.awt.Image image34 = xYPlot20.getBackgroundImage();
        java.awt.Image image35 = null;
        xYPlot20.setBackgroundImage(image35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = xYPlot20.getInsets();
        categoryPlot0.setAxisOffset(rectangleInsets37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray40 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer39 };
        categoryPlot0.setRenderers(categoryItemRendererArray40);
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(marker31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(categoryItemRendererArray40);
        org.junit.Assert.assertNotNull(sortOrder42);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean3 = valueMarker1.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        valueMarker1.setLabelOffset(rectangleInsets4);
        double double7 = rectangleInsets4.calculateRightInset((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot4.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot4.setDataset((int) (short) 0, xYDataset11);
        xYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getDomainAxis();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 5, (float) (byte) -1, (float) (-1));
        xYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot4.getRenderer((int) '#');
        int int23 = xYPlot4.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot4.getLegendItems();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(1.0d);
        java.awt.Font font28 = valueMarker27.getLabelFont();
        valueMarker27.setValue((double) (-1.0f));
        float float31 = valueMarker27.getAlpha();
        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double35 = rectangleInsets34.getTop();
        double double36 = rectangleInsets34.getLeft();
        boolean boolean37 = day33.equals((java.lang.Object) rectangleInsets34);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset38, valueAxis39, valueAxis40, xYItemRenderer41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        xYPlot42.setFixedRangeAxisSpace(axisSpace43);
        int int45 = day33.compareTo((java.lang.Object) xYPlot42);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        xYPlot42.drawAnnotations(graphics2D46, rectangle2D47, plotRenderingInfo48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double52 = rectangleInsets50.calculateBottomInset((double) (byte) -1);
        double double53 = rectangleInsets50.getBottom();
        xYPlot42.setInsets(rectangleInsets50, true);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset57, valueAxis58, valueAxis59, xYItemRenderer60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        java.awt.geom.Point2D point2D64 = null;
        xYPlot61.zoomDomainAxes((double) 100, plotRenderingInfo63, point2D64, false);
        org.jfree.data.xy.XYDataset xYDataset68 = null;
        xYPlot61.setDataset((int) (short) 0, xYDataset68);
        xYPlot61.setRangeGridlinesVisible(false);
        xYPlot61.clearRangeAxes();
        int int73 = xYPlot61.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace74 = null;
        xYPlot61.setFixedDomainAxisSpace(axisSpace74);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis();
        numberAxis76.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font81 = numberAxis80.getTickLabelFont();
        java.awt.Shape shape82 = numberAxis80.getUpArrow();
        numberAxis76.setDownArrow(shape82);
        org.jfree.data.Range range84 = xYPlot61.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis76);
        org.jfree.chart.util.Layer layer85 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection86 = xYPlot61.getDomainMarkers(layer85);
        java.util.Collection collection87 = xYPlot42.getRangeMarkers(0, layer85);
        xYPlot4.addDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker27, layer85);
        java.awt.Color color89 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.image.ColorModel colorModel90 = null;
        java.awt.Rectangle rectangle91 = null;
        java.awt.geom.Rectangle2D rectangle2D92 = null;
        java.awt.geom.AffineTransform affineTransform93 = null;
        java.awt.RenderingHints renderingHints94 = null;
        java.awt.PaintContext paintContext95 = color89.createContext(colorModel90, rectangle91, rectangle2D92, affineTransform93, renderingHints94);
        valueMarker27.setLabelPaint((java.awt.Paint) color89);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.8f + "'", float31 == 0.8f);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.0d + "'", double36 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(font81);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNull(range84);
        org.junit.Assert.assertNotNull(layer85);
        org.junit.Assert.assertNull(collection86);
        org.junit.Assert.assertNull(collection87);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(paintContext95);
    }
}

