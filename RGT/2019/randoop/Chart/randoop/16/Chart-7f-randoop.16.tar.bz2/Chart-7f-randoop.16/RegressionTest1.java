import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.previous();
        int int19 = day15.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 11);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues26.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues26.getDomainDescription();
        boolean boolean31 = year22.equals((java.lang.Object) str30);
        long long32 = year22.getSerialIndex();
        java.lang.String str33 = year22.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long37 = simpleTimePeriod36.getStartMillis();
        long long38 = simpleTimePeriod36.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean41 = simpleTimePeriod36.equals((java.lang.Object) timePeriodValues40);
        boolean boolean42 = year22.equals((java.lang.Object) timePeriodValues40);
        long long43 = year22.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 43466L);
        timePeriodValue45.setValue((java.lang.Number) 7L);
        timePeriodValues3.add(timePeriodValue45);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        java.lang.String str26 = year22.toString();
        long long27 = year22.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        timePeriodValues3.setNotify(false);
        timePeriodValues3.fireSeriesChanged();
        int int8 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        boolean boolean17 = timePeriodValues13.isEmpty();
        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
        timePeriodValues13.setDescription("");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
        int int26 = timePeriodValues8.getItemCount();
        boolean boolean27 = day0.equals((java.lang.Object) int26);
        org.jfree.data.time.SerialDate serialDate28 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate29 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues16.fireSeriesChanged();
        int int18 = timePeriodValues16.getMaxStartIndex();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timePeriodValues23.getDomainDescription();
        boolean boolean28 = year19.equals((java.lang.Object) str27);
        long long29 = year19.getSerialIndex();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year19, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year19.next();
        java.util.Date date33 = year19.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues38.fireSeriesChanged();
        int int40 = timePeriodValues38.getMaxStartIndex();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues45.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener47);
        java.lang.String str49 = timePeriodValues45.getDomainDescription();
        boolean boolean50 = year41.equals((java.lang.Object) str49);
        long long51 = year41.getSerialIndex();
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) year41, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year41.next();
        java.util.Date date55 = year41.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date33, date55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.previous();
        timePeriodValues3.setKey((java.lang.Comparable) year57);
        int int60 = year57.getYear();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str14 = timePeriodValues3.getRangeDescription();
        try {
            java.lang.Number number16 = timePeriodValues3.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        long long21 = year0.getSerialIndex();
        java.util.Date date22 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod23, 4.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod23, (java.lang.Number) (-1));
        java.lang.String str28 = timePeriodValue27.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TimePeriodValue[2020,-1]" + "'", str28.equals("TimePeriodValue[2020,-1]"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        long long19 = year6.getLastMillisecond();
        java.lang.String str20 = year6.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year0.previous();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year0.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        try {
            java.lang.Number number6 = timePeriodValues3.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException3.getSuppressed();
        java.lang.String str8 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        timePeriodValues3.setRangeDescription("");
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues15.fireSeriesChanged();
        int int17 = timePeriodValues15.getMaxStartIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues22.getDomainDescription();
        boolean boolean27 = year18.equals((java.lang.Object) str26);
        long long28 = year18.getSerialIndex();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year18, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year18.next();
        java.util.Date date32 = year18.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues37.fireSeriesChanged();
        int int39 = timePeriodValues37.getMaxStartIndex();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues44.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues44.removePropertyChangeListener(propertyChangeListener46);
        java.lang.String str48 = timePeriodValues44.getDomainDescription();
        boolean boolean49 = year40.equals((java.lang.Object) str48);
        long long50 = year40.getSerialIndex();
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) year40, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year40.next();
        java.util.Date date54 = year40.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod(date32, date54);
        boolean boolean56 = timePeriodValues3.equals((java.lang.Object) date32);
        java.lang.Object obj57 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(obj57);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '#', (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue(timePeriod9, (double) 2);
        timePeriodValues3.add(timePeriodValue11);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy(0, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener31);
        boolean boolean33 = timePeriodValues29.isEmpty();
        java.lang.Comparable comparable34 = timePeriodValues29.getKey();
        boolean boolean35 = timePeriodValues29.isEmpty();
        timePeriodValues29.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 4);
        timePeriodValues29.add(timePeriodValue42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (short) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year50.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year50.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod69, (java.lang.Number) 8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        int int15 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable16 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        int int22 = timePeriodValues20.getMaxStartIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues27.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener29);
        java.lang.String str31 = timePeriodValues27.getDomainDescription();
        boolean boolean32 = year23.equals((java.lang.Object) str31);
        long long33 = year23.getSerialIndex();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) year23, (double) ' ');
        long long36 = year23.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year23, (double) 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year23.previous();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (byte) 0 + "'", comparable16.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        int int4 = day0.getYear();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(11, 7);
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year11);
        java.lang.Object obj14 = seriesChangeEvent13.getSource();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        int int4 = day0.getDayOfMonth();
//        java.lang.String str5 = day0.toString();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        java.lang.Object obj9 = timePeriodValues3.clone();
        int int10 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
        int int7 = day6.getDayOfMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        java.lang.Throwable[] throwableArray13 = seriesException10.getSuppressed();
        java.lang.Throwable[] throwableArray14 = seriesException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        int int71 = day70.getMonth();
        org.jfree.data.general.SeriesException seriesException73 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException75 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException73.addSuppressed((java.lang.Throwable) timePeriodFormatException75);
        org.jfree.data.general.SeriesException seriesException78 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException75.addSuppressed((java.lang.Throwable) seriesException78);
        java.lang.Throwable[] throwableArray80 = seriesException78.getSuppressed();
        org.jfree.data.general.SeriesException seriesException82 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException84 = new org.jfree.data.general.SeriesException("");
        seriesException82.addSuppressed((java.lang.Throwable) seriesException84);
        seriesException78.addSuppressed((java.lang.Throwable) seriesException82);
        int int87 = day70.compareTo((java.lang.Object) seriesException82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = day70.previous();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(throwableArray80);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        long long6 = year0.getLastMillisecond();
        long long7 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]");
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) (byte) 0);
        int int16 = timePeriodValues3.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560452399999L + "'", long7 == 1560452399999L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues5.isEmpty();
        java.lang.Comparable comparable10 = timePeriodValues5.getKey();
        boolean boolean11 = timePeriodValues5.isEmpty();
        timePeriodValues5.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (double) 4);
        timePeriodValues5.add(timePeriodValue18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        int int25 = timePeriodValues23.getMaxStartIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
        java.lang.String str34 = timePeriodValues30.getDomainDescription();
        boolean boolean35 = year26.equals((java.lang.Object) str34);
        long long36 = year26.getSerialIndex();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) year26, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year26.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) (short) 0);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year26, (double) 1.0f);
        int int44 = year26.getYear();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent(obj9);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
//        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getYear();
//        java.lang.Object obj17 = null;
//        boolean boolean18 = day15.equals(obj17);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 10.0f);
//        int int21 = day15.getDayOfMonth();
//        long long22 = day15.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 43629L);
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        java.lang.Object obj9 = timePeriodValues3.clone();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValues7.add(timePeriodValue10);
        boolean boolean13 = timePeriodValue10.equals((java.lang.Object) 1577865599999L);
        timePeriodValues3.add(timePeriodValue10);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues3.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "org.jfree.data.general.SeriesException: ", "");
        int int6 = timePeriodValues5.getMaxEndIndex();
        java.lang.Comparable comparable7 = null;
        try {
            timePeriodValues5.setKey(comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.delete(9, 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues9.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues9.removePropertyChangeListener(propertyChangeListener11);
//        boolean boolean13 = timePeriodValues9.isEmpty();
//        int int14 = timePeriodValues9.getMaxStartIndex();
//        timePeriodValues9.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj17 = null;
//        boolean boolean18 = timePeriodValues9.equals(obj17);
//        boolean boolean20 = timePeriodValues9.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues9.removeChangeListener(seriesChangeListener21);
//        java.lang.String str23 = timePeriodValues9.getDescription();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getDayOfMonth();
//        java.util.Date date26 = day24.getEnd();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
//        int int30 = day27.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day27.previous();
//        boolean boolean32 = day24.equals((java.lang.Object) regularTimePeriod31);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day24, (double) (short) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day24, (double) 6);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, (int) (short) 10, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass48 = simpleTimePeriod47.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues52.fireSeriesChanged();
        int int54 = timePeriodValues52.getMaxStartIndex();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues59.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timePeriodValues59.removePropertyChangeListener(propertyChangeListener61);
        java.lang.String str63 = timePeriodValues59.getDomainDescription();
        boolean boolean64 = year55.equals((java.lang.Object) str63);
        long long65 = year55.getSerialIndex();
        timePeriodValues52.add((org.jfree.data.time.TimePeriod) year55, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year55.next();
        java.util.Date date69 = year55.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date69, timeZone70);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date20, timeZone70);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        timePeriodValues3.setRangeDescription("");
        java.lang.String str16 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDescription("TimePeriodValue[2019,1]");
        try {
            org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getStartMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setKey((java.lang.Comparable) 1.0d);
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(13, (-163));
        int int16 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        try {
            timePeriodValues3.delete((-163), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        long long6 = day5.getMiddleMillisecond();
//        int int7 = day5.getYear();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        long long6 = year0.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        int int12 = day9.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) '#');
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues19.setNotify(false);
        timePeriodValues19.setDomainDescription("");
        boolean boolean24 = day9.equals((java.lang.Object) "");
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "", "", "org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean28 = timePeriodValues27.getNotify();
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 4);
        timePeriodValues3.add(timePeriodValue6);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        try {
            java.lang.Number number11 = timePeriodValues3.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        int int12 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        int int14 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        boolean boolean5 = timePeriodValues3.getNotify();
        java.lang.Object obj6 = timePeriodValues3.clone();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
//        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        int int6 = timePeriodValues3.getMaxEndIndex();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable16 = timePeriodValues15.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues20.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
//        boolean boolean24 = timePeriodValues20.isEmpty();
//        java.lang.Comparable comparable25 = timePeriodValues20.getKey();
//        timePeriodValues20.setDescription("");
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) 0L);
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) (byte) 100);
//        int int33 = timePeriodValues15.getItemCount();
//        boolean boolean34 = day7.equals((java.lang.Object) int33);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (double) 1);
//        java.lang.String str37 = day7.toString();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (-1.0d) + "'", comparable16.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (-1.0d) + "'", comparable25.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        int int19 = timePeriodValues3.getMaxMiddleIndex();
        try {
            timePeriodValues3.update(5, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timePeriodValues3.getNotify();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        long long3 = day2.getLastMillisecond();
//        java.lang.String str4 = day2.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day2.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year16.previous();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        long long6 = year0.getFirstMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        int int15 = timePeriodValues13.getMaxStartIndex();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        java.lang.String str24 = timePeriodValues20.getDomainDescription();
        boolean boolean25 = year16.equals((java.lang.Object) str24);
        long long26 = year16.getSerialIndex();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year16, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year16.next();
        java.util.Date date30 = year16.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues35.fireSeriesChanged();
        int int37 = timePeriodValues35.getMaxStartIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues42.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues42.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues42.getDomainDescription();
        boolean boolean47 = year38.equals((java.lang.Object) str46);
        long long48 = year38.getSerialIndex();
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) year38, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year38.next();
        java.util.Date date52 = year38.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date30, date52);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues57.fireSeriesChanged();
        int int59 = timePeriodValues57.getMaxStartIndex();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues64.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timePeriodValues64.removePropertyChangeListener(propertyChangeListener66);
        java.lang.String str68 = timePeriodValues64.getDomainDescription();
        boolean boolean69 = year60.equals((java.lang.Object) str68);
        long long70 = year60.getSerialIndex();
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) year60, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year60.next();
        java.util.Date date74 = year60.getStart();
        boolean boolean75 = simpleTimePeriod53.equals((java.lang.Object) date74);
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date74, timeZone78);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date74);
        long long82 = day81.getSerialIndex();
        boolean boolean83 = year7.equals((java.lang.Object) day81);
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate85 = day84.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = day84.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue88 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day84, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue90 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day84, (double) 1560452399999L);
        boolean boolean91 = year7.equals((java.lang.Object) day84);
        int int92 = year0.compareTo((java.lang.Object) year7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "hi!" + "'", str68.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 43466L + "'", long82 == 43466L);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        boolean boolean26 = day18.equals((java.lang.Object) regularTimePeriod25);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day18, (double) (short) 10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = timePeriodValues3.createCopy(10, 4);
//        timePeriodValues31.setDescription("TimePeriodValue[2019,4.0]");
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue35 = timePeriodValues31.getDataItem(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(timePeriodValues31);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        timePeriodValues3.delete(100, 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues19.fireSeriesChanged();
//        int int21 = timePeriodValues19.getMaxStartIndex();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues26.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timePeriodValues26.removePropertyChangeListener(propertyChangeListener28);
//        java.lang.String str30 = timePeriodValues26.getDomainDescription();
//        boolean boolean31 = year22.equals((java.lang.Object) str30);
//        long long32 = year22.getSerialIndex();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year22, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year22.next();
//        java.util.Date date36 = year22.getStart();
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues41.fireSeriesChanged();
//        int int43 = timePeriodValues41.getMaxStartIndex();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues48.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timePeriodValues48.removePropertyChangeListener(propertyChangeListener50);
//        java.lang.String str52 = timePeriodValues48.getDomainDescription();
//        boolean boolean53 = year44.equals((java.lang.Object) str52);
//        long long54 = year44.getSerialIndex();
//        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year44, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year44.next();
//        java.util.Date date58 = year44.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(date36, date58);
//        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues63.fireSeriesChanged();
//        int int65 = timePeriodValues63.getMaxStartIndex();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues70.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener72 = null;
//        timePeriodValues70.removePropertyChangeListener(propertyChangeListener72);
//        java.lang.String str74 = timePeriodValues70.getDomainDescription();
//        boolean boolean75 = year66.equals((java.lang.Object) str74);
//        long long76 = year66.getSerialIndex();
//        timePeriodValues63.add((org.jfree.data.time.TimePeriod) year66, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year66.next();
//        java.util.Date date80 = year66.getStart();
//        boolean boolean81 = simpleTimePeriod59.equals((java.lang.Object) date80);
//        java.lang.Class class82 = null;
//        java.util.Date date83 = null;
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date83, timeZone84);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date80, timeZone84);
//        java.util.Date date87 = day86.getStart();
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day();
//        int int89 = day88.getDayOfMonth();
//        int int90 = day88.getDayOfMonth();
//        int int91 = day86.compareTo((java.lang.Object) day88);
//        int int92 = day86.getDayOfMonth();
//        timePeriodValues3.setKey((java.lang.Comparable) day86);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 2019L + "'", long76 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 13 + "'", int89 == 13);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 13 + "'", int90 == 13);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-163) + "'", int91 == (-163));
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,1]");
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560409200000L, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
        boolean boolean34 = timePeriodValues30.isEmpty();
        int int35 = timePeriodValues30.getItemCount();
        timePeriodValues30.setNotify(true);
        int int38 = timePeriodValues30.getMaxEndIndex();
        java.lang.String str39 = timePeriodValues30.getDescription();
        java.lang.Class<?> wildcardClass40 = timePeriodValues30.getClass();
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
        int int42 = year22.compareTo((java.lang.Object) wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: 2019");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (-1.0d));
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        long long9 = year6.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.previous();
        boolean boolean16 = timePeriodValue11.equals((java.lang.Object) year12);
        java.util.Date date17 = year12.getStart();
        int int18 = simpleTimePeriod2.compareTo((java.lang.Object) year12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setKey((java.lang.Comparable) 'a');
//        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        int int13 = timePeriodValues3.getItemCount();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        long long18 = day17.getFirstMillisecond();
//        java.util.Date date19 = day17.getStart();
//        timePeriodValues3.setKey((java.lang.Comparable) date19);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        java.util.Date date24 = simpleTimePeriod23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date19, timeZone25);
//        long long28 = day27.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560452399999L + "'", long28 == 1560452399999L);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        int int6 = timePeriodValues3.getMaxEndIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean8 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        java.lang.String str4 = day0.toString();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "", "13-June-2019");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
//        java.util.Date date12 = simpleTimePeriod11.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues16.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues16.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues16.getDomainDescription();
//        timePeriodValues16.fireSeriesChanged();
//        timePeriodValues16.setKey((java.lang.Comparable) 'a');
//        timePeriodValues16.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        int int26 = timePeriodValues16.getItemCount();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate29);
//        long long31 = day30.getFirstMillisecond();
//        java.util.Date date32 = day30.getStart();
//        timePeriodValues16.setKey((java.lang.Comparable) date32);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        java.util.Date date37 = simpleTimePeriod36.getStart();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37, timeZone38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date32, timeZone38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date12, timeZone38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date5, timeZone38);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues13.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
//        boolean boolean17 = timePeriodValues13.isEmpty();
//        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
//        int int26 = timePeriodValues8.getItemCount();
//        boolean boolean27 = day0.equals((java.lang.Object) int26);
//        int int28 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) -1);
//        java.lang.String str31 = timePeriodValue30.toString();
//        java.lang.Number number32 = timePeriodValue30.getValue();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "TimePeriodValue[13-June-2019,-1.0]" + "'", str31.equals("TimePeriodValue[13-June-2019,-1.0]"));
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-1.0d) + "'", number32.equals((-1.0d)));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        java.lang.Object obj7 = timePeriodValue4.clone();
        java.lang.Object obj8 = timePeriodValue4.clone();
        java.lang.Number number9 = timePeriodValue4.getValue();
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 1 + "'", number9.equals((byte) 1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 4);
        timePeriodValues14.add(timePeriodValue17);
        timePeriodValues3.add(timePeriodValue17);
        int int20 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getYear();
//        java.util.Date date5 = day0.getStart();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        int int8 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        timePeriodValues3.setDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues6.fireSeriesChanged();
        int int8 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        java.lang.String str17 = timePeriodValues13.getDomainDescription();
        boolean boolean18 = year9.equals((java.lang.Object) str17);
        long long19 = year9.getSerialIndex();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year9, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year9.next();
        java.util.Date date23 = year9.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        int int30 = timePeriodValues28.getMaxStartIndex();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues35.getDomainDescription();
        boolean boolean40 = year31.equals((java.lang.Object) str39);
        long long41 = year31.getSerialIndex();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year31, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year31.next();
        java.util.Date date45 = year31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(date23, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues50.fireSeriesChanged();
        int int52 = timePeriodValues50.getMaxStartIndex();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues57.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener59);
        java.lang.String str61 = timePeriodValues57.getDomainDescription();
        boolean boolean62 = year53.equals((java.lang.Object) str61);
        long long63 = year53.getSerialIndex();
        timePeriodValues50.add((org.jfree.data.time.TimePeriod) year53, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year53.next();
        java.util.Date date67 = year53.getStart();
        boolean boolean68 = simpleTimePeriod46.equals((java.lang.Object) date67);
        java.lang.Class class69 = null;
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date70, timeZone71);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date67, timeZone71);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date67);
        long long75 = day74.getSerialIndex();
        boolean boolean76 = year0.equals((java.lang.Object) day74);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate78 = day77.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day77.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue81 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day77, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue83 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day77, (double) 1560452399999L);
        boolean boolean84 = year0.equals((java.lang.Object) day77);
        java.util.Calendar calendar85 = null;
        try {
            long long86 = year0.getLastMillisecond(calendar85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 43466L + "'", long75 == 43466L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        long long21 = year0.getSerialIndex();
        java.util.Date date22 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod23, 4.0d);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timePeriod26);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,1530561599999]");
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues18.getDomainDescription();
        timePeriodValues18.setDomainDescription("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimePeriod timePeriod9 = null;
        try {
            timePeriodValues3.add(timePeriod9, (java.lang.Number) 1530561599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year0.next();
        long long22 = year0.getSerialIndex();
        java.util.Date date23 = year0.getStart();
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year0.getMiddleMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues12.isEmpty();
        int int17 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues12.equals(obj20);
        int int22 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        timePeriodValues12.add(timePeriod26, (java.lang.Number) 100);
        int int29 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriod26);
        java.util.Date date30 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 7L);
        java.util.Date date33 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        int int14 = timePeriodValues3.getMinStartIndex();
        java.lang.Object obj15 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(obj15);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        timePeriodValues3.setDomainDescription("hi!");
//        int int10 = timePeriodValues3.getItemCount();
//        int int11 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues17.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
//        boolean boolean21 = timePeriodValues17.isEmpty();
//        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
//        boolean boolean23 = timePeriodValues17.isEmpty();
//        timePeriodValues17.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timePeriodValues17.removeChangeListener(seriesChangeListener26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
//        timePeriodValues17.add(timePeriodValue30);
//        java.lang.Number number32 = timePeriodValue30.getValue();
//        timePeriodValues3.add(timePeriodValue30);
//        timePeriodValue30.setValue((java.lang.Number) 0);
//        java.lang.Object obj36 = timePeriodValue30.clone();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
//        int int40 = day37.compareTo((java.lang.Object) (-1L));
//        int int41 = day37.getDayOfMonth();
//        long long42 = day37.getSerialIndex();
//        boolean boolean43 = timePeriodValue30.equals((java.lang.Object) day37);
//        int int44 = day37.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 13 + "'", int41 == 13);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43629L + "'", long42 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 13 + "'", int44 == 13);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        timePeriodValues3.setRangeDescription("");
        int int16 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener31);
        boolean boolean33 = timePeriodValues29.isEmpty();
        java.lang.Comparable comparable34 = timePeriodValues29.getKey();
        boolean boolean35 = timePeriodValues29.isEmpty();
        timePeriodValues29.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 4);
        timePeriodValues29.add(timePeriodValue42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (short) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 0.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date71 = simpleTimePeriod70.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues73 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean74 = simpleTimePeriod70.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, (double) (short) 1);
        java.util.Date date77 = simpleTimePeriod70.getStart();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date77);
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date77);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(date77);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        java.lang.Object obj8 = null;
        try {
            int int9 = simpleTimePeriod2.compareTo(obj8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 4);
        timePeriodValues14.add(timePeriodValue17);
        timePeriodValues3.add(timePeriodValue17);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener21);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        timePeriodValues3.setNotify(false);
        int int12 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        long long20 = year6.getLastMillisecond();
        java.lang.String str21 = year6.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        seriesException14.addSuppressed((java.lang.Throwable) seriesException16);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) seriesException14);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) seriesException25);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) seriesException25);
        java.lang.String str28 = timePeriodFormatException12.toString();
        seriesException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException35 = new org.jfree.data.general.SeriesException("");
        seriesException33.addSuppressed((java.lang.Throwable) seriesException35);
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) seriesException33);
        org.jfree.data.general.SeriesException seriesException39 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        seriesException33.addSuppressed((java.lang.Throwable) seriesException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException46 = new org.jfree.data.general.SeriesException("");
        seriesException44.addSuppressed((java.lang.Throwable) seriesException46);
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) seriesException44);
        org.jfree.data.general.SeriesException seriesException50 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException50.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        org.jfree.data.general.SeriesException seriesException55 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException52.addSuppressed((java.lang.Throwable) seriesException55);
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) seriesException55);
        java.lang.String str58 = timePeriodFormatException42.toString();
        seriesException39.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues64.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timePeriodValues64.removePropertyChangeListener(propertyChangeListener66);
        java.lang.String str68 = timePeriodValues64.getDomainDescription();
        timePeriodValues64.fireSeriesChanged();
        org.jfree.data.general.SeriesException seriesException71 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException73 = new org.jfree.data.general.SeriesException("");
        seriesException71.addSuppressed((java.lang.Throwable) seriesException73);
        boolean boolean75 = timePeriodValues64.equals((java.lang.Object) seriesException71);
        java.lang.String str76 = seriesException71.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues80 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues80.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener82 = null;
        timePeriodValues80.removePropertyChangeListener(propertyChangeListener82);
        java.lang.String str84 = timePeriodValues80.getDomainDescription();
        timePeriodValues80.fireSeriesChanged();
        org.jfree.data.general.SeriesException seriesException87 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException89 = new org.jfree.data.general.SeriesException("");
        seriesException87.addSuppressed((java.lang.Throwable) seriesException89);
        boolean boolean91 = timePeriodValues80.equals((java.lang.Object) seriesException87);
        java.lang.String str92 = seriesException87.toString();
        seriesException71.addSuppressed((java.lang.Throwable) seriesException87);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) seriesException87);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str58.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "hi!" + "'", str68.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str76.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "hi!" + "'", str84.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str92.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        int int71 = day70.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day70.next();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj9 = timePeriodValues3.clone();
        int int10 = timePeriodValues3.getMinStartIndex();
        java.lang.String str11 = timePeriodValues3.getDomainDescription();
        java.lang.String str12 = timePeriodValues3.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.next();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues15.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener17);
        java.lang.String str19 = timePeriodValues15.getDomainDescription();
        boolean boolean20 = year11.equals((java.lang.Object) str19);
        long long21 = year11.getSerialIndex();
        java.lang.String str22 = year11.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long26 = simpleTimePeriod25.getStartMillis();
        long long27 = simpleTimePeriod25.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean30 = simpleTimePeriod25.equals((java.lang.Object) timePeriodValues29);
        boolean boolean31 = year11.equals((java.lang.Object) timePeriodValues29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year11.next();
        boolean boolean33 = year0.equals((java.lang.Object) regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener31);
        boolean boolean33 = timePeriodValues29.isEmpty();
        java.lang.Comparable comparable34 = timePeriodValues29.getKey();
        boolean boolean35 = timePeriodValues29.isEmpty();
        timePeriodValues29.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 4);
        timePeriodValues29.add(timePeriodValue42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (short) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 0.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date71 = simpleTimePeriod70.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues73 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean74 = simpleTimePeriod70.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, (double) (short) 1);
        java.util.Date date77 = simpleTimePeriod70.getStart();
        long long78 = simpleTimePeriod70.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue80 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod70, (java.lang.Number) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(7, (-1));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMaxEndIndex();
        boolean boolean12 = timePeriodValues3.getNotify();
        java.lang.String str13 = timePeriodValues3.getDescription();
        java.lang.String str14 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        int int10 = timePeriodValues9.getMinStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
//        int int12 = day9.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) '#');
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
//        long long19 = simpleTimePeriod18.getStartMillis();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 0L);
//        long long22 = simpleTimePeriod18.getEndMillis();
//        long long23 = simpleTimePeriod18.getStartMillis();
//        long long24 = simpleTimePeriod18.getStartMillis();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = day25.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day25.previous();
//        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
//        java.lang.String str30 = day25.toString();
//        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
//        int int32 = simpleTimePeriod18.compareTo((java.lang.Object) day25);
//        long long33 = simpleTimePeriod18.getEndMillis();
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,4.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.lang.String str6 = timePeriodValue5.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) day7);
        java.lang.Class<?> wildcardClass11 = day7.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues15.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener17);
        boolean boolean19 = timePeriodValues15.isEmpty();
        java.lang.Comparable comparable20 = timePeriodValues15.getKey();
        boolean boolean21 = timePeriodValues15.isEmpty();
        timePeriodValues15.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues15.removeChangeListener(seriesChangeListener24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year26, (double) 4);
        timePeriodValues15.add(timePeriodValue28);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues33.fireSeriesChanged();
        int int35 = timePeriodValues33.getMaxStartIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener42);
        java.lang.String str44 = timePeriodValues40.getDomainDescription();
        boolean boolean45 = year36.equals((java.lang.Object) str44);
        long long46 = year36.getSerialIndex();
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) year36, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year36.next();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year36, (java.lang.Number) (short) 0);
        java.lang.Comparable comparable52 = timePeriodValues15.getKey();
        timePeriodValues15.setDomainDescription("TimePeriodValue[2019,4.0]");
        int int55 = day7.compareTo((java.lang.Object) "TimePeriodValue[2019,4.0]");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,0]" + "'", str6.equals("TimePeriodValue[2019,0]"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (-1.0d) + "'", comparable20.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + (-1.0d) + "'", comparable52.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues5.isEmpty();
        int int10 = timePeriodValues5.getMaxStartIndex();
        timePeriodValues5.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = timePeriodValues5.equals(obj13);
        boolean boolean16 = timePeriodValues5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener17);
        int int19 = timePeriodValues5.getMinStartIndex();
        java.lang.String str20 = timePeriodValues5.getRangeDescription();
        int int21 = timePeriodValues5.getMinEndIndex();
        boolean boolean22 = day0.equals((java.lang.Object) timePeriodValues5);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue24 = timePeriodValues5.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        java.lang.Number number5 = null;
        timePeriodValue4.setValue(number5);
        timePeriodValue4.setValue((java.lang.Number) 10L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        int int11 = timePeriodValues3.getMinStartIndex();
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        int int13 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        int int23 = timePeriodValues21.getMaxStartIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        boolean boolean33 = year24.equals((java.lang.Object) str32);
        long long34 = year24.getSerialIndex();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year24, (double) ' ');
        long long37 = year24.getLastMillisecond();
        java.lang.Number number38 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, number38);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        long long17 = year14.getFirstMillisecond();
        boolean boolean18 = year11.equals((java.lang.Object) year14);
        long long19 = year14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year14.previous();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year14.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        try {
            java.lang.Number number18 = timePeriodValues3.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
        timePeriodValues17.add(timePeriodValue30);
        java.lang.Number number32 = timePeriodValue30.getValue();
        timePeriodValues3.add(timePeriodValue30);
        java.lang.Object obj34 = timePeriodValue30.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
        org.junit.Assert.assertNotNull(obj34);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
//        java.lang.String str11 = day0.toString();
//        int int12 = day0.getYear();
//        long long13 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int13 = timePeriodValues3.getItemCount();
        timePeriodValues3.fireSeriesChanged();
        boolean boolean15 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues3.createCopy((int) (short) 100, 0);
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timePeriodValues18);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        java.lang.Object obj3 = new java.lang.Object();
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 1562097599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        boolean boolean14 = timePeriodValues10.isEmpty();
        int int15 = timePeriodValues10.getMaxStartIndex();
        timePeriodValues10.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj18 = null;
        boolean boolean19 = timePeriodValues10.equals(obj18);
        boolean boolean21 = timePeriodValues10.equals((java.lang.Object) (byte) 1);
        boolean boolean22 = timePeriodValues10.isEmpty();
        int int23 = timePeriodValues10.getItemCount();
        boolean boolean24 = timePeriodValue6.equals((java.lang.Object) int23);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.String str14 = timePeriodValues10.getDomainDescription();
//        boolean boolean15 = year6.equals((java.lang.Object) str14);
//        long long16 = year6.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
//        java.util.Date date20 = year6.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues25.fireSeriesChanged();
//        int int27 = timePeriodValues25.getMaxStartIndex();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues32.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        boolean boolean37 = year28.equals((java.lang.Object) str36);
//        long long38 = year28.getSerialIndex();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
//        java.util.Date date42 = year28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues47.fireSeriesChanged();
//        int int49 = timePeriodValues47.getMaxStartIndex();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues54.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
//        java.lang.String str58 = timePeriodValues54.getDomainDescription();
//        boolean boolean59 = year50.equals((java.lang.Object) str58);
//        long long60 = year50.getSerialIndex();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
//        java.util.Date date64 = year50.getStart();
//        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
//        java.lang.Class class66 = null;
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
//        java.util.Date date71 = day70.getStart();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        int int74 = day72.getDayOfMonth();
//        int int75 = day70.compareTo((java.lang.Object) day72);
//        long long76 = day70.getFirstMillisecond();
//        int int77 = day70.getYear();
//        int int78 = day70.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 13 + "'", int73 == 13);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 13 + "'", int74 == 13);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-163) + "'", int75 == (-163));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1546329600000L + "'", long76 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        long long21 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 43466L);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year0.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener24);
        java.lang.String str26 = timePeriodValues18.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener27);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues3.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj9 = timePeriodValues3.clone();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1]");
        timePeriodValues3.setDescription("2019");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.String str10 = timePeriodValues3.getDescription();
        timePeriodValues3.fireSeriesChanged();
        boolean boolean12 = timePeriodValues3.isEmpty();
        int int13 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        int int13 = timePeriodValues8.getItemCount();
        timePeriodValues8.setNotify(true);
        int int16 = timePeriodValues8.getMaxEndIndex();
        int int17 = timePeriodValues8.getMaxStartIndex();
        int int18 = day0.compareTo((java.lang.Object) timePeriodValues8);
        java.lang.String str19 = timePeriodValues8.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        boolean boolean27 = timePeriodValues23.isEmpty();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        timePeriodValues23.setDescription("");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 0L);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (double) 4);
        long long37 = year34.getFirstMillisecond();
        boolean boolean38 = year31.equals((java.lang.Object) year34);
        long long39 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year34.previous();
        long long41 = year34.getFirstMillisecond();
        timePeriodValues8.setKey((java.lang.Comparable) year34);
        try {
            timePeriodValues8.update(0, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-1.0d) + "'", comparable28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1562097599999L + "'", long39 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        int int23 = timePeriodValues21.getMaxStartIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        boolean boolean33 = year24.equals((java.lang.Object) str32);
        long long34 = year24.getSerialIndex();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year24, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year24.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues43.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues43.removePropertyChangeListener(propertyChangeListener45);
        boolean boolean47 = timePeriodValues43.isEmpty();
        timePeriodValues43.setDomainDescription("hi!");
        java.lang.String str50 = timePeriodValues43.getDescription();
        timePeriodValues43.fireSeriesChanged();
        java.lang.Object obj52 = timePeriodValues43.clone();
        int int53 = timePeriodValues43.getMinMiddleIndex();
        boolean boolean54 = year24.equals((java.lang.Object) int53);
        java.util.Date date55 = year24.getEnd();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(date55);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        long long71 = day70.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1546415999999L + "'", long71 == 1546415999999L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, 13, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
//        int int14 = day10.getDayOfMonth();
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        timePeriodValues3.setDomainDescription("hi!");
//        int int10 = timePeriodValues3.getItemCount();
//        int int11 = timePeriodValues3.getMaxEndIndex();
//        boolean boolean12 = timePeriodValues3.getNotify();
//        java.lang.String str13 = timePeriodValues3.getDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues17.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues17.createCopy((int) (byte) 1, (int) (short) 10);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day24, (double) (byte) -1);
//        java.lang.Comparable comparable28 = timePeriodValues17.getKey();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        java.lang.Object obj31 = null;
//        boolean boolean32 = day29.equals(obj31);
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day29, (double) 10.0f);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day29, (double) 1);
//        long long37 = day29.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(timePeriodValues23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-1.0d) + "'", comparable28.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43629L + "'", long37 == 43629L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener28);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues5.isEmpty();
        java.lang.Comparable comparable10 = timePeriodValues5.getKey();
        boolean boolean11 = timePeriodValues5.isEmpty();
        timePeriodValues5.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (double) 4);
        timePeriodValues5.add(timePeriodValue18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        int int25 = timePeriodValues23.getMaxStartIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
        java.lang.String str34 = timePeriodValues30.getDomainDescription();
        boolean boolean35 = year26.equals((java.lang.Object) str34);
        long long36 = year26.getSerialIndex();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) year26, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year26.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) (short) 0);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year26, (double) 1.0f);
        java.util.Calendar calendar44 = null;
        try {
            long long45 = year26.getLastMillisecond(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues3.getMinStartIndex();
        java.lang.String str18 = timePeriodValues3.getRangeDescription();
        int int19 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj20 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(obj20);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        timePeriodValues3.setDomainDescription("hi!");
//        int int10 = timePeriodValues3.getItemCount();
//        int int11 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues17.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
//        boolean boolean21 = timePeriodValues17.isEmpty();
//        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
//        boolean boolean23 = timePeriodValues17.isEmpty();
//        timePeriodValues17.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timePeriodValues17.removeChangeListener(seriesChangeListener26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
//        timePeriodValues17.add(timePeriodValue30);
//        java.lang.Number number32 = timePeriodValue30.getValue();
//        timePeriodValues3.add(timePeriodValue30);
//        timePeriodValue30.setValue((java.lang.Number) 0);
//        java.lang.Object obj36 = timePeriodValue30.clone();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
//        int int40 = day37.compareTo((java.lang.Object) (-1L));
//        int int41 = day37.getDayOfMonth();
//        long long42 = day37.getSerialIndex();
//        boolean boolean43 = timePeriodValue30.equals((java.lang.Object) day37);
//        java.lang.Object obj44 = timePeriodValue30.clone();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 13 + "'", int41 == 13);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43629L + "'", long42 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(obj44);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.lang.Object obj4 = null;
//        int int5 = day0.compareTo(obj4);
//        long long6 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        int int12 = timePeriodValues10.getMaxStartIndex();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues17.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
//        java.lang.String str21 = timePeriodValues17.getDomainDescription();
//        boolean boolean22 = year13.equals((java.lang.Object) str21);
//        long long23 = year13.getSerialIndex();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year13, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year13.next();
//        long long27 = year13.getLastMillisecond();
//        boolean boolean28 = day0.equals((java.lang.Object) year13);
//        int int29 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        java.lang.String str4 = day0.toString();
//        java.util.Date date5 = day0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues7.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
//        java.lang.String str11 = timePeriodValues7.getDomainDescription();
//        timePeriodValues7.fireSeriesChanged();
//        timePeriodValues7.setKey((java.lang.Comparable) 'a');
//        timePeriodValues7.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        int int17 = timePeriodValues7.getItemCount();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
//        long long22 = day21.getFirstMillisecond();
//        java.util.Date date23 = day21.getStart();
//        timePeriodValues7.setKey((java.lang.Comparable) date23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        java.util.Date date28 = simpleTimePeriod27.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date23, timeZone29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date3, timeZone29);
//        java.lang.String str33 = year32.toString();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969" + "'", str33.equals("1969"));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date64, timeZone72);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date64);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(timeZone72);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        seriesException14.addSuppressed((java.lang.Throwable) seriesException16);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) seriesException14);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) seriesException25);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) seriesException25);
        java.lang.String str28 = timePeriodFormatException12.toString();
        seriesException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException35 = new org.jfree.data.general.SeriesException("");
        seriesException33.addSuppressed((java.lang.Throwable) seriesException35);
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) seriesException33);
        org.jfree.data.general.SeriesException seriesException39 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        seriesException33.addSuppressed((java.lang.Throwable) seriesException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException46 = new org.jfree.data.general.SeriesException("");
        seriesException44.addSuppressed((java.lang.Throwable) seriesException46);
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) seriesException44);
        org.jfree.data.general.SeriesException seriesException50 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException50.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        org.jfree.data.general.SeriesException seriesException55 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException52.addSuppressed((java.lang.Throwable) seriesException55);
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) seriesException55);
        java.lang.String str58 = timePeriodFormatException42.toString();
        seriesException39.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        java.lang.Throwable throwable61 = null;
        try {
            timePeriodFormatException12.addSuppressed(throwable61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str58.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        long long17 = year14.getFirstMillisecond();
        boolean boolean18 = year11.equals((java.lang.Object) year14);
        long long19 = year14.getLastMillisecond();
        int int21 = year14.compareTo((java.lang.Object) 12);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year22.previous();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues3.getDescription();
        java.lang.Class<?> wildcardClass13 = timePeriodValues3.getClass();
        try {
            java.lang.Number number15 = timePeriodValues3.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        java.lang.String str8 = timePeriodValues3.getDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) (short) -1);
        int int13 = year7.compareTo((java.lang.Object) 1546329600000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year16.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.previous();
        int int19 = day15.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day15.previous();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day15.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, 2019, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        java.util.Calendar calendar21 = null;
        try {
            year0.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        int int23 = timePeriodValues21.getMaxStartIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        boolean boolean33 = year24.equals((java.lang.Object) str32);
        long long34 = year24.getSerialIndex();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year24, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year24.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (short) 0);
        int int40 = year24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year24.previous();
        java.lang.Number number42 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, number42);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        seriesException16.addSuppressed((java.lang.Throwable) seriesException18);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException16);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) seriesException27);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException27);
        java.lang.String str30 = timePeriodFormatException14.toString();
        seriesException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str32 = seriesException10.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str32.equals("org.jfree.data.general.SeriesException: "));
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        java.lang.Class class0 = null;
//        java.util.Date date1 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues5.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timePeriodValues5.getDomainDescription();
//        timePeriodValues5.fireSeriesChanged();
//        timePeriodValues5.setKey((java.lang.Comparable) 'a');
//        timePeriodValues5.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        int int15 = timePeriodValues5.getItemCount();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
//        long long20 = day19.getFirstMillisecond();
//        java.util.Date date21 = day19.getStart();
//        timePeriodValues5.setKey((java.lang.Comparable) date21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        java.util.Date date26 = simpleTimePeriod25.getStart();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date21, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone27);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues10);
        try {
            timePeriodValues10.delete((int) (byte) 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues5.isEmpty();
        int int10 = timePeriodValues5.getMaxStartIndex();
        timePeriodValues5.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = timePeriodValues5.equals(obj13);
        boolean boolean16 = timePeriodValues5.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener17);
        int int19 = timePeriodValues5.getMinStartIndex();
        java.lang.String str20 = timePeriodValues5.getRangeDescription();
        int int21 = timePeriodValues5.getMinEndIndex();
        boolean boolean22 = day0.equals((java.lang.Object) timePeriodValues5);
        boolean boolean23 = timePeriodValues5.isEmpty();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        long long13 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.previous();
        int int15 = year0.getYear();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year0.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        boolean boolean5 = timePeriodValues3.getNotify();
        java.lang.Object obj6 = null;
        boolean boolean7 = timePeriodValues3.equals(obj6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        int int26 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener33);
        java.lang.String str35 = timePeriodValues31.getDomainDescription();
        boolean boolean36 = year27.equals((java.lang.Object) str35);
        long long37 = year27.getSerialIndex();
        long long38 = year27.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int43 = timePeriodValues42.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = timePeriodValues42.createCopy(0, (-1));
        boolean boolean47 = year27.equals((java.lang.Object) timePeriodValues42);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 43466L);
        java.util.Calendar calendar50 = null;
        try {
            long long51 = year27.getLastMillisecond(calendar50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        boolean boolean11 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.util.Date date66 = simpleTimePeriod43.getEnd();
        java.util.Date date67 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod43, "org.jfree.data.time.TimePeriodFormatException: 2019", "TimePeriodValue[2019,4.0]");
        java.util.Date date71 = simpleTimePeriod43.getStart();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(date71);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 7, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.String str14 = timePeriodValues10.getDomainDescription();
//        boolean boolean15 = year6.equals((java.lang.Object) str14);
//        long long16 = year6.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
//        java.util.Date date20 = year6.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues25.fireSeriesChanged();
//        int int27 = timePeriodValues25.getMaxStartIndex();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues32.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        boolean boolean37 = year28.equals((java.lang.Object) str36);
//        long long38 = year28.getSerialIndex();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
//        java.util.Date date42 = year28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues47.fireSeriesChanged();
//        int int49 = timePeriodValues47.getMaxStartIndex();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues54.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
//        java.lang.String str58 = timePeriodValues54.getDomainDescription();
//        boolean boolean59 = year50.equals((java.lang.Object) str58);
//        long long60 = year50.getSerialIndex();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
//        java.util.Date date64 = year50.getStart();
//        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
//        java.lang.Class class66 = null;
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
//        java.util.Date date71 = day70.getStart();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        int int74 = day72.getDayOfMonth();
//        int int75 = day70.compareTo((java.lang.Object) day72);
//        long long76 = day70.getFirstMillisecond();
//        java.lang.String str77 = day70.toString();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 13 + "'", int73 == 13);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 13 + "'", int74 == 13);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-163) + "'", int75 == (-163));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1546329600000L + "'", long76 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "1-January-2019" + "'", str77.equals("1-January-2019"));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener24);
        int int26 = timePeriodValues18.getMinMiddleIndex();
        java.lang.String str27 = timePeriodValues18.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        boolean boolean26 = day18.equals((java.lang.Object) regularTimePeriod25);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day18, (double) (short) 10);
//        int int29 = timePeriodValues3.getMaxMiddleIndex();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timePeriodValues3.setNotify(false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        boolean boolean26 = day18.equals((java.lang.Object) regularTimePeriod25);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day18, (double) (short) 10);
//        int int29 = timePeriodValues3.getMaxMiddleIndex();
//        boolean boolean30 = timePeriodValues3.isEmpty();
//        try {
//            org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValues3.getTimePeriod(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable13 = timePeriodValues12.getKey();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues12.createCopy(7, (-1));
        boolean boolean19 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues18);
        java.util.Date date20 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean13 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDescription("TimePeriodValue[2019,13]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues13.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
//        boolean boolean17 = timePeriodValues13.isEmpty();
//        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
//        int int26 = timePeriodValues8.getItemCount();
//        boolean boolean27 = day0.equals((java.lang.Object) int26);
//        int int28 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) -1);
//        java.lang.String str31 = day0.toString();
//        java.util.Date date32 = day0.getStart();
//        long long33 = day0.getFirstMillisecond();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues38.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
//        java.lang.String str42 = timePeriodValues38.getDomainDescription();
//        boolean boolean43 = year34.equals((java.lang.Object) str42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues47.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues47.removePropertyChangeListener(propertyChangeListener49);
//        boolean boolean51 = timePeriodValues47.isEmpty();
//        java.lang.Comparable comparable52 = timePeriodValues47.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timePeriodValues47.addChangeListener(seriesChangeListener53);
//        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues58.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timePeriodValues58.removePropertyChangeListener(propertyChangeListener60);
//        boolean boolean62 = timePeriodValues58.isEmpty();
//        java.lang.Comparable comparable63 = timePeriodValues58.getKey();
//        boolean boolean64 = timePeriodValues58.isEmpty();
//        int int65 = timePeriodValues58.getMaxStartIndex();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        timePeriodValues58.setKey((java.lang.Comparable) year66);
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year66, (java.lang.Number) (short) -1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year66, (double) 13);
//        boolean boolean72 = year34.equals((java.lang.Object) year66);
//        int int73 = day0.compareTo((java.lang.Object) year34);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + (-1.0d) + "'", comparable52.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + (-1.0d) + "'", comparable63.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        int int9 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        java.lang.String str18 = timePeriodValues14.getDomainDescription();
        boolean boolean19 = year10.equals((java.lang.Object) str18);
        long long20 = year10.getSerialIndex();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year10.next();
        java.util.Date date24 = year10.getStart();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date24, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date24);
        int int31 = day30.getYear();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, 2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues13.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
//        boolean boolean17 = timePeriodValues13.isEmpty();
//        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
//        int int26 = timePeriodValues8.getItemCount();
//        boolean boolean27 = day0.equals((java.lang.Object) int26);
//        int int28 = day0.getMonth();
//        java.lang.String str29 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        int int3 = day0.getYear();
        java.lang.Object obj4 = null;
        boolean boolean5 = day0.equals(obj4);
        java.util.Date date6 = day0.getStart();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        seriesException5.addSuppressed((java.lang.Throwable) seriesException7);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) seriesException16);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException16);
        java.lang.String str19 = timePeriodFormatException3.toString();
        java.lang.String str20 = timePeriodFormatException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date64);
        java.util.Calendar calendar72 = null;
        try {
            long long73 = day71.getLastMillisecond(calendar72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        int int4 = timePeriodValues3.getMinEndIndex();
//        int int5 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        int int9 = day6.compareTo((java.lang.Object) (-1L));
//        int int10 = day6.getDayOfMonth();
//        long long11 = day6.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
//        boolean boolean14 = timePeriodValues3.getNotify();
//        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,10.0]");
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray8 = seriesException6.getSuppressed();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        seriesException10.addSuppressed((java.lang.Throwable) seriesException12);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException10);
        java.lang.String str15 = seriesException6.toString();
        java.lang.String str16 = seriesException6.toString();
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str15.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str16.equals("org.jfree.data.general.SeriesException: "));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        boolean boolean26 = day18.equals((java.lang.Object) regularTimePeriod25);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day18, (double) (short) 10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = timePeriodValues3.createCopy(10, 4);
//        java.lang.Comparable comparable32 = timePeriodValues31.getKey();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(timePeriodValues31);
//        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + (byte) 0 + "'", comparable32.equals((byte) 0));
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str6 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        timePeriodValues3.setRangeDescription("");
        java.lang.Object obj11 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        timePeriodValues3.setNotify(true);
        try {
            timePeriodValues3.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timePeriodValues3.getNotify();
        int int14 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        int int14 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        java.lang.String str20 = timePeriodValues18.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod24 = timePeriodValue23.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue(timePeriod24, (double) 2);
        timePeriodValues18.add(timePeriodValue26);
        timePeriodValues3.add(timePeriodValue26);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(timePeriod24);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long16 = simpleTimePeriod15.getStartMillis();
        long long17 = simpleTimePeriod15.getEndMillis();
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        java.util.Date date19 = simpleTimePeriod15.getEnd();
        long long20 = simpleTimePeriod15.getEndMillis();
        java.util.Date date21 = simpleTimePeriod15.getStart();
        boolean boolean22 = timePeriodValue12.equals((java.lang.Object) simpleTimePeriod15);
        java.lang.Object obj23 = timePeriodValue12.clone();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
//        timePeriodValues3.setNotify(true);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues20.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
//        boolean boolean24 = timePeriodValues20.isEmpty();
//        timePeriodValues20.setDomainDescription("hi!");
//        int int27 = timePeriodValues20.getItemCount();
//        int int28 = timePeriodValues20.getMinEndIndex();
//        timePeriodValues20.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues34.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues34.removePropertyChangeListener(propertyChangeListener36);
//        boolean boolean38 = timePeriodValues34.isEmpty();
//        java.lang.Comparable comparable39 = timePeriodValues34.getKey();
//        boolean boolean40 = timePeriodValues34.isEmpty();
//        timePeriodValues34.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timePeriodValues34.removeChangeListener(seriesChangeListener43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year45, (double) 4);
//        timePeriodValues34.add(timePeriodValue47);
//        java.lang.Number number49 = timePeriodValue47.getValue();
//        timePeriodValues20.add(timePeriodValue47);
//        timePeriodValue47.setValue((java.lang.Number) 0);
//        java.lang.Object obj53 = timePeriodValue47.clone();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate55 = day54.getSerialDate();
//        int int57 = day54.compareTo((java.lang.Object) (-1L));
//        int int58 = day54.getDayOfMonth();
//        long long59 = day54.getSerialIndex();
//        boolean boolean60 = timePeriodValue47.equals((java.lang.Object) day54);
//        timePeriodValues3.add(timePeriodValue47);
//        java.lang.String str62 = timePeriodValue47.toString();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (-1.0d) + "'", comparable39.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 4.0d + "'", number49.equals(4.0d));
//        org.junit.Assert.assertNotNull(obj53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 13 + "'", int58 == 13);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "TimePeriodValue[2019,0]" + "'", str62.equals("TimePeriodValue[2019,0]"));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        boolean boolean6 = timePeriodValues5.getNotify();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues5.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 13);
        java.lang.String str6 = timePeriodValue5.toString();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues11.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues11.removePropertyChangeListener(propertyChangeListener13);
        java.lang.String str15 = timePeriodValues11.getDomainDescription();
        boolean boolean16 = year7.equals((java.lang.Object) str15);
        long long17 = year7.getSerialIndex();
        java.lang.String str18 = year7.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long22 = simpleTimePeriod21.getStartMillis();
        long long23 = simpleTimePeriod21.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean26 = simpleTimePeriod21.equals((java.lang.Object) timePeriodValues25);
        boolean boolean27 = year7.equals((java.lang.Object) timePeriodValues25);
        long long28 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 43466L);
        java.lang.Object obj31 = timePeriodValue30.clone();
        boolean boolean32 = timePeriodValue5.equals((java.lang.Object) timePeriodValue30);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,13]" + "'", str6.equals("TimePeriodValue[2019,13]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues3.isEmpty();
        int int19 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 4);
        timePeriodValues3.add(timePeriodValue6);
        boolean boolean9 = timePeriodValue6.equals((java.lang.Object) 1577865599999L);
        timePeriodValue6.setValue((java.lang.Number) (short) 0);
        boolean boolean13 = timePeriodValue6.equals((java.lang.Object) (short) 10);
        java.lang.Number number14 = timePeriodValue6.getValue();
        java.lang.String str15 = timePeriodValue6.toString();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 0 + "'", number14.equals((short) 0));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[2019,0]" + "'", str15.equals("TimePeriodValue[2019,0]"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        int int11 = timePeriodValues3.getMinStartIndex();
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        int int13 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj14 = timePeriodValues3.clone();
        timePeriodValues3.setKey((java.lang.Comparable) 10.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) (byte) 0);
        int int16 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues18.getDomainDescription();
        int int27 = timePeriodValues18.getMaxMiddleIndex();
        timePeriodValues18.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
        int int33 = day30.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day30.previous();
        java.util.Date date35 = day30.getEnd();
        timePeriodValues18.setKey((java.lang.Comparable) day30);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        long long21 = year0.getSerialIndex();
        java.util.Date date22 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod23, 4.0d);
        java.util.Date date26 = regularTimePeriod23.getEnd();
        java.util.Date date27 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date26, date27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) (short) -1);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 4);
        java.lang.Number number15 = timePeriodValue14.getValue();
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue14.getPeriod();
        timePeriodValues3.add(timePeriodValue14);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        java.lang.Object obj22 = null;
        int int23 = day18.compareTo(obj22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) day18);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 4.0d + "'", number15.equals(4.0d));
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timePeriodValues7.isEmpty();
        int int12 = timePeriodValues7.getMaxStartIndex();
        timePeriodValues7.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj15 = null;
        boolean boolean16 = timePeriodValues7.equals(obj15);
        int int17 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        boolean boolean27 = timePeriodValues23.isEmpty();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        timePeriodValues23.setDescription("");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 0L);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (double) 4);
        long long37 = year34.getFirstMillisecond();
        boolean boolean38 = year31.equals((java.lang.Object) year34);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year34, (double) (short) 0);
        boolean boolean41 = day0.equals((java.lang.Object) year34);
        java.util.Calendar calendar42 = null;
        try {
            long long43 = day0.getFirstMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-1.0d) + "'", comparable28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        int int9 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        java.util.Date date71 = day70.getStart();
        long long72 = day70.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1546415999999L + "'", long72 == 1546415999999L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-163), 2019L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass7 = simpleTimePeriod6.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues11.fireSeriesChanged();
        int int13 = timePeriodValues11.getMaxStartIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        java.lang.String str22 = timePeriodValues18.getDomainDescription();
        boolean boolean23 = year14.equals((java.lang.Object) str22);
        long long24 = year14.getSerialIndex();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year14, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year14.next();
        java.util.Date date28 = year14.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date3, timeZone29);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValues7.add(timePeriodValue10);
        boolean boolean13 = timePeriodValue10.equals((java.lang.Object) 1577865599999L);
        timePeriodValues3.add(timePeriodValue10);
        int int15 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(7, (-1));
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) 4);
        timePeriodValue14.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues24.fireSeriesChanged();
        int int26 = timePeriodValues24.getMaxStartIndex();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener33);
        java.lang.String str35 = timePeriodValues31.getDomainDescription();
        boolean boolean36 = year27.equals((java.lang.Object) str35);
        long long37 = year27.getSerialIndex();
        timePeriodValues24.add((org.jfree.data.time.TimePeriod) year27, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year27.next();
        java.util.Date date41 = year27.getStart();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date41, timeZone42);
        boolean boolean44 = timePeriodValue14.equals((java.lang.Object) timeZone42);
        timePeriodValues3.add(timePeriodValue14);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        int int24 = timePeriodValues17.getMaxStartIndex();
        int int25 = year11.compareTo((java.lang.Object) timePeriodValues17);
        int int26 = year11.getYear();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year11.getMiddleMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        int int15 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-163), 1560495599999L);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = day3.getSerialDate();
        boolean boolean10 = simpleTimePeriod2.equals((java.lang.Object) day3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
        java.util.Calendar calendar46 = null;
        try {
            year44.peg(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 11, (long) ' ');
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        java.util.Date date5 = day3.getEnd();
//        long long6 = day3.getSerialIndex();
//        int int7 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue(timePeriod3, (double) 2);
        java.lang.Object obj6 = timePeriodValue5.clone();
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue5.getPeriod();
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timePeriod7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        timePeriodValues3.setDomainDescription("");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = null;
        try {
            timePeriodValues3.add(timePeriodValue8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
        timePeriodValues17.add(timePeriodValue30);
        java.lang.Number number32 = timePeriodValue30.getValue();
        timePeriodValues3.add(timePeriodValue30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue30);
        timePeriodValue30.setValue((java.lang.Number) 10.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
        int int46 = year44.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year44, (-1.0d));
        java.util.Calendar calendar49 = null;
        try {
            long long50 = year44.getLastMillisecond(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getStart();
        long long23 = year21.getLastMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date27 = simpleTimePeriod26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        int int31 = year21.compareTo((java.lang.Object) day29);
        int int32 = year21.getYear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable12 = timePeriodValues11.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener13);
        java.lang.String str15 = timePeriodValues11.getDescription();
        timePeriodValues11.setDomainDescription("");
        timePeriodValues11.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        boolean boolean20 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues11);
        timePeriodValues11.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (-1.0d) + "'", comparable12.equals((-1.0d)));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
//        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.previous();
//        int int19 = day15.getMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day15.previous();
//        long long23 = day15.getSerialIndex();
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj9 = timePeriodValues3.clone();
        int int10 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        boolean boolean13 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        int int9 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        java.lang.String str18 = timePeriodValues14.getDomainDescription();
        boolean boolean19 = year10.equals((java.lang.Object) str18);
        long long20 = year10.getSerialIndex();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year10.next();
        java.util.Date date24 = year10.getStart();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date24, timeZone27);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(class30);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener24);
        boolean boolean26 = timePeriodValues22.isEmpty();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        boolean boolean28 = timePeriodValues22.isEmpty();
        timePeriodValues22.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (double) 4);
        timePeriodValues22.add(timePeriodValue35);
        timePeriodValues3.add(timePeriodValue35);
        int int38 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (-1.0d) + "'", comparable27.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        int int13 = timePeriodValues8.getItemCount();
        timePeriodValues8.setNotify(true);
        int int16 = timePeriodValues8.getMaxEndIndex();
        int int17 = timePeriodValues8.getMaxStartIndex();
        int int18 = day0.compareTo((java.lang.Object) timePeriodValues8);
        java.lang.String str19 = timePeriodValues8.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        boolean boolean27 = timePeriodValues23.isEmpty();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        timePeriodValues23.setDescription("");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 0L);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (double) 4);
        long long37 = year34.getFirstMillisecond();
        boolean boolean38 = year31.equals((java.lang.Object) year34);
        long long39 = year34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year34.previous();
        long long41 = year34.getFirstMillisecond();
        timePeriodValues8.setKey((java.lang.Comparable) year34);
        java.lang.String str43 = timePeriodValues8.getRangeDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-1.0d) + "'", comparable28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1562097599999L + "'", long39 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener24);
        boolean boolean26 = timePeriodValues22.isEmpty();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        boolean boolean28 = timePeriodValues22.isEmpty();
        timePeriodValues22.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (double) 4);
        timePeriodValues22.add(timePeriodValue35);
        timePeriodValues3.add(timePeriodValue35);
        int int38 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setNotify(true);
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (-1.0d) + "'", comparable27.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date64, timeZone72);
        java.lang.String str74 = year73.toString();
        long long75 = year73.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue77 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year73, (java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "2019" + "'", str74.equals("2019"));
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1546329600000L + "'", long75 == 1546329600000L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) (short) -1);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 4);
        java.lang.Number number15 = timePeriodValue14.getValue();
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue14.getPeriod();
        timePeriodValues3.add(timePeriodValue14);
        int int18 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 4.0d + "'", number15.equals(4.0d));
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        long long9 = year6.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) seriesException16);
        boolean boolean18 = year6.equals((java.lang.Object) seriesException16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year6.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues26.fireSeriesChanged();
        int int28 = timePeriodValues26.getMaxStartIndex();
        boolean boolean29 = timePeriodValues3.equals((java.lang.Object) int28);
        int int30 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 4);
        timePeriodValue35.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod38 = timePeriodValue35.getPeriod();
        java.lang.Number number39 = timePeriodValue35.getValue();
        java.lang.Number number40 = timePeriodValue35.getValue();
        boolean boolean41 = timePeriodValues3.equals((java.lang.Object) timePeriodValue35);
        int int42 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(timePeriod38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (byte) 1 + "'", number39.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (byte) 1 + "'", number40.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        long long13 = year11.getFirstMillisecond();
        java.lang.Class<?> wildcardClass14 = year11.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.next();
        java.util.Date date16 = year11.getEnd();
        int int18 = year11.compareTo((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,13]");
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValue12.setValue((java.lang.Number) (byte) 1);
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValues3.delete(10, 8);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int13 = timePeriodValues3.getItemCount();
        timePeriodValues3.fireSeriesChanged();
        boolean boolean15 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("2019");
        try {
            timePeriodValues3.update(6, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues8.createCopy(11, 7);
        boolean boolean12 = day0.equals((java.lang.Object) timePeriodValues11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 4);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 0.0f);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass24 = simpleTimePeriod23.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
        boolean boolean28 = year13.equals((java.lang.Object) class27);
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) (short) -1);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        boolean boolean4 = timePeriodValues3.getNotify();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year0.next();
        long long22 = year0.getSerialIndex();
        java.util.Date date23 = year0.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass27 = simpleTimePeriod26.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues31.fireSeriesChanged();
        int int33 = timePeriodValues31.getMaxStartIndex();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues38.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
        java.lang.String str42 = timePeriodValues38.getDomainDescription();
        boolean boolean43 = year34.equals((java.lang.Object) str42);
        long long44 = year34.getSerialIndex();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year34, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year34.next();
        java.util.Date date48 = year34.getStart();
        java.lang.Class class49 = null;
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date48, timeZone51);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date23, timeZone51);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year55, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue59 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year55, (double) 4);
        timePeriodValue59.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass65 = simpleTimePeriod64.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues69.fireSeriesChanged();
        int int71 = timePeriodValues69.getMaxStartIndex();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues76 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues76.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener78 = null;
        timePeriodValues76.removePropertyChangeListener(propertyChangeListener78);
        java.lang.String str80 = timePeriodValues76.getDomainDescription();
        boolean boolean81 = year72.equals((java.lang.Object) str80);
        long long82 = year72.getSerialIndex();
        timePeriodValues69.add((org.jfree.data.time.TimePeriod) year72, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year72.next();
        java.util.Date date86 = year72.getStart();
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date86, timeZone87);
        boolean boolean89 = timePeriodValue59.equals((java.lang.Object) timeZone87);
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date23, timeZone87);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "hi!" + "'", str80.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 2019L + "'", long82 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 0.0f);
        java.util.Date date7 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.previous();
        org.jfree.data.time.SerialDate serialDate12 = day8.getSerialDate();
        int int13 = day8.getMonth();
        java.util.Date date14 = day8.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date7, date14);
        java.util.Date date16 = simpleTimePeriod15.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day5);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        boolean boolean15 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues3.createCopy(12, 11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timePeriodValues20);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        timePeriodValues8.setDomainDescription("hi!");
        int int15 = timePeriodValues8.getItemCount();
        int int16 = timePeriodValues8.getMinEndIndex();
        java.lang.Object obj17 = timePeriodValues8.clone();
        java.lang.String str18 = timePeriodValues8.getDomainDescription();
        boolean boolean19 = year0.equals((java.lang.Object) timePeriodValues8);
        java.util.Date date20 = year0.getStart();
        long long21 = year0.getLastMillisecond();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year0.getMiddleMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) year6);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues12.createCopy(11, 7);
        boolean boolean16 = year6.equals((java.lang.Object) 11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) seriesException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException14);
        java.lang.String str17 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException1.getSuppressed();
        java.lang.String str19 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) 1560452399999L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
//        int int17 = day13.getDayOfMonth();
//        boolean boolean18 = timePeriodValue12.equals((java.lang.Object) day13);
//        boolean boolean19 = day5.equals((java.lang.Object) day13);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int13 = timePeriodValues3.getItemCount();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDescription("13-June-2019");
        int int17 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        long long13 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timePeriodValues18.isEmpty();
        timePeriodValues18.setDomainDescription("hi!");
        int int25 = year0.compareTo((java.lang.Object) timePeriodValues18);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
        java.lang.String str34 = timePeriodValues30.getDomainDescription();
        boolean boolean35 = year26.equals((java.lang.Object) str34);
        long long36 = year26.getSerialIndex();
        java.lang.String str37 = year26.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long41 = simpleTimePeriod40.getStartMillis();
        long long42 = simpleTimePeriod40.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean45 = simpleTimePeriod40.equals((java.lang.Object) timePeriodValues44);
        boolean boolean46 = year26.equals((java.lang.Object) timePeriodValues44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year26.next();
        long long48 = year26.getSerialIndex();
        long long49 = year26.getSerialIndex();
        long long50 = year26.getMiddleMillisecond();
        int int51 = year26.getYear();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) year26, (double) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year26.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1562097599999L + "'", long50 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        long long11 = year0.getFirstMillisecond();
        int int12 = year0.getYear();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable16 = timePeriodValues15.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        boolean boolean24 = timePeriodValues20.isEmpty();
        java.lang.Comparable comparable25 = timePeriodValues20.getKey();
        timePeriodValues20.setDescription("");
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) 0L);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) (byte) 100);
        int int33 = timePeriodValues15.getItemCount();
        boolean boolean34 = day7.equals((java.lang.Object) int33);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (double) 1);
        java.util.Date date37 = day7.getStart();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (-1.0d) + "'", comparable16.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (-1.0d) + "'", comparable25.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.Calendar calendar24 = null;
        try {
            year23.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
//        java.lang.String str11 = day0.toString();
//        int int12 = day0.getYear();
//        long long13 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        java.lang.String str4 = day0.toString();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "", "13-June-2019");
//        int int9 = timePeriodValues8.getMinEndIndex();
//        timePeriodValues8.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year6.previous();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues12.isEmpty();
        int int17 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues12.equals(obj20);
        int int22 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        timePeriodValues12.add(timePeriod26, (java.lang.Number) 100);
        int int29 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriod26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int29);
        try {
            java.lang.Number number32 = timePeriodValues30.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.lang.String str5 = day0.toString();
//        int int6 = day0.getYear();
//        long long7 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0d);
//        java.lang.String str13 = timePeriodValue12.toString();
//        java.lang.String str14 = timePeriodValue12.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str13.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str14.equals("TimePeriodValue[13-June-2019,10.0]"));
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj9 = timePeriodValues3.clone();
        int int10 = timePeriodValues3.getMinStartIndex();
        java.lang.String str11 = timePeriodValues3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setKey((java.lang.Comparable) 1.0d);
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(13, (-163));
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) seriesException22);
        java.lang.Throwable[] throwableArray24 = seriesException22.getSuppressed();
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
        seriesException26.addSuppressed((java.lang.Throwable) seriesException28);
        seriesException22.addSuppressed((java.lang.Throwable) seriesException26);
        boolean boolean31 = timePeriodValues15.equals((java.lang.Object) seriesException22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener32);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.lang.String str6 = timePeriodValue5.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        seriesException12.addSuppressed((java.lang.Throwable) seriesException14);
        java.lang.String str16 = seriesException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException14.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray20 = seriesException14.getSuppressed();
        boolean boolean21 = timePeriodValue5.equals((java.lang.Object) throwableArray20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable26 = timePeriodValues25.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
        boolean boolean34 = timePeriodValues30.isEmpty();
        java.lang.Comparable comparable35 = timePeriodValues30.getKey();
        timePeriodValues30.setDescription("");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 0L);
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) (byte) 100);
        long long43 = year38.getMiddleMillisecond();
        boolean boolean44 = timePeriodValue5.equals((java.lang.Object) long43);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,0]" + "'", str6.equals("TimePeriodValue[2019,0]"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str16.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (-1.0d) + "'", comparable26.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (-1.0d) + "'", comparable35.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1562097599999L + "'", long43 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,1546329600000]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
        timePeriodValues17.add(timePeriodValue30);
        java.lang.Number number32 = timePeriodValue30.getValue();
        timePeriodValues3.add(timePeriodValue30);
        timePeriodValue30.setValue((java.lang.Number) 0);
        java.lang.Number number36 = timePeriodValue30.getValue();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0 + "'", number36.equals(0));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 1546415999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.previous();
        org.jfree.data.time.SerialDate serialDate27 = day23.getSerialDate();
        int int28 = day23.getMonth();
        java.util.Date date29 = day23.getStart();
        java.util.Date date30 = day23.getEnd();
        java.util.Date date31 = day23.getEnd();
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        java.lang.Class<?> wildcardClass37 = timePeriodFormatException35.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues41.fireSeriesChanged();
        int int43 = timePeriodValues41.getMaxStartIndex();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues48.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues48.removePropertyChangeListener(propertyChangeListener50);
        java.lang.String str52 = timePeriodValues48.getDomainDescription();
        boolean boolean53 = year44.equals((java.lang.Object) str52);
        long long54 = year44.getSerialIndex();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year44, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year44.next();
        java.util.Date date58 = year44.getStart();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass63 = simpleTimePeriod62.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues67.fireSeriesChanged();
        int int69 = timePeriodValues67.getMaxStartIndex();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues74.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timePeriodValues74.removePropertyChangeListener(propertyChangeListener76);
        java.lang.String str78 = timePeriodValues74.getDomainDescription();
        boolean boolean79 = year70.equals((java.lang.Object) str78);
        long long80 = year70.getSerialIndex();
        timePeriodValues67.add((org.jfree.data.time.TimePeriod) year70, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = year70.next();
        java.util.Date date84 = year70.getStart();
        java.lang.Class class85 = null;
        java.util.Date date86 = null;
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class85, date86, timeZone87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date84, timeZone87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date58, timeZone87);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date31, timeZone87);
        int int92 = year16.compareTo((java.lang.Object) date31);
        java.util.Calendar calendar93 = null;
        try {
            year16.peg(calendar93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "hi!" + "'", str78.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 2019L + "'", long80 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 1.0f);
        java.lang.String str15 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues3.getTimePeriod(0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(timePeriod17);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        int int16 = timePeriodValues3.getMinEndIndex();
        java.lang.String str17 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues3.createCopy((int) (byte) 100, 8);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue22 = timePeriodValues3.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(timePeriodValues20);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getYear();
        java.lang.Object obj17 = null;
        boolean boolean18 = day15.equals(obj17);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 10.0f);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues3.createCopy((int) (byte) 1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
//        long long5 = day4.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        timePeriodValues3.setDomainDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1L) + "'", obj2.equals((-1L)));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (-1L) + "'", obj5.equals((-1L)));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) (short) -1);
        java.lang.String str12 = year7.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues12.isEmpty();
        int int17 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues12.equals(obj20);
        int int22 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        timePeriodValues12.add(timePeriod26, (java.lang.Number) 100);
        int int29 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriod26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int29);
        int int31 = timePeriodValues30.getMinStartIndex();
        int int32 = timePeriodValues30.getMaxEndIndex();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(11, 7);
        timePeriodValues1.setRangeDescription("");
        timePeriodValues1.setDomainDescription("TimePeriodValue[2019,0]");
        org.junit.Assert.assertNotNull(timePeriodValues4);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        long long5 = day0.getFirstMillisecond();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMaxEndIndex();
        boolean boolean12 = timePeriodValues3.getNotify();
        java.lang.String str13 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setKey((java.lang.Comparable) 'a');
//        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        int int13 = timePeriodValues3.getItemCount();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        long long18 = day17.getFirstMillisecond();
//        java.util.Date date19 = day17.getStart();
//        timePeriodValues3.setKey((java.lang.Comparable) date19);
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.delete(12, (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        long long24 = year23.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        boolean boolean5 = timePeriodValues3.getNotify();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1]");
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues19.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener21);
        boolean boolean23 = timePeriodValues19.isEmpty();
        java.lang.Comparable comparable24 = timePeriodValues19.getKey();
        timePeriodValues19.setDescription("");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 0L);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year30, (double) 4);
        long long33 = year30.getFirstMillisecond();
        boolean boolean34 = year27.equals((java.lang.Object) year30);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year30, (double) (short) 0);
        long long37 = year30.getFirstMillisecond();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = year30.getMiddleMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (-1.0d) + "'", comparable24.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int14 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener15);
        boolean boolean17 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        boolean boolean17 = timePeriodValues13.isEmpty();
        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues24.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues24.removePropertyChangeListener(propertyChangeListener26);
        boolean boolean28 = timePeriodValues24.isEmpty();
        java.lang.Comparable comparable29 = timePeriodValues24.getKey();
        boolean boolean30 = timePeriodValues24.isEmpty();
        int int31 = timePeriodValues24.getMaxStartIndex();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        timePeriodValues24.setKey((java.lang.Comparable) year32);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) 13);
        boolean boolean38 = year0.equals((java.lang.Object) year32);
        long long39 = year32.getSerialIndex();
        java.lang.String str40 = year32.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (-1.0d) + "'", comparable29.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.lang.String str6 = timePeriodValue5.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) day7);
        timePeriodValue5.setValue((java.lang.Number) 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,0]" + "'", str6.equals("TimePeriodValue[2019,0]"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue16.getPeriod();
        timePeriodValues3.add(timePeriod17, (java.lang.Number) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener20);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue23 = timePeriodValues3.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriod17);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
//        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 0.0f);
//        java.util.Date date7 = simpleTimePeriod2.getStart();
//        java.lang.Class<?> wildcardClass8 = date7.getClass();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.previous();
//        boolean boolean17 = simpleTimePeriod12.equals((java.lang.Object) regularTimePeriod16);
//        java.util.Date date18 = simpleTimePeriod12.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
//        java.lang.String str22 = day19.toString();
//        java.lang.String str23 = day19.toString();
//        java.util.Date date24 = day19.getEnd();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues29.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timePeriodValues29.removePropertyChangeListener(propertyChangeListener31);
//        java.lang.String str33 = timePeriodValues29.getDomainDescription();
//        timePeriodValues29.fireSeriesChanged();
//        timePeriodValues29.setKey((java.lang.Comparable) 'a');
//        timePeriodValues29.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        int int39 = timePeriodValues29.getItemCount();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(serialDate42);
//        long long44 = day43.getFirstMillisecond();
//        java.util.Date date45 = day43.getStart();
//        timePeriodValues29.setKey((java.lang.Comparable) date45);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        java.util.Date date50 = simpleTimePeriod49.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date45, timeZone51);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date24, timeZone51);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date18, timeZone51);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date7, timeZone51);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560409200000L + "'", long44 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date64, timeZone72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date64);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day75.previous();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        int int12 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues3.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        int int13 = timePeriodValues8.getItemCount();
        timePeriodValues8.setNotify(true);
        int int16 = timePeriodValues8.getMaxEndIndex();
        int int17 = timePeriodValues8.getMaxStartIndex();
        int int18 = day0.compareTo((java.lang.Object) timePeriodValues8);
        java.lang.String str19 = timePeriodValues8.getRangeDescription();
        java.lang.String str20 = timePeriodValues8.getDescription();
        java.lang.String str21 = timePeriodValues8.getRangeDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        try {
            java.lang.Number number25 = timePeriodValues3.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 2019");
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        timePeriodValues4.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues4.clone();
        boolean boolean11 = year0.equals(obj10);
        long long12 = year0.getFirstMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            year0.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setKey((java.lang.Comparable) 1.0d);
        timePeriodValues3.setKey((java.lang.Comparable) "TimePeriodValue[2019,0]");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 4);
        timePeriodValues14.add(timePeriodValue17);
        timePeriodValues3.add(timePeriodValue17);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        int int21 = timePeriodValues3.getMaxEndIndex();
        int int22 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = day0.equals(obj2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year0.next();
        long long22 = year0.getSerialIndex();
        java.util.Date date23 = year0.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        java.lang.Object obj4 = null;
        int int5 = day0.compareTo(obj4);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "org.jfree.data.general.SeriesChangeEvent[source=-1]");
        int int11 = timePeriodValues10.getMinEndIndex();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues4.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
//        java.lang.String str8 = timePeriodValues4.getDomainDescription();
//        boolean boolean9 = year0.equals((java.lang.Object) str8);
//        long long10 = year0.getSerialIndex();
//        long long11 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable16 = timePeriodValues15.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timePeriodValues15.removeChangeListener(seriesChangeListener17);
//        java.lang.String str19 = timePeriodValues15.getDescription();
//        timePeriodValues15.setDomainDescription("");
//        timePeriodValues15.setKey((java.lang.Comparable) 1.0d);
//        int int24 = timePeriodValues15.getMaxStartIndex();
//        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
//        seriesException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
//        boolean boolean30 = timePeriodValues15.equals((java.lang.Object) seriesException26);
//        timePeriodValues15.setDomainDescription("13-June-2019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues36.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timePeriodValues36.removePropertyChangeListener(propertyChangeListener38);
//        boolean boolean40 = timePeriodValues36.isEmpty();
//        timePeriodValues36.setDomainDescription("hi!");
//        int int43 = timePeriodValues36.getItemCount();
//        int int44 = timePeriodValues36.getMinEndIndex();
//        timePeriodValues36.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues50.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timePeriodValues50.removePropertyChangeListener(propertyChangeListener52);
//        boolean boolean54 = timePeriodValues50.isEmpty();
//        java.lang.Comparable comparable55 = timePeriodValues50.getKey();
//        boolean boolean56 = timePeriodValues50.isEmpty();
//        timePeriodValues50.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
//        timePeriodValues50.removeChangeListener(seriesChangeListener59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year61, (double) 4);
//        timePeriodValues50.add(timePeriodValue63);
//        java.lang.Number number65 = timePeriodValue63.getValue();
//        timePeriodValues36.add(timePeriodValue63);
//        timePeriodValue63.setValue((java.lang.Number) 0);
//        java.lang.Object obj69 = timePeriodValue63.clone();
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate71 = day70.getSerialDate();
//        int int73 = day70.compareTo((java.lang.Object) (-1L));
//        int int74 = day70.getDayOfMonth();
//        long long75 = day70.getSerialIndex();
//        boolean boolean76 = timePeriodValue63.equals((java.lang.Object) day70);
//        int int77 = day70.getYear();
//        boolean boolean78 = timePeriodValues15.equals((java.lang.Object) day70);
//        int int79 = year0.compareTo((java.lang.Object) boolean78);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (-1.0d) + "'", comparable16.equals((-1.0d)));
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + (-1.0d) + "'", comparable55.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 4.0d + "'", number65.equals(4.0d));
//        org.junit.Assert.assertNotNull(obj69);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 13 + "'", int74 == 13);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 43629L + "'", long75 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getYear();
        java.lang.Object obj17 = null;
        boolean boolean18 = day15.equals(obj17);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 10.0f);
        int int21 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        java.lang.Number number7 = timePeriodValue4.getValue();
        timePeriodValue4.setValue((java.lang.Number) 0L);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        int int13 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues19.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener21);
        boolean boolean23 = timePeriodValues19.isEmpty();
        java.lang.Comparable comparable24 = timePeriodValues19.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues19.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
        boolean boolean34 = timePeriodValues30.isEmpty();
        java.lang.Comparable comparable35 = timePeriodValues30.getKey();
        boolean boolean36 = timePeriodValues30.isEmpty();
        int int37 = timePeriodValues30.getMaxStartIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        timePeriodValues30.setKey((java.lang.Comparable) year38);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues45.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener47);
        boolean boolean49 = timePeriodValues45.isEmpty();
        java.lang.Comparable comparable50 = timePeriodValues45.getKey();
        boolean boolean51 = timePeriodValues45.isEmpty();
        timePeriodValues45.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timePeriodValues45.removeChangeListener(seriesChangeListener54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue58 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year56, (double) 4);
        timePeriodValues45.add(timePeriodValue58);
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues63.fireSeriesChanged();
        int int65 = timePeriodValues63.getMaxStartIndex();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues70.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener72 = null;
        timePeriodValues70.removePropertyChangeListener(propertyChangeListener72);
        java.lang.String str74 = timePeriodValues70.getDomainDescription();
        boolean boolean75 = year66.equals((java.lang.Object) str74);
        long long76 = year66.getSerialIndex();
        timePeriodValues63.add((org.jfree.data.time.TimePeriod) year66, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year66.next();
        timePeriodValues45.add((org.jfree.data.time.TimePeriod) year66, (java.lang.Number) (short) 0);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year66, (java.lang.Number) 0.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod86 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date87 = simpleTimePeriod86.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues89 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean90 = simpleTimePeriod86.equals((java.lang.Object) 0.0f);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) simpleTimePeriod86, (double) (short) 1);
        java.util.Date date93 = simpleTimePeriod86.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod86, (double) (-163));
        int int96 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (-1.0d) + "'", comparable24.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (-1.0d) + "'", comparable35.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + (-1.0d) + "'", comparable50.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 2019L + "'", long76 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        int int26 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str27 = timePeriodValues3.getDomainDescription();
        java.lang.String str28 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setKey((java.lang.Comparable) 1.0d);
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(13, (-163));
        int int16 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        boolean boolean24 = timePeriodValues20.isEmpty();
        java.lang.Comparable comparable25 = timePeriodValues20.getKey();
        timePeriodValues20.setDescription("");
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) 0L);
        timePeriodValues3.setKey((java.lang.Comparable) 0L);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener32);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (-1.0d) + "'", comparable25.equals((-1.0d)));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        int int15 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
        boolean boolean23 = simpleTimePeriod18.equals((java.lang.Object) regularTimePeriod22);
        java.lang.Number number24 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod22, number24);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue4.getPeriod();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue4);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.setNotify(false);
        timePeriodValues18.setDomainDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable27 = timePeriodValues26.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues26.createCopy(1, (int) ' ');
        int int31 = timePeriodValues26.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues35.fireSeriesChanged();
        int int37 = timePeriodValues35.getMaxStartIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues42.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues42.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues42.getDomainDescription();
        boolean boolean47 = year38.equals((java.lang.Object) str46);
        long long48 = year38.getSerialIndex();
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) year38, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        boolean boolean58 = timePeriodValues54.isEmpty();
        java.lang.Comparable comparable59 = timePeriodValues54.getKey();
        boolean boolean60 = timePeriodValues54.isEmpty();
        timePeriodValues54.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
        timePeriodValues54.removeChangeListener(seriesChangeListener63);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year65, (double) 4);
        timePeriodValues54.add(timePeriodValue67);
        timePeriodValues35.add(timePeriodValue67);
        timePeriodValues26.add(timePeriodValue67);
        timePeriodValue67.setValue((java.lang.Number) 1577865599999L);
        timePeriodValues18.add(timePeriodValue67);
        timePeriodValues3.add(timePeriodValue67);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 3 + "'", comparable27.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + comparable59 + "' != '" + (-1.0d) + "'", comparable59.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        int int16 = timePeriodValues3.getMinEndIndex();
        int int17 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues3.createCopy(4, (int) (byte) 1);
        java.lang.String str21 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        java.lang.Number number3 = timePeriodValue2.getValue();
        java.lang.Number number4 = timePeriodValue2.getValue();
        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue2.getPeriod();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 4.0d + "'", number3.equals(4.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.0d + "'", number4.equals(4.0d));
        org.junit.Assert.assertNotNull(timePeriod5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 0.0f);
        java.util.Date date7 = simpleTimePeriod2.getStart();
        java.lang.Class<?> wildcardClass8 = date7.getClass();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day9.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.Class<?> wildcardClass26 = timePeriodFormatException24.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        int int32 = timePeriodValues30.getMaxStartIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues37.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timePeriodValues37.removePropertyChangeListener(propertyChangeListener39);
        java.lang.String str41 = timePeriodValues37.getDomainDescription();
        boolean boolean42 = year33.equals((java.lang.Object) str41);
        long long43 = year33.getSerialIndex();
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) year33, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year33.next();
        java.util.Date date47 = year33.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass52 = simpleTimePeriod51.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues56.fireSeriesChanged();
        int int58 = timePeriodValues56.getMaxStartIndex();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues63.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues63.removePropertyChangeListener(propertyChangeListener65);
        java.lang.String str67 = timePeriodValues63.getDomainDescription();
        boolean boolean68 = year59.equals((java.lang.Object) str67);
        long long69 = year59.getSerialIndex();
        timePeriodValues56.add((org.jfree.data.time.TimePeriod) year59, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year59.next();
        java.util.Date date73 = year59.getStart();
        java.lang.Class class74 = null;
        java.util.Date date75 = null;
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date73, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date47, timeZone76);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date20, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year80.next();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 7, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean4 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
//        int int4 = timePeriodValues3.getMinEndIndex();
//        int int5 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        int int9 = day6.compareTo((java.lang.Object) (-1L));
//        int int10 = day6.getDayOfMonth();
//        long long11 = day6.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 5);
//        long long14 = day6.getLastMillisecond();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day6.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) (short) 100);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) ' ');
        java.lang.Number number7 = timePeriodValue6.getValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 32.0d + "'", number7.equals(32.0d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        long long13 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timePeriodValues18.isEmpty();
        timePeriodValues18.setDomainDescription("hi!");
        int int25 = year0.compareTo((java.lang.Object) timePeriodValues18);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
        java.lang.String str34 = timePeriodValues30.getDomainDescription();
        boolean boolean35 = year26.equals((java.lang.Object) str34);
        long long36 = year26.getSerialIndex();
        java.lang.String str37 = year26.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long41 = simpleTimePeriod40.getStartMillis();
        long long42 = simpleTimePeriod40.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean45 = simpleTimePeriod40.equals((java.lang.Object) timePeriodValues44);
        boolean boolean46 = year26.equals((java.lang.Object) timePeriodValues44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year26.next();
        long long48 = year26.getSerialIndex();
        long long49 = year26.getSerialIndex();
        long long50 = year26.getMiddleMillisecond();
        int int51 = year26.getYear();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) year26, (double) 100);
        boolean boolean54 = timePeriodValues18.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1562097599999L + "'", long50 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) (short) 100);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        int int6 = day3.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
//        boolean boolean8 = day0.equals((java.lang.Object) regularTimePeriod7);
//        int int9 = day0.getYear();
//        java.util.Date date10 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int14 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener15);
        boolean boolean17 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        int int6 = day3.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
//        boolean boolean8 = day0.equals((java.lang.Object) regularTimePeriod7);
//        java.lang.Object obj9 = null;
//        boolean boolean10 = day0.equals(obj9);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        java.lang.Number number7 = timePeriodValue4.getValue();
        java.lang.Class<?> wildcardClass8 = number7.getClass();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy(10, (int) (byte) 1);
        java.lang.Comparable comparable9 = null;
        try {
            timePeriodValues3.setKey(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        long long13 = year11.getFirstMillisecond();
        java.lang.Class<?> wildcardClass14 = year11.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.next();
        long long16 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = timePeriodValues20.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day27, (double) (byte) -1);
        java.lang.Comparable comparable31 = timePeriodValues20.getKey();
        timePeriodValues20.setKey((java.lang.Comparable) false);
        boolean boolean34 = year11.equals((java.lang.Object) timePeriodValues20);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(timePeriodValues26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (-1.0d) + "'", comparable31.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Object obj12 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues16.fireSeriesChanged();
        int int18 = timePeriodValues16.getMaxStartIndex();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timePeriodValues23.getDomainDescription();
        boolean boolean28 = year19.equals((java.lang.Object) str27);
        long long29 = year19.getSerialIndex();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year19, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year19.next();
        java.util.Date date33 = year19.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues38.fireSeriesChanged();
        int int40 = timePeriodValues38.getMaxStartIndex();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues45.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener47);
        java.lang.String str49 = timePeriodValues45.getDomainDescription();
        boolean boolean50 = year41.equals((java.lang.Object) str49);
        long long51 = year41.getSerialIndex();
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) year41, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year41.next();
        java.util.Date date55 = year41.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date33, date55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.previous();
        timePeriodValues3.setKey((java.lang.Comparable) year57);
        java.util.Calendar calendar60 = null;
        try {
            long long61 = year57.getMiddleMillisecond(calendar60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        java.util.Date date8 = day0.getEnd();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        int int20 = timePeriodValues18.getMaxStartIndex();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener27);
        java.lang.String str29 = timePeriodValues25.getDomainDescription();
        boolean boolean30 = year21.equals((java.lang.Object) str29);
        long long31 = year21.getSerialIndex();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) year21, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year21.next();
        java.util.Date date35 = year21.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass40 = simpleTimePeriod39.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues44.fireSeriesChanged();
        int int46 = timePeriodValues44.getMaxStartIndex();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues51.removePropertyChangeListener(propertyChangeListener53);
        java.lang.String str55 = timePeriodValues51.getDomainDescription();
        boolean boolean56 = year47.equals((java.lang.Object) str55);
        long long57 = year47.getSerialIndex();
        timePeriodValues44.add((org.jfree.data.time.TimePeriod) year47, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year47.next();
        java.util.Date date61 = year47.getStart();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date35, timeZone64);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date8, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        long long70 = year68.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "hi!" + "'", str55.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(1530561599999L, 1546415999999L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) 1546415999999L);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(7, (-1));
//        int int10 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        int int16 = day11.getMonth();
//        long long17 = day11.getFirstMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day11, (double) 3);
//        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,0]");
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,1546329600000]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        java.lang.Object obj6 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1L) + "'", obj2.equals((-1L)));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1L) + "'", obj4.equals((-1L)));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (-1L) + "'", obj5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (-1L) + "'", obj6.equals((-1L)));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        timePeriodValues8.setDomainDescription("hi!");
        int int15 = timePeriodValues8.getItemCount();
        int int16 = timePeriodValues8.getMinEndIndex();
        java.lang.Object obj17 = timePeriodValues8.clone();
        java.lang.String str18 = timePeriodValues8.getDomainDescription();
        boolean boolean19 = year0.equals((java.lang.Object) timePeriodValues8);
        java.util.Date date20 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod21, (double) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 4);
        timePeriodValues14.add(timePeriodValue17);
        timePeriodValues3.add(timePeriodValue17);
        try {
            org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValues3.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues3.getMinEndIndex();
        java.lang.Class<?> wildcardClass17 = timePeriodValues3.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues3.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        int int16 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.delete((int) '4', (-1));
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) 4);
        timePeriodValue24.setValue((java.lang.Number) (byte) 1);
        java.lang.Number number27 = timePeriodValue24.getValue();
        timePeriodValues3.add(timePeriodValue24);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (byte) 1 + "'", number27.equals((byte) 1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValue12.setValue((java.lang.Number) (byte) 1);
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues19.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener21);
        java.lang.String str23 = timePeriodValues19.getDomainDescription();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 4);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 1.0f);
        java.lang.String str31 = year24.toString();
        java.util.Date date32 = year24.getEnd();
        timePeriodValues3.setKey((java.lang.Comparable) date32);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-163), 2019L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(11, 7);
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        long long19 = year6.getFirstMillisecond();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.previous();
        org.jfree.data.time.SerialDate serialDate24 = day20.getSerialDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        int int26 = year6.compareTo((java.lang.Object) serialDate24);
        int int27 = year6.getYear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,-1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDescription("TimePeriodValue[2019,1]");
        boolean boolean20 = timePeriodValues3.getNotify();
        boolean boolean21 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7L + "'", long4 == 7L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timePeriodValues7.isEmpty();
        timePeriodValues7.setDomainDescription("hi!");
        java.lang.String str14 = timePeriodValues7.getDescription();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.lang.String str11 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 0.0f);
        java.util.Date date7 = simpleTimePeriod2.getStart();
        java.lang.Class<?> wildcardClass8 = date7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues6.fireSeriesChanged();
        int int8 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        java.lang.String str17 = timePeriodValues13.getDomainDescription();
        boolean boolean18 = year9.equals((java.lang.Object) str17);
        long long19 = year9.getSerialIndex();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year9, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year9.next();
        java.util.Date date23 = year9.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        int int30 = timePeriodValues28.getMaxStartIndex();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues35.getDomainDescription();
        boolean boolean40 = year31.equals((java.lang.Object) str39);
        long long41 = year31.getSerialIndex();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year31, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year31.next();
        java.util.Date date45 = year31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(date23, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues50.fireSeriesChanged();
        int int52 = timePeriodValues50.getMaxStartIndex();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues57.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener59);
        java.lang.String str61 = timePeriodValues57.getDomainDescription();
        boolean boolean62 = year53.equals((java.lang.Object) str61);
        long long63 = year53.getSerialIndex();
        timePeriodValues50.add((org.jfree.data.time.TimePeriod) year53, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year53.next();
        java.util.Date date67 = year53.getStart();
        boolean boolean68 = simpleTimePeriod46.equals((java.lang.Object) date67);
        java.lang.Class class69 = null;
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date70, timeZone71);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date67, timeZone71);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date67);
        long long75 = day74.getSerialIndex();
        boolean boolean76 = year0.equals((java.lang.Object) day74);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate78 = day77.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day77.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue81 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day77, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue83 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day77, (double) 1560452399999L);
        boolean boolean84 = year0.equals((java.lang.Object) day77);
        int int86 = year0.compareTo((java.lang.Object) 10.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 43466L + "'", long75 == 43466L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        timePeriodValues3.setDomainDescription("hi!");
//        int int10 = timePeriodValues3.getItemCount();
//        int int11 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues17.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
//        boolean boolean21 = timePeriodValues17.isEmpty();
//        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
//        boolean boolean23 = timePeriodValues17.isEmpty();
//        timePeriodValues17.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timePeriodValues17.removeChangeListener(seriesChangeListener26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
//        timePeriodValues17.add(timePeriodValue30);
//        java.lang.Number number32 = timePeriodValue30.getValue();
//        timePeriodValues3.add(timePeriodValue30);
//        timePeriodValue30.setValue((java.lang.Number) 0);
//        java.lang.Object obj36 = timePeriodValue30.clone();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
//        int int40 = day37.compareTo((java.lang.Object) (-1L));
//        int int41 = day37.getDayOfMonth();
//        long long42 = day37.getSerialIndex();
//        boolean boolean43 = timePeriodValue30.equals((java.lang.Object) day37);
//        org.jfree.data.time.TimePeriod timePeriod44 = timePeriodValue30.getPeriod();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 13 + "'", int41 == 13);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43629L + "'", long42 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(timePeriod44);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        java.lang.String str23 = year16.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year16, "TimePeriodValue[13-June-2019,1546329600000]", "TimePeriodValue[13-June-2019,-1.0]");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.lang.String str5 = timePeriodValues3.getDomainDescription();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable15 = timePeriodValues14.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues19.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues19.removePropertyChangeListener(propertyChangeListener21);
//        boolean boolean23 = timePeriodValues19.isEmpty();
//        java.lang.Comparable comparable24 = timePeriodValues19.getKey();
//        timePeriodValues19.setDescription("");
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 0L);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) (byte) 100);
//        int int32 = timePeriodValues14.getItemCount();
//        boolean boolean33 = day6.equals((java.lang.Object) int32);
//        int int34 = day6.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) (short) -1);
//        java.lang.String str37 = day6.toString();
//        java.util.Date date38 = day6.getStart();
//        long long39 = day6.getFirstMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (-1.0d) + "'", comparable15.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (-1.0d) + "'", comparable24.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560409200000L + "'", long39 == 1560409200000L);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean13 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 1593676799999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        int int23 = year22.getYear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 0.0f);
        java.util.Date date7 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long11 = simpleTimePeriod10.getStartMillis();
        long long12 = simpleTimePeriod10.getEndMillis();
        java.util.Date date13 = simpleTimePeriod10.getEnd();
        java.util.Date date14 = simpleTimePeriod10.getEnd();
        long long15 = simpleTimePeriod10.getEndMillis();
        java.util.Date date16 = simpleTimePeriod10.getStart();
        try {
            int int17 = simpleTimePeriod2.compareTo((java.lang.Object) date16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues12.isEmpty();
        int int17 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues12.equals(obj20);
        int int22 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        timePeriodValues12.add(timePeriod26, (java.lang.Number) 100);
        int int29 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriod26);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod2);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1530561599999L, 1546415999999L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1530561599999L + "'", long3 == 1530561599999L);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test373");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean13 = timePeriodValues3.getNotify();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.previous();
//        org.jfree.data.time.SerialDate serialDate18 = day14.getSerialDate();
//        int int19 = day14.getMonth();
//        java.util.Date date20 = day14.getStart();
//        java.lang.String str21 = day14.toString();
//        timePeriodValues3.setKey((java.lang.Comparable) str21);
//        timePeriodValues3.fireSeriesChanged();
//        java.lang.String str24 = timePeriodValues3.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNull(str24);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        java.lang.Object obj7 = timePeriodValue4.clone();
        java.lang.Object obj8 = timePeriodValue4.clone();
        java.lang.String str9 = timePeriodValue4.toString();
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,1]" + "'", str9.equals("TimePeriodValue[2019,1]"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        int int4 = timePeriodValues3.getItemCount();
//        boolean boolean5 = timePeriodValues3.getNotify();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues9.fireSeriesChanged();
//        int int11 = timePeriodValues9.getMaxStartIndex();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues16.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues16.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues16.getDomainDescription();
//        boolean boolean21 = year12.equals((java.lang.Object) str20);
//        long long22 = year12.getSerialIndex();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year12, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year12.next();
//        java.util.Date date26 = year12.getStart();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues31.fireSeriesChanged();
//        int int33 = timePeriodValues31.getMaxStartIndex();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues38.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
//        java.lang.String str42 = timePeriodValues38.getDomainDescription();
//        boolean boolean43 = year34.equals((java.lang.Object) str42);
//        long long44 = year34.getSerialIndex();
//        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year34, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year34.next();
//        java.util.Date date48 = year34.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date26, date48);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues53.fireSeriesChanged();
//        int int55 = timePeriodValues53.getMaxStartIndex();
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues60.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener62 = null;
//        timePeriodValues60.removePropertyChangeListener(propertyChangeListener62);
//        java.lang.String str64 = timePeriodValues60.getDomainDescription();
//        boolean boolean65 = year56.equals((java.lang.Object) str64);
//        long long66 = year56.getSerialIndex();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) year56, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year56.next();
//        java.util.Date date70 = year56.getStart();
//        boolean boolean71 = simpleTimePeriod49.equals((java.lang.Object) date70);
//        java.lang.Class class72 = null;
//        java.util.Date date73 = null;
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date73, timeZone74);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date70, timeZone74);
//        java.util.Date date77 = day76.getStart();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        int int79 = day78.getDayOfMonth();
//        int int80 = day78.getDayOfMonth();
//        int int81 = day76.compareTo((java.lang.Object) day78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = day78.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod82, (java.lang.Number) (-163));
//        java.beans.PropertyChangeListener propertyChangeListener85 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener85);
//        int int87 = timePeriodValues3.getMaxMiddleIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 13 + "'", int79 == 13);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 13 + "'", int80 == 13);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-163) + "'", int81 == (-163));
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        int int9 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        java.lang.String str18 = timePeriodValues14.getDomainDescription();
        boolean boolean19 = year10.equals((java.lang.Object) str18);
        long long20 = year10.getSerialIndex();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year10.next();
        java.util.Date date24 = year10.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date24, timeZone25);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues31.fireSeriesChanged();
        int int33 = timePeriodValues31.getMaxStartIndex();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues38.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
        java.lang.String str42 = timePeriodValues38.getDomainDescription();
        boolean boolean43 = year34.equals((java.lang.Object) str42);
        long long44 = year34.getSerialIndex();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year34, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year34.next();
        java.util.Date date48 = year34.getStart();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues53.fireSeriesChanged();
        int int55 = timePeriodValues53.getMaxStartIndex();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues60.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues60.removePropertyChangeListener(propertyChangeListener62);
        java.lang.String str64 = timePeriodValues60.getDomainDescription();
        boolean boolean65 = year56.equals((java.lang.Object) str64);
        long long66 = year56.getSerialIndex();
        timePeriodValues53.add((org.jfree.data.time.TimePeriod) year56, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year56.next();
        java.util.Date date70 = year56.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod(date48, date70);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date70);
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date70, timeZone73);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        boolean boolean5 = timePeriodValues3.getNotify();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1]");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        java.lang.String str17 = timePeriodValues13.getDomainDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) 4);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 1.0f);
        java.lang.String str25 = year18.toString();
        java.util.Date date26 = year18.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year18.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 1560452399999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod4, 0.0d);
        java.lang.Number number7 = timePeriodValue6.getValue();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(8, 3);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues1.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues4);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0d);
//        long long13 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1560452399999L);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        int int11 = day7.getDayOfMonth();
//        boolean boolean12 = timePeriodValue6.equals((java.lang.Object) day7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        int int16 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues21.removePropertyChangeListener(propertyChangeListener23);
        java.lang.String str25 = timePeriodValues21.getDomainDescription();
        boolean boolean26 = year17.equals((java.lang.Object) str25);
        long long27 = year17.getSerialIndex();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year17, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year17.next();
        java.util.Date date31 = year17.getStart();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues36.fireSeriesChanged();
        int int38 = timePeriodValues36.getMaxStartIndex();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues43.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues43.removePropertyChangeListener(propertyChangeListener45);
        java.lang.String str47 = timePeriodValues43.getDomainDescription();
        boolean boolean48 = year39.equals((java.lang.Object) str47);
        long long49 = year39.getSerialIndex();
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) year39, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year39.next();
        java.util.Date date53 = year39.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date31, date53);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues58.fireSeriesChanged();
        int int60 = timePeriodValues58.getMaxStartIndex();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues65.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener67 = null;
        timePeriodValues65.removePropertyChangeListener(propertyChangeListener67);
        java.lang.String str69 = timePeriodValues65.getDomainDescription();
        boolean boolean70 = year61.equals((java.lang.Object) str69);
        long long71 = year61.getSerialIndex();
        timePeriodValues58.add((org.jfree.data.time.TimePeriod) year61, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year61.next();
        java.util.Date date75 = year61.getStart();
        boolean boolean76 = simpleTimePeriod54.equals((java.lang.Object) date75);
        java.lang.Class class77 = null;
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date78, timeZone79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date75, timeZone79);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date75);
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date75, timeZone83);
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date75);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year85, (java.lang.Number) 1560452399999L);
        int int88 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2019L + "'", long71 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) (short) 100);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) ' ');
        long long7 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable16 = timePeriodValues15.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        boolean boolean24 = timePeriodValues20.isEmpty();
        java.lang.Comparable comparable25 = timePeriodValues20.getKey();
        timePeriodValues20.setDescription("");
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) 0L);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year28, (java.lang.Number) (byte) 100);
        int int33 = timePeriodValues15.getItemCount();
        boolean boolean34 = day7.equals((java.lang.Object) int33);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (double) 1);
        java.util.Date date37 = day7.getStart();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = day7.getLastMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (-1.0d) + "'", comparable16.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (-1.0d) + "'", comparable25.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean12);
        java.lang.Object obj14 = seriesChangeEvent13.getSource();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + false + "'", obj14.equals(false));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.String str11 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timePeriodValues7.isEmpty();
        java.lang.Comparable comparable12 = timePeriodValues7.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timePeriodValues18.isEmpty();
        java.lang.Comparable comparable23 = timePeriodValues18.getKey();
        boolean boolean24 = timePeriodValues18.isEmpty();
        int int25 = timePeriodValues18.getMaxStartIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        timePeriodValues18.setKey((java.lang.Comparable) year26);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) (short) -1);
        int int30 = simpleTimePeriod2.compareTo((java.lang.Object) year26);
        java.lang.Class<?> wildcardClass31 = simpleTimePeriod2.getClass();
        long long32 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (-1.0d) + "'", comparable12.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0d) + "'", comparable23.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
        int int11 = timePeriodValues10.getMaxEndIndex();
        timePeriodValues10.setRangeDescription("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        timePeriodValues8.setDomainDescription("hi!");
        int int15 = timePeriodValues8.getItemCount();
        int int16 = timePeriodValues8.getMinEndIndex();
        java.lang.Object obj17 = timePeriodValues8.clone();
        java.lang.String str18 = timePeriodValues8.getDomainDescription();
        boolean boolean19 = year0.equals((java.lang.Object) timePeriodValues8);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) 4);
        long long23 = year20.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.general.SeriesException seriesException30 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) seriesException30);
        boolean boolean32 = year20.equals((java.lang.Object) seriesException30);
        boolean boolean33 = year0.equals((java.lang.Object) seriesException30);
        java.lang.Throwable[] throwableArray34 = seriesException30.getSuppressed();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.previous();
        org.jfree.data.time.SerialDate serialDate27 = day23.getSerialDate();
        int int28 = day23.getMonth();
        java.util.Date date29 = day23.getStart();
        java.util.Date date30 = day23.getEnd();
        java.util.Date date31 = day23.getEnd();
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        java.lang.Class<?> wildcardClass37 = timePeriodFormatException35.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues41.fireSeriesChanged();
        int int43 = timePeriodValues41.getMaxStartIndex();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues48.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues48.removePropertyChangeListener(propertyChangeListener50);
        java.lang.String str52 = timePeriodValues48.getDomainDescription();
        boolean boolean53 = year44.equals((java.lang.Object) str52);
        long long54 = year44.getSerialIndex();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year44, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year44.next();
        java.util.Date date58 = year44.getStart();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass63 = simpleTimePeriod62.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues67.fireSeriesChanged();
        int int69 = timePeriodValues67.getMaxStartIndex();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues74.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timePeriodValues74.removePropertyChangeListener(propertyChangeListener76);
        java.lang.String str78 = timePeriodValues74.getDomainDescription();
        boolean boolean79 = year70.equals((java.lang.Object) str78);
        long long80 = year70.getSerialIndex();
        timePeriodValues67.add((org.jfree.data.time.TimePeriod) year70, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = year70.next();
        java.util.Date date84 = year70.getStart();
        java.lang.Class class85 = null;
        java.util.Date date86 = null;
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class85, date86, timeZone87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date84, timeZone87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date58, timeZone87);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date31, timeZone87);
        int int92 = year16.compareTo((java.lang.Object) date31);
        int int93 = year16.getYear();
        long long94 = year16.getSerialIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "hi!" + "'", str78.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 2019L + "'", long80 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2019 + "'", int93 == 2019);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 2019L + "'", long94 == 2019L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        int int10 = year0.getYear();
        long long11 = year0.getSerialIndex();
        java.util.Date date12 = year0.getStart();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        int int11 = timePeriodValues3.getMinStartIndex();
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 0.0d);
        timePeriodValues3.setDescription("2019");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        boolean boolean15 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        timePeriodValues3.setRangeDescription("TimePeriodValue[13-June-2019,1546329600000]");
        int int20 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        timePeriodValues3.setDomainDescription("hi!");
//        int int10 = timePeriodValues3.getItemCount();
//        int int11 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.String str14 = timePeriodValues3.getRangeDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        long long18 = day15.getLastMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 1593676799999L);
//        boolean boolean21 = timePeriodValues3.isEmpty();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) (short) -1);
        long long12 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.setNotify(false);
        int int13 = timePeriodValues10.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.setNotify(false);
        int int20 = timePeriodValues17.getMaxStartIndex();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) 4);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year21, (double) (short) -1);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year26, (double) 4);
        java.lang.Number number29 = timePeriodValue28.getValue();
        org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValue28.getPeriod();
        timePeriodValues17.add(timePeriodValue28);
        timePeriodValues10.add(timePeriodValue28);
        boolean boolean33 = timePeriodValues3.equals((java.lang.Object) timePeriodValue28);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 4.0d + "'", number29.equals(4.0d));
        org.junit.Assert.assertNotNull(timePeriod30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) (byte) 0);
        timePeriodValues3.setNotify(true);
        int int18 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, (-163), 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Object obj11 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test403");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.lang.String str5 = day0.toString();
//        int int6 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test404");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        boolean boolean26 = day18.equals((java.lang.Object) regularTimePeriod25);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day18, (double) (short) 10);
//        java.util.Calendar calendar29 = null;
//        try {
//            long long30 = day18.getFirstMillisecond(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException27.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues33.fireSeriesChanged();
        int int35 = timePeriodValues33.getMaxStartIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener42);
        java.lang.String str44 = timePeriodValues40.getDomainDescription();
        boolean boolean45 = year36.equals((java.lang.Object) str44);
        long long46 = year36.getSerialIndex();
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) year36, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year36.next();
        java.util.Date date50 = year36.getStart();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass55 = simpleTimePeriod54.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues59.fireSeriesChanged();
        int int61 = timePeriodValues59.getMaxStartIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues66.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener68 = null;
        timePeriodValues66.removePropertyChangeListener(propertyChangeListener68);
        java.lang.String str70 = timePeriodValues66.getDomainDescription();
        boolean boolean71 = year62.equals((java.lang.Object) str70);
        long long72 = year62.getSerialIndex();
        timePeriodValues59.add((org.jfree.data.time.TimePeriod) year62, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year62.next();
        java.util.Date date76 = year62.getStart();
        java.lang.Class class77 = null;
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date78, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date76, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date50, timeZone79);
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date22, timeZone79);
        org.jfree.data.time.SerialDate serialDate84 = day83.getSerialDate();
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(serialDate84);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "hi!" + "'", str70.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2019L + "'", long72 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(serialDate84);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getYear();
//        long long5 = day0.getFirstMillisecond();
//        int int6 = day0.getYear();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(11, 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener5);
        org.junit.Assert.assertNotNull(timePeriodValues4);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test408");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        long long6 = day5.getLastMillisecond();
//        java.util.Date date7 = day5.getStart();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues3.createCopy((int) ' ', (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        timePeriodValues8.setDomainDescription("hi!");
        int int15 = timePeriodValues8.getItemCount();
        int int16 = timePeriodValues8.getMinEndIndex();
        java.lang.Object obj17 = timePeriodValues8.clone();
        java.lang.String str18 = timePeriodValues8.getDomainDescription();
        boolean boolean19 = year0.equals((java.lang.Object) timePeriodValues8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year0.next();
        java.util.Calendar calendar21 = null;
        try {
            year0.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.util.Date date66 = simpleTimePeriod43.getEnd();
        java.util.Date date67 = simpleTimePeriod43.getEnd();
        java.util.Date date68 = simpleTimePeriod43.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long72 = simpleTimePeriod71.getStartMillis();
        long long73 = simpleTimePeriod71.getEndMillis();
        java.util.Date date74 = simpleTimePeriod71.getEnd();
        java.util.Date date75 = simpleTimePeriod71.getEnd();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod(date68, date75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 100L + "'", long73 == 100L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(date75);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener31);
        boolean boolean33 = timePeriodValues29.isEmpty();
        java.lang.Comparable comparable34 = timePeriodValues29.getKey();
        boolean boolean35 = timePeriodValues29.isEmpty();
        timePeriodValues29.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 4);
        timePeriodValues29.add(timePeriodValue42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (short) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year50.previous();
        long long69 = year50.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560365999999L, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test417");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timePeriodValues9.isEmpty();
        java.lang.Comparable comparable14 = timePeriodValues9.getKey();
        timePeriodValues9.setDescription("");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        boolean boolean27 = timePeriodValues23.isEmpty();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        boolean boolean29 = timePeriodValues23.isEmpty();
        int int30 = timePeriodValues23.getMaxStartIndex();
        int int31 = year17.compareTo((java.lang.Object) timePeriodValues23);
        try {
            int int32 = simpleTimePeriod2.compareTo((java.lang.Object) int31);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-1.0d) + "'", comparable28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,0]");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test420");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
//        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue(timePeriod3, (double) 2);
//        java.lang.Class<?> wildcardClass6 = timePeriodValue5.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        boolean boolean14 = timePeriodValues10.isEmpty();
//        java.lang.Comparable comparable15 = timePeriodValues10.getKey();
//        boolean boolean16 = timePeriodValues10.isEmpty();
//        int int17 = timePeriodValues10.getMaxStartIndex();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        timePeriodValues10.setKey((java.lang.Comparable) year18);
//        long long20 = year18.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass21 = year18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.next();
//        java.util.Date date23 = year18.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues27.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues27.removePropertyChangeListener(propertyChangeListener29);
//        java.lang.String str31 = timePeriodValues27.getDomainDescription();
//        timePeriodValues27.fireSeriesChanged();
//        timePeriodValues27.setKey((java.lang.Comparable) 'a');
//        timePeriodValues27.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        java.lang.Class<?> wildcardClass37 = timePeriodValues27.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate40 = day39.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate41 = day39.getSerialDate();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
//        long long43 = day42.getFirstMillisecond();
//        java.util.Date date44 = day42.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
//        java.util.Date date48 = simpleTimePeriod47.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues52.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener54 = null;
//        timePeriodValues52.removePropertyChangeListener(propertyChangeListener54);
//        java.lang.String str56 = timePeriodValues52.getDomainDescription();
//        timePeriodValues52.fireSeriesChanged();
//        timePeriodValues52.setKey((java.lang.Comparable) 'a');
//        timePeriodValues52.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        int int62 = timePeriodValues52.getItemCount();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate64 = day63.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate65 = day63.getSerialDate();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(serialDate65);
//        long long67 = day66.getFirstMillisecond();
//        java.util.Date date68 = day66.getStart();
//        timePeriodValues52.setKey((java.lang.Comparable) date68);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        java.util.Date date73 = simpleTimePeriod72.getStart();
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date73, timeZone74);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date68, timeZone74);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date48, timeZone74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date44, timeZone74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone74);
//        org.junit.Assert.assertNotNull(timePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (-1.0d) + "'", comparable15.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560409200000L + "'", long43 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560409200000L + "'", long67 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        seriesException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        seriesException22.addSuppressed((java.lang.Throwable) seriesException24);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) seriesException22);
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        seriesException22.addSuppressed((java.lang.Throwable) seriesException28);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException35 = new org.jfree.data.general.SeriesException("");
        seriesException33.addSuppressed((java.lang.Throwable) seriesException35);
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) seriesException33);
        org.jfree.data.general.SeriesException seriesException39 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException39.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException41.addSuppressed((java.lang.Throwable) seriesException44);
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) seriesException44);
        java.lang.String str47 = timePeriodFormatException31.toString();
        seriesException28.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.jfree.data.general.SeriesException seriesException50 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException50.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        java.lang.Class<?> wildcardClass54 = timePeriodFormatException52.getClass();
        java.lang.String str55 = timePeriodFormatException52.toString();
        seriesException28.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        java.lang.String str57 = seriesException28.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) seriesException28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str47.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str55.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str57.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMaxEndIndex();
        boolean boolean12 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener18);
        boolean boolean20 = timePeriodValues16.isEmpty();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) 4);
        timePeriodValue25.setValue((java.lang.Number) (byte) 1);
        timePeriodValues16.add(timePeriodValue25);
        java.lang.Number number29 = timePeriodValue25.getValue();
        timePeriodValues3.add(timePeriodValue25);
        int int31 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 1 + "'", number29.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues12.isEmpty();
        int int17 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues12.equals(obj20);
        int int22 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        timePeriodValues12.add(timePeriod26, (java.lang.Number) 100);
        int int29 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriod26);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod2);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener36);
        boolean boolean38 = timePeriodValues34.isEmpty();
        int int39 = timePeriodValues34.getMaxStartIndex();
        timePeriodValues34.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj42 = null;
        boolean boolean43 = timePeriodValues34.equals(obj42);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener44);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year50, (double) 4);
        timePeriodValues49.add(timePeriodValue52);
        boolean boolean54 = timePeriodValues34.equals((java.lang.Object) timePeriodValues49);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues49.removePropertyChangeListener(propertyChangeListener55);
        timePeriodValues49.setRangeDescription("TimePeriodValue[2019,1]");
        try {
            int int59 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues49);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test424");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues8.createCopy(11, 7);
//        boolean boolean12 = day0.equals((java.lang.Object) timePeriodValues11);
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate15 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timePeriodValues11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test425");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        long long3 = day2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        int int12 = day9.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) '#');
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues19.setNotify(false);
        timePeriodValues19.setDomainDescription("");
        boolean boolean24 = day9.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day9.previous();
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue16.getPeriod();
        timePeriodValues3.add(timePeriod17, (java.lang.Number) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues3.createCopy(6, (int) (short) -1);
        java.lang.String str25 = timePeriodValues3.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener26);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriod17);
        org.junit.Assert.assertNotNull(timePeriodValues24);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int2 = day0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test429");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        timePeriodValues18.setNotify(true);
        int int23 = timePeriodValues18.getItemCount();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(0, (-1));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        boolean boolean15 = simpleTimePeriod10.equals((java.lang.Object) regularTimePeriod14);
        java.util.Date date16 = simpleTimePeriod10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        boolean boolean24 = timePeriodValues20.isEmpty();
        int int25 = timePeriodValues20.getMaxStartIndex();
        timePeriodValues20.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj28 = null;
        boolean boolean29 = timePeriodValues20.equals(obj28);
        int int30 = timePeriodValues20.getMaxMiddleIndex();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue33.getPeriod();
        timePeriodValues20.add(timePeriod34, (java.lang.Number) 100);
        int int37 = simpleTimePeriod10.compareTo((java.lang.Object) timePeriod34);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (java.lang.Number) (short) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timePeriod34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) year6);
        long long11 = year6.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.String str17 = seriesException15.toString();
        int int18 = year6.compareTo((java.lang.Object) str17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year6.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable12 = timePeriodValues11.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener18);
        boolean boolean20 = timePeriodValues16.isEmpty();
        java.lang.Comparable comparable21 = timePeriodValues16.getKey();
        timePeriodValues16.setDescription("");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 0L);
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (byte) 100);
        long long29 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year24.previous();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (-1.0d) + "'", comparable12.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (-1.0d) + "'", comparable21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        java.lang.Number number9 = timePeriodValue8.getValue();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) number9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 4.0d + "'", number9.equals(4.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year7, (double) (short) -1);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year7.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test437");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int4, "TimePeriodValue[13-June-2019,-1.0]", "TimePeriodValue[2019,4.0]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable17 = timePeriodValues16.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues21.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues21.removePropertyChangeListener(propertyChangeListener23);
//        boolean boolean25 = timePeriodValues21.isEmpty();
//        java.lang.Comparable comparable26 = timePeriodValues21.getKey();
//        timePeriodValues21.setDescription("");
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 0L);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) (byte) 100);
//        int int34 = timePeriodValues16.getItemCount();
//        boolean boolean35 = day8.equals((java.lang.Object) int34);
//        org.jfree.data.time.SerialDate serialDate36 = day8.getSerialDate();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) (short) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues42.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timePeriodValues42.removePropertyChangeListener(propertyChangeListener44);
//        boolean boolean46 = timePeriodValues42.isEmpty();
//        timePeriodValues42.setDomainDescription("hi!");
//        int int49 = timePeriodValues42.getItemCount();
//        int int50 = timePeriodValues42.getMaxEndIndex();
//        boolean boolean51 = timePeriodValues42.getNotify();
//        timePeriodValues42.fireSeriesChanged();
//        boolean boolean53 = day8.equals((java.lang.Object) timePeriodValues42);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (-1.0d) + "'", comparable17.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (-1.0d) + "'", comparable26.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test438");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues7.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
//        java.lang.String str11 = timePeriodValues7.getDomainDescription();
//        boolean boolean12 = year3.equals((java.lang.Object) str11);
//        long long13 = year3.getSerialIndex();
//        java.lang.String str14 = year3.toString();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
//        long long18 = simpleTimePeriod17.getStartMillis();
//        long long19 = simpleTimePeriod17.getEndMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
//        boolean boolean22 = simpleTimePeriod17.equals((java.lang.Object) timePeriodValues21);
//        boolean boolean23 = year3.equals((java.lang.Object) timePeriodValues21);
//        long long24 = year3.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) 43466L);
//        timePeriodValue26.setValue((java.lang.Number) 7L);
//        int int29 = day0.compareTo((java.lang.Object) 7L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test439");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date5 = simpleTimePeriod2.getEnd();
//        java.util.Date date6 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues13.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
//        boolean boolean17 = timePeriodValues13.isEmpty();
//        int int18 = timePeriodValues13.getMaxStartIndex();
//        timePeriodValues13.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj21 = null;
//        boolean boolean22 = timePeriodValues13.equals(obj21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (double) 4);
//        timePeriodValues28.add(timePeriodValue31);
//        boolean boolean33 = timePeriodValues13.equals((java.lang.Object) timePeriodValues28);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues28.removePropertyChangeListener(propertyChangeListener34);
//        int int36 = timePeriodValues28.getMinMiddleIndex();
//        int int37 = day7.compareTo((java.lang.Object) timePeriodValues28);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setKey((java.lang.Comparable) 1.0d);
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(13, (-163));
        int int16 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 4);
        long long20 = year17.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.previous();
        boolean boolean27 = timePeriodValue22.equals((java.lang.Object) year23);
        java.lang.Object obj28 = timePeriodValue22.clone();
        java.lang.Number number29 = timePeriodValue22.getValue();
        timePeriodValues3.add(timePeriodValue22);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 0 + "'", number29.equals((byte) 0));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue4.getPeriod();
        java.lang.Number number8 = timePeriodValue4.getValue();
        java.lang.String str9 = timePeriodValue4.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day10.previous();
        java.lang.Object obj14 = null;
        int int15 = day10.compareTo(obj14);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) 0);
        boolean boolean18 = timePeriodValue4.equals((java.lang.Object) day10);
        int int19 = day10.getYear();
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 1 + "'", number8.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,1]" + "'", str9.equals("TimePeriodValue[2019,1]"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year11);
        java.lang.String str14 = seriesChangeEvent13.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str14.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test443");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getFirstMillisecond();
//        java.util.Date date5 = day3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day3, "TimePeriodValue[2019,0]", "TimePeriodValue[13-June-2019,1546329600000]");
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test444");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
//        timePeriodValues3.setNotify(true);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues20.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
//        boolean boolean24 = timePeriodValues20.isEmpty();
//        timePeriodValues20.setDomainDescription("hi!");
//        int int27 = timePeriodValues20.getItemCount();
//        int int28 = timePeriodValues20.getMinEndIndex();
//        timePeriodValues20.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues34.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues34.removePropertyChangeListener(propertyChangeListener36);
//        boolean boolean38 = timePeriodValues34.isEmpty();
//        java.lang.Comparable comparable39 = timePeriodValues34.getKey();
//        boolean boolean40 = timePeriodValues34.isEmpty();
//        timePeriodValues34.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timePeriodValues34.removeChangeListener(seriesChangeListener43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year45, (double) 4);
//        timePeriodValues34.add(timePeriodValue47);
//        java.lang.Number number49 = timePeriodValue47.getValue();
//        timePeriodValues20.add(timePeriodValue47);
//        timePeriodValue47.setValue((java.lang.Number) 0);
//        java.lang.Object obj53 = timePeriodValue47.clone();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate55 = day54.getSerialDate();
//        int int57 = day54.compareTo((java.lang.Object) (-1L));
//        int int58 = day54.getDayOfMonth();
//        long long59 = day54.getSerialIndex();
//        boolean boolean60 = timePeriodValue47.equals((java.lang.Object) day54);
//        timePeriodValues3.add(timePeriodValue47);
//        java.lang.Number number63 = timePeriodValues3.getValue(0);
//        int int64 = timePeriodValues3.getMinStartIndex();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (-1.0d) + "'", comparable39.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 4.0d + "'", number49.equals(4.0d));
//        org.junit.Assert.assertNotNull(obj53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 13 + "'", int58 == 13);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 0 + "'", number63.equals(0));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinEndIndex();
        int int5 = timePeriodValues3.getMinStartIndex();
        int int6 = timePeriodValues3.getMinEndIndex();
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        java.util.Date date8 = day0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 4);
        timePeriodValues12.add(timePeriodValue15);
        boolean boolean18 = timePeriodValue15.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1577865599999L);
        java.lang.String str20 = seriesChangeEvent19.toString();
        java.lang.Object obj21 = seriesChangeEvent19.getSource();
        java.lang.Object obj22 = seriesChangeEvent19.getSource();
        boolean boolean23 = day0.equals((java.lang.Object) seriesChangeEvent19);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) 4);
        long long27 = year24.getFirstMillisecond();
        java.lang.Class<?> wildcardClass28 = year24.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timePeriodValues32.isEmpty();
        timePeriodValues32.setDomainDescription("hi!");
        int int39 = timePeriodValues32.getItemCount();
        int int40 = timePeriodValues32.getMinEndIndex();
        java.lang.Object obj41 = timePeriodValues32.clone();
        java.lang.String str42 = timePeriodValues32.getDomainDescription();
        boolean boolean43 = year24.equals((java.lang.Object) timePeriodValues32);
        java.util.Date date44 = year24.getStart();
        boolean boolean45 = day0.equals((java.lang.Object) date44);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str20.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
        org.junit.Assert.assertTrue("'" + obj21 + "' != '" + 1577865599999L + "'", obj21.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + 1577865599999L + "'", obj22.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }
}

