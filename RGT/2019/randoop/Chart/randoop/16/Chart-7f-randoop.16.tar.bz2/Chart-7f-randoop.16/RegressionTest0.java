import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.delete((int) (byte) 1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        try {
            timePeriodValues3.add(timePeriod5, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriod timePeriod8 = null;
        try {
            timePeriodValues3.add(timePeriod8, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        org.jfree.data.time.TimePeriod timePeriod9 = null;
        try {
            timePeriodValues3.add(timePeriod9, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = null;
        try {
            timePeriodValues3.add(timePeriodValue9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        try {
            timePeriodValues3.delete((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "org.jfree.data.time.TimePeriodFormatException: ", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone3);
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date0, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "hi!", "");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue5 = timePeriodValues3.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, (long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year11.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        boolean boolean11 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone3);
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date0, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) (byte) 0);
        try {
            timePeriodValues3.update(4, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            year0.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues3.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        java.lang.String str5 = timePeriodValues3.getDescription();
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues3.getDataItem(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues3.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "hi!", "");
        int int4 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.String str8 = seriesException6.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int13 = timePeriodValues3.getItemCount();
        int int14 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues6.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = timePeriodValues6.isEmpty();
        int int11 = timePeriodValues6.getMaxStartIndex();
        timePeriodValues6.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj14 = null;
        boolean boolean15 = timePeriodValues6.equals(obj14);
        try {
            int int16 = simpleTimePeriod2.compareTo(obj14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 7, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue5 = timePeriodValues3.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        java.lang.String str4 = day0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues3.getDescription();
        try {
            timePeriodValues3.update((int) (byte) -1, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year11.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue16.getPeriod();
        timePeriodValues3.add(timePeriod17, (java.lang.Number) 100);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriod17);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        try {
            java.lang.Number number9 = timePeriodValues7.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        boolean boolean14 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener24);
        boolean boolean26 = timePeriodValues22.isEmpty();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        boolean boolean28 = timePeriodValues22.isEmpty();
        timePeriodValues22.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (double) 4);
        timePeriodValues22.add(timePeriodValue35);
        timePeriodValues3.add(timePeriodValue35);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue39 = timePeriodValues3.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (-1.0d) + "'", comparable27.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            day3.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 4);
        timePeriodValues14.add(timePeriodValue17);
        timePeriodValues3.add(timePeriodValue17);
        org.jfree.data.time.TimePeriod timePeriod20 = null;
        try {
            timePeriodValues3.add(timePeriod20, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.getNotify();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues3.getDataItem(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        int int23 = timePeriodValues21.getMaxStartIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        boolean boolean33 = year24.equals((java.lang.Object) str32);
        long long34 = year24.getSerialIndex();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year24, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year24.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (short) 0);
        boolean boolean40 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        int int3 = day0.getYear();
        java.lang.Object obj4 = null;
        boolean boolean5 = day0.equals(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues3.getDataItem(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        long long66 = simpleTimePeriod43.getEndMillis();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1546329600000L + "'", long66 == 1546329600000L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1530561599999L + "'", long4 == 1530561599999L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 4);
        long long10 = year7.getFirstMillisecond();
        java.lang.Class<?> wildcardClass11 = year7.getClass();
        try {
            int int12 = simpleTimePeriod2.compareTo((java.lang.Object) wildcardClass11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Class cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 4);
        timePeriodValues14.add(timePeriodValue17);
        timePeriodValues3.add(timePeriodValue17);
        java.lang.String str20 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.delete(100, (int) (short) 1);
        try {
            timePeriodValues3.delete(6, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        try {
            int int7 = simpleTimePeriod2.compareTo((java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Short cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 2, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        int int23 = timePeriodValues21.getMaxStartIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        boolean boolean33 = year24.equals((java.lang.Object) str32);
        long long34 = year24.getSerialIndex();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year24, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year24.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (short) 0);
        java.util.Calendar calendar40 = null;
        try {
            long long41 = year24.getLastMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        try {
            timePeriodValues3.delete(1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 4);
        timePeriodValues3.add(timePeriodValue6);
        java.lang.String str8 = timePeriodValue6.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,4.0]" + "'", str8.equals("TimePeriodValue[2019,4.0]"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year6.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        boolean boolean24 = timePeriodValues20.isEmpty();
        int int25 = timePeriodValues20.getMaxStartIndex();
        timePeriodValues20.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj28 = null;
        boolean boolean29 = timePeriodValues20.equals(obj28);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year36, (double) 4);
        timePeriodValues35.add(timePeriodValue38);
        boolean boolean40 = timePeriodValues20.equals((java.lang.Object) timePeriodValues35);
        boolean boolean41 = timePeriodValues3.equals((java.lang.Object) boolean40);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        int int4 = day0.getDayOfMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getFirstMillisecond();
//        java.util.Date date5 = day3.getStart();
//        java.util.TimeZone timeZone6 = null;
//        try {
//            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        int int6 = day0.compareTo((java.lang.Object) 1530561599999L);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        int int8 = timePeriodValues3.getMinEndIndex();
        int int9 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
        java.util.Calendar calendar45 = null;
        try {
            long long46 = year44.getFirstMillisecond(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 7, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        try {
            timePeriodValues3.update((int) (byte) 100, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getFirstMillisecond();
//        int int5 = day3.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getFirstMillisecond();
//        java.util.Date date5 = day3.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues9.fireSeriesChanged();
//        int int11 = timePeriodValues9.getMaxStartIndex();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues16.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues16.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues16.getDomainDescription();
//        boolean boolean21 = year12.equals((java.lang.Object) str20);
//        long long22 = year12.getSerialIndex();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year12, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year12.next();
//        java.util.Date date26 = year12.getStart();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues31.fireSeriesChanged();
//        int int33 = timePeriodValues31.getMaxStartIndex();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues38.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
//        java.lang.String str42 = timePeriodValues38.getDomainDescription();
//        boolean boolean43 = year34.equals((java.lang.Object) str42);
//        long long44 = year34.getSerialIndex();
//        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year34, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year34.next();
//        java.util.Date date48 = year34.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date26, date48);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues53.fireSeriesChanged();
//        int int55 = timePeriodValues53.getMaxStartIndex();
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues60.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener62 = null;
//        timePeriodValues60.removePropertyChangeListener(propertyChangeListener62);
//        java.lang.String str64 = timePeriodValues60.getDomainDescription();
//        boolean boolean65 = year56.equals((java.lang.Object) str64);
//        long long66 = year56.getSerialIndex();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) year56, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year56.next();
//        java.util.Date date70 = year56.getStart();
//        boolean boolean71 = simpleTimePeriod49.equals((java.lang.Object) date70);
//        java.lang.Class class72 = null;
//        java.util.Date date73 = null;
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date73, timeZone74);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date70, timeZone74);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date70);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date70, timeZone78);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod80 = new org.jfree.data.time.SimpleTimePeriod(date5, date70);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(timeZone78);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        int int23 = timePeriodValues21.getMaxStartIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        boolean boolean33 = year24.equals((java.lang.Object) str32);
        long long34 = year24.getSerialIndex();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year24, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year24.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (short) 0);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 4);
        long long43 = year40.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (java.lang.Number) (byte) 0);
        timePeriodValues3.add(timePeriodValue45);
        try {
            java.lang.Number number48 = timePeriodValues3.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        int int13 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.next();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year22.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener24);
        boolean boolean26 = timePeriodValues22.isEmpty();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        boolean boolean28 = timePeriodValues22.isEmpty();
        timePeriodValues22.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (double) 4);
        timePeriodValues22.add(timePeriodValue35);
        timePeriodValues3.add(timePeriodValue35);
        int int38 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, (double) 4);
        long long42 = year39.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) (byte) 0);
        long long45 = year39.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) 1560409200000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (-1.0d) + "'", comparable27.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
        java.util.Calendar calendar45 = null;
        try {
            year44.peg(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        int int15 = timePeriodValues13.getMaxStartIndex();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        java.lang.String str24 = timePeriodValues20.getDomainDescription();
        boolean boolean25 = year16.equals((java.lang.Object) str24);
        long long26 = year16.getSerialIndex();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year16, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year16.next();
        java.util.Date date30 = year16.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues35.fireSeriesChanged();
        int int37 = timePeriodValues35.getMaxStartIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues42.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues42.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues42.getDomainDescription();
        boolean boolean47 = year38.equals((java.lang.Object) str46);
        long long48 = year38.getSerialIndex();
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) year38, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year38.next();
        java.util.Date date52 = year38.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date30, date52);
        boolean boolean54 = timePeriodValues3.equals((java.lang.Object) date30);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        timePeriodValues3.setDescription("TimePeriodValue[2019,0]");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 1.0f);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues3.createCopy((int) (byte) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        int int14 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update((int) (byte) 100, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setKey((java.lang.Comparable) 1.0d);
        int int12 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues6.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = timePeriodValues6.isEmpty();
        java.lang.Comparable comparable11 = timePeriodValues6.getKey();
        boolean boolean12 = timePeriodValues6.isEmpty();
        int int13 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues6.setKey((java.lang.Comparable) year14);
        long long16 = year14.getFirstMillisecond();
        java.lang.Class<?> wildcardClass17 = year14.getClass();
        int int18 = day2.compareTo((java.lang.Object) year14);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (-1.0d) + "'", comparable11.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.util.Date date66 = simpleTimePeriod43.getEnd();
        long long67 = simpleTimePeriod43.getStartMillis();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1546329600000L + "'", long67 == 1546329600000L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timePeriodValues7.isEmpty();
        int int12 = timePeriodValues7.getMaxStartIndex();
        timePeriodValues7.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj15 = null;
        boolean boolean16 = timePeriodValues7.equals(obj15);
        int int17 = timePeriodValues7.getMaxMiddleIndex();
        boolean boolean18 = timePeriodValues3.equals((java.lang.Object) int17);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        java.lang.Number number18 = timePeriodValue16.getValue();
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue16.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 4.0d + "'", number18.equals(4.0d));
        org.junit.Assert.assertNotNull(timePeriod19);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "org.jfree.data.general.SeriesException: ");
        java.lang.Comparable comparable2 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", comparable2.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        int int3 = day0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        boolean boolean17 = timePeriodValues13.isEmpty();
        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues24.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues24.removePropertyChangeListener(propertyChangeListener26);
        boolean boolean28 = timePeriodValues24.isEmpty();
        java.lang.Comparable comparable29 = timePeriodValues24.getKey();
        boolean boolean30 = timePeriodValues24.isEmpty();
        int int31 = timePeriodValues24.getMaxStartIndex();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        timePeriodValues24.setKey((java.lang.Comparable) year32);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) 13);
        boolean boolean38 = year0.equals((java.lang.Object) year32);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = year0.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (-1.0d) + "'", comparable29.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        long long17 = year14.getFirstMillisecond();
        boolean boolean18 = year11.equals((java.lang.Object) year14);
        long long19 = year14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year14.previous();
        int int21 = year14.getYear();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
        java.util.Date date45 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(date42, date45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 4);
        timePeriodValues3.add(timePeriodValue6);
        java.lang.Object obj8 = timePeriodValue6.clone();
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        int int3 = day0.getYear();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
//        java.lang.Class<?> wildcardClass8 = simpleTimePeriod7.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues12.fireSeriesChanged();
//        int int14 = timePeriodValues12.getMaxStartIndex();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues19.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues19.removePropertyChangeListener(propertyChangeListener21);
//        java.lang.String str23 = timePeriodValues19.getDomainDescription();
//        boolean boolean24 = year15.equals((java.lang.Object) str23);
//        long long25 = year15.getSerialIndex();
//        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year15, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year15.next();
//        java.util.Date date29 = year15.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date29, timeZone30);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date4, date29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        int int16 = timePeriodValues3.getMinEndIndex();
        int int17 = timePeriodValues3.getMaxMiddleIndex();
        try {
            timePeriodValues3.update((int) 'a', (java.lang.Number) 1530561599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year6.next();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year0.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1L) + "'", obj2.equals((-1L)));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1L) + "'", obj3.equals((-1L)));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
        timePeriodValues17.add(timePeriodValue30);
        java.lang.Number number32 = timePeriodValue30.getValue();
        timePeriodValues3.add(timePeriodValue30);
        timePeriodValue30.setValue((java.lang.Number) 0);
        java.lang.Object obj36 = timePeriodValue30.clone();
        java.lang.Number number37 = timePeriodValue30.getValue();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 0 + "'", number37.equals(0));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 5, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        timePeriodValues3.update((int) (byte) 0, (java.lang.Number) 11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year0.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        int int15 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable16 = timePeriodValues3.getKey();
        int int17 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,0]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (byte) 0 + "'", comparable16.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year66, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue70 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year66, (double) 4);
        timePeriodValue70.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod73 = timePeriodValue70.getPeriod();
        int int74 = simpleTimePeriod43.compareTo((java.lang.Object) timePeriod73);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timePeriod73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        long long6 = year0.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        java.lang.Comparable comparable12 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (-1.0d) + "'", comparable12.equals((-1.0d)));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) 2019L);
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getYear();
        java.lang.Object obj17 = null;
        boolean boolean18 = day15.equals(obj17);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 10.0f);
        int int21 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,4.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener24);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues18.removeChangeListener(seriesChangeListener26);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) year6);
        long long11 = year6.getFirstMillisecond();
        int int12 = year6.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        long long5 = day0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
//        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getYear();
//        java.lang.Object obj17 = null;
//        boolean boolean18 = day15.equals(obj17);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 10.0f);
//        int int21 = day15.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 1546329600000L);
//        java.lang.String str24 = timePeriodValue23.toString();
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TimePeriodValue[13-June-2019,1546329600000]" + "'", str24.equals("TimePeriodValue[13-June-2019,1546329600000]"));
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.next();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year22.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        java.lang.String str5 = timePeriodValues3.getDescription();
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str5);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        java.lang.String str7 = day0.toString();
//        long long8 = day0.getLastMillisecond();
//        int int9 = day0.getYear();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        java.util.Calendar calendar26 = null;
        try {
            year22.peg(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.String str14 = timePeriodValues10.getDomainDescription();
//        boolean boolean15 = year6.equals((java.lang.Object) str14);
//        long long16 = year6.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
//        java.util.Date date20 = year6.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues25.fireSeriesChanged();
//        int int27 = timePeriodValues25.getMaxStartIndex();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues32.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        boolean boolean37 = year28.equals((java.lang.Object) str36);
//        long long38 = year28.getSerialIndex();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
//        java.util.Date date42 = year28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues47.fireSeriesChanged();
//        int int49 = timePeriodValues47.getMaxStartIndex();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues54.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
//        java.lang.String str58 = timePeriodValues54.getDomainDescription();
//        boolean boolean59 = year50.equals((java.lang.Object) str58);
//        long long60 = year50.getSerialIndex();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
//        java.util.Date date64 = year50.getStart();
//        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
//        java.lang.Class class66 = null;
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
//        java.util.Date date71 = day70.getStart();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        int int74 = day72.getDayOfMonth();
//        int int75 = day70.compareTo((java.lang.Object) day72);
//        int int76 = day70.getDayOfMonth();
//        java.util.Calendar calendar77 = null;
//        try {
//            day70.peg(calendar77);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 13 + "'", int73 == 13);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 13 + "'", int74 == 13);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-163) + "'", int75 == (-163));
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        long long8 = simpleTimePeriod2.getStartMillis();
        java.util.Date date9 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str9 = timePeriodValues3.getDescription();
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2);
        timePeriodValues1.setNotify(false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues48.fireSeriesChanged();
        int int50 = timePeriodValues48.getMaxStartIndex();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues55.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener57);
        java.lang.String str59 = timePeriodValues55.getDomainDescription();
        boolean boolean60 = year51.equals((java.lang.Object) str59);
        long long61 = year51.getSerialIndex();
        timePeriodValues48.add((org.jfree.data.time.TimePeriod) year51, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year51.next();
        java.util.Date date65 = year51.getStart();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues70.fireSeriesChanged();
        int int72 = timePeriodValues70.getMaxStartIndex();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues77 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues77.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener79 = null;
        timePeriodValues77.removePropertyChangeListener(propertyChangeListener79);
        java.lang.String str81 = timePeriodValues77.getDomainDescription();
        boolean boolean82 = year73.equals((java.lang.Object) str81);
        long long83 = year73.getSerialIndex();
        timePeriodValues70.add((org.jfree.data.time.TimePeriod) year73, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = year73.next();
        java.util.Date date87 = year73.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod88 = new org.jfree.data.time.SimpleTimePeriod(date65, date87);
        boolean boolean89 = year44.equals((java.lang.Object) date87);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2019L + "'", long61 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "hi!" + "'", str81.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 2019L + "'", long83 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        int int11 = timePeriodValues3.getMinStartIndex();
        java.lang.String str12 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener24);
        boolean boolean26 = timePeriodValues22.isEmpty();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        boolean boolean28 = timePeriodValues22.isEmpty();
        timePeriodValues22.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (double) 4);
        timePeriodValues22.add(timePeriodValue35);
        timePeriodValues3.add(timePeriodValue35);
        int int38 = timePeriodValues3.getItemCount();
        try {
            java.lang.Number number40 = timePeriodValues3.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (-1.0d) + "'", comparable27.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) year6);
        long long11 = year6.getFirstMillisecond();
        java.util.Date date12 = year6.getStart();
        long long13 = year6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, 11, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
//        long long11 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        try {
            timePeriodValues3.delete(11, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
        timePeriodValues17.add(timePeriodValue30);
        java.lang.Number number32 = timePeriodValue30.getValue();
        timePeriodValues3.add(timePeriodValue30);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 7, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        java.util.Date date8 = day0.getEnd();
        java.lang.Class class9 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date13 = simpleTimePeriod12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        int int19 = timePeriodValues17.getMaxStartIndex();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues24.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues24.removePropertyChangeListener(propertyChangeListener26);
        java.lang.String str28 = timePeriodValues24.getDomainDescription();
        boolean boolean29 = year20.equals((java.lang.Object) str28);
        long long30 = year20.getSerialIndex();
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year20, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year20.next();
        java.util.Date date34 = year20.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues39.fireSeriesChanged();
        int int41 = timePeriodValues39.getMaxStartIndex();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues46.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues46.removePropertyChangeListener(propertyChangeListener48);
        java.lang.String str50 = timePeriodValues46.getDomainDescription();
        boolean boolean51 = year42.equals((java.lang.Object) str50);
        long long52 = year42.getSerialIndex();
        timePeriodValues39.add((org.jfree.data.time.TimePeriod) year42, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year42.next();
        java.util.Date date56 = year42.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date34, date56);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues61.fireSeriesChanged();
        int int63 = timePeriodValues61.getMaxStartIndex();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues68.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timePeriodValues68.removePropertyChangeListener(propertyChangeListener70);
        java.lang.String str72 = timePeriodValues68.getDomainDescription();
        boolean boolean73 = year64.equals((java.lang.Object) str72);
        long long74 = year64.getSerialIndex();
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) year64, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year64.next();
        java.util.Date date78 = year64.getStart();
        boolean boolean79 = simpleTimePeriod57.equals((java.lang.Object) date78);
        java.lang.Class class80 = null;
        java.util.Date date81 = null;
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date81, timeZone82);
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date78, timeZone82);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date78);
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date78, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date13, timeZone86);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod89 = new org.jfree.data.time.SimpleTimePeriod(date8, date13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 2019L + "'", long52 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "hi!" + "'", str72.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 2019L + "'", long74 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNull(regularTimePeriod88);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        java.lang.Number number18 = timePeriodValue16.getValue();
        java.lang.Number number19 = timePeriodValue16.getValue();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 4.0d + "'", number18.equals(4.0d));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 4.0d + "'", number19.equals(4.0d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        int int14 = timePeriodValues3.getMaxMiddleIndex();
        try {
            java.lang.Number number16 = timePeriodValues3.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        int int24 = timePeriodValues18.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        java.util.Calendar calendar6 = null;
        try {
            day5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        java.lang.Object obj3 = new java.lang.Object();
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        long long5 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "hi!", "");
        try {
            int int8 = simpleTimePeriod2.compareTo((java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        boolean boolean26 = day18.equals((java.lang.Object) regularTimePeriod25);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day18, (double) (short) 10);
//        int int29 = day18.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        int int9 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        java.lang.String str18 = timePeriodValues14.getDomainDescription();
        boolean boolean19 = year10.equals((java.lang.Object) str18);
        long long20 = year10.getSerialIndex();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year10.next();
        java.util.Date date24 = year10.getStart();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date24, timeZone27);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues33.fireSeriesChanged();
        int int35 = timePeriodValues33.getMaxStartIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener42);
        java.lang.String str44 = timePeriodValues40.getDomainDescription();
        boolean boolean45 = year36.equals((java.lang.Object) str44);
        long long46 = year36.getSerialIndex();
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) year36, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year36.next();
        java.util.Date date50 = year36.getStart();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues55.fireSeriesChanged();
        int int57 = timePeriodValues55.getMaxStartIndex();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues62.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues62.removePropertyChangeListener(propertyChangeListener64);
        java.lang.String str66 = timePeriodValues62.getDomainDescription();
        boolean boolean67 = year58.equals((java.lang.Object) str66);
        long long68 = year58.getSerialIndex();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year58, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year58.next();
        java.util.Date date72 = year58.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(date50, date72);
        org.jfree.data.time.TimePeriodValues timePeriodValues77 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues77.fireSeriesChanged();
        int int79 = timePeriodValues77.getMaxStartIndex();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues84 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues84.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener86 = null;
        timePeriodValues84.removePropertyChangeListener(propertyChangeListener86);
        java.lang.String str88 = timePeriodValues84.getDomainDescription();
        boolean boolean89 = year80.equals((java.lang.Object) str88);
        long long90 = year80.getSerialIndex();
        timePeriodValues77.add((org.jfree.data.time.TimePeriod) year80, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = year80.next();
        java.util.Date date94 = year80.getStart();
        boolean boolean95 = simpleTimePeriod73.equals((java.lang.Object) date94);
        java.util.Date date96 = simpleTimePeriod73.getEnd();
        java.util.TimeZone timeZone97 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date96, timeZone97);
        java.lang.Class class99 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 2019L + "'", long90 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(date96);
        org.junit.Assert.assertNull(regularTimePeriod98);
        org.junit.Assert.assertNotNull(class99);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        int int4 = day0.getDayOfMonth();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        seriesException10.addSuppressed((java.lang.Throwable) seriesException12);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) seriesException10);
        java.lang.Throwable[] throwableArray15 = seriesException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        int int8 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        int int14 = timePeriodValues12.getMaxStartIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues19.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener21);
        java.lang.String str23 = timePeriodValues19.getDomainDescription();
        boolean boolean24 = year15.equals((java.lang.Object) str23);
        long long25 = year15.getSerialIndex();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year15, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener33);
        boolean boolean35 = timePeriodValues31.isEmpty();
        java.lang.Comparable comparable36 = timePeriodValues31.getKey();
        boolean boolean37 = timePeriodValues31.isEmpty();
        timePeriodValues31.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues31.removeChangeListener(seriesChangeListener40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (double) 4);
        timePeriodValues31.add(timePeriodValue44);
        timePeriodValues12.add(timePeriodValue44);
        timePeriodValues3.add(timePeriodValue44);
        timePeriodValue44.setValue((java.lang.Number) 0L);
        java.lang.Object obj50 = timePeriodValue44.clone();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + (-1.0d) + "'", comparable36.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        int int3 = day0.getYear();
        java.lang.Object obj4 = null;
        boolean boolean5 = day0.equals(obj4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean5);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        timePeriodValues3.setRangeDescription("");
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        java.lang.Object obj12 = timePeriodValues3.clone();
        boolean boolean13 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        boolean boolean5 = timePeriodValues3.getNotify();
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (-1.0d) + "'", comparable6.equals((-1.0d)));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 13);
        java.util.Calendar calendar28 = null;
        try {
            year22.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        timePeriodValues3.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.lang.Class<?> wildcardClass22 = date20.getClass();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        try {
            timePeriodValues3.update((int) '#', (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.util.Date date66 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate68 = day67.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day67.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day67, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues75 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable76 = timePeriodValues75.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues80 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues80.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener82 = null;
        timePeriodValues80.removePropertyChangeListener(propertyChangeListener82);
        boolean boolean84 = timePeriodValues80.isEmpty();
        java.lang.Comparable comparable85 = timePeriodValues80.getKey();
        timePeriodValues80.setDescription("");
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year();
        timePeriodValues80.add((org.jfree.data.time.TimePeriod) year88, (java.lang.Number) 0L);
        timePeriodValues75.add((org.jfree.data.time.TimePeriod) year88, (java.lang.Number) (byte) 100);
        int int93 = timePeriodValues75.getItemCount();
        boolean boolean94 = day67.equals((java.lang.Object) int93);
        int int95 = day67.getMonth();
        boolean boolean96 = simpleTimePeriod43.equals((java.lang.Object) day67);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + comparable76 + "' != '" + (-1.0d) + "'", comparable76.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + comparable85 + "' != '" + (-1.0d) + "'", comparable85.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 6 + "'", int95 == 6);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
        timePeriodValues17.add(timePeriodValue30);
        java.lang.Number number32 = timePeriodValue30.getValue();
        timePeriodValues3.add(timePeriodValue30);
        timePeriodValue30.setValue((java.lang.Number) 8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        try {
            int int4 = simpleTimePeriod2.compareTo((java.lang.Object) "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date64, timeZone71);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(timeZone71);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        boolean boolean14 = timePeriodValues10.isEmpty();
//        java.lang.Comparable comparable15 = timePeriodValues10.getKey();
//        timePeriodValues10.setDescription("");
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 0L);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) 4);
//        long long24 = year21.getFirstMillisecond();
//        boolean boolean25 = year18.equals((java.lang.Object) year21);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod27, 0.0d);
//        boolean boolean30 = year18.equals((java.lang.Object) 0.0d);
//        boolean boolean31 = day0.equals((java.lang.Object) 0.0d);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (-1.0d) + "'", comparable15.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        java.lang.Object obj18 = timePeriodValue16.clone();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        long long22 = year19.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.previous();
        boolean boolean29 = timePeriodValue24.equals((java.lang.Object) year25);
        boolean boolean30 = timePeriodValue16.equals((java.lang.Object) boolean29);
        java.lang.Number number31 = timePeriodValue16.getValue();
        java.lang.Object obj32 = timePeriodValue16.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 4.0d + "'", number31.equals(4.0d));
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timePeriodValues7.isEmpty();
        java.lang.Comparable comparable12 = timePeriodValues7.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timePeriodValues18.isEmpty();
        java.lang.Comparable comparable23 = timePeriodValues18.getKey();
        boolean boolean24 = timePeriodValues18.isEmpty();
        int int25 = timePeriodValues18.getMaxStartIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        timePeriodValues18.setKey((java.lang.Comparable) year26);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) (short) -1);
        int int30 = simpleTimePeriod2.compareTo((java.lang.Object) year26);
        java.lang.String str31 = year26.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (-1.0d) + "'", comparable12.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0d) + "'", comparable23.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        int int12 = day9.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) '#');
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long19 = simpleTimePeriod18.getStartMillis();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 0L);
        java.lang.Object obj22 = null;
        try {
            int int23 = simpleTimePeriod18.compareTo(obj22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getLastMillisecond();
        java.util.Calendar calendar22 = null;
        try {
            year16.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 4);
        timePeriodValues14.add(timePeriodValue17);
        timePeriodValues3.add(timePeriodValue17);
        int int20 = timePeriodValues3.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue22 = timePeriodValues3.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        java.lang.Object obj3 = null;
        try {
            int int4 = simpleTimePeriod2.compareTo(obj3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.delete((-163), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.Class<?> wildcardClass26 = timePeriodFormatException24.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        int int32 = timePeriodValues30.getMaxStartIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues37.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timePeriodValues37.removePropertyChangeListener(propertyChangeListener39);
        java.lang.String str41 = timePeriodValues37.getDomainDescription();
        boolean boolean42 = year33.equals((java.lang.Object) str41);
        long long43 = year33.getSerialIndex();
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) year33, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year33.next();
        java.util.Date date47 = year33.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass52 = simpleTimePeriod51.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues56.fireSeriesChanged();
        int int58 = timePeriodValues56.getMaxStartIndex();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues63.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues63.removePropertyChangeListener(propertyChangeListener65);
        java.lang.String str67 = timePeriodValues63.getDomainDescription();
        boolean boolean68 = year59.equals((java.lang.Object) str67);
        long long69 = year59.getSerialIndex();
        timePeriodValues56.add((org.jfree.data.time.TimePeriod) year59, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year59.next();
        java.util.Date date73 = year59.getStart();
        java.lang.Class class74 = null;
        java.util.Date date75 = null;
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date73, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date47, timeZone76);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date20, timeZone76);
        java.util.Calendar calendar81 = null;
        try {
            year80.peg(calendar81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        int int16 = timePeriodValues3.getMinEndIndex();
        try {
            java.lang.Number number18 = timePeriodValues3.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        int int15 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 3, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date26 = simpleTimePeriod25.getStart();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date22, date26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean2 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        long long17 = year14.getFirstMillisecond();
        boolean boolean18 = year11.equals((java.lang.Object) year14);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod20, 0.0d);
        boolean boolean23 = year11.equals((java.lang.Object) 0.0d);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year11.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        java.lang.Comparable comparable16 = timePeriodValues3.getKey();
        int int17 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (-1.0d) + "'", comparable16.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        long long6 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue25 = timePeriodValues18.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        int int14 = timePeriodValues3.getMinStartIndex();
        int int15 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 4);
        timePeriodValues3.add(timePeriodValue6);
        boolean boolean9 = timePeriodValue6.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue6.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        long long6 = day5.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day5.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (byte) 10);
//        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue8.getPeriod();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timePeriod9);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 7, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        boolean boolean4 = timePeriodValues3.isEmpty();
        int int5 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        long long6 = year0.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        java.lang.Class<?> wildcardClass4 = day3.getClass();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.next();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) year6);
        long long11 = year6.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.String str17 = seriesException15.toString();
        int int18 = year6.compareTo((java.lang.Object) str17);
        long long19 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date64);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj9 = timePeriodValues3.clone();
        int int10 = timePeriodValues3.getMinStartIndex();
        boolean boolean11 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
        timePeriodValues17.add(timePeriodValue30);
        java.lang.Number number32 = timePeriodValue30.getValue();
        timePeriodValues3.add(timePeriodValue30);
        java.lang.String str34 = timePeriodValue30.toString();
        java.lang.Object obj35 = timePeriodValue30.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TimePeriodValue[2019,4.0]" + "'", str34.equals("TimePeriodValue[2019,4.0]"));
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0f);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 10.0f + "'", obj2.equals(10.0f));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj9 = timePeriodValues3.clone();
        int int10 = timePeriodValues3.getMinStartIndex();
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        boolean boolean12 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (-1.0d) + "'", comparable11.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        seriesException10.addSuppressed((java.lang.Throwable) seriesException12);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) seriesException10);
        boolean boolean15 = timePeriodValues3.getNotify();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues3.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues12.isEmpty();
        int int17 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues12.equals(obj20);
        int int22 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        timePeriodValues12.add(timePeriod26, (java.lang.Number) 100);
        int int29 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriod26);
        long long30 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 7L + "'", long30 == 7L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues8.createCopy(11, 7);
        boolean boolean12 = day0.equals((java.lang.Object) timePeriodValues11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        int int15 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable16 = timePeriodValues3.getKey();
        int int17 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (byte) 0 + "'", comparable16.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        boolean boolean5 = timePeriodValues3.getNotify();
        try {
            timePeriodValues3.update((int) '#', (java.lang.Number) 43466L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        int int12 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getYear();
//        long long5 = day0.getFirstMillisecond();
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,1]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue(timePeriod7, (double) (-1));
        boolean boolean11 = timePeriodValue9.equals((java.lang.Object) 5);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Class<?> wildcardClass13 = timePeriodValues3.getClass();
        int int14 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        int int12 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues3.getDescription();
        java.lang.Class<?> wildcardClass13 = timePeriodValues3.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        int int8 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        int int14 = timePeriodValues12.getMaxStartIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues19.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener21);
        java.lang.String str23 = timePeriodValues19.getDomainDescription();
        boolean boolean24 = year15.equals((java.lang.Object) str23);
        long long25 = year15.getSerialIndex();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year15, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener33);
        boolean boolean35 = timePeriodValues31.isEmpty();
        java.lang.Comparable comparable36 = timePeriodValues31.getKey();
        boolean boolean37 = timePeriodValues31.isEmpty();
        timePeriodValues31.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues31.removeChangeListener(seriesChangeListener40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (double) 4);
        timePeriodValues31.add(timePeriodValue44);
        timePeriodValues12.add(timePeriodValue44);
        timePeriodValues3.add(timePeriodValue44);
        timePeriodValue44.setValue((java.lang.Number) 0L);
        java.lang.String str50 = timePeriodValue44.toString();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + (-1.0d) + "'", comparable36.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "TimePeriodValue[2019,0]" + "'", str50.equals("TimePeriodValue[2019,0]"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean13 = timePeriodValues3.getNotify();
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 0 + "'", comparable14.equals((byte) 0));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        try {
            timePeriodValues3.update((int) 'a', (java.lang.Number) 7L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        long long13 = year11.getFirstMillisecond();
        java.lang.Class<?> wildcardClass14 = year11.getClass();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year11.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timePeriodValues7.isEmpty();
        java.lang.Comparable comparable12 = timePeriodValues7.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timePeriodValues18.isEmpty();
        java.lang.Comparable comparable23 = timePeriodValues18.getKey();
        boolean boolean24 = timePeriodValues18.isEmpty();
        int int25 = timePeriodValues18.getMaxStartIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        timePeriodValues18.setKey((java.lang.Comparable) year26);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) (short) -1);
        int int30 = simpleTimePeriod2.compareTo((java.lang.Object) year26);
        long long31 = year26.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (-1.0d) + "'", comparable12.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0d) + "'", comparable23.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        java.lang.Object obj4 = null;
        int int5 = day0.compareTo(obj4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        boolean boolean9 = day0.equals((java.lang.Object) day8);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long8 = simpleTimePeriod7.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues12.isEmpty();
        java.lang.Comparable comparable17 = timePeriodValues12.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues12.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        boolean boolean27 = timePeriodValues23.isEmpty();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        boolean boolean29 = timePeriodValues23.isEmpty();
        int int30 = timePeriodValues23.getMaxStartIndex();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        timePeriodValues23.setKey((java.lang.Comparable) year31);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) (short) -1);
        int int35 = simpleTimePeriod7.compareTo((java.lang.Object) year31);
        int int36 = day0.compareTo((java.lang.Object) int35);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (-1.0d) + "'", comparable17.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-1.0d) + "'", comparable28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        int int11 = timePeriodValues3.getMinStartIndex();
        boolean boolean12 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.String str14 = timePeriodValues10.getDomainDescription();
//        boolean boolean15 = year6.equals((java.lang.Object) str14);
//        long long16 = year6.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
//        java.util.Date date20 = year6.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues25.fireSeriesChanged();
//        int int27 = timePeriodValues25.getMaxStartIndex();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues32.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        boolean boolean37 = year28.equals((java.lang.Object) str36);
//        long long38 = year28.getSerialIndex();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
//        java.util.Date date42 = year28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues47.fireSeriesChanged();
//        int int49 = timePeriodValues47.getMaxStartIndex();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues54.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
//        java.lang.String str58 = timePeriodValues54.getDomainDescription();
//        boolean boolean59 = year50.equals((java.lang.Object) str58);
//        long long60 = year50.getSerialIndex();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
//        java.util.Date date64 = year50.getStart();
//        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
//        java.lang.Class class66 = null;
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
//        java.util.Date date71 = day70.getStart();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        int int74 = day72.getDayOfMonth();
//        int int75 = day70.compareTo((java.lang.Object) day72);
//        int int77 = day70.compareTo((java.lang.Object) 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 13 + "'", int73 == 13);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 13 + "'", int74 == 13);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-163) + "'", int75 == (-163));
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesChangeListener12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues12.isEmpty();
        int int17 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues12.equals(obj20);
        int int22 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
        timePeriodValues12.add(timePeriod26, (java.lang.Number) 100);
        int int29 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriod26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long33 = simpleTimePeriod32.getStartMillis();
        long long34 = simpleTimePeriod32.getEndMillis();
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        java.util.Date date36 = simpleTimePeriod32.getEnd();
        int int37 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod32);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMinEndIndex();
        try {
            timePeriodValues3.update((int) ' ', (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,1]");
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 0.0f);
        java.util.Date date7 = simpleTimePeriod2.getStart();
        long long8 = simpleTimePeriod2.getEndMillis();
        java.util.Date date9 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        int int9 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        java.lang.String str18 = timePeriodValues14.getDomainDescription();
        boolean boolean19 = year10.equals((java.lang.Object) str18);
        long long20 = year10.getSerialIndex();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year10.next();
        java.util.Date date24 = year10.getStart();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date24, timeZone27);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues33.fireSeriesChanged();
        int int35 = timePeriodValues33.getMaxStartIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener42);
        java.lang.String str44 = timePeriodValues40.getDomainDescription();
        boolean boolean45 = year36.equals((java.lang.Object) str44);
        long long46 = year36.getSerialIndex();
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) year36, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year36.next();
        java.util.Date date50 = year36.getStart();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues55.fireSeriesChanged();
        int int57 = timePeriodValues55.getMaxStartIndex();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues62.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues62.removePropertyChangeListener(propertyChangeListener64);
        java.lang.String str66 = timePeriodValues62.getDomainDescription();
        boolean boolean67 = year58.equals((java.lang.Object) str66);
        long long68 = year58.getSerialIndex();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year58, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year58.next();
        java.util.Date date72 = year58.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(date50, date72);
        org.jfree.data.time.TimePeriodValues timePeriodValues77 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues77.fireSeriesChanged();
        int int79 = timePeriodValues77.getMaxStartIndex();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues84 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues84.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener86 = null;
        timePeriodValues84.removePropertyChangeListener(propertyChangeListener86);
        java.lang.String str88 = timePeriodValues84.getDomainDescription();
        boolean boolean89 = year80.equals((java.lang.Object) str88);
        long long90 = year80.getSerialIndex();
        timePeriodValues77.add((org.jfree.data.time.TimePeriod) year80, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = year80.next();
        java.util.Date date94 = year80.getStart();
        boolean boolean95 = simpleTimePeriod73.equals((java.lang.Object) date94);
        java.util.Date date96 = simpleTimePeriod73.getEnd();
        java.util.TimeZone timeZone97 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date96, timeZone97);
        org.jfree.data.time.Year year99 = new org.jfree.data.time.Year(date96);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 2019L + "'", long90 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(date96);
        org.junit.Assert.assertNull(regularTimePeriod98);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str14 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        timePeriodValues3.setDescription("2019");
        java.lang.String str16 = timePeriodValues3.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues3.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        boolean boolean17 = timePeriodValues13.isEmpty();
        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
        timePeriodValues13.setDescription("");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
        int int26 = timePeriodValues8.getItemCount();
        boolean boolean27 = day0.equals((java.lang.Object) int26);
        int int28 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener36);
        boolean boolean38 = timePeriodValues34.isEmpty();
        timePeriodValues34.setDomainDescription("hi!");
        int int41 = timePeriodValues34.getItemCount();
        int int42 = timePeriodValues34.getMinEndIndex();
        timePeriodValues34.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean46 = timePeriodValues34.equals((java.lang.Object) (byte) 0);
        boolean boolean47 = timePeriodValue30.equals((java.lang.Object) boolean46);
        java.lang.Number number48 = timePeriodValue30.getValue();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0d) + "'", number48.equals((-1.0d)));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener24);
        int int26 = timePeriodValues18.getMinMiddleIndex();
        timePeriodValues18.fireSeriesChanged();
        int int28 = timePeriodValues18.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        long long17 = year14.getFirstMillisecond();
        boolean boolean18 = year11.equals((java.lang.Object) year14);
        long long19 = year14.getLastMillisecond();
        long long20 = year14.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        long long23 = year16.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int13 = timePeriodValues3.getItemCount();
        timePeriodValues3.fireSeriesChanged();
        boolean boolean15 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues3.createCopy((int) (short) 100, 0);
        timePeriodValues3.delete(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timePeriodValues18);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year16.getMiddleMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        int int3 = day0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues8.createCopy(11, 7);
//        boolean boolean12 = day0.equals((java.lang.Object) timePeriodValues11);
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timePeriodValues11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        boolean boolean5 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        long long3 = day2.getLastMillisecond();
//        long long4 = day2.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getStart();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 4);
        timePeriodValues14.add(timePeriodValue17);
        timePeriodValues3.add(timePeriodValue17);
        java.lang.Number number20 = timePeriodValue17.getValue();
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue17.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 4.0d + "'", number20.equals(4.0d));
        org.junit.Assert.assertNotNull(timePeriod21);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        boolean boolean17 = timePeriodValues13.isEmpty();
        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
        timePeriodValues13.setDescription("");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
        int int26 = timePeriodValues8.getItemCount();
        boolean boolean27 = day0.equals((java.lang.Object) int26);
        int int28 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) -1);
        java.lang.Class<?> wildcardClass31 = day0.getClass();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        int int8 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        boolean boolean12 = timePeriodValues3.equals((java.lang.Object) 43466L);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable12 = timePeriodValues11.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener18);
        boolean boolean20 = timePeriodValues16.isEmpty();
        java.lang.Comparable comparable21 = timePeriodValues16.getKey();
        timePeriodValues16.setDescription("");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 0L);
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (byte) 100);
        try {
            int int29 = simpleTimePeriod2.compareTo((java.lang.Object) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Byte cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (-1.0d) + "'", comparable12.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (-1.0d) + "'", comparable21.equals((-1.0d)));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        long long20 = year6.getLastMillisecond();
        java.util.Date date21 = year6.getStart();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        int int4 = day3.getDayOfMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            day3.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues6.fireSeriesChanged();
        int int8 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        java.lang.String str17 = timePeriodValues13.getDomainDescription();
        boolean boolean18 = year9.equals((java.lang.Object) str17);
        long long19 = year9.getSerialIndex();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year9, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year9.next();
        java.util.Date date23 = year9.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        int int30 = timePeriodValues28.getMaxStartIndex();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues35.getDomainDescription();
        boolean boolean40 = year31.equals((java.lang.Object) str39);
        long long41 = year31.getSerialIndex();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year31, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year31.next();
        java.util.Date date45 = year31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(date23, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues50.fireSeriesChanged();
        int int52 = timePeriodValues50.getMaxStartIndex();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues57.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener59);
        java.lang.String str61 = timePeriodValues57.getDomainDescription();
        boolean boolean62 = year53.equals((java.lang.Object) str61);
        long long63 = year53.getSerialIndex();
        timePeriodValues50.add((org.jfree.data.time.TimePeriod) year53, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year53.next();
        java.util.Date date67 = year53.getStart();
        boolean boolean68 = simpleTimePeriod46.equals((java.lang.Object) date67);
        java.lang.Class class69 = null;
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date70, timeZone71);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date67, timeZone71);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date67);
        long long75 = day74.getSerialIndex();
        boolean boolean76 = year0.equals((java.lang.Object) day74);
        int int77 = day74.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 43466L + "'", long75 == 43466L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
//        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.previous();
//        int int19 = day15.getMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (double) 11);
//        int int22 = day15.getDayOfMonth();
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(1, (int) ' ');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        try {
            timePeriodValues3.update((int) (short) 100, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass10 = simpleTimePeriod9.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        int int16 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues21.removePropertyChangeListener(propertyChangeListener23);
        java.lang.String str25 = timePeriodValues21.getDomainDescription();
        boolean boolean26 = year17.equals((java.lang.Object) str25);
        long long27 = year17.getSerialIndex();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year17, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year17.next();
        java.util.Date date31 = year17.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date31, timeZone32);
        boolean boolean34 = timePeriodValue4.equals((java.lang.Object) timeZone32);
        java.lang.Number number35 = timePeriodValue4.getValue();
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (byte) 1 + "'", number35.equals((byte) 1));
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues13.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
//        boolean boolean17 = timePeriodValues13.isEmpty();
//        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
//        int int26 = timePeriodValues8.getItemCount();
//        boolean boolean27 = day0.equals((java.lang.Object) int26);
//        int int28 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) -1);
//        java.lang.String str31 = day0.toString();
//        java.util.Date date32 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day0.next();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 13);
        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue27.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timePeriod28);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date13 = simpleTimePeriod12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean16 = simpleTimePeriod12.equals((java.lang.Object) 0.0f);
        java.util.Date date17 = simpleTimePeriod12.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) date17);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "org.jfree.data.general.SeriesException: ", "");
        int int6 = timePeriodValues5.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener31);
        boolean boolean33 = timePeriodValues29.isEmpty();
        java.lang.Comparable comparable34 = timePeriodValues29.getKey();
        boolean boolean35 = timePeriodValues29.isEmpty();
        timePeriodValues29.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 4);
        timePeriodValues29.add(timePeriodValue42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (short) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 0.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date71 = simpleTimePeriod70.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues73 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean74 = simpleTimePeriod70.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, (double) (short) 1);
        java.util.Date date77 = simpleTimePeriod70.getStart();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year78.next();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        int int9 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        java.lang.String str18 = timePeriodValues14.getDomainDescription();
        boolean boolean19 = year10.equals((java.lang.Object) str18);
        long long20 = year10.getSerialIndex();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year10, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year10.next();
        java.util.Date date24 = year10.getStart();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date24, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date24);
        int int31 = day30.getDayOfMonth();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        long long13 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.previous();
        int int15 = year0.getYear();
        boolean boolean17 = year0.equals((java.lang.Object) "2019");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        int int6 = day3.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
//        boolean boolean8 = day0.equals((java.lang.Object) regularTimePeriod7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.previous();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener31);
        boolean boolean33 = timePeriodValues29.isEmpty();
        java.lang.Comparable comparable34 = timePeriodValues29.getKey();
        boolean boolean35 = timePeriodValues29.isEmpty();
        timePeriodValues29.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 4);
        timePeriodValues29.add(timePeriodValue42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (short) 0);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year50.previous();
        long long69 = year50.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues13.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
//        boolean boolean17 = timePeriodValues13.isEmpty();
//        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
//        int int26 = timePeriodValues8.getItemCount();
//        boolean boolean27 = day0.equals((java.lang.Object) int26);
//        int int28 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) (short) -1);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1530561599999L);
//        java.lang.String str33 = timePeriodValue32.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[13-June-2019,1530561599999]" + "'", str33.equals("TimePeriodValue[13-June-2019,1530561599999]"));
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues21.fireSeriesChanged();
        int int23 = timePeriodValues21.getMaxStartIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues28.getDomainDescription();
        boolean boolean33 = year24.equals((java.lang.Object) str32);
        long long34 = year24.getSerialIndex();
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) year24, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year24.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (short) 0);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 4);
        long long43 = year40.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (java.lang.Number) (byte) 0);
        timePeriodValues3.add(timePeriodValue45);
        boolean boolean47 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        timePeriodValues8.setDomainDescription("hi!");
        int int15 = timePeriodValues8.getItemCount();
        int int16 = timePeriodValues8.getMinEndIndex();
        java.lang.Object obj17 = timePeriodValues8.clone();
        java.lang.String str18 = timePeriodValues8.getDomainDescription();
        boolean boolean19 = year0.equals((java.lang.Object) timePeriodValues8);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        boolean boolean27 = timePeriodValues23.isEmpty();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener36);
        boolean boolean38 = timePeriodValues34.isEmpty();
        java.lang.Comparable comparable39 = timePeriodValues34.getKey();
        boolean boolean40 = timePeriodValues34.isEmpty();
        int int41 = timePeriodValues34.getMaxStartIndex();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        timePeriodValues34.setKey((java.lang.Comparable) year42);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues49.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timePeriodValues49.removePropertyChangeListener(propertyChangeListener51);
        boolean boolean53 = timePeriodValues49.isEmpty();
        java.lang.Comparable comparable54 = timePeriodValues49.getKey();
        boolean boolean55 = timePeriodValues49.isEmpty();
        timePeriodValues49.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        timePeriodValues49.removeChangeListener(seriesChangeListener58);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year60, (double) 4);
        timePeriodValues49.add(timePeriodValue62);
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues67.fireSeriesChanged();
        int int69 = timePeriodValues67.getMaxStartIndex();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues74.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timePeriodValues74.removePropertyChangeListener(propertyChangeListener76);
        java.lang.String str78 = timePeriodValues74.getDomainDescription();
        boolean boolean79 = year70.equals((java.lang.Object) str78);
        long long80 = year70.getSerialIndex();
        timePeriodValues67.add((org.jfree.data.time.TimePeriod) year70, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = year70.next();
        timePeriodValues49.add((org.jfree.data.time.TimePeriod) year70, (java.lang.Number) (short) 0);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) year70, (java.lang.Number) 0.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod90 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date91 = simpleTimePeriod90.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues93 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f);
        boolean boolean94 = simpleTimePeriod90.equals((java.lang.Object) 0.0f);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod90, (double) (short) 1);
        java.util.Date date97 = simpleTimePeriod90.getStart();
        org.jfree.data.time.Year year98 = new org.jfree.data.time.Year(date97);
        boolean boolean99 = timePeriodValues8.equals((java.lang.Object) date97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-1.0d) + "'", comparable28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (-1.0d) + "'", comparable39.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + (-1.0d) + "'", comparable54.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "hi!" + "'", str78.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 2019L + "'", long80 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(date97);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) 0);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        seriesException14.addSuppressed((java.lang.Throwable) seriesException16);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) seriesException14);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) seriesException25);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) seriesException25);
        java.lang.String str28 = timePeriodFormatException12.toString();
        seriesException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str30 = seriesException9.toString();
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str30.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        long long13 = year11.getFirstMillisecond();
        java.lang.Class<?> wildcardClass14 = year11.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.next();
        long long16 = year11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        java.lang.String str5 = timePeriodValues3.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        java.lang.String str17 = year6.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long21 = simpleTimePeriod20.getStartMillis();
        long long22 = simpleTimePeriod20.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean25 = simpleTimePeriod20.equals((java.lang.Object) timePeriodValues24);
        boolean boolean26 = year6.equals((java.lang.Object) timePeriodValues24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year6.next();
        long long28 = year6.getSerialIndex();
        long long29 = year6.getSerialIndex();
        timePeriodValues3.setKey((java.lang.Comparable) long29);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str9 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str9.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        int int13 = timePeriodValues8.getItemCount();
        timePeriodValues8.setNotify(true);
        int int16 = timePeriodValues8.getMaxEndIndex();
        int int17 = timePeriodValues8.getMaxStartIndex();
        int int18 = day0.compareTo((java.lang.Object) timePeriodValues8);
        int int19 = timePeriodValues8.getItemCount();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        java.lang.Comparable comparable16 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (-1.0d) + "'", comparable16.equals((-1.0d)));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy(5, (int) (byte) 0);
        java.lang.String str17 = timePeriodValues16.getDomainDescription();
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.util.Date date5 = simpleTimePeriod2.getEnd();
//        java.util.Date date6 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) day7);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day7.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod4, 0.0d);
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue6.getPeriod();
        timePeriodValue6.setValue((java.lang.Number) 12);
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue6.getPeriod();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (double) 4);
        timePeriodValues18.add(timePeriodValue21);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues18);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues18.getDomainDescription();
        int int27 = timePeriodValues18.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod29 = timePeriodValues18.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getItemCount();
        boolean boolean5 = timePeriodValues3.getNotify();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1]");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        try {
            timePeriodValues3.update((int) ' ', (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        java.lang.Object obj4 = null;
        int int5 = day0.compareTo(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        java.util.Date date21 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.lang.Object obj4 = null;
//        int int5 = day0.compareTo(obj4);
//        long long6 = day0.getSerialIndex();
//        int int7 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues5.isEmpty();
        java.lang.Comparable comparable10 = timePeriodValues5.getKey();
        boolean boolean11 = timePeriodValues5.isEmpty();
        timePeriodValues5.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (double) 4);
        timePeriodValues5.add(timePeriodValue18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues23.fireSeriesChanged();
        int int25 = timePeriodValues23.getMaxStartIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener32);
        java.lang.String str34 = timePeriodValues30.getDomainDescription();
        boolean boolean35 = year26.equals((java.lang.Object) str34);
        long long36 = year26.getSerialIndex();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) year26, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year26.next();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) (short) 0);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year26, (double) 1.0f);
        int int44 = timePeriodValues1.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues47 = timePeriodValues1.createCopy(8, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        long long11 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int16 = timePeriodValues15.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = timePeriodValues15.createCopy(0, (-1));
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year0.previous();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        int int9 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        int int15 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
        boolean boolean23 = simpleTimePeriod18.equals((java.lang.Object) regularTimePeriod22);
        java.lang.Number number24 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod22, number24);
        int int26 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        int int13 = timePeriodValues8.getItemCount();
        timePeriodValues8.setNotify(true);
        int int16 = timePeriodValues8.getMaxEndIndex();
        int int17 = timePeriodValues8.getMaxStartIndex();
        int int18 = day0.compareTo((java.lang.Object) timePeriodValues8);
        java.util.Date date19 = day0.getEnd();
        java.util.Calendar calendar20 = null;
        try {
            day0.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        boolean boolean17 = timePeriodValues13.isEmpty();
        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues24.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues24.removePropertyChangeListener(propertyChangeListener26);
        boolean boolean28 = timePeriodValues24.isEmpty();
        java.lang.Comparable comparable29 = timePeriodValues24.getKey();
        boolean boolean30 = timePeriodValues24.isEmpty();
        int int31 = timePeriodValues24.getMaxStartIndex();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        timePeriodValues24.setKey((java.lang.Comparable) year32);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) 13);
        boolean boolean38 = year0.equals((java.lang.Object) year32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year0.next();
        long long40 = regularTimePeriod39.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (-1.0d) + "'", comparable29.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1593676799999L + "'", long40 == 1593676799999L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValues7.add(timePeriodValue10);
        boolean boolean13 = timePeriodValue10.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1577865599999L);
        java.lang.String str15 = seriesChangeEvent14.toString();
        try {
            int int16 = simpleTimePeriod2.compareTo((java.lang.Object) str15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setRangeDescription("");
        int int16 = timePeriodValues3.getMinEndIndex();
        int int17 = timePeriodValues3.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue19 = timePeriodValues3.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        boolean boolean26 = day18.equals((java.lang.Object) regularTimePeriod25);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day18, (double) (short) 10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = timePeriodValues3.createCopy(10, 4);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue33 = timePeriodValues31.getDataItem((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(timePeriodValues31);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        try {
            java.lang.Number number13 = timePeriodValues3.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        int int4 = day0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        int int13 = timePeriodValues8.getItemCount();
        timePeriodValues8.setNotify(true);
        int int16 = timePeriodValues8.getMaxEndIndex();
        int int17 = timePeriodValues8.getMaxStartIndex();
        int int18 = day0.compareTo((java.lang.Object) timePeriodValues8);
        int int19 = day0.getMonth();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) year6);
        long long11 = year6.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.String str17 = seriesException15.toString();
        int int18 = year6.compareTo((java.lang.Object) str17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year6.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        int int14 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.delete((int) (byte) 100, (-163));
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue19 = timePeriodValues3.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        java.util.Date date7 = day0.getEnd();
//        long long8 = day0.getSerialIndex();
//        int int9 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        long long13 = year11.getFirstMillisecond();
        java.lang.Class<?> wildcardClass14 = year11.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        try {
            timePeriodValues1.update(10, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "13-June-2019");
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.Class<?> wildcardClass26 = timePeriodFormatException24.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.fireSeriesChanged();
        int int32 = timePeriodValues30.getMaxStartIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues37.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timePeriodValues37.removePropertyChangeListener(propertyChangeListener39);
        java.lang.String str41 = timePeriodValues37.getDomainDescription();
        boolean boolean42 = year33.equals((java.lang.Object) str41);
        long long43 = year33.getSerialIndex();
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) year33, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year33.next();
        java.util.Date date47 = year33.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass52 = simpleTimePeriod51.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues56.fireSeriesChanged();
        int int58 = timePeriodValues56.getMaxStartIndex();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues63.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues63.removePropertyChangeListener(propertyChangeListener65);
        java.lang.String str67 = timePeriodValues63.getDomainDescription();
        boolean boolean68 = year59.equals((java.lang.Object) str67);
        long long69 = year59.getSerialIndex();
        timePeriodValues56.add((org.jfree.data.time.TimePeriod) year59, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year59.next();
        java.util.Date date73 = year59.getStart();
        java.lang.Class class74 = null;
        java.util.Date date75 = null;
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date73, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date47, timeZone76);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date20, timeZone76);
        org.jfree.data.time.TimePeriodValues timePeriodValues84 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues84.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener86 = null;
        timePeriodValues84.removePropertyChangeListener(propertyChangeListener86);
        java.lang.String str88 = timePeriodValues84.getDomainDescription();
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue91 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year89, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue93 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year89, (double) 4);
        timePeriodValues84.add((org.jfree.data.time.TimePeriod) year89, (java.lang.Number) 1.0f);
        java.lang.String str96 = year89.toString();
        java.util.Date date97 = year89.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod98 = new org.jfree.data.time.SimpleTimePeriod(date20, date97);
        long long99 = simpleTimePeriod98.getEndMillis();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "2019" + "'", str96.equals("2019"));
        org.junit.Assert.assertNotNull(date97);
        org.junit.Assert.assertTrue("'" + long99 + "' != '" + 1577865599999L + "'", long99 == 1577865599999L);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
//        timePeriodValues3.setNotify(true);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues20.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
//        boolean boolean24 = timePeriodValues20.isEmpty();
//        timePeriodValues20.setDomainDescription("hi!");
//        int int27 = timePeriodValues20.getItemCount();
//        int int28 = timePeriodValues20.getMinEndIndex();
//        timePeriodValues20.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues34.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues34.removePropertyChangeListener(propertyChangeListener36);
//        boolean boolean38 = timePeriodValues34.isEmpty();
//        java.lang.Comparable comparable39 = timePeriodValues34.getKey();
//        boolean boolean40 = timePeriodValues34.isEmpty();
//        timePeriodValues34.setDescription("");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timePeriodValues34.removeChangeListener(seriesChangeListener43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year45, (double) 4);
//        timePeriodValues34.add(timePeriodValue47);
//        java.lang.Number number49 = timePeriodValue47.getValue();
//        timePeriodValues20.add(timePeriodValue47);
//        timePeriodValue47.setValue((java.lang.Number) 0);
//        java.lang.Object obj53 = timePeriodValue47.clone();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate55 = day54.getSerialDate();
//        int int57 = day54.compareTo((java.lang.Object) (-1L));
//        int int58 = day54.getDayOfMonth();
//        long long59 = day54.getSerialIndex();
//        boolean boolean60 = timePeriodValue47.equals((java.lang.Object) day54);
//        timePeriodValues3.add(timePeriodValue47);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue63 = timePeriodValues3.getDataItem((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (-1.0d) + "'", comparable39.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 4.0d + "'", number49.equals(4.0d));
//        org.junit.Assert.assertNotNull(obj53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 13 + "'", int58 == 13);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str9 = timePeriodValues3.getDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str9 = timePeriodValues3.getDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues6.fireSeriesChanged();
        int int8 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        java.lang.String str17 = timePeriodValues13.getDomainDescription();
        boolean boolean18 = year9.equals((java.lang.Object) str17);
        long long19 = year9.getSerialIndex();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year9, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year9.next();
        java.util.Date date23 = year9.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues28.fireSeriesChanged();
        int int30 = timePeriodValues28.getMaxStartIndex();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues35.getDomainDescription();
        boolean boolean40 = year31.equals((java.lang.Object) str39);
        long long41 = year31.getSerialIndex();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year31, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year31.next();
        java.util.Date date45 = year31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(date23, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues50.fireSeriesChanged();
        int int52 = timePeriodValues50.getMaxStartIndex();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues57.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener59);
        java.lang.String str61 = timePeriodValues57.getDomainDescription();
        boolean boolean62 = year53.equals((java.lang.Object) str61);
        long long63 = year53.getSerialIndex();
        timePeriodValues50.add((org.jfree.data.time.TimePeriod) year53, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year53.next();
        java.util.Date date67 = year53.getStart();
        boolean boolean68 = simpleTimePeriod46.equals((java.lang.Object) date67);
        java.lang.Class class69 = null;
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date70, timeZone71);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date67, timeZone71);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date67);
        long long75 = day74.getSerialIndex();
        boolean boolean76 = year0.equals((java.lang.Object) day74);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate78 = day77.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day77.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue81 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day77, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue83 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day77, (double) 1560452399999L);
        boolean boolean84 = year0.equals((java.lang.Object) day77);
        java.util.Calendar calendar85 = null;
        try {
            long long86 = day77.getMiddleMillisecond(calendar85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 43466L + "'", long75 == 43466L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        seriesException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str19 = seriesException10.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str19.equals("org.jfree.data.general.SeriesException: "));
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValue4.getPeriod();
        timePeriodValue4.setValue((java.lang.Number) 11);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(timePeriod5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues15.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener17);
        boolean boolean19 = timePeriodValues15.isEmpty();
        java.lang.Comparable comparable20 = timePeriodValues15.getKey();
        java.lang.Object obj21 = timePeriodValues15.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod24, (double) (short) 10);
        java.util.Date date27 = simpleTimePeriod24.getStart();
        boolean boolean28 = timePeriodValues3.equals((java.lang.Object) simpleTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (-1.0d) + "'", comparable20.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(11, 7);
        timePeriodValues1.setRangeDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        timePeriodValues3.delete(100, 0);
        try {
            java.lang.Number number17 = timePeriodValues3.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,4.0]");
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 1.0f);
        java.lang.String str15 = year8.toString();
        int int16 = year8.getYear();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Class<?> wildcardClass13 = timePeriodValues3.getClass();
        timePeriodValues3.delete((int) (short) 10, 7);
        int int17 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        timePeriodValue4.setValue((java.lang.Number) (byte) 1);
        java.lang.Number number7 = timePeriodValue4.getValue();
        java.lang.Object obj8 = timePeriodValue4.clone();
        java.lang.Object obj9 = timePeriodValue4.clone();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str14 = timePeriodValues3.getRangeDescription();
        java.lang.Object obj15 = timePeriodValues3.clone();
        boolean boolean16 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod3, (double) 1562097599999L);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues8.createCopy(11, 7);
//        boolean boolean12 = day0.equals((java.lang.Object) timePeriodValues11);
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timePeriodValues11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getStart();
//        int int5 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener24);
        boolean boolean26 = timePeriodValues22.isEmpty();
        java.lang.Comparable comparable27 = timePeriodValues22.getKey();
        boolean boolean28 = timePeriodValues22.isEmpty();
        timePeriodValues22.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (double) 4);
        timePeriodValues22.add(timePeriodValue35);
        timePeriodValues3.add(timePeriodValue35);
        org.jfree.data.time.TimePeriod timePeriod38 = timePeriodValue35.getPeriod();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (-1.0d) + "'", comparable27.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(timePeriod38);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        java.util.Date date5 = year0.getStart();
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.isEmpty();
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timePeriodValues3.equals(obj11);
//        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener15);
//        java.lang.String str17 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.util.Date date20 = day18.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day21.previous();
//        boolean boolean26 = day18.equals((java.lang.Object) regularTimePeriod25);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day18, (double) (short) 10);
//        int int29 = timePeriodValues3.getMaxMiddleIndex();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        java.lang.String str32 = timePeriodValues3.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str32.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=-1]");
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        java.lang.Class<?> wildcardClass29 = timePeriodFormatException27.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues33.fireSeriesChanged();
        int int35 = timePeriodValues33.getMaxStartIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener42);
        java.lang.String str44 = timePeriodValues40.getDomainDescription();
        boolean boolean45 = year36.equals((java.lang.Object) str44);
        long long46 = year36.getSerialIndex();
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) year36, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year36.next();
        java.util.Date date50 = year36.getStart();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass55 = simpleTimePeriod54.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues59.fireSeriesChanged();
        int int61 = timePeriodValues59.getMaxStartIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues66.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener68 = null;
        timePeriodValues66.removePropertyChangeListener(propertyChangeListener68);
        java.lang.String str70 = timePeriodValues66.getDomainDescription();
        boolean boolean71 = year62.equals((java.lang.Object) str70);
        long long72 = year62.getSerialIndex();
        timePeriodValues59.add((org.jfree.data.time.TimePeriod) year62, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year62.next();
        java.util.Date date76 = year62.getStart();
        java.lang.Class class77 = null;
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date78, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date76, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date50, timeZone79);
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date22, timeZone79);
        org.jfree.data.time.TimePeriodValue timePeriodValue85 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day83, (java.lang.Number) 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "hi!" + "'", str70.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2019L + "'", long72 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) regularTimePeriod6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
        boolean boolean17 = timePeriodValues13.isEmpty();
        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues24.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues24.removePropertyChangeListener(propertyChangeListener26);
        boolean boolean28 = timePeriodValues24.isEmpty();
        java.lang.Comparable comparable29 = timePeriodValues24.getKey();
        boolean boolean30 = timePeriodValues24.isEmpty();
        int int31 = timePeriodValues24.getMaxStartIndex();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        timePeriodValues24.setKey((java.lang.Comparable) year32);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) 13);
        boolean boolean38 = year0.equals((java.lang.Object) year32);
        long long39 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (-1.0d) + "'", comparable29.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,1530561599999]");
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timePeriodValues3.getDomainDescription();
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setKey((java.lang.Comparable) 'a');
//        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        int int13 = timePeriodValues3.getItemCount();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        long long18 = day17.getFirstMillisecond();
//        java.util.Date date19 = day17.getStart();
//        timePeriodValues3.setKey((java.lang.Comparable) date19);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
//        java.util.Date date24 = simpleTimePeriod23.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date19, timeZone25);
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = day27.getMiddleMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getMonth();
//        java.util.Date date6 = day0.getStart();
//        java.util.Date date7 = day0.getEnd();
//        long long8 = day0.getSerialIndex();
//        int int9 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        int int19 = timePeriodValues3.getMaxMiddleIndex();
        int int20 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Comparable comparable13 = timePeriodValues8.getKey();
        timePeriodValues8.setDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.previous();
        java.lang.String str23 = year16.toString();
        long long24 = year16.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1.0d) + "'", comparable13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue(timePeriod3, (double) 2);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "org.jfree.data.general.SeriesException: ", "TimePeriodValue[13-June-2019,1530561599999]");
        org.junit.Assert.assertNotNull(timePeriod3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        int int6 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str7 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        java.util.Date date8 = day0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 4);
        timePeriodValues12.add(timePeriodValue15);
        boolean boolean18 = timePeriodValue15.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1577865599999L);
        java.lang.String str20 = seriesChangeEvent19.toString();
        java.lang.Object obj21 = seriesChangeEvent19.getSource();
        java.lang.Object obj22 = seriesChangeEvent19.getSource();
        boolean boolean23 = day0.equals((java.lang.Object) seriesChangeEvent19);
        java.lang.String str24 = seriesChangeEvent19.toString();
        java.lang.String str25 = seriesChangeEvent19.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str20.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
        org.junit.Assert.assertTrue("'" + obj21 + "' != '" + 1577865599999L + "'", obj21.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + 1577865599999L + "'", obj22.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str24.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str25.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date64, timeZone72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date64);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date64);
        int int76 = day75.getMonth();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues6.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
//        boolean boolean10 = timePeriodValues6.isEmpty();
//        java.lang.Comparable comparable11 = timePeriodValues6.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues6.addChangeListener(seriesChangeListener12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues17.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
//        boolean boolean21 = timePeriodValues17.isEmpty();
//        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
//        boolean boolean23 = timePeriodValues17.isEmpty();
//        int int24 = timePeriodValues17.getMaxStartIndex();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        timePeriodValues17.setKey((java.lang.Comparable) year25);
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) (short) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.next();
//        boolean boolean30 = day0.equals((java.lang.Object) year25);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (-1.0d) + "'", comparable11.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        timePeriodValues3.setDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean19 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues18);
        boolean boolean20 = year0.equals((java.lang.Object) timePeriodValues18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year0.next();
        long long22 = year0.getSerialIndex();
        java.util.Date date23 = year0.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 'a');
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) 0);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        int int6 = day3.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
//        boolean boolean8 = day0.equals((java.lang.Object) regularTimePeriod7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.previous();
//        int int10 = day0.getMonth();
//        long long11 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        java.lang.Object obj9 = timePeriodValues3.clone();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        boolean boolean9 = year0.equals((java.lang.Object) str8);
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (short) -1, 6);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year28, (double) 4);
        timePeriodValues17.add(timePeriodValue30);
        java.lang.Number number32 = timePeriodValue30.getValue();
        timePeriodValues3.add(timePeriodValue30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue30);
        org.jfree.data.time.TimePeriod timePeriod35 = timePeriodValue30.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 4.0d + "'", number32.equals(4.0d));
        org.junit.Assert.assertNotNull(timePeriod35);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues9.fireSeriesChanged();
        int int11 = timePeriodValues9.getMaxStartIndex();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues16.getDomainDescription();
        boolean boolean21 = year12.equals((java.lang.Object) str20);
        long long22 = year12.getSerialIndex();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year12, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year12.next();
        java.util.Date date26 = year12.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues31.fireSeriesChanged();
        int int33 = timePeriodValues31.getMaxStartIndex();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues38.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
        java.lang.String str42 = timePeriodValues38.getDomainDescription();
        boolean boolean43 = year34.equals((java.lang.Object) str42);
        long long44 = year34.getSerialIndex();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year34, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year34.next();
        java.util.Date date48 = year34.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date26, date48);
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date26, timeZone50);
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(class52);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day10, (double) (byte) -1);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Object obj17 = timePeriodValues3.clone();
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (-1.0d) + "'", comparable14.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValues7.add(timePeriodValue10);
        boolean boolean13 = timePeriodValue10.equals((java.lang.Object) 1577865599999L);
        timePeriodValues3.add(timePeriodValue10);
        int int15 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) 4);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) 4);
//        timePeriodValue7.setValue((java.lang.Number) (byte) 1);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
//        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues17.fireSeriesChanged();
//        int int19 = timePeriodValues17.getMaxStartIndex();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues24.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues24.removePropertyChangeListener(propertyChangeListener26);
//        java.lang.String str28 = timePeriodValues24.getDomainDescription();
//        boolean boolean29 = year20.equals((java.lang.Object) str28);
//        long long30 = year20.getSerialIndex();
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year20, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year20.next();
//        java.util.Date date34 = year20.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date34, timeZone35);
//        boolean boolean37 = timePeriodValue7.equals((java.lang.Object) timeZone35);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date2, timeZone35);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date2);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 3, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        int int6 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 3 + "'", comparable4.equals(3));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.String str14 = timePeriodValues10.getDomainDescription();
//        boolean boolean15 = year6.equals((java.lang.Object) str14);
//        long long16 = year6.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
//        java.util.Date date20 = year6.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues25.fireSeriesChanged();
//        int int27 = timePeriodValues25.getMaxStartIndex();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues32.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        boolean boolean37 = year28.equals((java.lang.Object) str36);
//        long long38 = year28.getSerialIndex();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
//        java.util.Date date42 = year28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues47.fireSeriesChanged();
//        int int49 = timePeriodValues47.getMaxStartIndex();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues54.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
//        java.lang.String str58 = timePeriodValues54.getDomainDescription();
//        boolean boolean59 = year50.equals((java.lang.Object) str58);
//        long long60 = year50.getSerialIndex();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
//        java.util.Date date64 = year50.getStart();
//        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
//        java.lang.Class class66 = null;
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
//        java.util.Date date71 = day70.getStart();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        int int74 = day72.getDayOfMonth();
//        int int75 = day70.compareTo((java.lang.Object) day72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day72.previous();
//        long long77 = day72.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 13 + "'", int73 == 13);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 13 + "'", int74 == 13);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-163) + "'", int75 == (-163));
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 43629L + "'", long77 == 43629L);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) year6);
        java.lang.String str11 = year6.toString();
        long long12 = year6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        java.util.Date date8 = simpleTimePeriod2.getStart();
        long long9 = simpleTimePeriod2.getEndMillis();
        long long10 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getItemCount();
        try {
            java.lang.Number number8 = timePeriodValues3.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setKey((java.lang.Comparable) 1.0d);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getSerialIndex();
        long long4 = year0.getLastMillisecond();
        java.util.Date date5 = year0.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.String str7 = seriesChangeEvent6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timePeriodValues3.getNotify();
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        boolean boolean20 = timePeriodValues14.isEmpty();
        int int21 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues14.setKey((java.lang.Comparable) year22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) (short) -1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener26);
        org.jfree.data.time.TimePeriod timePeriod29 = timePeriodValues3.getTimePeriod(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (-1.0d) + "'", comparable19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(timePeriod29);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setKey((java.lang.Comparable) 1.0d);
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(13, (-163));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues13.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues13.removePropertyChangeListener(propertyChangeListener15);
//        boolean boolean17 = timePeriodValues13.isEmpty();
//        java.lang.Comparable comparable18 = timePeriodValues13.getKey();
//        timePeriodValues13.setDescription("");
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0L);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 100);
//        int int26 = timePeriodValues8.getItemCount();
//        boolean boolean27 = day0.equals((java.lang.Object) int26);
//        org.jfree.data.time.SerialDate serialDate28 = day0.getSerialDate();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
//        long long30 = day29.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-1.0d) + "'", comparable18.equals((-1.0d)));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timePeriodValues7.isEmpty();
        java.lang.Comparable comparable12 = timePeriodValues7.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timePeriodValues18.isEmpty();
        java.lang.Comparable comparable23 = timePeriodValues18.getKey();
        boolean boolean24 = timePeriodValues18.isEmpty();
        int int25 = timePeriodValues18.getMaxStartIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        timePeriodValues18.setKey((java.lang.Comparable) year26);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) (short) -1);
        int int30 = simpleTimePeriod2.compareTo((java.lang.Object) year26);
        java.util.Date date31 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (-1.0d) + "'", comparable12.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0d) + "'", comparable23.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(date31);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues3.fireSeriesChanged();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues10.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.String str14 = timePeriodValues10.getDomainDescription();
//        boolean boolean15 = year6.equals((java.lang.Object) str14);
//        long long16 = year6.getSerialIndex();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
//        java.util.Date date20 = year6.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues25.fireSeriesChanged();
//        int int27 = timePeriodValues25.getMaxStartIndex();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues32.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
//        java.lang.String str36 = timePeriodValues32.getDomainDescription();
//        boolean boolean37 = year28.equals((java.lang.Object) str36);
//        long long38 = year28.getSerialIndex();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
//        java.util.Date date42 = year28.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues47.fireSeriesChanged();
//        int int49 = timePeriodValues47.getMaxStartIndex();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        timePeriodValues54.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
//        java.lang.String str58 = timePeriodValues54.getDomainDescription();
//        boolean boolean59 = year50.equals((java.lang.Object) str58);
//        long long60 = year50.getSerialIndex();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
//        java.util.Date date64 = year50.getStart();
//        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
//        java.lang.Class class66 = null;
//        java.util.Date date67 = null;
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
//        java.util.Date date71 = day70.getStart();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        int int73 = day72.getDayOfMonth();
//        int int74 = day72.getDayOfMonth();
//        int int75 = day70.compareTo((java.lang.Object) day72);
//        long long76 = day72.getLastMillisecond();
//        java.util.Calendar calendar77 = null;
//        try {
//            long long78 = day72.getLastMillisecond(calendar77);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 13 + "'", int73 == 13);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 13 + "'", int74 == 13);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-163) + "'", int75 == (-163));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560495599999L + "'", long76 == 1560495599999L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 4);
        timePeriodValues3.add(timePeriodValue6);
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.String str9 = timePeriodValues3.getDescription();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues10);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues9.fireSeriesChanged();
        int int11 = timePeriodValues9.getMaxStartIndex();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues16.getDomainDescription();
        boolean boolean21 = year12.equals((java.lang.Object) str20);
        long long22 = year12.getSerialIndex();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year12, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year12.next();
        java.util.Date date26 = year12.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues31.fireSeriesChanged();
        int int33 = timePeriodValues31.getMaxStartIndex();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues38.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues38.removePropertyChangeListener(propertyChangeListener40);
        java.lang.String str42 = timePeriodValues38.getDomainDescription();
        boolean boolean43 = year34.equals((java.lang.Object) str42);
        long long44 = year34.getSerialIndex();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year34, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year34.next();
        java.util.Date date48 = year34.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date26, date48);
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues53.fireSeriesChanged();
        int int55 = timePeriodValues53.getMaxStartIndex();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues60.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues60.removePropertyChangeListener(propertyChangeListener62);
        java.lang.String str64 = timePeriodValues60.getDomainDescription();
        boolean boolean65 = year56.equals((java.lang.Object) str64);
        long long66 = year56.getSerialIndex();
        timePeriodValues53.add((org.jfree.data.time.TimePeriod) year56, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year56.next();
        java.util.Date date70 = year56.getStart();
        boolean boolean71 = simpleTimePeriod49.equals((java.lang.Object) date70);
        java.util.Date date72 = simpleTimePeriod49.getEnd();
        boolean boolean73 = timePeriodValue5.equals((java.lang.Object) date72);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timePeriodValues8.isEmpty();
        timePeriodValues8.setDomainDescription("hi!");
        int int15 = timePeriodValues8.getItemCount();
        int int16 = timePeriodValues8.getMinEndIndex();
        java.lang.Object obj17 = timePeriodValues8.clone();
        java.lang.String str18 = timePeriodValues8.getDomainDescription();
        boolean boolean19 = year0.equals((java.lang.Object) timePeriodValues8);
        timePeriodValues8.setNotify(false);
        boolean boolean22 = timePeriodValues8.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        boolean boolean4 = timePeriodValues3.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) true, "hi!", "org.jfree.data.time.TimePeriodFormatException: ");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        boolean boolean5 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        java.lang.String str5 = timePeriodValues3.getDescription();
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setRangeDescription("hi!");
        int int9 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (-1.0d) + "'", comparable4.equals((-1.0d)));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int5 = day0.getMonth();
        java.util.Date date6 = day0.getStart();
        java.util.Date date7 = day0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues10.createCopy((-1), 3);
        boolean boolean14 = timePeriodValues13.isEmpty();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        long long17 = year14.getFirstMillisecond();
        boolean boolean18 = year11.equals((java.lang.Object) year14);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod20, 0.0d);
        boolean boolean23 = year11.equals((java.lang.Object) 0.0d);
        long long24 = year11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 4);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        boolean boolean12 = year0.equals((java.lang.Object) seriesException10);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        seriesException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException16.getSuppressed();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Calendar calendar5 = null;
        try {
            day4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener34);
        java.lang.String str36 = timePeriodValues32.getDomainDescription();
        boolean boolean37 = year28.equals((java.lang.Object) str36);
        long long38 = year28.getSerialIndex();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year28, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year28.next();
        java.util.Date date42 = year28.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        boolean boolean65 = simpleTimePeriod43.equals((java.lang.Object) date64);
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date64, timeZone68);
        int int71 = day70.getMonth();
        java.util.Date date72 = day70.getEnd();
        java.util.Calendar calendar73 = null;
        try {
            long long74 = day70.getFirstMillisecond(calendar73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(date72);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod1, 0.0d);
        timePeriodValue3.setValue((java.lang.Number) (-1.0d));
        java.lang.Number number6 = timePeriodValue3.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timePeriodValues17.isEmpty();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        boolean boolean23 = timePeriodValues17.isEmpty();
        int int24 = timePeriodValues17.getMaxStartIndex();
        int int25 = year11.compareTo((java.lang.Object) timePeriodValues17);
        int int26 = year11.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues30.setNotify(false);
        int int33 = timePeriodValues30.getMaxStartIndex();
        java.lang.Comparable comparable34 = timePeriodValues30.getKey();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener35);
        boolean boolean37 = year11.equals((java.lang.Object) propertyChangeListener35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (-1.0d) + "'", comparable22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (-1.0d) + "'", comparable34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 4);
        timePeriodValues3.add(timePeriodValue16);
        java.lang.Object obj18 = timePeriodValue16.clone();
        java.lang.Object obj19 = timePeriodValue16.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 4);
        timePeriodValue10.setValue((java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue10.getPeriod();
        java.lang.Class<?> wildcardClass14 = timePeriod13.getClass();
        java.util.Date date15 = null;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues20.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener22);
        java.lang.String str24 = timePeriodValues20.getDomainDescription();
        boolean boolean25 = year16.equals((java.lang.Object) str24);
        long long26 = year16.getSerialIndex();
        java.lang.String str27 = year16.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 100);
        long long31 = simpleTimePeriod30.getStartMillis();
        long long32 = simpleTimePeriod30.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f);
        boolean boolean35 = simpleTimePeriod30.equals((java.lang.Object) timePeriodValues34);
        boolean boolean36 = year16.equals((java.lang.Object) timePeriodValues34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year16.next();
        long long38 = year16.getSerialIndex();
        java.util.Date date39 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        java.lang.Class<?> wildcardClass43 = simpleTimePeriod42.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues47.fireSeriesChanged();
        int int49 = timePeriodValues47.getMaxStartIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues54.getDomainDescription();
        boolean boolean59 = year50.equals((java.lang.Object) str58);
        long long60 = year50.getSerialIndex();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year50, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
        java.util.Date date64 = year50.getStart();
        java.lang.Class class65 = null;
        java.util.Date date66 = null;
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date64, timeZone67);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date39, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone67);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date5, timeZone67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timePeriodValues3.equals(obj11);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) (byte) 1);
        int int15 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable16 = timePeriodValues3.getKey();
        java.lang.String str17 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (byte) 0 + "'", comparable16.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy((int) (byte) 1, (int) (short) 10);
        java.lang.Comparable comparable10 = timePeriodValues9.getKey();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues9.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1.0d) + "'", comparable10.equals((-1.0d)));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues3.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("hi!");
        int int10 = timePeriodValues3.getItemCount();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues3.getMinStartIndex();
        boolean boolean17 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 7);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        long long5 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 4);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 1.0f);
        java.lang.String str15 = timePeriodValues3.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues3.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getFirstMillisecond();
//        java.util.Date date5 = day3.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        boolean boolean15 = year6.equals((java.lang.Object) str14);
        long long16 = year6.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, (double) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        java.util.Date date20 = year6.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.lang.String str24 = year23.toString();
        long long25 = year23.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.setKey((java.lang.Comparable) year11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year11);
        long long14 = year11.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
    }
}

