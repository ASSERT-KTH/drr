import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) 100, (float) 10, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke6 = null;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("item", "", "hi!", "", shape4, paint5, stroke6, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) (short) 0);
        try {
            java.lang.Number number5 = xYSeriesCollection0.getStartY((int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        try {
            xYStepRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.lang.Comparable comparable2 = null;
        try {
            java.awt.Paint paint3 = ringPlot0.getSectionPaint(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            xYStepRenderer0.fillDomainGridBand(graphics2D1, xYPlot2, valueAxis3, rectangle2D4, 1.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("index.html", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot2.getIgnoreZeroValues();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = categoryAxis3D0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) ringPlot2, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        java.util.List list2 = null;
        try {
            org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("item", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        try {
            org.jfree.chart.entity.PlotEntity plotEntity4 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) ringPlot1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100);
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, (double) 100);
        try {
            boolean boolean6 = range2.intersects(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("index.html");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.util.LogFormat logFormat7 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean8 = logFormat7.isParseIntegerOnly();
        java.text.ParsePosition parsePosition10 = null;
        java.lang.Object obj11 = logFormat7.parseObject("", parsePosition10);
        int int12 = logFormat7.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat17 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean18 = logFormat17.isParseIntegerOnly();
        java.text.ParsePosition parsePosition20 = null;
        java.lang.Object obj21 = logFormat17.parseObject("", parsePosition20);
        int int22 = logFormat17.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator23 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat7, (java.text.NumberFormat) logFormat17);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator23, xYURLGenerator24);
        try {
            java.lang.String str26 = numberFormat0.format((java.lang.Object) xYAreaRenderer25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        org.jfree.chart.axis.TickUnit tickUnit5 = null;
        try {
            polarPlot4.setAngleTickUnit(tickUnit5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) ' ', (double) 100, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer2.setSeriesOutlinePaint((int) (byte) 10, paint4, false);
        try {
            org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("index.html", font1, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        java.lang.String str6 = logFormat4.format((long) 8);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.58" + "'", str6.equals("0.58"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("index.html", "hi!", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) (byte) -1, (double) (-1), 0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = null;
        java.awt.geom.RectangularShape rectangularShape9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            gradientXYBarPainter3.paintBarShadow(graphics2D4, xYBarRenderer5, 0, (int) '4', true, rectangularShape9, rectangleEdge10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        java.awt.Stroke stroke7 = null;
        try {
            xYStepRenderer0.setBaseOutlineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint2 = ringPlot0.getBackgroundPaint();
        boolean boolean3 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            java.lang.Comparable comparable2 = xYSeriesCollection0.getSeriesKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        try {
            polarPlot4.zoom((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("index.html");
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean2 = xYStepRenderer0.getSeriesLinesVisible((int) (byte) 0);
        boolean boolean6 = xYStepRenderer0.getItemCreateEntity((int) ' ', 1, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            xYStepRenderer0.fillDomainGridBand(graphics2D7, xYPlot8, valueAxis9, rectangle2D10, (double) '#', (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryAxis3D0.setTickMarkPaint(paint4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean6 = polarPlot4.equals((java.lang.Object) 100.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            polarPlot4.zoomRangeAxes((double) 0L, (double) (byte) 100, plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = null;
        try {
            ringPlot0.setLabelLinkStyle(pieLabelLinkStyle3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (short) 100;
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape6 = legendItem5.getLine();
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "0.58", "index.html", shape6, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            categoryAxis3D0.setLabelInsets(rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) 1L, (double) (byte) -1, (int) (short) -1, (java.lang.Comparable) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot0.getDrawingSupplier();
        ringPlot0.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean6 = logFormat5.isParseIntegerOnly();
        java.text.ParsePosition parsePosition8 = null;
        java.lang.Object obj9 = logFormat5.parseObject("", parsePosition8);
        int int10 = logFormat5.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean16 = logFormat15.isParseIntegerOnly();
        java.text.ParsePosition parsePosition18 = null;
        java.lang.Object obj19 = logFormat15.parseObject("", parsePosition18);
        int int20 = logFormat15.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection22 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection22, valueAxis24, polarItemRenderer25);
        try {
            java.lang.String str29 = standardXYToolTipGenerator21.generateToolTip((org.jfree.data.xy.XYDataset) xYSeriesCollection22, 12, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 2, (double) 1.0f, (int) (short) -1, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = null;
        try {
            java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape6 = legendItem5.getLine();
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot9 = categoryAxis3D8.getPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D8.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color11);
        try {
            org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem(attributedString0, "item", "", "index.html", shape6, stroke7, (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) true, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape6 = legendItem5.getLine();
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.Stroke stroke8 = null;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem(attributedString0, "item", "index.html", "", shape6, (java.awt.Paint) color7, stroke8, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        int int5 = logFormat4.getMinimumFractionDigits();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) 10.0f, (double) 2, 8, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            xYStepRenderer0.fillRangeGridBand(graphics2D4, xYPlot5, valueAxis6, rectangle2D7, (double) 2.0f, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("-∞");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart1, 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        try {
            xYSeries1.delete(0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("-∞", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean6 = logFormat5.isParseIntegerOnly();
        java.text.ParsePosition parsePosition8 = null;
        java.lang.Object obj9 = logFormat5.parseObject("", parsePosition8);
        int int10 = logFormat5.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean16 = logFormat15.isParseIntegerOnly();
        java.text.ParsePosition parsePosition18 = null;
        java.lang.Object obj19 = logFormat15.parseObject("", parsePosition18);
        int int20 = logFormat15.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection22 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection22);
        try {
            java.lang.String str26 = standardXYToolTipGenerator21.generateToolTip((org.jfree.data.xy.XYDataset) xYSeriesCollection22, 12, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = null;
        try {
            logAxis1.setTickUnit(numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float[] floatArray8 = new float[] { 2958465, 1.0f, 12 };
        try {
            float[] floatArray9 = color3.getComponents(floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("index.html", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) 100L, (double) '#', 8, (java.lang.Comparable) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint10 = xYAreaRenderer8.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = xYAreaRenderer8.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = xYAreaRenderer8.initialise(graphics2D12, rectangle2D13, xYPlot14, xYDataset15, plotRenderingInfo16);
        boolean boolean18 = xYItemRendererState17.getProcessVisibleItemsOnly();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("");
        double double24 = logAxis22.calculateValue((double) 8);
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("");
        logAxis26.setPositiveArrowVisible(false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection29 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection29);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection29, valueAxis31, polarItemRenderer32);
        try {
            xYStepRenderer0.drawItem(graphics2D7, xYItemRendererState17, rectangle2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) logAxis22, (org.jfree.chart.axis.ValueAxis) logAxis26, (org.jfree.data.xy.XYDataset) xYSeriesCollection29, 7, (int) (short) 0, true, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(xYToolTipGenerator11);
        org.junit.Assert.assertNotNull(xYItemRendererState17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E8d + "'", double24 == 1.0E8d);
        org.junit.Assert.assertNull(range30);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean2 = xYStepRenderer0.getSeriesLinesVisible((int) (byte) 0);
        boolean boolean6 = xYStepRenderer0.getItemCreateEntity((int) ' ', 1, false);
        int int7 = xYStepRenderer0.getPassCount();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean5 = org.jfree.chart.util.PaintUtilities.equal(paint3, paint4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            org.jfree.data.xy.XYSeries xYSeries2 = xYSeriesCollection0.getSeries(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        double double2 = categoryAxis3D0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        java.util.List list6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        try {
            double double9 = categoryAxis3D0.getCategoryMiddle((java.lang.Comparable) "ChartChangeEventType.NEW_DATASET", list6, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        xYSeriesCollection0.validateObject();
        try {
            double double8 = xYSeriesCollection0.getYValue(2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            barRenderer3D0.drawBackground(graphics2D3, categoryPlot4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ChartChangeEventType.NEW_DATASET", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.Object obj0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        double double4 = logAxis2.calculateValue((double) 8);
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 100);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 10L);
        logAxis2.setRange(range7, true, false);
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E8d + "'", double4 == 1.0E8d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        xYSeriesCollection0.validateObject();
        try {
            java.lang.Number number8 = xYSeriesCollection0.getY(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.plot.Marker marker5 = null;
        try {
            boolean boolean6 = combinedDomainXYPlot4.removeRangeMarker(marker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYSeries1.equals((java.lang.Object) xYStepRenderer8);
        xYSeries1.add((double) (short) 1, (java.lang.Number) 1.0E-8d, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D0.getCategoryStart(3, (int) (byte) 10, rectangle2D4, rectangleEdge5);
        java.awt.Font font8 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) (byte) 10);
        categoryAxis3D0.setLabelAngle((double) 5);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        try {
            double double17 = categoryAxis3D0.getCategorySeriesMiddle((java.lang.Comparable) (-1.0d), (java.lang.Comparable) '4', categoryDataset13, (double) 0.0f, rectangle2D15, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.addFragment(textFragment1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-∞", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Image image2 = ringPlot0.getBackgroundImage();
        ringPlot0.setCircular(true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        boolean boolean5 = ringPlot0.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (byte) 0, (double) 8, (double) 100.0f, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(10.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D0.getCategoryStart(3, (int) (byte) 10, rectangle2D4, rectangleEdge5);
        categoryAxis3D0.setLabelToolTip("index.html");
        categoryAxis3D0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            categoryAxis3D0.setLabelInsets(rectangleInsets11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D6.setTickLabelsVisible(true);
        boolean boolean9 = logAxis5.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape12 = xYAreaRenderer10.lookupSeriesShape((int) (short) -1);
        logAxis5.setDownArrow(shape12);
        java.awt.Paint paint14 = null;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "index.html", "0.58", "hi!", shape12, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        xYSeriesCollection0.validateObject();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        try {
            java.lang.Comparable comparable9 = xYSeriesCollection0.getSeriesKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter(0.0d, (double) 8, (double) 100);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer2.setSeriesOutlinePaint((int) (byte) 10, paint4, false);
        paintList0.setPaint((int) (short) 0, paint4);
        java.lang.Object obj8 = paintList0.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str2 = legendItem1.getURLText();
        java.awt.Paint paint3 = legendItem1.getLabelPaint();
        java.lang.String str4 = legendItem1.getDescription();
        boolean boolean5 = legendItem1.isShapeVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot4.getDomainMinorGridlineStroke();
        java.awt.Stroke stroke7 = null;
        try {
            combinedDomainXYPlot4.setDomainCrosshairStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint2 = ringPlot0.getBackgroundPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.String str7 = standardPieSectionLabelGenerator4.generateSectionLabel(pieDataset5, (java.lang.Comparable) 1);
        ringPlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYStepRenderer9.setSeriesURLGenerator(100, xYURLGenerator11);
        org.jfree.chart.util.LogFormat logFormat20 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean21 = logFormat20.isParseIntegerOnly();
        java.text.ParsePosition parsePosition23 = null;
        java.lang.Object obj24 = logFormat20.parseObject("", parsePosition23);
        int int25 = logFormat20.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat30 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean31 = logFormat30.isParseIntegerOnly();
        java.text.ParsePosition parsePosition33 = null;
        java.lang.Object obj34 = logFormat30.parseObject("", parsePosition33);
        int int35 = logFormat30.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator36 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat20, (java.text.NumberFormat) logFormat30);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer38 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator36, xYURLGenerator37);
        xYStepRenderer9.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator36);
        boolean boolean40 = ringPlot0.equals((java.lang.Object) 2958465);
        try {
            ringPlot0.setBackgroundImageAlpha(10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ChartChangeEventType.NEW_DATASET", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesVisible((int) 'a', (java.lang.Boolean) true, false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel(1);
        org.junit.Assert.assertNull(attributedString3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        ringPlot7.setDataset(pieDataset9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean22 = logFormat21.isParseIntegerOnly();
        java.text.ParsePosition parsePosition24 = null;
        java.lang.Object obj25 = logFormat21.parseObject("", parsePosition24);
        int int26 = logFormat21.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator27 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat11, (java.text.NumberFormat) logFormat21);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27, xYURLGenerator28);
        xYStepRenderer0.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27);
        java.lang.Boolean boolean32 = xYStepRenderer0.getSeriesShapesFilled((int) (short) 10);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        logAxis35.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot38 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = combinedDomainXYPlot38.getRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D40 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator41 = null;
        barRenderer3D40.setBaseToolTipGenerator(categoryToolTipGenerator41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = null;
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("");
        logAxis46.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot49 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis46);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer52 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer52.setSeriesOutlinePaint((int) (byte) 10, paint54, false);
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D40.drawRangeLine(graphics2D43, categoryPlot44, (org.jfree.chart.axis.ValueAxis) logAxis46, rectangle2D50, (double) (short) 0, paint54, stroke57);
        combinedDomainXYPlot38.setRangeZeroBaselineStroke(stroke57);
        xYStepRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke57, true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertNull(xYItemRenderer39);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D0.getCategoryStart(3, (int) (byte) 10, rectangle2D4, rectangleEdge5);
        categoryAxis3D0.setLabelToolTip("index.html");
        categoryAxis3D0.setVisible(false);
        java.lang.String str11 = categoryAxis3D0.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "index.html" + "'", str11.equals("index.html"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean22 = logFormat21.isParseIntegerOnly();
        java.text.ParsePosition parsePosition24 = null;
        java.lang.Object obj25 = logFormat21.parseObject("", parsePosition24);
        int int26 = logFormat21.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator27 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat11, (java.text.NumberFormat) logFormat21);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27, xYURLGenerator28);
        xYStepRenderer0.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27);
        java.lang.Boolean boolean32 = xYStepRenderer0.getSeriesShapesFilled((int) (short) 10);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        logAxis35.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot38 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis35);
        java.awt.geom.GeneralPath generalPath39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.RenderingSource renderingSource41 = null;
        combinedDomainXYPlot38.select(generalPath39, rectangle2D40, renderingSource41);
        org.jfree.chart.axis.LogAxis logAxis44 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D45.setTickLabelsVisible(true);
        boolean boolean48 = logAxis44.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer49 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape51 = xYAreaRenderer49.lookupSeriesShape((int) (short) -1);
        logAxis44.setDownArrow(shape51);
        logAxis44.configure();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        try {
            xYStepRenderer0.fillDomainGridBand(graphics2D33, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot38, (org.jfree.chart.axis.ValueAxis) logAxis44, rectangle2D54, (double) 10.0f, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(shape51);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean2 = xYStepRenderer0.getSeriesLinesVisible((int) (byte) 0);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer4.setSeriesOutlinePaint((int) (byte) 10, paint6, false);
        xYStepRenderer4.setSeriesShapesVisible((int) (short) 10, (java.lang.Boolean) false);
        boolean boolean12 = xYStepRenderer4.getBaseShapesFilled();
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        xYStepRenderer16.setSeriesURLGenerator(100, xYURLGenerator18);
        xYStepRenderer16.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot(pieDataset22);
        boolean boolean24 = xYStepRenderer16.hasListener((java.util.EventListener) ringPlot23);
        java.awt.Color color26 = java.awt.Color.lightGray;
        xYStepRenderer16.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color26);
        org.jfree.chart.text.TextMeasurer textMeasurer29 = null;
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color26, (float) 100L, textMeasurer29);
        xYStepRenderer4.setSeriesItemLabelFont(7, font15, false);
        try {
            xYStepRenderer0.setLegendTextFont((int) (short) -1, font15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(textBlock30);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets1.createInsetRectangle(rectangle2D3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        xYAreaRenderer0.setOutline(true);
        java.awt.Font font7 = xYAreaRenderer0.lookupLegendTextFont(3);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double[] doubleArray5 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray22 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset23, true);
        try {
            org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset23, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        org.jfree.chart.JFreeChart jFreeChart2 = axisChangeEvent1.getChart();
        org.junit.Assert.assertNull(jFreeChart2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        try {
            barRenderer3D0.setLegendItemLabelGenerator(categorySeriesLabelGenerator1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint2 = ringPlot0.getBackgroundPaint();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.String str7 = standardPieSectionLabelGenerator4.generateSectionLabel(pieDataset5, (java.lang.Comparable) 1);
        ringPlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYStepRenderer9.setSeriesURLGenerator(100, xYURLGenerator11);
        org.jfree.chart.util.LogFormat logFormat20 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean21 = logFormat20.isParseIntegerOnly();
        java.text.ParsePosition parsePosition23 = null;
        java.lang.Object obj24 = logFormat20.parseObject("", parsePosition23);
        int int25 = logFormat20.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat30 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean31 = logFormat30.isParseIntegerOnly();
        java.text.ParsePosition parsePosition33 = null;
        java.lang.Object obj34 = logFormat30.parseObject("", parsePosition33);
        int int35 = logFormat30.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator36 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat20, (java.text.NumberFormat) logFormat30);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer38 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator36, xYURLGenerator37);
        xYStepRenderer9.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator36);
        boolean boolean40 = ringPlot0.equals((java.lang.Object) 2958465);
        ringPlot0.setMinimumArcAngleToDraw((double) 8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity4 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "index.html", "-∞");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=128,g=255,b=255]"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        java.lang.Boolean boolean20 = barRenderer3D0.getSeriesItemLabelsVisible((int) '#');
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        double double24 = ringPlot23.getInnerSeparatorExtension();
        boolean boolean25 = ringPlot23.getIgnoreZeroValues();
        java.awt.Paint paint26 = ringPlot23.getLabelOutlinePaint();
        categoryPlot22.setRangeMinorGridlinePaint(paint26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot22.setRangeAxisLocation(7, axisLocation29, false);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            barRenderer3D0.drawOutline(graphics2D21, categoryPlot22, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        java.util.Date date3 = null;
        try {
            boolean boolean4 = segmentedTimeline0.containsDomainValue(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float float5 = categoryAxis3D0.getTickMarkInsideLength();
        categoryAxis3D0.configure();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list9 = segmentedTimeline8.getExceptionSegments();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        try {
            double double12 = categoryAxis3D0.getCategoryMiddle((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.", list9, rectangle2D10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setIncludeBaseInRange(false);
        try {
            java.lang.String str4 = numberFormat0.format((java.lang.Object) barRenderer3D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        xYSeriesCollection0.validateObject();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        try {
            boolean boolean10 = xYSeriesCollection0.isSelected((int) 'a', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        java.awt.Paint paint3 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) 3);
        java.awt.Paint paint6 = multiplePiePlot1.getAggregatedItemsPaint();
        java.lang.Comparable comparable7 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "Other" + "'", comparable7.equals("Other"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) pieURLGenerator2, jFreeChart4, (int) 'a', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        try {
            xYSeries1.delete(0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        xYStepRenderer0.setSeriesShapesVisible((int) (short) 10, (java.lang.Boolean) false);
        boolean boolean8 = xYStepRenderer0.getBaseShapesFilled();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        logAxis11.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot14.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis17 = combinedDomainXYPlot14.getDomainAxis(3);
        combinedDomainXYPlot14.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D21 = combinedDomainXYPlot14.getQuadrantOrigin();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D24.setTickLabelsVisible(true);
        boolean boolean27 = logAxis23.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer28 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape30 = xYAreaRenderer28.lookupSeriesShape((int) (short) -1);
        logAxis23.setDownArrow(shape30);
        logAxis23.configure();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            xYStepRenderer0.fillDomainGridBand(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot14, (org.jfree.chart.axis.ValueAxis) logAxis23, rectangle2D33, (double) (byte) 10, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0f, jFreeChart1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYSeries1.equals((java.lang.Object) xYStepRenderer8);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer8.setSeriesItemLabelFont(8, font11, true);
        java.util.Collection collection14 = xYStepRenderer8.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreNullValues();
        java.lang.Object obj3 = ringPlot1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        try {
            double double6 = polarPlot4.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot3 = categoryAxis3D2.getPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color5);
        org.jfree.chart.text.TextMeasurer textMeasurer8 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("-∞", font1, (java.awt.Paint) color5, 0.0f, textMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = axisSpace0.reserved(rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        combinedDomainXYPlot4.select(generalPath5, rectangle2D6, renderingSource7);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            combinedDomainXYPlot4.addAnnotation(xYAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        try {
            java.lang.Number number4 = timeSeriesCollection1.getY(10, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        boolean boolean10 = xYStepRenderer2.hasListener((java.util.EventListener) ringPlot9);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color12);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color12, (float) 100L, textMeasurer15);
        float[] floatArray19 = new float[] { (-1.0f), (short) 0 };
        try {
            float[] floatArray20 = color12.getColorComponents(floatArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("0.58");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        xYStepRenderer0.drawRangeMarker(graphics2D1, xYPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Stroke stroke8 = xYStepRenderer0.lookupSeriesStroke((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) (short) 0);
        double double3 = xYSeriesCollection0.getIntervalWidth();
        xYSeriesCollection0.setIntervalPositionFactor(0.0d);
        try {
            double double8 = xYSeriesCollection0.getStartYValue(5, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis3D1.draw(graphics2D2, 8.0d, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        double double4 = logAxis2.calculateValue((double) 8);
        boolean boolean5 = pieLabelLinkStyle0.equals((java.lang.Object) logAxis2);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYStepRenderer6.setSeriesURLGenerator(100, xYURLGenerator8);
        xYStepRenderer6.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer6.setUseFillPaint(false);
        xYStepRenderer6.setUseOutlinePaint(true);
        java.awt.Stroke stroke18 = xYStepRenderer6.getSeriesStroke(0);
        boolean boolean19 = logAxis2.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E8d + "'", double4 == 1.0E8d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("item");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieToolTipGenerator1.generateToolTip(pieDataset2, (java.lang.Comparable) 7);
        java.lang.String str5 = standardPieToolTipGenerator1.getLabelFormat();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "item" + "'", str5.equals("item"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 900000L, "hi!", textAnchor2, textAnchor3, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = xYStepRenderer0.lookupLegendTextFont(0);
        xYStepRenderer0.setDefaultEntityRadius(100);
        boolean boolean5 = xYStepRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        java.text.ParsePosition parsePosition6 = null;
        java.lang.Number number7 = logFormat4.parse("HorizontalAlignment.CENTER", parsePosition6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date1 = null;
        try {
            segmentedTimeline0.addException(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float float5 = categoryAxis3D0.getTickMarkInsideLength();
        categoryAxis3D0.configure();
        categoryAxis3D0.setLowerMargin((double) 2958465);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) (short) 0);
        try {
            java.lang.Number number5 = xYSeriesCollection0.getY((int) '#', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        java.lang.String str6 = rectangleInsets5.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.String str3 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str2.equals("org.jfree.data.UnknownKeyException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str3.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("0.58", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int3 = java.awt.Color.HSBtoRGB((float) 0L, 0.0f, (float) 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-5) + "'", int3 == (-5));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) (short) 0);
        double double4 = xYSeriesCollection0.getRangeUpperBound(false);
        try {
            double double7 = xYSeriesCollection0.getStartXValue((int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.clearSeriesPaints(true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D0.getCategoryStart(3, (int) (byte) 10, rectangle2D4, rectangleEdge5);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) ' ');
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalWidth();
        java.lang.Object obj2 = xYSeriesCollection0.clone();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            double double6 = xYSeriesCollection0.getStartXValue((int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        boolean boolean2 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        ringPlot1.setInnerSeparatorExtension(0.0d);
        boolean boolean6 = ringPlot1.getSimpleLabels();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            ringPlot1.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer3D8.setBaseToolTipGenerator(categoryToolTipGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer20 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer20.setSeriesOutlinePaint((int) (byte) 10, paint22, false);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D8.drawRangeLine(graphics2D11, categoryPlot12, (org.jfree.chart.axis.ValueAxis) logAxis14, rectangle2D18, (double) (short) 0, paint22, stroke25);
        boolean boolean27 = logAxis14.isAxisLineVisible();
        java.awt.Paint paint28 = logAxis14.getAxisLinePaint();
        try {
            combinedDomainXYPlot4.setDomainAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) logAxis14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        categoryAxis3D0.setMinorTickMarkInsideLength((float) (byte) -1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("0.58", graphics2D1, (double) '4', (float) ' ', (float) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getMaximumCategoryLabelLines();
        float float2 = categoryAxis3D0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        crosshairState0.setDatasetIndex((int) (short) 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            barRenderer3D0.drawDomainGridline(graphics2D4, categoryPlot5, rectangle2D6, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("ERROR : Relative To String");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 5.0d, 0.0d, 2, (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer0.setUseFillPaint(false);
        xYStepRenderer0.setUseOutlinePaint(true);
        java.awt.Stroke stroke12 = xYStepRenderer0.getSeriesStroke(0);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYStepRenderer0.setBaseItemLabelFont(font13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        logAxis17.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis23 = combinedDomainXYPlot20.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker24 = null;
        boolean boolean25 = combinedDomainXYPlot20.removeDomainMarker(marker24);
        java.awt.Stroke stroke26 = combinedDomainXYPlot20.getDomainGridlineStroke();
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D29.setTickLabelsVisible(true);
        boolean boolean32 = logAxis28.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer33 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape35 = xYAreaRenderer33.lookupSeriesShape((int) (short) -1);
        logAxis28.setDownArrow(shape35);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            xYStepRenderer0.fillRangeGridBand(graphics2D15, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot20, (org.jfree.chart.axis.ValueAxis) logAxis28, rectangle2D37, (double) (short) -1, (double) 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 0, (-5));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape3 = legendItem2.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis6, polarItemRenderer7);
        xYSeriesCollection4.validateObject();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        legendItem2.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection4);
        xYSeriesCollection4.setIntervalPositionFactor(0.0d);
        try {
            java.lang.String str17 = standardXYToolTipGenerator0.generateToolTip((org.jfree.data.xy.XYDataset) xYSeriesCollection4, 12, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        java.lang.String str4 = ringPlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, (int) (short) 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreNullValues();
        ringPlot1.clearSectionOutlineStrokes(true);
        boolean boolean5 = ringPlot1.getSectionOutlinesVisible();
        double double6 = ringPlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-5d + "'", double6 == 1.0E-5d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        java.lang.Boolean boolean20 = barRenderer3D0.getSeriesItemLabelsVisible((int) '#');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        try {
            barRenderer3D0.addAnnotation(categoryAnnotation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(boolean20);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        int int1 = crosshairState0.getDatasetIndex();
        int int2 = crosshairState0.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        logAxis9.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot12.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis15 = combinedDomainXYPlot12.getDomainAxis(3);
        combinedDomainXYPlot12.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D19 = combinedDomainXYPlot12.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            combinedDomainXYPlot4.draw(graphics2D6, rectangle2D7, point2D19, plotState20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(point2D19);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint1 = categoryAxis3D0.getTickLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list4 = categoryPlot3.getAnnotations();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double7 = categoryAxis3D0.getCategoryMiddle((java.lang.Comparable) 15, list4, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        int int2 = timeSeriesCollection1.getSeriesCount();
        try {
            boolean boolean5 = timeSeriesCollection1.isSelected((int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (32).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("ChartChangeEventType.NEW_DATASET", regularTimePeriod1, regularTimePeriod2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.String[] strArray1 = null;
        try {
            org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("", strArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        boolean boolean10 = logAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        xYSeries1.removePropertyChangeListener(propertyChangeListener8);
        double double10 = xYSeries1.getMaxX();
        java.lang.Number number11 = null;
        try {
            xYSeries1.add(number11, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'x' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        ringPlot7.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        ringPlot7.handleClick(1, (int) 'a', plotRenderingInfo13);
        org.jfree.chart.util.Rotation rotation15 = null;
        try {
            ringPlot7.setDirection(rotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        xYSeries1.add(xYDataItem4, false);
        xYSeries1.add((java.lang.Number) 8, (java.lang.Number) (byte) 0, true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Color color7 = java.awt.Color.orange;
        try {
            combinedDomainXYPlot4.setQuadrantPaint((int) (byte) 10, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean3 = xYAreaRenderer0.getItemVisible((int) (byte) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean5 = logFormat4.isParseIntegerOnly();
        java.text.ParsePosition parsePosition7 = null;
        java.lang.Object obj8 = logFormat4.parseObject("", parsePosition7);
        java.lang.Object obj9 = null;
        boolean boolean10 = logFormat4.equals(obj9);
        logFormat4.setParseIntegerOnly(true);
        logFormat4.setGroupingUsed(true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot4.removeDomainMarker(marker8);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            combinedDomainXYPlot4.addDomainMarker((int) (byte) -1, marker11, layer12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        java.util.Currency currency1 = null;
        try {
            numberFormat0.setCurrency(currency1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) 100);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 10L);
        logAxis1.setRange(range6, true, false);
        boolean boolean14 = range6.intersects((double) (short) -1, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        xYStepRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator(3, xYItemLabelGenerator10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        try {
            boolean boolean2 = categoryPlot0.removeRangeMarker(marker1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = labelBlock11.getTextAnchor();
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font14);
        labelBlock11.setFont(font14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        boolean boolean4 = barRenderer3D0.getShadowsVisible();
        java.awt.Stroke stroke8 = barRenderer3D0.getItemStroke((int) (short) -1, 0, false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getInnerSeparatorExtension();
        boolean boolean6 = ringPlot4.getIgnoreZeroValues();
        java.awt.Paint paint7 = ringPlot4.getLabelOutlinePaint();
        categoryPlot3.setRangeMinorGridlinePaint(paint7);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot3.removeDomainMarker(0, marker10, layer11);
        double[] doubleArray18 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray22 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray26 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray30 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray34 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray35 = new double[][] { doubleArray18, doubleArray22, doubleArray26, doubleArray30, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray35);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset36, true);
        int int39 = categoryPlot3.indexOf(categoryDataset36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot41 = categoryAxis3D40.getPlot();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D40.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color43);
        float float45 = categoryAxis3D40.getTickMarkInsideLength();
        categoryAxis3D40.configure();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle48.setMargin(rectangleInsets49);
        textTitle48.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = textTitle48.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = textTitle48.getPosition();
        try {
            double double55 = barRenderer3D0.getItemMiddle((java.lang.Comparable) 10, (java.lang.Comparable) (-1.0f), categoryDataset36, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, rectangle2D47, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        try {
            combinedDomainXYPlot4.rendererChanged(rendererChangeEvent5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double[] doubleArray5 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray22 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset23);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape3 = xYAreaRenderer1.lookupSeriesShape((int) (short) -1);
        boolean boolean4 = dateTickUnitType0.equals((java.lang.Object) (short) -1);
        int int5 = dateTickUnitType0.getCalendarField();
        java.lang.String str6 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DateTickUnitType.MINUTE" + "'", str6.equals("DateTickUnitType.MINUTE"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState1.setMax(0.0d);
        axisState1.cursorDown(1.0E8d);
        axisState1.cursorRight((double) (-1L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0d, (java.lang.Object) textAnchor7);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RangeType.FULL", graphics2D1, (float) 7, (float) (byte) 100, textAnchor4, Double.NaN, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis13 = combinedDomainXYPlot4.getRangeAxisForDataset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 35 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0d, (java.lang.Object) textAnchor5);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("0.58", graphics2D1, (float) 2958465, (float) ' ', textAnchor5, (double) (byte) 1, 0.0f, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        xYItemRendererState9.setProcessVisibleItemsOnly(true);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        xYItemRendererState9.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        try {
            java.lang.Number number17 = timeSeriesCollection13.getStartY((int) '4', 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        boolean boolean19 = logAxis6.isAxisLineVisible();
        java.awt.Paint paint20 = logAxis6.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = logAxis6.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            rectangleInsets21.trim(rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        xYSeriesCollection3.setIntervalPositionFactor(0.0d);
        try {
            java.lang.Number number16 = xYSeriesCollection3.getStartY(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        textTitle0.setBackgroundPaint(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((-1.0d), 0.2d);
        xYDataItem2.setSelected(true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        int int18 = jFreeChart16.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            jFreeChart16.draw(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        try {
            java.lang.Number number18 = timeSeriesCollection13.getY(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float float5 = categoryAxis3D0.getTickMarkInsideLength();
        double double6 = categoryAxis3D0.getLowerMargin();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        java.awt.Stroke stroke20 = barRenderer3D0.getSeriesOutlineStroke((int) (short) -1);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Stroke stroke27 = null;
        try {
            barRenderer3D0.drawRangeLine(graphics2D21, categoryPlot22, valueAxis23, rectangle2D24, (double) 1L, (java.awt.Paint) color26, stroke27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D0.getCategoryStart(3, (int) (byte) 10, rectangle2D4, rectangleEdge5);
        categoryAxis3D0.setLabelToolTip("index.html");
        boolean boolean9 = categoryAxis3D0.isTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace13.add((double) 1, rectangleEdge15);
        try {
            double double17 = categoryAxis3D0.getCategoryEnd((int) (short) 10, 10, rectangle2D12, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100);
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 10L);
        double double5 = range2.getLowerBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        java.util.List list3 = categoryPlot0.getCategories();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYStepRenderer0.getBaseToolTipGenerator();
        java.lang.Object obj13 = xYStepRenderer0.clone();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint17 = xYAreaRenderer15.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = xYAreaRenderer15.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = xYAreaRenderer15.initialise(graphics2D19, rectangle2D20, xYPlot21, xYDataset22, plotRenderingInfo23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYAreaRenderer15.getBasePositiveItemLabelPosition();
        xYStepRenderer0.setSeriesPositiveItemLabelPosition(2, itemLabelPosition25);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator27 = null;
        xYStepRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator27);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(xYToolTipGenerator18);
        org.junit.Assert.assertNotNull(xYItemRendererState24);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float float5 = categoryAxis3D0.getTickMarkInsideLength();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 10.0f, font7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace12.add((double) 1, rectangleEdge14);
        try {
            double double16 = categoryAxis3D0.getCategoryEnd(4, (-1), rectangle2D11, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean7 = logFormat6.isParseIntegerOnly();
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Object obj10 = logFormat6.parseObject("", parsePosition9);
        int int11 = logFormat6.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean17 = logFormat16.isParseIntegerOnly();
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat16.parseObject("", parsePosition19);
        int int21 = logFormat16.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat16);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator22, xYURLGenerator23);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = xYAreaRenderer24.getGradientTransformer();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer25);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("");
        logAxis8.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis8);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer14.setSeriesOutlinePaint((int) (byte) 10, paint16, false);
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D2.drawRangeLine(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) logAxis8, rectangle2D12, (double) (short) 0, paint16, stroke19);
        boolean boolean21 = logAxis8.isAxisLineVisible();
        java.awt.Paint paint22 = logAxis8.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = logAxis8.getTickLabelInsets();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape26 = legendItem25.getLine();
        logAxis8.setUpArrow(shape26);
        multiplePiePlot1.setLegendItemShape(shape26);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot0.getDrawingSupplier();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        ringPlot0.datasetChanged(datasetChangeEvent6);
        ringPlot0.setCircular(false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = null;
        try {
            ringPlot0.setLabelDistributor(abstractPieLabelDistributor10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer3D0.getBaseURLGenerator();
        java.awt.Font font5 = barRenderer3D0.getLegendTextFont(9999);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot9.getRenderer((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D12.setTickLabelsVisible(true);
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        logAxis16.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis16);
        logAxis16.setLowerMargin(0.05d);
        double[] doubleArray27 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray31 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray35 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray39 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray43 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray44 = new double[][] { doubleArray27, doubleArray31, doubleArray35, doubleArray39, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray44);
        try {
            barRenderer3D0.drawItem(graphics2D6, categoryItemRendererState7, rectangle2D8, categoryPlot9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D12, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryDataset45, (int) ' ', 0, true, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = timeSeries1.equals((java.lang.Object) textBlockAnchor2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            timeSeries1.add(regularTimePeriod4, (double) 5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) (short) 0, (int) (short) 0, false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D9.setTickLabelsVisible(true);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            barRenderer3D0.drawDomainMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9, categoryMarker12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        java.awt.RenderingHints renderingHints18 = null;
        try {
            jFreeChart16.setRenderingHints(renderingHints18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        try {
            java.lang.Number number17 = intervalXYDelegate14.getStartX(100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalWidth();
        try {
            java.lang.Number number4 = xYSeriesCollection0.getX((int) 'a', (-5));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot4.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        double double11 = logAxis9.calculateValue((double) 8);
        boolean boolean12 = pieLabelLinkStyle7.equals((java.lang.Object) logAxis9);
        combinedDomainXYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis9);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        try {
            boolean boolean16 = combinedDomainXYPlot4.removeAnnotation(xYAnnotation14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E8d + "'", double11 == 1.0E8d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint1 = categoryAxis3D0.getTickLabelPaint();
        categoryAxis3D0.setMinorTickMarkInsideLength((float) 9999);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = categoryPlot4.getDatasetRenderingOrder();
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        double double9 = logAxis7.calculateValue((double) 8);
        logAxis7.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot12.setRangeMinorGridlinePaint(paint13);
        logAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            barRenderer3D0.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis7, marker16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E8d + "'", double9 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer1.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState10 = xYAreaRenderer1.initialise(graphics2D5, rectangle2D6, xYPlot7, xYDataset8, plotRenderingInfo9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer1.getBasePositiveItemLabelPosition();
        boolean boolean12 = itemLabelAnchor0.equals((java.lang.Object) xYAreaRenderer1);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint16 = xYAreaRenderer14.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = xYAreaRenderer14.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer14.initialise(graphics2D18, rectangle2D19, xYPlot20, xYDataset21, plotRenderingInfo22);
        boolean boolean24 = xYItemRendererState23.getProcessVisibleItemsOnly();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        logAxis27.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = combinedDomainXYPlot30.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis33 = combinedDomainXYPlot30.getDomainAxis(3);
        combinedDomainXYPlot30.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D37 = combinedDomainXYPlot30.getQuadrantOrigin();
        java.lang.Object obj38 = combinedDomainXYPlot30.clone();
        double double39 = combinedDomainXYPlot30.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        logAxis42.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot45 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis42);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = combinedDomainXYPlot45.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection47 = combinedDomainXYPlot45.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace48 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot45.setFixedRangeAxisSpace(axisSpace48);
        org.jfree.chart.axis.ValueAxis valueAxis50 = combinedDomainXYPlot45.getDomainAxis();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection51 = new org.jfree.data.xy.XYSeriesCollection();
        int int53 = xYSeriesCollection51.indexOf((java.lang.Comparable) (short) 0);
        try {
            xYAreaRenderer1.drawItem(graphics2D13, xYItemRendererState23, rectangle2D25, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30, valueAxis40, valueAxis50, (org.jfree.data.xy.XYDataset) xYSeriesCollection51, (int) ' ', (int) '4', true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(xYToolTipGenerator4);
        org.junit.Assert.assertNotNull(xYItemRendererState10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(xYToolTipGenerator17);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(xYItemRenderer31);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(point2D37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer46);
        org.junit.Assert.assertNull(legendItemCollection47);
        org.junit.Assert.assertNotNull(valueAxis50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            timeSeries1.add(regularTimePeriod2, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer16.setSeriesOutlinePaint((int) (byte) 10, paint18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D4.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) logAxis10, rectangle2D14, (double) (short) 0, paint18, stroke21);
        boolean boolean23 = logAxis10.isAxisLineVisible();
        java.awt.Paint paint24 = logAxis10.getAxisLinePaint();
        org.jfree.chart.util.LogFormat logFormat31 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean32 = logFormat31.isParseIntegerOnly();
        java.text.ParsePosition parsePosition34 = null;
        java.lang.Object obj35 = logFormat31.parseObject("", parsePosition34);
        int int36 = logFormat31.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat41 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean42 = logFormat41.isParseIntegerOnly();
        java.text.ParsePosition parsePosition44 = null;
        java.lang.Object obj45 = logFormat41.parseObject("", parsePosition44);
        int int46 = logFormat41.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator47 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat31, (java.text.NumberFormat) logFormat41);
        logFormat31.setParseIntegerOnly(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit50 = new org.jfree.chart.axis.NumberTickUnit(1.0E8d, (java.text.NumberFormat) logFormat31);
        logAxis10.setTickUnit(numberTickUnit50);
        try {
            org.jfree.data.xy.XYDataset xYDataset52 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (byte) 10, 0.0d, (int) '#', (java.lang.Comparable) numberTickUnit50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYStepRenderer7.setSeriesURLGenerator(100, xYURLGenerator9);
        xYStepRenderer7.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = xYStepRenderer7.hasListener((java.util.EventListener) ringPlot14);
        java.awt.Color color17 = java.awt.Color.lightGray;
        xYStepRenderer7.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color17);
        xYStepRenderer1.setBaseOutlinePaint((java.awt.Paint) color17, true);
        java.lang.Class<?> wildcardClass21 = xYStepRenderer1.getClass();
        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (java.lang.Class) wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(inputStream22);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ChartChangeEventType.NEW_DATASET");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ChartChangeEventType.NEW_DATASET, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        combinedDomainXYPlot4.setRangeZeroBaselineVisible(true);
        boolean boolean16 = combinedDomainXYPlot4.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.data.xy.XYDataItem xYDataItem10 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        java.lang.Number number11 = xYDataItem10.getX();
        java.lang.Number number12 = xYDataItem10.getX();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) xYDataItem10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color2, true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot8 = categoryAxis3D7.getPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D7.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color10);
        float float12 = categoryAxis3D7.getTickMarkInsideLength();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            barRenderer3D0.drawDomainMarker(graphics2D5, categoryPlot6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, categoryMarker13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            categoryPlot0.drawBackground(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean6 = polarPlot4.equals((java.lang.Object) 100.0f);
        polarPlot4.clearCornerTextItems();
        polarPlot4.addCornerTextItem("RangeType.FULL");
        boolean boolean10 = polarPlot4.isDomainZoomable();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = combinedDomainXYPlot17.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis20 = combinedDomainXYPlot17.getDomainAxis(3);
        combinedDomainXYPlot17.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D24 = combinedDomainXYPlot17.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            polarPlot4.draw(graphics2D11, rectangle2D12, point2D24, plotState25, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = xYAreaRenderer0.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset6, (int) (byte) 10, (int) (short) 1, (java.lang.Comparable) 'a', "0.58", "HorizontalAlignment.CENTER");
        java.lang.String str13 = pieSectionEntity12.getURLText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "HorizontalAlignment.CENTER" + "'", str13.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.Paint paint5 = null;
        try {
            combinedDomainXYPlot4.setDomainMinorGridlinePaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean2 = domainOrder0.equals((java.lang.Object) textAnchor1);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1, 2, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        boolean boolean10 = xYStepRenderer2.hasListener((java.util.EventListener) ringPlot9);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color12);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color12, (float) 100L, textMeasurer15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = textBlock16.calculateDimensions(graphics2D17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = null;
        try {
            textBlock16.setLineAlignment(horizontalAlignment19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(size2D18);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        org.jfree.data.Range range16 = xYSeriesCollection8.getRangeBounds(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean7 = logFormat6.isParseIntegerOnly();
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Object obj10 = logFormat6.parseObject("", parsePosition9);
        int int11 = logFormat6.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean17 = logFormat16.isParseIntegerOnly();
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat16.parseObject("", parsePosition19);
        int int21 = logFormat16.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat16);
        logFormat6.setParseIntegerOnly(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = new org.jfree.chart.axis.NumberTickUnit(1.0E8d, (java.text.NumberFormat) logFormat6);
        java.math.RoundingMode roundingMode26 = null;
        try {
            logFormat6.setRoundingMode(roundingMode26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom(0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean6 = polarPlot4.equals((java.lang.Object) 100.0f);
        java.awt.Color color7 = java.awt.Color.lightGray;
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color7);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        xYStepRenderer13.setSeriesURLGenerator(100, xYURLGenerator15);
        xYStepRenderer13.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot(pieDataset19);
        boolean boolean21 = xYStepRenderer13.hasListener((java.util.EventListener) ringPlot20);
        java.awt.Color color23 = java.awt.Color.lightGray;
        xYStepRenderer13.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color23);
        org.jfree.chart.text.TextMeasurer textMeasurer26 = null;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, (java.awt.Paint) color23, (float) 100L, textMeasurer26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = textBlock27.calculateDimensions(graphics2D28);
        java.awt.Font font33 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection34 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection34, valueAxis36, polarItemRenderer37);
        boolean boolean40 = polarPlot38.equals((java.lang.Object) 100.0f);
        java.awt.Color color41 = java.awt.Color.lightGray;
        polarPlot38.setAngleGridlinePaint((java.awt.Paint) color41);
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font33, (java.awt.Paint) color41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = labelBlock43.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, (double) 1, (double) (short) 0, rectangleAnchor44);
        try {
            java.awt.Point point46 = polarPlot4.translateValueThetaRadiusToJava2D((double) 1L, 0.05d, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot4.removeDomainMarker(marker8);
        combinedDomainXYPlot4.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            combinedDomainXYPlot4.addRangeMarker((-5), marker12, layer13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYStepRenderer0.getBaseToolTipGenerator();
        java.lang.Object obj13 = xYStepRenderer0.clone();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint17 = xYAreaRenderer15.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = xYAreaRenderer15.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = xYAreaRenderer15.initialise(graphics2D19, rectangle2D20, xYPlot21, xYDataset22, plotRenderingInfo23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYAreaRenderer15.getBasePositiveItemLabelPosition();
        xYStepRenderer0.setSeriesPositiveItemLabelPosition(2, itemLabelPosition25);
        java.awt.Stroke stroke28 = xYStepRenderer0.getSeriesOutlineStroke((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(xYToolTipGenerator18);
        org.junit.Assert.assertNotNull(xYItemRendererState24);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNull(stroke28);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean6 = xYStepRenderer0.getUseFillPaint();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYStepRenderer8.setSeriesURLGenerator(100, xYURLGenerator10);
        xYStepRenderer8.setAutoPopulateSeriesStroke(true);
        boolean boolean14 = xYStepRenderer8.getUseFillPaint();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYStepRenderer8.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, false);
        xYStepRenderer0.setSeriesToolTipGenerator(6, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("item");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            float float4 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        double double4 = logAxis2.calculateValue((double) 8);
        boolean boolean5 = pieLabelLinkStyle0.equals((java.lang.Object) logAxis2);
        java.lang.String str6 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E8d + "'", double4 == 1.0E8d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str6.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("-∞");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Color color2 = java.awt.Color.getColor("", 9999);
        java.awt.Color color3 = color2.darker();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Paint paint6 = null;
        try {
            categoryPlot0.setDomainCrosshairPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = booleanList0.equals((java.lang.Object) (-1.0d));
        booleanList0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot0.getDrawingSupplier();
        boolean boolean6 = ringPlot0.getSimpleLabels();
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean9 = xYSeries8.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries12 = xYSeries8.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        xYSeries8.addChangeListener(seriesChangeListener13);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean16 = xYSeries8.equals((java.lang.Object) xYStepRenderer15);
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer15.setSeriesItemLabelFont(8, font18, true);
        ringPlot0.setLabelFont(font18);
        ringPlot0.clearSectionOutlineStrokes(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(xYSeries12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean6 = polarPlot4.equals((java.lang.Object) 100.0f);
        java.awt.Color color7 = java.awt.Color.lightGray;
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color7);
        java.lang.Object obj9 = polarPlot4.clone();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Color color2 = java.awt.Color.gray;
        boolean boolean3 = datasetRenderingOrder1.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.String str4 = legendItemEntity3.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str4.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) '4', (double) 100);
        java.lang.String str3 = dateRange2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        segmentedTimeline0.addBaseTimelineExclusions((long) 3, (long) (short) 0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer8 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        boolean boolean9 = segmentedTimeline0.equals((java.lang.Object) standardGradientPaintTransformer8);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYStepRenderer5.setSeriesURLGenerator(100, xYURLGenerator7);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        boolean boolean13 = xYStepRenderer5.hasListener((java.util.EventListener) ringPlot12);
        ringPlot12.setCircular(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection16, valueAxis18, polarItemRenderer19);
        boolean boolean22 = polarPlot20.equals((java.lang.Object) 100.0f);
        java.awt.Color color23 = java.awt.Color.lightGray;
        polarPlot20.setAngleGridlinePaint((java.awt.Paint) color23);
        ringPlot12.setLabelOutlinePaint((java.awt.Paint) color23);
        combinedDomainXYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color23);
        java.lang.Object obj27 = combinedDomainXYPlot4.clone();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator34 = null;
        xYStepRenderer32.setSeriesURLGenerator(100, xYURLGenerator34);
        xYStepRenderer32.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot(pieDataset38);
        boolean boolean40 = xYStepRenderer32.hasListener((java.util.EventListener) ringPlot39);
        java.awt.Color color42 = java.awt.Color.lightGray;
        xYStepRenderer32.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color42);
        org.jfree.chart.text.TextMeasurer textMeasurer45 = null;
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("", font31, (java.awt.Paint) color42, (float) 100L, textMeasurer45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.util.Size2D size2D48 = textBlock46.calculateDimensions(graphics2D47);
        java.awt.Font font52 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection53 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection53, valueAxis55, polarItemRenderer56);
        boolean boolean59 = polarPlot57.equals((java.lang.Object) 100.0f);
        java.awt.Color color60 = java.awt.Color.lightGray;
        polarPlot57.setAngleGridlinePaint((java.awt.Paint) color60);
        org.jfree.chart.block.LabelBlock labelBlock62 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font52, (java.awt.Paint) color60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = labelBlock62.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D64 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D48, (double) 1, (double) (short) 0, rectangleAnchor63);
        rectangleInsets29.trim(rectangle2D64);
        org.jfree.chart.axis.LogAxis logAxis67 = new org.jfree.chart.axis.LogAxis("");
        logAxis67.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot70 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis67);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = combinedDomainXYPlot70.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis73 = combinedDomainXYPlot70.getDomainAxis(3);
        combinedDomainXYPlot70.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D77 = combinedDomainXYPlot70.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState78 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        try {
            combinedDomainXYPlot4.draw(graphics2D28, rectangle2D64, point2D77, plotState78, plotRenderingInfo79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(textBlock46);
        org.junit.Assert.assertNotNull(size2D48);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNull(xYItemRenderer71);
        org.junit.Assert.assertNull(valueAxis73);
        org.junit.Assert.assertNotNull(point2D77);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        xYAreaRenderer0.setOutline(true);
        java.awt.Paint paint7 = xYAreaRenderer0.lookupSeriesPaint(100);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        xYStepRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = xYStepRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint10 = xYStepRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = null;
        xYStepRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator11, false);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator9);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (short) -1, "", "LegendItemEntity: seriesKey=null, dataset=null", false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        org.jfree.data.xy.XYDataset xYDataset10 = polarPlot4.getDataset();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYStepRenderer14.setSeriesURLGenerator(100, xYURLGenerator16);
        xYStepRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        boolean boolean22 = xYStepRenderer14.hasListener((java.util.EventListener) ringPlot21);
        java.awt.Color color24 = java.awt.Color.lightGray;
        xYStepRenderer14.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color24);
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, (java.awt.Paint) color24, (float) 100L, textMeasurer27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = textBlock28.calculateDimensions(graphics2D29);
        java.awt.Font font34 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection35 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection35, valueAxis37, polarItemRenderer38);
        boolean boolean41 = polarPlot39.equals((java.lang.Object) 100.0f);
        java.awt.Color color42 = java.awt.Color.lightGray;
        polarPlot39.setAngleGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font34, (java.awt.Paint) color42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = labelBlock44.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) 1, (double) (short) 0, rectangleAnchor45);
        try {
            polarPlot4.drawBackground(graphics2D11, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(xYDataset10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreNullValues();
        ringPlot1.setMinimumArcAngleToDraw(Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("LegendItemEntity: seriesKey=null, dataset=null");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name LegendItemEntity: seriesKey=null, dataset=null, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean6 = logFormat5.isParseIntegerOnly();
        java.text.ParsePosition parsePosition8 = null;
        java.lang.Object obj9 = logFormat5.parseObject("", parsePosition8);
        int int10 = logFormat5.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean16 = logFormat15.isParseIntegerOnly();
        java.text.ParsePosition parsePosition18 = null;
        java.lang.Object obj19 = logFormat15.parseObject("", parsePosition18);
        int int20 = logFormat15.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat15);
        logFormat5.setParseIntegerOnly(false);
        logFormat5.setMinimumFractionDigits((int) '4');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(0, marker7, layer8);
        double[] doubleArray15 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray19 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray23 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray27 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray31 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray32 = new double[][] { doubleArray15, doubleArray19, doubleArray23, doubleArray27, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        int int36 = categoryPlot0.indexOf(categoryDataset33);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        java.lang.Object obj1 = standardXYSeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        java.lang.Object obj12 = combinedDomainXYPlot4.clone();
        combinedDomainXYPlot4.clearAnnotations();
        boolean boolean14 = combinedDomainXYPlot4.isDomainMinorGridlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        combinedDomainXYPlot4.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = combinedDomainXYPlot4.getDomainAxisEdge(0);
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        axisSpace19.setBottom((double) (short) -1);
        combinedDomainXYPlot4.setFixedDomainAxisSpace(axisSpace19, true);
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = combinedDomainXYPlot4.removeDomainMarker(4, marker25, layer26);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean6 = logFormat5.isParseIntegerOnly();
        java.text.ParsePosition parsePosition8 = null;
        java.lang.Object obj9 = logFormat5.parseObject("", parsePosition8);
        int int10 = logFormat5.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean16 = logFormat15.isParseIntegerOnly();
        java.text.ParsePosition parsePosition18 = null;
        java.lang.Object obj19 = logFormat15.parseObject("", parsePosition18);
        int int20 = logFormat15.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat15);
        logFormat5.setMaximumIntegerDigits(0);
        org.jfree.data.xy.XYSeries xYSeries25 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean26 = xYSeries25.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries29 = xYSeries25.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        xYSeries25.addChangeListener(seriesChangeListener30);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean33 = xYSeries25.equals((java.lang.Object) xYStepRenderer32);
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer32.setSeriesItemLabelFont(8, font35, true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer39 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = null;
        xYStepRenderer39.setSeriesURLGenerator(100, xYURLGenerator41);
        xYStepRenderer39.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = xYStepRenderer39.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator48 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer39.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator48, true);
        xYStepRenderer32.setSeriesURLGenerator((int) (byte) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator48, false);
        java.lang.StringBuffer stringBuffer53 = null;
        java.text.FieldPosition fieldPosition54 = null;
        try {
            java.lang.StringBuffer stringBuffer55 = logFormat5.format((java.lang.Object) standardXYURLGenerator48, stringBuffer53, fieldPosition54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(xYSeries29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection9, valueAxis11, polarItemRenderer12);
        boolean boolean15 = polarPlot13.equals((java.lang.Object) 100.0f);
        java.awt.Color color16 = java.awt.Color.lightGray;
        polarPlot13.setAngleGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font8, (java.awt.Paint) color16);
        java.awt.Color color20 = java.awt.Color.green;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape25 = legendItem24.getLine();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color27 = java.awt.Color.gray;
        try {
            org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "org.jfree.data.UnknownKeyException: hi!", "RangeType.FULL", false, shape5, true, (java.awt.Paint) color16, true, (java.awt.Paint) color20, stroke21, true, shape25, stroke26, (java.awt.Paint) color27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(7, axisLocation7, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        try {
            categoryPlot0.zoom(1.0E8d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        logAxis1.setLowerMargin(0.05d);
        boolean boolean7 = logAxis1.isInverted();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = logAxis1.exponentLengthToJava2D((double) 5, rectangle2D9, rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        legendItem1.setLineVisible(true);
        boolean boolean5 = legendItem1.isShapeVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color2, true);
        boolean boolean5 = barRenderer3D0.isDrawBarOutline();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer3D0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        jFreeChart16.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer20 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = null;
        xYStepRenderer20.setSeriesURLGenerator(100, xYURLGenerator22);
        xYStepRenderer20.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot(pieDataset26);
        boolean boolean28 = xYStepRenderer20.hasListener((java.util.EventListener) ringPlot27);
        java.awt.Paint paint29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer20.setBaseItemLabelPaint(paint29, false);
        try {
            jFreeChart16.setTextAntiAlias((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: false incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        boolean boolean6 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str4 = legendItem3.getURLText();
        java.awt.Paint paint5 = legendItem3.getLabelPaint();
        boolean boolean6 = standardXYURLGenerator1.equals((java.lang.Object) legendItem3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = legendItem3.getFillPaintTransformer();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        java.lang.Object obj12 = combinedDomainXYPlot4.clone();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        combinedDomainXYPlot4.setRangeAxis((int) ' ', valueAxis14);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        try {
            boolean boolean17 = combinedDomainXYPlot4.removeAnnotation(xYAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        boolean boolean6 = logAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        xYSeries5.setMaximumItemCount(0);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries5.remove((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYStepRenderer3.setSeriesURLGenerator(100, xYURLGenerator5);
        xYStepRenderer3.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        boolean boolean11 = xYStepRenderer3.hasListener((java.util.EventListener) ringPlot10);
        java.awt.Color color13 = java.awt.Color.lightGray;
        xYStepRenderer3.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color13);
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color13, (float) 100L, textMeasurer16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock17.calculateDimensions(graphics2D18);
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection24, valueAxis26, polarItemRenderer27);
        boolean boolean30 = polarPlot28.equals((java.lang.Object) 100.0f);
        java.awt.Color color31 = java.awt.Color.lightGray;
        polarPlot28.setAngleGridlinePaint((java.awt.Paint) color31);
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font23, (java.awt.Paint) color31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = labelBlock33.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) 1, (double) (short) 0, rectangleAnchor34);
        rectangleInsets0.trim(rectangle2D35);
        org.jfree.chart.util.UnitType unitType37 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(unitType37);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle0.draw(graphics2D11, rectangle2D12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getHeightConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint15.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D18 = textTitle0.arrange(graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("DateTickUnitType.MINUTE", graphics2D1, 1.0f, (-1.0f), (double) (byte) 10, (-1.0f), (float) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.plot.Plot plot3 = ringPlot0.getParent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        combinedDomainXYPlot4.setRangeZeroBaselineVisible(true);
        java.awt.Paint paint16 = null;
        try {
            combinedDomainXYPlot4.setRangeGridlinePaint(paint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot4.getDomainMarkers(layer12);
        combinedDomainXYPlot4.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace15.add((double) 1, rectangleEdge17);
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace15);
        java.awt.Paint paint20 = combinedDomainXYPlot4.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine0.calculateDimensions(graphics2D3);
        java.lang.Object obj5 = size2D4.clone();
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean2 = xYStepRenderer0.getSeriesLinesVisible((int) (byte) 0);
        java.awt.Paint paint4 = xYStepRenderer0.getLegendTextPaint(12);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        boolean boolean3 = numberAxis3D1.getAutoRangeIncludesZero();
        boolean boolean4 = numberAxis3D1.getAutoRangeIncludesZero();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        xYSeriesCollection3.setIntervalWidth((double) 2.0f);
        try {
            int int19 = xYSeriesCollection3.getItemCount((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer1.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState10 = xYAreaRenderer1.initialise(graphics2D5, rectangle2D6, xYPlot7, xYDataset8, plotRenderingInfo9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer1.getBasePositiveItemLabelPosition();
        boolean boolean12 = itemLabelAnchor0.equals((java.lang.Object) xYAreaRenderer1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = null;
        xYAreaRenderer1.setSeriesItemLabelGenerator(0, xYItemLabelGenerator14, false);
        java.util.Collection collection17 = xYAreaRenderer1.getAnnotations();
        java.util.Collection collection18 = org.jfree.chart.util.ObjectUtilities.deepClone(collection17);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(xYToolTipGenerator4);
        org.junit.Assert.assertNotNull(xYItemRendererState10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer3D0.setSeriesURLGenerator(6, categoryURLGenerator4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = null;
        try {
            jFreeChart16.titleChanged(titleChangeEvent18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        categoryAxis3D0.configure();
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        java.lang.String str1 = dateRange0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis7, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot9.zoomDomainAxes((double) 100.0f, plotRenderingInfo12, point2D13);
        java.awt.Stroke stroke15 = polarPlot9.getRadiusGridlineStroke();
        barRenderer3D0.setSeriesOutlineStroke((int) 'a', stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer3D0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(itemLabelPosition17);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean22 = logFormat21.isParseIntegerOnly();
        java.text.ParsePosition parsePosition24 = null;
        java.lang.Object obj25 = logFormat21.parseObject("", parsePosition24);
        int int26 = logFormat21.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator27 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat11, (java.text.NumberFormat) logFormat21);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27, xYURLGenerator28);
        xYStepRenderer0.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27);
        java.lang.Boolean boolean32 = xYStepRenderer0.getSeriesShapesFilled((int) (short) 10);
        xYStepRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, true);
        java.awt.Font font37 = xYStepRenderer0.getBaseLegendTextFont();
        double double38 = xYStepRenderer0.getStepPoint();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertNull(font37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer0.setUseFillPaint(false);
        xYStepRenderer0.setUseOutlinePaint(true);
        java.awt.Stroke stroke12 = xYStepRenderer0.getSeriesStroke(0);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYStepRenderer0.setBaseItemLabelFont(font13);
        java.lang.Object obj15 = xYStepRenderer0.clone();
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3D6.setBaseToolTipGenerator(categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        logAxis12.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer18.setSeriesOutlinePaint((int) (byte) 10, paint20, false);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D6.drawRangeLine(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D16, (double) (short) 0, paint20, stroke23);
        combinedDomainXYPlot4.setRangeZeroBaselineStroke(stroke23);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint28 = xYAreaRenderer26.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = xYAreaRenderer26.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = xYAreaRenderer26.initialise(graphics2D30, rectangle2D31, xYPlot32, xYDataset33, plotRenderingInfo34);
        xYItemRendererState35.setProcessVisibleItemsOnly(true);
        org.jfree.data.time.TimeSeries timeSeries38 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeSeries38);
        xYItemRendererState35.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection39);
        combinedDomainXYPlot4.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        java.util.List list42 = null;
        try {
            org.jfree.data.Range range44 = timeSeriesCollection39.getDomainBounds(list42, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNull(xYToolTipGenerator29);
        org.junit.Assert.assertNotNull(xYItemRendererState35);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 5.0d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        polarPlot4.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        polarPlot4.setRenderer(polarItemRenderer9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot4.getAxis();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        java.awt.Stroke stroke8 = combinedDomainXYPlot4.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = ringPlot0.getDrawingSupplier();
        ringPlot0.setAutoPopulateSectionOutlineStroke(true);
        float float5 = ringPlot0.getBackgroundImageAlpha();
        java.lang.Object obj6 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color2, true);
        boolean boolean6 = barRenderer3D0.isSeriesVisibleInLegend(0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        boolean boolean3 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        xYStepRenderer4.setSeriesURLGenerator(100, xYURLGenerator6);
        xYStepRenderer4.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer4.setUseFillPaint(false);
        xYStepRenderer4.setUseOutlinePaint(true);
        java.awt.Stroke stroke16 = xYStepRenderer4.getSeriesStroke(0);
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYStepRenderer4.setBaseItemLabelFont(font17);
        barRenderer3D0.setBaseItemLabelFont(font17);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        xYSeriesCollection0.validateObject();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        ringPlot7.setLegendLabelURLGenerator(pieURLGenerator8);
        ringPlot7.setInnerSeparatorExtension(0.0d);
        boolean boolean12 = ringPlot7.getSimpleLabels();
        java.awt.Paint paint14 = ringPlot7.getSectionOutlinePaint((java.lang.Comparable) (byte) 10);
        boolean boolean15 = xYSeriesCollection0.equals((java.lang.Object) ringPlot7);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str17 = pieLabelLinkStyle16.toString();
        ringPlot7.setLabelLinkStyle(pieLabelLinkStyle16);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str17.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        double double9 = logAxis7.calculateValue((double) 8);
        logAxis7.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot12.setRangeMinorGridlinePaint(paint13);
        logAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        java.lang.Object obj16 = null;
        boolean boolean17 = logAxis7.equals(obj16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        logAxis19.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis19);
        logAxis19.setLowerMargin(0.05d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat27 = numberAxis3D26.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType28 = numberAxis3D26.getRangeType();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { logAxis7, logAxis19, numberAxis3D26 };
        categoryPlot0.setRangeAxes(valueAxisArray29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.SortOrder sortOrder32 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E8d + "'", double9 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rangeType28);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot4.removeDomainMarker(marker8);
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = combinedDomainXYPlot4.getRangeAxisEdge();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        java.lang.Object obj12 = combinedDomainXYPlot4.clone();
        double double13 = combinedDomainXYPlot4.getRangeCrosshairValue();
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        logAxis15.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = combinedDomainXYPlot18.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = combinedDomainXYPlot18.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace21 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot18.setFixedRangeAxisSpace(axisSpace21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = combinedDomainXYPlot18.getDomainAxis();
        java.awt.Font font25 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection26, valueAxis28, polarItemRenderer29);
        boolean boolean32 = polarPlot30.equals((java.lang.Object) 100.0f);
        java.awt.Color color33 = java.awt.Color.lightGray;
        polarPlot30.setAngleGridlinePaint((java.awt.Paint) color33);
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font25, (java.awt.Paint) color33);
        valueAxis23.setTickLabelPaint((java.awt.Paint) color33);
        combinedDomainXYPlot4.setDomainMinorGridlinePaint((java.awt.Paint) color33);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYStepRenderer7.setSeriesURLGenerator(100, xYURLGenerator9);
        xYStepRenderer7.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = xYStepRenderer7.hasListener((java.util.EventListener) ringPlot14);
        java.awt.Color color17 = java.awt.Color.lightGray;
        xYStepRenderer7.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color17);
        xYStepRenderer1.setBaseOutlinePaint((java.awt.Paint) color17, true);
        java.lang.Class<?> wildcardClass21 = xYStepRenderer1.getClass();
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass21);
        java.net.URLClassLoader uRLClassLoader23 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL22, uRLClassLoader23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(uRL22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        try {
            timeSeries6.delete(3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepRenderer0.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9, true);
        org.jfree.chart.util.LogFormat logFormat18 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean19 = logFormat18.isParseIntegerOnly();
        java.text.ParsePosition parsePosition21 = null;
        java.lang.Object obj22 = logFormat18.parseObject("", parsePosition21);
        int int23 = logFormat18.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat28 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean29 = logFormat28.isParseIntegerOnly();
        java.text.ParsePosition parsePosition31 = null;
        java.lang.Object obj32 = logFormat28.parseObject("", parsePosition31);
        int int33 = logFormat28.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator34 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat18, (java.text.NumberFormat) logFormat28);
        xYStepRenderer0.setSeriesToolTipGenerator((int) (short) 10, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator34, false);
        java.awt.Paint paint38 = xYStepRenderer0.lookupSeriesPaint(4);
        xYStepRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setHorizontalAlignment(horizontalAlignment11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot13.setRangeMinorGridlinePaint(paint14);
        textTitle0.setPaint(paint14);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double[] doubleArray5 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray22 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset23, true);
        org.jfree.data.KeyToGroupMap keyToGroupMap26 = null;
        try {
            org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23, keyToGroupMap26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        int int3 = xYSeries1.indexOf((java.lang.Number) 9999);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        boolean boolean4 = barRenderer3D0.getShadowsVisible();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer3D0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str16 = projectInfo15.getName();
        org.jfree.chart.ui.Library[] libraryArray17 = projectInfo15.getOptionalLibraries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) projectInfo15);
        java.util.List list19 = projectInfo15.getContributors();
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean22 = xYSeries21.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries25 = xYSeries21.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        xYSeries21.addChangeListener(seriesChangeListener26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        xYSeries21.removePropertyChangeListener(propertyChangeListener28);
        boolean boolean30 = projectInfo15.equals((java.lang.Object) xYSeries21);
        xYSeriesCollection8.addSeries(xYSeries21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(libraryArray17);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(xYSeries25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        java.awt.Stroke stroke10 = xYStepRenderer0.lookupSeriesStroke((int) '4');
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Font font7 = xYStepRenderer0.getLegendTextFont(7);
        boolean boolean10 = xYStepRenderer0.getItemShapeVisible((int) '4', 5);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator2);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer3D1.getGradientPaintTransformer();
        xYAreaRenderer0.setGradientTransformer(gradientPaintTransformer4);
        org.jfree.chart.LegendItem legendItem8 = xYAreaRenderer0.getLegendItem((int) (short) 0, 8);
        boolean boolean9 = xYAreaRenderer0.getPlotArea();
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        org.jfree.data.xy.XYDataset xYDataset10 = polarPlot4.getDataset();
        java.lang.Object obj11 = polarPlot4.clone();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(xYDataset10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint6 = categoryAxis3D5.getTickLabelPaint();
        java.awt.Stroke stroke7 = null;
        java.awt.Paint paint8 = null;
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "0.19", "0.58", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", shape4, paint6, stroke7, paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = timeSeries1.equals((java.lang.Object) textBlockAnchor2);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        xYItemRendererState9.setProcessVisibleItemsOnly(true);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        xYItemRendererState9.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState15 = xYItemRendererState9.getSelectionState();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState15);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        logAxis7.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer13.setSeriesOutlinePaint((int) (byte) 10, paint15, false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D1.drawRangeLine(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) logAxis7, rectangle2D11, (double) (short) 0, paint15, stroke18);
        boolean boolean20 = logAxis7.isAxisLineVisible();
        boolean boolean21 = borderArrangement0.equals((java.lang.Object) logAxis7);
        org.jfree.chart.block.BlockContainer blockContainer22 = null;
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        double double27 = logAxis25.calculateValue((double) 8);
        org.jfree.data.Range range28 = null;
        org.jfree.data.Range range30 = org.jfree.data.Range.expandToInclude(range28, (double) 100);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range30, (double) 10L);
        logAxis25.setRangeWithMargins(range32, false, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint(range32, (double) (-1.0f));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint37.toFixedHeight((double) 100.0f);
        try {
            org.jfree.chart.util.Size2D size2D40 = borderArrangement0.arrange(blockContainer22, graphics2D23, rectangleConstraint37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0E8d + "'", double27 == 1.0E8d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) 100);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 10L);
        logAxis1.setRange(range6, true, false);
        org.jfree.data.Range range13 = org.jfree.data.Range.scale(range6, (double) 3);
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range13, range14);
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) 100);
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint15.toRangeHeight(range16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        try {
            int int19 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection3, 5, 0.0d, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) (short) 0);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer16.setSeriesOutlinePaint((int) (byte) 10, paint18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D4.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) logAxis10, rectangle2D14, (double) (short) 0, paint18, stroke21);
        boolean boolean23 = logAxis10.isAxisLineVisible();
        java.awt.Paint paint24 = logAxis10.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = logAxis10.getTickLabelInsets();
        logAxis10.configure();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis10);
        logAxis10.setLabelAngle((-1.0d));
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalWidth();
        java.lang.Object obj2 = xYSeriesCollection0.clone();
        double double4 = xYSeriesCollection0.getDomainUpperBound(true);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        crosshairState0.updateCrosshairY((double) 1L, (int) (byte) -1);
        crosshairState0.setCrosshairX(0.12d);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        crosshairState0.updateCrosshairPoint((double) 10L, (double) 5, 0, (int) (short) 0, 0.0d, (double) 3, plotOrientation14);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Other");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat4 = numberAxis3D3.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType5 = numberAxis3D3.getRangeType();
        java.lang.String str6 = rangeType5.toString();
        numberAxis1.setRangeType(rangeType5);
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RangeType.FULL" + "'", str6.equals("RangeType.FULL"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis7, polarItemRenderer8);
        boolean boolean11 = polarPlot9.equals((java.lang.Object) 100.0f);
        polarPlot9.clearCornerTextItems();
        xYStepRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        boolean boolean14 = xYStepRenderer0.getBaseShapesFilled();
        int int15 = xYStepRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYStepRenderer3.drawRangeMarker(graphics2D4, xYPlot5, valueAxis6, marker7, rectangle2D8);
        java.awt.Paint paint11 = xYStepRenderer3.lookupSeriesOutlinePaint(10);
        ringPlot0.setSeparatorPaint(paint11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        segmentedTimeline0.addBaseTimelineExclusions((long) 3, (long) (short) 0);
        java.util.Date date8 = null;
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline0.getSegment(date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalWidth();
        try {
            double double4 = xYSeriesCollection0.getEndXValue((int) '#', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        polarPlot4.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        logAxis13.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedDomainXYPlot16.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis19 = combinedDomainXYPlot16.getDomainAxis(3);
        combinedDomainXYPlot16.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D23 = combinedDomainXYPlot16.getQuadrantOrigin();
        try {
            polarPlot4.zoomRangeAxes((double) (-5), (double) (-5), plotRenderingInfo11, point2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(point2D23);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getInnerSeparatorExtension();
        boolean boolean8 = ringPlot6.getIgnoreZeroValues();
        java.awt.Paint paint9 = ringPlot6.getLabelOutlinePaint();
        double double10 = ringPlot6.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = ringPlot6.getLabelDistributor();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat14 = numberAxis3D13.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D13.setTickUnit(numberTickUnit15, true, false);
        java.awt.Font font20 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font20);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("item");
        textLine21.addFragment(textFragment23);
        java.awt.Paint paint25 = textFragment23.getPaint();
        ringPlot6.setSectionPaint((java.lang.Comparable) numberTickUnit15, paint25);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot28 = categoryAxis3D27.getPlot();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D27.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color30);
        ringPlot0.setSectionPaint((java.lang.Comparable) numberTickUnit15, (java.awt.Paint) color30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14d + "'", double10 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        barRenderer3D0.setShadowYOffset((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = null;
        xYItemRendererState1.workingLine = line2D2;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis6, polarItemRenderer7);
        xYSeriesCollection4.validateObject();
        xYItemRendererState1.endSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection4, 12, 15, (int) 'a', (int) (short) 10, 10);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState16 = new org.jfree.chart.plot.XYCrosshairState();
        xYItemRendererState1.setCrosshairState(xYCrosshairState16);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color10);
        xYStepRenderer0.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = xYStepRenderer0.getSeriesToolTipGenerator(2958465);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYToolTipGenerator14);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis7, polarItemRenderer8);
        boolean boolean11 = polarPlot9.equals((java.lang.Object) 100.0f);
        polarPlot9.clearCornerTextItems();
        xYStepRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        boolean boolean14 = xYStepRenderer0.getBaseShapesFilled();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator15 = null;
        xYStepRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator15, false);
        java.awt.Paint paint19 = xYStepRenderer0.getSeriesItemLabelPaint((-5));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYStepRenderer3.setSeriesURLGenerator(100, xYURLGenerator5);
        xYStepRenderer3.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        boolean boolean11 = xYStepRenderer3.hasListener((java.util.EventListener) ringPlot10);
        java.awt.Color color13 = java.awt.Color.lightGray;
        xYStepRenderer3.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color13);
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color13, (float) 100L, textMeasurer16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock17.calculateDimensions(graphics2D18);
        boolean boolean20 = paintList0.equals((java.lang.Object) size2D19);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYStepRenderer3.setSeriesURLGenerator(100, xYURLGenerator5);
        xYStepRenderer3.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        boolean boolean11 = xYStepRenderer3.hasListener((java.util.EventListener) ringPlot10);
        java.awt.Color color13 = java.awt.Color.lightGray;
        xYStepRenderer3.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color13);
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color13, (float) 100L, textMeasurer16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock17.calculateDimensions(graphics2D18);
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection24, valueAxis26, polarItemRenderer27);
        boolean boolean30 = polarPlot28.equals((java.lang.Object) 100.0f);
        java.awt.Color color31 = java.awt.Color.lightGray;
        polarPlot28.setAngleGridlinePaint((java.awt.Paint) color31);
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font23, (java.awt.Paint) color31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = labelBlock33.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) 1, (double) (short) 0, rectangleAnchor34);
        rectangleInsets0.trim(rectangle2D35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D35, rectangleAnchor37);
        java.lang.String str39 = rectangleAnchor37.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleAnchor.TOP" + "'", str39.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            barRenderer3D0.drawOutline(graphics2D3, categoryPlot4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState21 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState21.cursorUp((double) 8);
        axisState21.cursorLeft((double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle26.setMargin(rectangleInsets27);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot30 = categoryAxis3D29.getPlot();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer36 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = null;
        xYStepRenderer36.setSeriesURLGenerator(100, xYURLGenerator38);
        xYStepRenderer36.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot(pieDataset42);
        boolean boolean44 = xYStepRenderer36.hasListener((java.util.EventListener) ringPlot43);
        java.awt.Color color46 = java.awt.Color.lightGray;
        xYStepRenderer36.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color46);
        org.jfree.chart.text.TextMeasurer textMeasurer49 = null;
        org.jfree.chart.text.TextBlock textBlock50 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, (java.awt.Paint) color46, (float) 100L, textMeasurer49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.util.Size2D size2D52 = textBlock50.calculateDimensions(graphics2D51);
        java.awt.Font font56 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection57 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection57);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection57, valueAxis59, polarItemRenderer60);
        boolean boolean63 = polarPlot61.equals((java.lang.Object) 100.0f);
        java.awt.Color color64 = java.awt.Color.lightGray;
        polarPlot61.setAngleGridlinePaint((java.awt.Paint) color64);
        org.jfree.chart.block.LabelBlock labelBlock66 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font56, (java.awt.Paint) color64);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = labelBlock66.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D68 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) 1, (double) (short) 0, rectangleAnchor67);
        rectangleInsets33.trim(rectangle2D68);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle70.setMargin(rectangleInsets71);
        textTitle70.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = textTitle70.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = textTitle70.getPosition();
        org.jfree.chart.axis.AxisState axisState78 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState78.setMax(0.0d);
        axisState78.cursorDown(1.0E8d);
        categoryAxis3D29.drawTickMarks(graphics2D31, (double) 0L, rectangle2D68, rectangleEdge76, axisState78);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType84 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D86 = rectangleInsets27.createAdjustedRectangle(rectangle2D68, lengthAdjustmentType84, lengthAdjustmentType85);
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = null;
        java.util.List list88 = logAxis6.refreshTicks(graphics2D19, axisState21, rectangle2D68, rectangleEdge87);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(textBlock50);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(lengthAdjustmentType84);
        org.junit.Assert.assertNotNull(lengthAdjustmentType85);
        org.junit.Assert.assertNotNull(rectangle2D86);
        org.junit.Assert.assertNotNull(list88);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        double double9 = logAxis7.calculateValue((double) 8);
        logAxis7.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot12.setRangeMinorGridlinePaint(paint13);
        logAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        java.lang.Object obj16 = null;
        boolean boolean17 = logAxis7.equals(obj16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        logAxis19.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis19);
        logAxis19.setLowerMargin(0.05d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat27 = numberAxis3D26.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType28 = numberAxis3D26.getRangeType();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { logAxis7, logAxis19, numberAxis3D26 };
        categoryPlot0.setRangeAxes(valueAxisArray29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E8d + "'", double9 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rangeType28);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }
}

