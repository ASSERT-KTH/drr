import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        combinedDomainXYPlot4.setRangePannable(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            combinedDomainXYPlot4.handleClick((int) 'a', (int) (byte) -1, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot4.getDomainAxis();
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainCrosshairStroke();
        boolean boolean11 = combinedDomainXYPlot4.isDomainPannable();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = xYItemRendererState9.getInfo();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, valueAxis13, polarItemRenderer14);
        xYSeriesCollection11.validateObject();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = null;
        ringPlot18.setLegendLabelURLGenerator(pieURLGenerator19);
        ringPlot18.setInnerSeparatorExtension(0.0d);
        boolean boolean23 = ringPlot18.getSimpleLabels();
        java.awt.Paint paint25 = ringPlot18.getSectionOutlinePaint((java.lang.Comparable) (byte) 10);
        boolean boolean26 = xYSeriesCollection11.equals((java.lang.Object) ringPlot18);
        xYItemRendererState9.endSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (int) '4', 100, (-5), (int) '4', 6);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertNull(plotRenderingInfo10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("HorizontalAlignment.CENTER");
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState1.cursorUp((double) 8);
        axisState1.cursorLeft(100.0d);
        axisState1.cursorUp((double) 7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color2, true);
        boolean boolean5 = barRenderer3D0.isDrawBarOutline();
        barRenderer3D0.setItemMargin((double) 15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        legendItem1.setLineVisible(true);
        legendItem1.setToolTipText("HorizontalAlignment.CENTER");
        legendItem1.setToolTipText("hi!");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot2.setRangeMinorGridlinePaint(paint3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis7, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot9.zoomDomainAxes((double) 100.0f, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        logAxis16.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = combinedDomainXYPlot19.getRenderer();
        java.awt.Stroke stroke21 = combinedDomainXYPlot19.getDomainMinorGridlineStroke();
        polarPlot9.setRadiusGridlineStroke(stroke21);
        categoryPlot2.setRangeZeroBaselineStroke(stroke21);
        categoryPlot0.setRangeGridlineStroke(stroke21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 2958465, (float) 9999);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) (short) 0);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer16.setSeriesOutlinePaint((int) (byte) 10, paint18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D4.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) logAxis10, rectangle2D14, (double) (short) 0, paint18, stroke21);
        boolean boolean23 = logAxis10.isAxisLineVisible();
        java.awt.Paint paint24 = logAxis10.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = logAxis10.getTickLabelInsets();
        logAxis10.configure();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.lang.Comparable comparable28 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.data.category.CategoryDataset categoryDataset29 = categoryPlot0.getDataset();
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(comparable28);
        org.junit.Assert.assertNull(categoryDataset29);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        double double19 = barRenderer3D0.getMaximumBarWidth();
        barRenderer3D0.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        try {
            java.lang.Number number16 = xYSeriesCollection8.getY(9999, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        xYItemRendererState9.setProcessVisibleItemsOnly(true);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        xYItemRendererState9.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list16 = segmentedTimeline15.getExceptionSegments();
        org.jfree.data.Range range18 = timeSeriesCollection13.getDomainBounds(list16, true);
        try {
            timeSeriesCollection13.setSelected((int) (byte) 100, 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertNotNull(segmentedTimeline15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean6 = polarPlot4.equals((java.lang.Object) 100.0f);
        polarPlot4.clearCornerTextItems();
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        logAxis11.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot14.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis17 = combinedDomainXYPlot14.getDomainAxis(3);
        combinedDomainXYPlot14.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D21 = combinedDomainXYPlot14.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedDomainXYPlot14.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = null;
        combinedDomainXYPlot14.plotChanged(plotChangeEvent24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle27.setMargin(rectangleInsets28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot31 = categoryAxis3D30.getPlot();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer37 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = null;
        xYStepRenderer37.setSeriesURLGenerator(100, xYURLGenerator39);
        xYStepRenderer37.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot(pieDataset43);
        boolean boolean45 = xYStepRenderer37.hasListener((java.util.EventListener) ringPlot44);
        java.awt.Color color47 = java.awt.Color.lightGray;
        xYStepRenderer37.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color47);
        org.jfree.chart.text.TextMeasurer textMeasurer50 = null;
        org.jfree.chart.text.TextBlock textBlock51 = org.jfree.chart.text.TextUtilities.createTextBlock("", font36, (java.awt.Paint) color47, (float) 100L, textMeasurer50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.util.Size2D size2D53 = textBlock51.calculateDimensions(graphics2D52);
        java.awt.Font font57 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection58 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection58);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection58, valueAxis60, polarItemRenderer61);
        boolean boolean64 = polarPlot62.equals((java.lang.Object) 100.0f);
        java.awt.Color color65 = java.awt.Color.lightGray;
        polarPlot62.setAngleGridlinePaint((java.awt.Paint) color65);
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font57, (java.awt.Paint) color65);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = labelBlock67.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D69 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D53, (double) 1, (double) (short) 0, rectangleAnchor68);
        rectangleInsets34.trim(rectangle2D69);
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle71.setMargin(rectangleInsets72);
        textTitle71.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = textTitle71.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = textTitle71.getPosition();
        org.jfree.chart.axis.AxisState axisState79 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState79.setMax(0.0d);
        axisState79.cursorDown(1.0E8d);
        categoryAxis3D30.drawTickMarks(graphics2D32, (double) 0L, rectangle2D69, rectangleEdge77, axisState79);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType86 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets28.createAdjustedRectangle(rectangle2D69, lengthAdjustmentType85, lengthAdjustmentType86);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        combinedDomainXYPlot14.drawAnnotations(graphics2D26, rectangle2D69, plotRenderingInfo88);
        try {
            java.awt.Point point90 = polarPlot4.translateValueThetaRadiusToJava2D(1.0E-8d, 0.0d, rectangle2D69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(plot31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(textBlock51);
        org.junit.Assert.assertNotNull(size2D53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertNotNull(lengthAdjustmentType85);
        org.junit.Assert.assertNotNull(lengthAdjustmentType86);
        org.junit.Assert.assertNotNull(rectangle2D87);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle17.setMargin(rectangleInsets18);
        textTitle17.setVisible(false);
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.block.BlockFrame blockFrame23 = textTitle17.getFrame();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(blockFrame23);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getURLGenerator();
        double double7 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = ringPlot0.getLabelLinkStyle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getLibraries();
        projectInfo0.setLicenceText("Other");
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Other", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Paint paint1 = categoryAxis3D0.getTickLabelPaint();
        float float2 = categoryAxis3D0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        double double9 = logAxis7.calculateValue((double) 8);
        logAxis7.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot12.setRangeMinorGridlinePaint(paint13);
        logAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        java.lang.Object obj16 = null;
        boolean boolean17 = logAxis7.equals(obj16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        logAxis19.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis19);
        logAxis19.setLowerMargin(0.05d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat27 = numberAxis3D26.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType28 = numberAxis3D26.getRangeType();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { logAxis7, logAxis19, numberAxis3D26 };
        categoryPlot0.setRangeAxes(valueAxisArray29);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D34 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D34.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color36, true);
        boolean boolean39 = barRenderer3D34.isDrawBarOutline();
        categoryPlot0.setRenderer((int) '4', (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D34, true);
        java.awt.Stroke stroke42 = null;
        try {
            barRenderer3D34.setBaseOutlineStroke(stroke42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E8d + "'", double9 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rangeType28);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.Number number3 = null;
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year2, number3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        xYAreaRenderer0.clearSeriesStrokes(false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean22 = logFormat21.isParseIntegerOnly();
        java.text.ParsePosition parsePosition24 = null;
        java.lang.Object obj25 = logFormat21.parseObject("", parsePosition24);
        int int26 = logFormat21.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator27 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat11, (java.text.NumberFormat) logFormat21);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27, xYURLGenerator28);
        xYStepRenderer0.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        boolean boolean32 = ringPlot31.getIgnoreZeroValues();
        java.awt.Paint paint33 = ringPlot31.getBackgroundPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle34 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        ringPlot31.setLabelLinkStyle(pieLabelLinkStyle34);
        boolean boolean36 = standardXYToolTipGenerator27.equals((java.lang.Object) ringPlot31);
        java.awt.Paint paint38 = ringPlot31.getSectionOutlinePaint((java.lang.Comparable) 1.0E8d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(paint38);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.text.DateFormat dateFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("0.19", dateFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'yFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot0.getDrawingSupplier();
        boolean boolean6 = ringPlot0.getSimpleLabels();
        ringPlot0.setLabelGap(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(0, marker7, layer8);
        categoryPlot0.clearDomainMarkers();
        java.awt.Image image11 = null;
        categoryPlot0.setBackgroundImage(image11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        combinedDomainXYPlot4.setRangePannable(true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = combinedDomainXYPlot4.getDomainAxisForDataset(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 100 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedDomainXYPlot9.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = combinedDomainXYPlot9.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot9.setFixedRangeAxisSpace(axisSpace12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = combinedDomainXYPlot9.getDomainAxis();
        java.awt.Stroke stroke15 = combinedDomainXYPlot9.getDomainCrosshairStroke();
        ringPlot0.setBaseSectionOutlineStroke(stroke15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot4.removeDomainMarker(marker8);
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainGridlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot11 = null;
        try {
            combinedDomainXYPlot4.add(xYPlot11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subplot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str4 = legendItem3.getURLText();
        java.awt.Paint paint5 = legendItem3.getLabelPaint();
        boolean boolean6 = standardXYURLGenerator1.equals((java.lang.Object) legendItem3);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D7.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color9, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer3D7.getLegendItemLabelGenerator();
        boolean boolean13 = standardXYURLGenerator1.equals((java.lang.Object) barRenderer3D7);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot15.setRangeMinorGridlinePaint(paint16);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection18, valueAxis20, polarItemRenderer21);
        boolean boolean23 = polarPlot22.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        polarPlot22.zoomDomainAxes((double) 100.0f, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        logAxis29.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot32 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = combinedDomainXYPlot32.getRenderer();
        java.awt.Stroke stroke34 = combinedDomainXYPlot32.getDomainMinorGridlineStroke();
        polarPlot22.setRadiusGridlineStroke(stroke34);
        categoryPlot15.setRangeZeroBaselineStroke(stroke34);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font39 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator42 = null;
        xYStepRenderer40.setSeriesURLGenerator(100, xYURLGenerator42);
        xYStepRenderer40.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.plot.RingPlot ringPlot47 = new org.jfree.chart.plot.RingPlot(pieDataset46);
        boolean boolean48 = xYStepRenderer40.hasListener((java.util.EventListener) ringPlot47);
        java.awt.Color color50 = java.awt.Color.lightGray;
        xYStepRenderer40.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color50);
        org.jfree.chart.text.TextMeasurer textMeasurer53 = null;
        org.jfree.chart.text.TextBlock textBlock54 = org.jfree.chart.text.TextUtilities.createTextBlock("", font39, (java.awt.Paint) color50, (float) 100L, textMeasurer53);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = textBlock54.calculateDimensions(graphics2D55);
        java.awt.Font font60 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection61 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer64 = null;
        org.jfree.chart.plot.PolarPlot polarPlot65 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection61, valueAxis63, polarItemRenderer64);
        boolean boolean67 = polarPlot65.equals((java.lang.Object) 100.0f);
        java.awt.Color color68 = java.awt.Color.lightGray;
        polarPlot65.setAngleGridlinePaint((java.awt.Paint) color68);
        org.jfree.chart.block.LabelBlock labelBlock70 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font60, (java.awt.Paint) color68);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = labelBlock70.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, (double) 1, (double) (short) 0, rectangleAnchor71);
        rectangleInsets37.trim(rectangle2D72);
        try {
            barRenderer3D7.drawOutline(graphics2D14, categoryPlot15, rectangle2D72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(textBlock54);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState2 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = xYItemRendererState2.getInfo();
        boolean boolean4 = gradientPaintTransformType0.equals((java.lang.Object) plotRenderingInfo3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        xYStepRenderer0.setSeriesShapesVisible((int) (short) 10, (java.lang.Boolean) false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYStepRenderer0.getSeriesToolTipGenerator(8);
        java.awt.Stroke stroke13 = xYStepRenderer0.getItemOutlineStroke((int) (byte) 100, (int) (byte) 10, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        combinedDomainXYPlot4.select(generalPath5, rectangle2D6, renderingSource7);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot4.getRangeAxisForDataset(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 15 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getMaximumCategoryLabelLines();
        boolean boolean2 = categoryAxis3D0.isVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedDomainXYPlot9.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis12 = combinedDomainXYPlot9.getDomainAxis(3);
        combinedDomainXYPlot9.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D16 = combinedDomainXYPlot9.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = combinedDomainXYPlot9.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        combinedDomainXYPlot9.plotChanged(plotChangeEvent19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle22.setMargin(rectangleInsets23);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot26 = categoryAxis3D25.getPlot();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator34 = null;
        xYStepRenderer32.setSeriesURLGenerator(100, xYURLGenerator34);
        xYStepRenderer32.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot(pieDataset38);
        boolean boolean40 = xYStepRenderer32.hasListener((java.util.EventListener) ringPlot39);
        java.awt.Color color42 = java.awt.Color.lightGray;
        xYStepRenderer32.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color42);
        org.jfree.chart.text.TextMeasurer textMeasurer45 = null;
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("", font31, (java.awt.Paint) color42, (float) 100L, textMeasurer45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.util.Size2D size2D48 = textBlock46.calculateDimensions(graphics2D47);
        java.awt.Font font52 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection53 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection53);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer56 = null;
        org.jfree.chart.plot.PolarPlot polarPlot57 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection53, valueAxis55, polarItemRenderer56);
        boolean boolean59 = polarPlot57.equals((java.lang.Object) 100.0f);
        java.awt.Color color60 = java.awt.Color.lightGray;
        polarPlot57.setAngleGridlinePaint((java.awt.Paint) color60);
        org.jfree.chart.block.LabelBlock labelBlock62 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font52, (java.awt.Paint) color60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = labelBlock62.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D64 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D48, (double) 1, (double) (short) 0, rectangleAnchor63);
        rectangleInsets29.trim(rectangle2D64);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle66.setMargin(rectangleInsets67);
        textTitle66.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = textTitle66.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = textTitle66.getPosition();
        org.jfree.chart.axis.AxisState axisState74 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState74.setMax(0.0d);
        axisState74.cursorDown(1.0E8d);
        categoryAxis3D25.drawTickMarks(graphics2D27, (double) 0L, rectangle2D64, rectangleEdge72, axisState74);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType80 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType81 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D82 = rectangleInsets23.createAdjustedRectangle(rectangle2D64, lengthAdjustmentType80, lengthAdjustmentType81);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        combinedDomainXYPlot9.drawAnnotations(graphics2D21, rectangle2D64, plotRenderingInfo83);
        org.jfree.chart.axis.AxisSpace axisSpace85 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace85.add((double) 1, rectangleEdge87);
        try {
            double double89 = categoryAxis3D0.getCategoryMiddle(2958465, (int) (short) 10, rectangle2D64, rectangleEdge87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 2958465");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(textBlock46);
        org.junit.Assert.assertNotNull(size2D48);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(lengthAdjustmentType80);
        org.junit.Assert.assertNotNull(lengthAdjustmentType81);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(rectangleEdge87);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot4.getDomainAxis();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            boolean boolean11 = combinedDomainXYPlot4.removeAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(valueAxis9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        logAxis4.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedDomainXYPlot7.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot7.getDomainAxis(3);
        combinedDomainXYPlot7.setDomainCrosshairValue(0.0d, false);
        combinedDomainXYPlot7.setRangePannable(true);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) categoryPlot0);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 2);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        logAxis5.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot8.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis11 = combinedDomainXYPlot8.getDomainAxis(3);
        combinedDomainXYPlot8.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D15 = combinedDomainXYPlot8.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedDomainXYPlot8.getRenderer(10);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot8);
        combinedDomainXYPlot8.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNull(xYItemRenderer17);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        double[][] doubleArray6 = xYSeries1.toArray();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        xYSeries1.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3D6.setBaseToolTipGenerator(categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        logAxis12.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer18.setSeriesOutlinePaint((int) (byte) 10, paint20, false);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D6.drawRangeLine(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D16, (double) (short) 0, paint20, stroke23);
        combinedDomainXYPlot4.setRangeZeroBaselineStroke(stroke23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedDomainXYPlot4.setDomainAxisLocation((int) (short) 0, axisLocation29);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(7, axisLocation7, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        categoryPlot0.setDomainCrosshairVisible(false);
        java.awt.Paint paint14 = categoryPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYStepRenderer8.setSeriesURLGenerator(100, xYURLGenerator10);
        xYStepRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        boolean boolean16 = xYStepRenderer8.hasListener((java.util.EventListener) ringPlot15);
        java.awt.Color color18 = java.awt.Color.lightGray;
        xYStepRenderer8.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color18);
        xYStepRenderer2.setBaseOutlinePaint((java.awt.Paint) color18, true);
        java.lang.Class<?> wildcardClass22 = xYStepRenderer2.getClass();
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass22);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", (java.lang.Class) wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(uRL23);
        org.junit.Assert.assertNull(uRL24);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (short) 10);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        xYStepRenderer4.setSeriesURLGenerator(100, xYURLGenerator6);
        xYStepRenderer4.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        java.lang.Object obj11 = xYStepRenderer4.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepRenderer4.getSeriesPositiveItemLabelPosition(0);
        xYStepRenderer4.setAutoPopulateSeriesStroke(false);
        java.awt.Stroke stroke17 = xYStepRenderer4.lookupSeriesStroke(15);
        boolean boolean18 = standardPieSectionLabelGenerator1.equals((java.lang.Object) stroke17);
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 3, 0.12d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.lang.Object obj6 = combinedDomainXYPlot4.clone();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = combinedDomainXYPlot4.removeDomainMarker(marker7);
        boolean boolean9 = combinedDomainXYPlot4.isDomainPannable();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle17.setMargin(rectangleInsets18);
        textTitle17.setVisible(false);
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        try {
            jFreeChart16.plotChanged(plotChangeEvent23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Color color1 = java.awt.Color.cyan;
        java.awt.Color color2 = java.awt.Color.getColor("index.html", color1);
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = color2.getRGBColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = booleanList0.equals((java.lang.Object) (-1.0d));
        java.lang.Object obj3 = booleanList0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean2 = xYStepRenderer0.getSeriesLinesVisible((int) (byte) 0);
        xYStepRenderer0.clearSeriesStrokes(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = xYStepRenderer0.getToolTipGenerator(2, 0, true);
        boolean boolean9 = xYStepRenderer0.getBaseCreateEntities();
        boolean boolean11 = xYStepRenderer0.isSeriesItemLabelsVisible((int) (short) 1);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D15.setTickLabelsVisible(true);
        boolean boolean18 = logAxis14.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape21 = xYAreaRenderer19.lookupSeriesShape((int) (short) -1);
        logAxis14.setDownArrow(shape21);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.data.xy.XYDataItem xYDataItem28 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity31 = new org.jfree.chart.entity.PieSectionEntity(shape21, pieDataset23, (int) (short) 0, 0, (java.lang.Comparable) xYDataItem28, "org.jfree.data.UnknownKeyException: hi!", "HorizontalAlignment.CENTER");
        xYStepRenderer0.setLegendShape((int) (byte) 10, shape21);
        java.io.ObjectOutputStream objectOutputStream33 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape21, objectOutputStream33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(xYToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        boolean boolean3 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(2958465, categoryURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        java.awt.Paint paint3 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) 3);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        categoryPlot6.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape8 = xYAreaRenderer6.lookupSeriesShape((int) (short) -1);
        logAxis1.setDownArrow(shape8);
        logAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean17 = logFormat16.isParseIntegerOnly();
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat16.parseObject("", parsePosition19);
        java.lang.Object obj21 = null;
        boolean boolean22 = logFormat16.equals(obj21);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("PieLabelLinkStyle.STANDARD");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        logAxis4.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedDomainXYPlot7.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot7.getDomainAxis(3);
        combinedDomainXYPlot7.configureRangeAxes();
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        xYStepRenderer16.setSeriesURLGenerator(100, xYURLGenerator18);
        xYStepRenderer16.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot(pieDataset22);
        boolean boolean24 = xYStepRenderer16.hasListener((java.util.EventListener) ringPlot23);
        java.awt.Color color26 = java.awt.Color.lightGray;
        xYStepRenderer16.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color26);
        org.jfree.chart.text.TextMeasurer textMeasurer29 = null;
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color26, (float) 100L, textMeasurer29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.util.Size2D size2D32 = textBlock30.calculateDimensions(graphics2D31);
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection37);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer40 = null;
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection37, valueAxis39, polarItemRenderer40);
        boolean boolean43 = polarPlot41.equals((java.lang.Object) 100.0f);
        java.awt.Color color44 = java.awt.Color.lightGray;
        polarPlot41.setAngleGridlinePaint((java.awt.Paint) color44);
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font36, (java.awt.Paint) color44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = labelBlock46.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D48 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, (double) 1, (double) (short) 0, rectangleAnchor47);
        org.jfree.chart.RenderingSource renderingSource49 = null;
        combinedDomainXYPlot7.select((double) 5, (double) 2958465, rectangle2D48, renderingSource49);
        java.awt.geom.Point2D point2D51 = null;
        org.jfree.chart.plot.PlotState plotState52 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        try {
            piePlot3D0.draw(graphics2D2, rectangle2D48, point2D51, plotState52, plotRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (-1), (double) 12);
        long long3 = dateRange2.getUpperMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.Object obj4 = legendItemEntity3.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 0, (double) 0.0f, 0.0d, (double) (short) 100);
        org.jfree.data.RangeType rangeType5 = org.jfree.data.RangeType.NEGATIVE;
        boolean boolean6 = blockBorder4.equals((java.lang.Object) rangeType5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder4.getInsets();
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart16.getLegend();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle17.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle17.getLegendItemGraphicEdge();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendTitle17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.Range range2 = numberAxis3D1.getRange();
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        int int2 = timeSeriesCollection1.getSeriesCount();
        try {
            double double5 = timeSeriesCollection1.getXValue(0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) 100);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 10L);
        logAxis1.setRangeWithMargins(range8, false, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, (double) (-1.0f));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toFixedHeight((double) 100.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint13.getHeightConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        double double9 = logAxis7.calculateValue((double) 8);
        logAxis7.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot12.setRangeMinorGridlinePaint(paint13);
        logAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        java.lang.Object obj16 = null;
        boolean boolean17 = logAxis7.equals(obj16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        logAxis19.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis19);
        logAxis19.setLowerMargin(0.05d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat27 = numberAxis3D26.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType28 = numberAxis3D26.getRangeType();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { logAxis7, logAxis19, numberAxis3D26 };
        categoryPlot0.setRangeAxes(valueAxisArray29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot0.getDomainAxis();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E8d + "'", double9 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rangeType28);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(categoryAxis32);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setHorizontalAlignment(horizontalAlignment11);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYStepRenderer14.setSeriesURLGenerator(100, xYURLGenerator16);
        xYStepRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        boolean boolean22 = xYStepRenderer14.hasListener((java.util.EventListener) ringPlot21);
        ringPlot21.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        ringPlot21.handleClick(1, (int) 'a', plotRenderingInfo27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot21);
        jFreeChart29.clearSubtitles();
        int int31 = jFreeChart29.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection35 = chartRenderingInfo34.getEntityCollection();
        jFreeChart29.handleClick((int) 'a', (int) 'a', chartRenderingInfo34);
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        boolean boolean38 = jFreeChart29.isNotify();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNotNull(entityCollection35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        boolean boolean13 = xYSeriesCollection3.isAutoWidth();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalWidth();
        java.lang.Object obj2 = xYSeriesCollection0.clone();
        double double4 = xYSeriesCollection0.getDomainUpperBound(true);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 9999, jFreeChart1, (int) (byte) 0, 0);
        java.lang.Object obj5 = chartProgressEvent4.getSource();
        org.jfree.chart.JFreeChart jFreeChart6 = chartProgressEvent4.getChart();
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 9999 + "'", obj5.equals(9999));
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) 100);
        segment2.moveIndexToEnd();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean5 = logFormat4.isParseIntegerOnly();
        java.text.ParsePosition parsePosition7 = null;
        java.lang.Object obj8 = logFormat4.parseObject("", parsePosition7);
        java.lang.Object obj9 = null;
        boolean boolean10 = logFormat4.equals(obj9);
        logFormat4.setParseIntegerOnly(true);
        logFormat4.setGroupingUsed(true);
        logFormat4.setMaximumIntegerDigits((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        combinedDomainXYPlot4.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            combinedDomainXYPlot4.addDomainMarker(4, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        xYSeriesCollection0.validateObject();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        textTitle0.setToolTipText("item");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PieLabelLinkStyle.STANDARD", graphics2D1, (float) ' ', 0.0f, textAnchor4, 1.0E8d, (float) (-5), (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        double double15 = intervalXYDelegate14.getIntervalWidth();
        try {
            double double18 = intervalXYDelegate14.getEndXValue(3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle17.setMargin(rectangleInsets18);
        textTitle17.setVisible(false);
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        boolean boolean23 = jFreeChart16.getAntiAlias();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle25.setMargin(rectangleInsets26);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot29 = categoryAxis3D28.getPlot();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font34 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer35 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        xYStepRenderer35.setSeriesURLGenerator(100, xYURLGenerator37);
        xYStepRenderer35.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot(pieDataset41);
        boolean boolean43 = xYStepRenderer35.hasListener((java.util.EventListener) ringPlot42);
        java.awt.Color color45 = java.awt.Color.lightGray;
        xYStepRenderer35.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color45);
        org.jfree.chart.text.TextMeasurer textMeasurer48 = null;
        org.jfree.chart.text.TextBlock textBlock49 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, (java.awt.Paint) color45, (float) 100L, textMeasurer48);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.util.Size2D size2D51 = textBlock49.calculateDimensions(graphics2D50);
        java.awt.Font font55 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection56 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection56);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer59 = null;
        org.jfree.chart.plot.PolarPlot polarPlot60 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection56, valueAxis58, polarItemRenderer59);
        boolean boolean62 = polarPlot60.equals((java.lang.Object) 100.0f);
        java.awt.Color color63 = java.awt.Color.lightGray;
        polarPlot60.setAngleGridlinePaint((java.awt.Paint) color63);
        org.jfree.chart.block.LabelBlock labelBlock65 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font55, (java.awt.Paint) color63);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = labelBlock65.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D67 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D51, (double) 1, (double) (short) 0, rectangleAnchor66);
        rectangleInsets32.trim(rectangle2D67);
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle69.setMargin(rectangleInsets70);
        textTitle69.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = textTitle69.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = textTitle69.getPosition();
        org.jfree.chart.axis.AxisState axisState77 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState77.setMax(0.0d);
        axisState77.cursorDown(1.0E8d);
        categoryAxis3D28.drawTickMarks(graphics2D30, (double) 0L, rectangle2D67, rectangleEdge75, axisState77);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType83 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType84 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D85 = rectangleInsets26.createAdjustedRectangle(rectangle2D67, lengthAdjustmentType83, lengthAdjustmentType84);
        try {
            jFreeChart16.draw(graphics2D24, rectangle2D85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(textBlock49);
        org.junit.Assert.assertNotNull(size2D51);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertNotNull(lengthAdjustmentType83);
        org.junit.Assert.assertNotNull(lengthAdjustmentType84);
        org.junit.Assert.assertNotNull(rectangle2D85);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        xYStepRenderer0.setSeriesShapesVisible((int) (short) 10, (java.lang.Boolean) false);
        boolean boolean8 = xYStepRenderer0.getBaseShapesFilled();
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        xYStepRenderer12.setSeriesURLGenerator(100, xYURLGenerator14);
        xYStepRenderer12.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset18);
        boolean boolean20 = xYStepRenderer12.hasListener((java.util.EventListener) ringPlot19);
        java.awt.Color color22 = java.awt.Color.lightGray;
        xYStepRenderer12.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color22);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color22, (float) 100L, textMeasurer25);
        xYStepRenderer0.setSeriesItemLabelFont(7, font11, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator29 = null;
        xYStepRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator29, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(textBlock26);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray5 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray22 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset23, true);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        try {
            org.jfree.data.general.PieDataset pieDataset28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset23, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot3.setLegendLabelURLGenerator(pieURLGenerator4);
        ringPlot3.setInnerSeparatorExtension(0.0d);
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo0, (java.lang.Object) ringPlot3);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        double double10 = ringPlot9.getInnerSeparatorExtension();
        boolean boolean11 = ringPlot9.getIgnoreZeroValues();
        java.awt.Paint paint12 = ringPlot9.getLabelOutlinePaint();
        double double13 = ringPlot9.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = ringPlot9.getLabelDistributor();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset17 = null;
        java.lang.String str19 = standardPieSectionLabelGenerator16.generateSectionLabel(pieDataset17, (java.lang.Comparable) 1);
        ringPlot9.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        ringPlot3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.14d + "'", double13 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor14);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false, false);
        xYSeries3.clear();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        xYSeries3.removePropertyChangeListener(propertyChangeListener5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        double double15 = intervalXYDelegate14.getIntervalWidth();
        org.jfree.data.Range range17 = intervalXYDelegate14.getDomainBounds(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("item");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer3D0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer3D0.setSeriesToolTipGenerator(12, categoryToolTipGenerator6, false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(itemLabelPosition4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot3.setLegendLabelURLGenerator(pieURLGenerator4);
        ringPlot3.setInnerSeparatorExtension(0.0d);
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo0, (java.lang.Object) ringPlot3);
        java.awt.Paint paint9 = ringPlot3.getLabelShadowPaint();
        ringPlot3.setPieIndex(5);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = ringPlot12.getIgnoreZeroValues();
        boolean boolean14 = ringPlot12.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        ringPlot12.datasetChanged(datasetChangeEvent15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = ringPlot12.getDrawingSupplier();
        ringPlot3.setDrawingSupplier(drawingSupplier17, false);
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(drawingSupplier17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getName();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getOptionalLibraries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) projectInfo0);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent3.getSummary();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNull(seriesChangeInfo4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        int int5 = timeSeries1.getItemCount();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (short) 1, false);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year6.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot4.removeDomainMarker(marker8);
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainGridlineStroke();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        combinedDomainXYPlot4.datasetChanged(datasetChangeEvent11);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        jFreeChart16.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj21 = null;
        boolean boolean22 = textTitle20.equals(obj21);
        jFreeChart16.setTitle(textTitle20);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator0 = new org.jfree.chart.urls.StandardXYURLGenerator();
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        double double3 = crosshairState0.getCrosshairDistance();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float float5 = categoryAxis3D0.getTickMarkInsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot6.getDatasetRenderingOrder();
        boolean boolean8 = categoryAxis3D0.equals((java.lang.Object) datasetRenderingOrder7);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        double double6 = textTitle0.getContentYOffset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        try {
            textTitle0.setVerticalAlignment(verticalAlignment7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        double double6 = textTitle0.getContentYOffset();
        boolean boolean7 = textTitle0.visible;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot8.getRenderer((int) (short) 0);
        categoryPlot8.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D12 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        barRenderer3D12.setBaseToolTipGenerator(categoryToolTipGenerator13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        logAxis18.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis18);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer24 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer24.setSeriesOutlinePaint((int) (byte) 10, paint26, false);
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D12.drawRangeLine(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) logAxis18, rectangle2D22, (double) (short) 0, paint26, stroke29);
        boolean boolean31 = logAxis18.isAxisLineVisible();
        java.awt.Paint paint32 = logAxis18.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = logAxis18.getTickLabelInsets();
        logAxis18.configure();
        categoryPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot38 = categoryAxis3D37.getPlot();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font43 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer44 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator46 = null;
        xYStepRenderer44.setSeriesURLGenerator(100, xYURLGenerator46);
        xYStepRenderer44.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.RingPlot ringPlot51 = new org.jfree.chart.plot.RingPlot(pieDataset50);
        boolean boolean52 = xYStepRenderer44.hasListener((java.util.EventListener) ringPlot51);
        java.awt.Color color54 = java.awt.Color.lightGray;
        xYStepRenderer44.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color54);
        org.jfree.chart.text.TextMeasurer textMeasurer57 = null;
        org.jfree.chart.text.TextBlock textBlock58 = org.jfree.chart.text.TextUtilities.createTextBlock("", font43, (java.awt.Paint) color54, (float) 100L, textMeasurer57);
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.util.Size2D size2D60 = textBlock58.calculateDimensions(graphics2D59);
        java.awt.Font font64 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection65 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range66 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection65);
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer68 = null;
        org.jfree.chart.plot.PolarPlot polarPlot69 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection65, valueAxis67, polarItemRenderer68);
        boolean boolean71 = polarPlot69.equals((java.lang.Object) 100.0f);
        java.awt.Color color72 = java.awt.Color.lightGray;
        polarPlot69.setAngleGridlinePaint((java.awt.Paint) color72);
        org.jfree.chart.block.LabelBlock labelBlock74 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font64, (java.awt.Paint) color72);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = labelBlock74.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D76 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D60, (double) 1, (double) (short) 0, rectangleAnchor75);
        rectangleInsets41.trim(rectangle2D76);
        org.jfree.chart.title.TextTitle textTitle78 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle78.setMargin(rectangleInsets79);
        textTitle78.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = textTitle78.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = textTitle78.getPosition();
        org.jfree.chart.axis.AxisState axisState86 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState86.setMax(0.0d);
        axisState86.cursorDown(1.0E8d);
        categoryAxis3D37.drawTickMarks(graphics2D39, (double) 0L, rectangle2D76, rectangleEdge84, axisState86);
        org.jfree.chart.util.RectangleEdge rectangleEdge92 = null;
        double double93 = logAxis18.java2DToValue((double) 8, rectangle2D76, rectangleEdge92);
        textTitle0.setBounds(rectangle2D76);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(textBlock58);
        org.junit.Assert.assertNotNull(size2D60);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(rectangleInsets79);
        org.junit.Assert.assertNotNull(rectangleInsets83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + Double.POSITIVE_INFINITY + "'", double93 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot4.getDomainMinorGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot4.getRangeAxis(12);
        boolean boolean9 = combinedDomainXYPlot4.isDomainZoomable();
        try {
            java.awt.Paint paint11 = combinedDomainXYPlot4.getQuadrantPaint((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepRenderer0.getSeriesPositiveItemLabelPosition(5);
        double double8 = itemLabelPosition7.getAngle();
        double double9 = itemLabelPosition7.getAngle();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        java.lang.Object obj2 = segmentedTimeline0.clone();
        long long3 = segmentedTimeline0.getSegmentSize();
        long long5 = segmentedTimeline0.toTimelineValue((long) 15);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 900000L + "'", long3 == 900000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 644288400000L + "'", long5 == 644288400000L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = ringPlot0.getLabelDistributor();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = ringPlot0.getSimpleLabelOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        ringPlot1.setInnerSeparatorExtension(0.0d);
        float float6 = ringPlot1.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Shape shape5 = xYAreaRenderer0.getLegendShape((int) ' ');
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        double double9 = logAxis7.calculateValue((double) 8);
        logAxis7.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot12.setRangeMinorGridlinePaint(paint13);
        logAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        java.lang.Object obj16 = null;
        boolean boolean17 = logAxis7.equals(obj16);
        float float18 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape21 = legendItem20.getLine();
        logAxis7.setUpArrow(shape21);
        xYAreaRenderer0.setLegendArea(shape21);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E8d + "'", double9 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        boolean boolean19 = logAxis6.isAxisLineVisible();
        java.awt.Paint paint20 = logAxis6.getAxisLinePaint();
        java.text.NumberFormat numberFormat21 = logAxis6.getNumberFormatOverride();
        java.awt.Paint paint22 = logAxis6.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean6 = xYStepRenderer0.getUseFillPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        int int9 = xYSeriesCollection7.indexOf((java.lang.Comparable) (short) 0);
        double double10 = xYSeriesCollection7.getIntervalWidth();
        org.jfree.data.Range range11 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        try {
            xYSeriesCollection7.setSelected((int) (short) 10, 2958465, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("HorizontalAlignment.CENTER", graphics2D1, 0.0f, (float) 3, 0.0d, (float) 8, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 15, (double) 900000L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreNullValues();
        ringPlot1.clearSectionOutlineStrokes(true);
        boolean boolean5 = ringPlot1.getSectionOutlinesVisible();
        boolean boolean6 = ringPlot1.getSeparatorsVisible();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle7.setMargin(rectangleInsets8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot11 = categoryAxis3D10.getPlot();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        xYStepRenderer17.setSeriesURLGenerator(100, xYURLGenerator19);
        xYStepRenderer17.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot(pieDataset23);
        boolean boolean25 = xYStepRenderer17.hasListener((java.util.EventListener) ringPlot24);
        java.awt.Color color27 = java.awt.Color.lightGray;
        xYStepRenderer17.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color27);
        org.jfree.chart.text.TextMeasurer textMeasurer30 = null;
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("", font16, (java.awt.Paint) color27, (float) 100L, textMeasurer30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.util.Size2D size2D33 = textBlock31.calculateDimensions(graphics2D32);
        java.awt.Font font37 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection38 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection38);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection38, valueAxis40, polarItemRenderer41);
        boolean boolean44 = polarPlot42.equals((java.lang.Object) 100.0f);
        java.awt.Color color45 = java.awt.Color.lightGray;
        polarPlot42.setAngleGridlinePaint((java.awt.Paint) color45);
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font37, (java.awt.Paint) color45);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = labelBlock47.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D49 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D33, (double) 1, (double) (short) 0, rectangleAnchor48);
        rectangleInsets14.trim(rectangle2D49);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle51.setMargin(rectangleInsets52);
        textTitle51.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = textTitle51.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = textTitle51.getPosition();
        org.jfree.chart.axis.AxisState axisState59 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState59.setMax(0.0d);
        axisState59.cursorDown(1.0E8d);
        categoryAxis3D10.drawTickMarks(graphics2D12, (double) 0L, rectangle2D49, rectangleEdge57, axisState59);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets8.createAdjustedRectangle(rectangle2D49, lengthAdjustmentType65, lengthAdjustmentType66);
        ringPlot1.setLabelPadding(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNotNull(size2D33);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(lengthAdjustmentType65);
        org.junit.Assert.assertNotNull(lengthAdjustmentType66);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot0.setURLGenerator(pieURLGenerator2);
        org.jfree.chart.block.Arrangement arrangement4 = null;
        org.jfree.chart.block.Arrangement arrangement5 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0, arrangement4, arrangement5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer3D0.getBaseURLGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getInnerSeparatorExtension();
        boolean boolean8 = ringPlot6.getIgnoreZeroValues();
        java.awt.Paint paint9 = ringPlot6.getLabelOutlinePaint();
        categoryPlot5.setRangeMinorGridlinePaint(paint9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot5.getDomainMarkers((int) (short) -1, layer12);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot5.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot15.getRenderer((int) (short) 0);
        categoryPlot15.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D19 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        barRenderer3D19.setBaseToolTipGenerator(categoryToolTipGenerator20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        logAxis25.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer31 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer31.setSeriesOutlinePaint((int) (byte) 10, paint33, false);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D19.drawRangeLine(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) logAxis25, rectangle2D29, (double) (short) 0, paint33, stroke36);
        boolean boolean38 = logAxis25.isAxisLineVisible();
        java.awt.Paint paint39 = logAxis25.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = logAxis25.getTickLabelInsets();
        logAxis25.configure();
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot15.getRangeAxis();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        barRenderer3D0.drawRangeGridline(graphics2D4, categoryPlot5, valueAxis43, rectangle2D44, 10.0d);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        int int49 = categoryPlot48.getDatasetCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot48.getRenderer(0);
        java.awt.Font font53 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer54 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator56 = null;
        xYStepRenderer54.setSeriesURLGenerator(100, xYURLGenerator56);
        xYStepRenderer54.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset60 = null;
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot(pieDataset60);
        boolean boolean62 = xYStepRenderer54.hasListener((java.util.EventListener) ringPlot61);
        java.awt.Color color64 = java.awt.Color.lightGray;
        xYStepRenderer54.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color64);
        org.jfree.chart.text.TextMeasurer textMeasurer67 = null;
        org.jfree.chart.text.TextBlock textBlock68 = org.jfree.chart.text.TextUtilities.createTextBlock("", font53, (java.awt.Paint) color64, (float) 100L, textMeasurer67);
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.util.Size2D size2D70 = textBlock68.calculateDimensions(graphics2D69);
        java.awt.Font font74 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection75 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range76 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection75);
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer78 = null;
        org.jfree.chart.plot.PolarPlot polarPlot79 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection75, valueAxis77, polarItemRenderer78);
        boolean boolean81 = polarPlot79.equals((java.lang.Object) 100.0f);
        java.awt.Color color82 = java.awt.Color.lightGray;
        polarPlot79.setAngleGridlinePaint((java.awt.Paint) color82);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font74, (java.awt.Paint) color82);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = labelBlock84.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D86 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D70, (double) 1, (double) (short) 0, rectangleAnchor85);
        try {
            barRenderer3D0.drawBackground(graphics2D47, categoryPlot48, rectangle2D86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(valueAxis43);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer51);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(textBlock68);
        org.junit.Assert.assertNotNull(size2D70);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertNull(range76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNotNull(rectangle2D86);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint2 = ringPlot0.getBackgroundPaint();
        ringPlot0.setBackgroundImageAlignment((int) 'a');
        boolean boolean5 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("RangeType.FULL");
        logAxis1.setLowerMargin((double) 12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.String str5 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str5.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        xYAreaRenderer0.setOutline(true);
        java.lang.Boolean boolean7 = xYAreaRenderer0.getSeriesVisibleInLegend(7);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 9999, jFreeChart1, (int) (byte) 0, 0);
        chartProgressEvent4.setType((int) (short) 10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.removeAnnotations();
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 9999, jFreeChart1, (int) (byte) 0, 0);
        int int5 = chartProgressEvent4.getType();
        int int6 = chartProgressEvent4.getPercent();
        chartProgressEvent4.setPercent((-5));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        java.lang.Object obj5 = xYSeriesCollection0.clone();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        org.jfree.data.general.DatasetGroup datasetGroup16 = null;
        try {
            xYSeriesCollection3.setGroup(datasetGroup16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) (short) 0, (int) (short) 0, false);
        double double5 = barRenderer3D0.getShadowYOffset();
        java.awt.Stroke stroke6 = barRenderer3D0.getBaseStroke();
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        org.jfree.data.xy.XYDataset xYDataset10 = polarPlot4.getDataset();
        java.lang.String str11 = polarPlot4.getPlotType();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("item");
        java.awt.Font font2 = textFragment1.getFont();
        java.awt.Font font3 = textFragment1.getFont();
        java.lang.String str4 = textFragment1.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "item" + "'", str4.equals("item"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape4 = legendItem3.getLine();
        legendItem3.setLineVisible(true);
        legendItem3.setSeriesIndex((int) (short) 1);
        legendItemCollection0.add(legendItem3);
        java.lang.Object obj10 = legendItemCollection0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 100L + "'", long0 == 100L);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.Number number9 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Date date10 = year8.getStart();
        java.util.TimeZone timeZone11 = null;
        try {
            org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("0.58", "0.58", "0.58", "index.html", "item");
        basicProjectInfo5.setLicenceName("HorizontalAlignment.CENTER");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getLibraries();
        basicProjectInfo5.setVersion("RectangleAnchor.TOP");
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.lang.Object obj6 = combinedDomainXYPlot4.clone();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = combinedDomainXYPlot4.removeDomainMarker(marker7);
        combinedDomainXYPlot4.setDomainCrosshairLockedOnData(false);
        java.lang.Object obj11 = combinedDomainXYPlot4.clone();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setAnchorValue((double) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge(0);
        java.lang.Object obj6 = null;
        boolean boolean7 = rectangleEdge5.equals(obj6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long2 = segmentedTimeline0.toMillisecond(0L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927600000L) + "'", long2 == (-2208927600000L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        ringPlot1.setInnerSeparatorExtension(0.0d);
        boolean boolean6 = ringPlot1.getSimpleLabels();
        java.awt.Paint paint7 = ringPlot1.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = ringPlot1.getLabelPadding();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = ringPlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        boolean boolean4 = barRenderer3D0.getIncludeBaseInRange();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYStepRenderer5.setSeriesURLGenerator(100, xYURLGenerator7);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepRenderer5.getSeriesPositiveItemLabelPosition(5);
        double double13 = itemLabelPosition12.getAngle();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape4 = legendItem3.getLine();
        legendItem3.setLineVisible(true);
        legendItem3.setSeriesIndex((int) (short) 1);
        legendItemCollection0.add(legendItem3);
        boolean boolean10 = legendItem3.isShapeFilled();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape3 = legendItem2.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis6, polarItemRenderer7);
        xYSeriesCollection4.validateObject();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        legendItem2.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection4);
        java.awt.Paint paint13 = legendItem2.getLinePaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis3D14.getCategoryStart(3, (int) (byte) 10, rectangle2D18, rectangleEdge19);
        java.awt.Font font22 = categoryAxis3D14.getTickLabelFont((java.lang.Comparable) (byte) 10);
        legendItem2.setLabelFont(font22);
        java.awt.Color color25 = java.awt.Color.CYAN;
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        logAxis27.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = combinedDomainXYPlot30.getRenderer();
        java.awt.Stroke stroke32 = combinedDomainXYPlot30.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color25, stroke32);
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font22, (java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(xYItemRenderer31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(textBlock34);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = itemLabelPosition10.getItemLabelAnchor();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        java.lang.Comparable comparable2 = categoryPlot0.getDomainCrosshairRowKey();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        long long4 = segmentedTimeline0.toMillisecond((long) (short) -1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2208927600001L) + "'", long4 == (-2208927600001L));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape8 = xYAreaRenderer6.lookupSeriesShape((int) (short) -1);
        logAxis1.setDownArrow(shape8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.data.xy.XYDataItem xYDataItem15 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape8, pieDataset10, (int) (short) 0, 0, (java.lang.Comparable) xYDataItem15, "org.jfree.data.UnknownKeyException: hi!", "HorizontalAlignment.CENTER");
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer0.setUseFillPaint(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator9);
        boolean boolean13 = xYStepRenderer0.getItemLineVisible((int) ' ', 0);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYStepRenderer18.setSeriesURLGenerator(100, xYURLGenerator20);
        xYStepRenderer18.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot(pieDataset24);
        boolean boolean26 = xYStepRenderer18.hasListener((java.util.EventListener) ringPlot25);
        java.awt.Color color28 = java.awt.Color.lightGray;
        xYStepRenderer18.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color28);
        org.jfree.chart.text.TextMeasurer textMeasurer31 = null;
        org.jfree.chart.text.TextBlock textBlock32 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color28, (float) 100L, textMeasurer31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.util.Size2D size2D34 = textBlock32.calculateDimensions(graphics2D33);
        java.awt.Font font38 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection39 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer42 = null;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection39, valueAxis41, polarItemRenderer42);
        boolean boolean45 = polarPlot43.equals((java.lang.Object) 100.0f);
        java.awt.Color color46 = java.awt.Color.lightGray;
        polarPlot43.setAngleGridlinePaint((java.awt.Paint) color46);
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font38, (java.awt.Paint) color46);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = labelBlock48.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) 1, (double) (short) 0, rectangleAnchor49);
        rectangleInsets15.trim(rectangle2D50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor52);
        org.jfree.chart.axis.LogAxis logAxis55 = new org.jfree.chart.axis.LogAxis("");
        logAxis55.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot58 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis55);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = combinedDomainXYPlot58.getRenderer();
        java.awt.Stroke stroke60 = combinedDomainXYPlot58.getDomainMinorGridlineStroke();
        org.jfree.data.time.TimeSeries timeSeries61 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection62 = new org.jfree.data.time.TimeSeriesCollection(timeSeries61);
        int int63 = timeSeriesCollection62.getSeriesCount();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor64 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        timeSeriesCollection62.setXPosition(timePeriodAnchor64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState67 = xYStepRenderer0.initialise(graphics2D14, rectangle2D50, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot58, (org.jfree.data.xy.XYDataset) timeSeriesCollection62, plotRenderingInfo66);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity68 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D50);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(textBlock32);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNull(xYItemRenderer59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor64);
        org.junit.Assert.assertNotNull(xYItemRendererState67);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 1.0f, 2.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = xYItemRendererState1.getInfo();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState3 = null;
        xYItemRendererState1.setCrosshairState(xYCrosshairState3);
        xYItemRendererState1.setProcessVisibleItemsOnly(false);
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.Number number9 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) year8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis7, polarItemRenderer8);
        boolean boolean11 = polarPlot9.equals((java.lang.Object) 100.0f);
        polarPlot9.clearCornerTextItems();
        xYStepRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        java.awt.Color color14 = java.awt.Color.white;
        polarPlot9.setAngleGridlinePaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        try {
            java.lang.Number number4 = timeSeriesCollection1.getStartY((int) 'a', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        java.lang.Object obj7 = xYStepRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepRenderer0.getSeriesPositiveItemLabelPosition(0);
        xYStepRenderer0.setAutoPopulateSeriesStroke(false);
        java.awt.Shape shape13 = xYStepRenderer0.getSeriesShape(5);
        java.util.Collection collection14 = xYStepRenderer0.getAnnotations();
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) ' ', 0.05d, 0.14d, (double) 8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = timeSeries1.equals((java.lang.Object) textBlockAnchor2);
        boolean boolean4 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot1.getDataset();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape6 = xYAreaRenderer4.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        xYStepRenderer11.setSeriesURLGenerator(100, xYURLGenerator13);
        xYStepRenderer11.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        boolean boolean19 = xYStepRenderer11.hasListener((java.util.EventListener) ringPlot18);
        ringPlot18.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        ringPlot18.handleClick(1, (int) 'a', plotRenderingInfo24);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot18);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity29 = new org.jfree.chart.entity.JFreeChartEntity(shape6, jFreeChart26, "Other", "");
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart26.setBorderStroke(stroke30);
        multiplePiePlot1.setPieChart(jFreeChart26);
        try {
            org.jfree.chart.title.Title title34 = jFreeChart26.getSubtitle(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) 100);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) 0);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot5.getIgnoreZeroValues();
        try {
            int int7 = segment4.compareTo((java.lang.Object) ringPlot5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.RingPlot cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint2 = ringPlot0.getBackgroundPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        ringPlot0.setLabelLinkStyle(pieLabelLinkStyle3);
        java.lang.String str5 = pieLabelLinkStyle3.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str5.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        jFreeChart16.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.event.ChartChangeListener chartChangeListener20 = null;
        try {
            jFreeChart16.addChangeListener(chartChangeListener20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        logAxis1.setLowerMargin(0.05d);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean19 = xYStepRenderer17.getSeriesLinesVisible((int) (byte) 0);
        java.lang.String str20 = logFormat11.format((java.lang.Object) (byte) 0);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat11);
        logAxis1.setSmallestValue((double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-∞" + "'", str20.equals("-∞"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreNullValues();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries4.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Date date13 = year11.getStart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection15 = chartRenderingInfo14.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot(pieDataset16);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator18 = null;
        ringPlot17.setLegendLabelURLGenerator(pieURLGenerator18);
        ringPlot17.setInnerSeparatorExtension(0.0d);
        boolean boolean22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo14, (java.lang.Object) ringPlot17);
        java.awt.Paint paint23 = ringPlot17.getLabelShadowPaint();
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) year11, paint23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(entityCollection15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.Number number9 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Date date10 = year8.getStart();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        int int12 = year8.compareTo((java.lang.Object) xYAreaRenderer11);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("");
        double double10 = logAxis8.calculateValue((double) 8);
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range11, (double) 100);
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude(range13, (double) 10L);
        logAxis8.setRange(range13, true, false);
        org.jfree.data.Range range19 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis8);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E8d + "'", double10 == 1.0E8d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3D6.setBaseToolTipGenerator(categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        logAxis12.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer18.setSeriesOutlinePaint((int) (byte) 10, paint20, false);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D6.drawRangeLine(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D16, (double) (short) 0, paint20, stroke23);
        combinedDomainXYPlot4.setRangeZeroBaselineStroke(stroke23);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = combinedDomainXYPlot4.getAxisOffset();
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint31);
        combinedDomainXYPlot4.setDomainZeroBaselinePaint(paint31);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("0.58", "0.58", "0.58", "index.html", "item");
        basicProjectInfo5.setLicenceName("HorizontalAlignment.CENTER");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getLibraries();
        java.lang.String str9 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "index.html" + "'", str9.equals("index.html"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYSeries1.equals((java.lang.Object) xYStepRenderer8);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer8.setSeriesItemLabelFont(8, font11, true);
        boolean boolean15 = xYStepRenderer8.isSeriesVisible(3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        double double15 = intervalXYDelegate14.getIntervalPositionFactor();
        try {
            java.lang.Number number18 = intervalXYDelegate14.getStartX(2, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        boolean boolean3 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYStepRenderer5.setSeriesURLGenerator(100, xYURLGenerator7);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        boolean boolean13 = xYStepRenderer5.hasListener((java.util.EventListener) ringPlot12);
        ringPlot12.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        ringPlot12.handleClick(1, (int) 'a', plotRenderingInfo18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot12);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle21.setMargin(rectangleInsets22);
        textTitle21.setVisible(false);
        jFreeChart20.removeSubtitle((org.jfree.chart.title.Title) textTitle21);
        boolean boolean27 = jFreeChart20.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis3D1, jFreeChart20);
        java.lang.Object obj29 = jFreeChart20.clone();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        boolean boolean3 = legendItem1.isShapeVisible();
        java.awt.Stroke stroke4 = legendItem1.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer3D0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarPainter barPainter20 = barRenderer3D0.getBarPainter();
        boolean boolean21 = barRenderer3D0.getShadowsVisible();
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(barPainter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer1.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState10 = xYAreaRenderer1.initialise(graphics2D5, rectangle2D6, xYPlot7, xYDataset8, plotRenderingInfo9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer1.getBasePositiveItemLabelPosition();
        boolean boolean12 = itemLabelAnchor0.equals((java.lang.Object) xYAreaRenderer1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = null;
        xYAreaRenderer1.setSeriesItemLabelGenerator(0, xYItemLabelGenerator14, false);
        java.util.Collection collection17 = xYAreaRenderer1.getAnnotations();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer20 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = null;
        xYStepRenderer20.setSeriesURLGenerator(100, xYURLGenerator22);
        xYStepRenderer20.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = xYStepRenderer20.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator29 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer20.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator29, true);
        org.jfree.chart.util.LogFormat logFormat38 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean39 = logFormat38.isParseIntegerOnly();
        java.text.ParsePosition parsePosition41 = null;
        java.lang.Object obj42 = logFormat38.parseObject("", parsePosition41);
        int int43 = logFormat38.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat48 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean49 = logFormat48.isParseIntegerOnly();
        java.text.ParsePosition parsePosition51 = null;
        java.lang.Object obj52 = logFormat48.parseObject("", parsePosition51);
        int int53 = logFormat48.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator54 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat38, (java.text.NumberFormat) logFormat48);
        xYStepRenderer20.setSeriesToolTipGenerator((int) (short) 10, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator54, false);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator58 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str61 = legendItem60.getURLText();
        java.awt.Paint paint62 = legendItem60.getLabelPaint();
        boolean boolean63 = standardXYURLGenerator58.equals((java.lang.Object) legendItem60);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer64 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator54, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator58);
        try {
            xYAreaRenderer1.setSeriesURLGenerator((int) (byte) -1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(xYToolTipGenerator4);
        org.junit.Assert.assertNotNull(xYItemRendererState10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        logAxis2.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis2);
        logAxis2.setLowerMargin(0.05d);
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean13 = logFormat12.isParseIntegerOnly();
        java.text.ParsePosition parsePosition15 = null;
        java.lang.Object obj16 = logFormat12.parseObject("", parsePosition15);
        int int17 = logFormat12.getMinimumIntegerDigits();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean20 = xYStepRenderer18.getSeriesLinesVisible((int) (byte) 0);
        java.lang.String str21 = logFormat12.format((java.lang.Object) (byte) 0);
        logAxis2.setNumberFormatOverride((java.text.NumberFormat) logFormat12);
        org.jfree.chart.util.LogFormat logFormat27 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean28 = logFormat27.isParseIntegerOnly();
        java.text.ParsePosition parsePosition30 = null;
        java.lang.Object obj31 = logFormat27.parseObject("", parsePosition30);
        java.lang.Object obj32 = null;
        boolean boolean33 = logFormat27.equals(obj32);
        logFormat27.setParseIntegerOnly(true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("0.58", (java.text.NumberFormat) logFormat12, (java.text.NumberFormat) logFormat27);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        java.lang.String str39 = standardPieSectionLabelGenerator36.generateSectionLabel(pieDataset37, (java.lang.Comparable) "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-∞" + "'", str21.equals("-∞"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean9 = logFormat8.isParseIntegerOnly();
        java.text.ParsePosition parsePosition11 = null;
        java.lang.Object obj12 = logFormat8.parseObject("", parsePosition11);
        int int13 = logFormat8.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat18 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean19 = logFormat18.isParseIntegerOnly();
        java.text.ParsePosition parsePosition21 = null;
        java.lang.Object obj22 = logFormat18.parseObject("", parsePosition21);
        int int23 = logFormat18.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator24 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat8, (java.text.NumberFormat) logFormat18);
        logFormat8.setMaximumIntegerDigits(0);
        numberAxis3D1.setNumberFormatOverride((java.text.NumberFormat) logFormat8);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean2 = xYStepRenderer0.getSeriesLinesVisible((int) (byte) 0);
        java.awt.Paint paint4 = xYStepRenderer0.getSeriesFillPaint(8);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint2);
        java.awt.Stroke stroke4 = intervalMarker3.getOutlineStroke();
        intervalMarker3.setLabel("");
        double double7 = intervalMarker3.getStartValue();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean4 = xYSeries3.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries7 = xYSeries3.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        xYSeries3.addChangeListener(seriesChangeListener8);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean11 = xYSeries3.equals((java.lang.Object) xYStepRenderer10);
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer10.setSeriesItemLabelFont(8, font13, true);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font13, paint16);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("ThreadContext", font13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(xYSeries7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape15 = xYAreaRenderer13.lookupSeriesShape((int) (short) -1);
        xYStepRenderer0.setSeriesShape(0, shape15, true);
        org.jfree.chart.LegendItem legendItem20 = xYStepRenderer0.getLegendItem((int) (byte) -1, 500);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(legendItem20);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setAnchorValue((double) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge(0);
        java.awt.Color color7 = java.awt.Color.CYAN;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        logAxis9.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot12.getRenderer();
        java.awt.Stroke stroke14 = combinedDomainXYPlot12.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color7, stroke14);
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart16.getLegend();
        boolean boolean18 = jFreeChart16.getAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendTitle17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYStepRenderer6.setSeriesURLGenerator(100, xYURLGenerator8);
        xYStepRenderer6.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        boolean boolean14 = xYStepRenderer6.hasListener((java.util.EventListener) ringPlot13);
        java.awt.Color color16 = java.awt.Color.lightGray;
        xYStepRenderer6.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color16);
        xYStepRenderer0.setBaseOutlinePaint((java.awt.Paint) color16, true);
        int int20 = color16.getBlue();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 192 + "'", int20 == 192);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        logAxis7.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer13.setSeriesOutlinePaint((int) (byte) 10, paint15, false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D1.drawRangeLine(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) logAxis7, rectangle2D11, (double) (short) 0, paint15, stroke18);
        boolean boolean20 = logAxis7.isAxisLineVisible();
        boolean boolean21 = borderArrangement0.equals((java.lang.Object) logAxis7);
        org.jfree.chart.block.Block block22 = null;
        try {
            borderArrangement0.add(block22, (java.lang.Object) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setHorizontalAlignment(horizontalAlignment11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        double double15 = ringPlot14.getInnerSeparatorExtension();
        boolean boolean16 = ringPlot14.getIgnoreZeroValues();
        java.awt.Paint paint17 = ringPlot14.getLabelOutlinePaint();
        categoryPlot13.setRangeMinorGridlinePaint(paint17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot13.setRangeAxisLocation(7, axisLocation20, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot13.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot13.setFixedDomainAxisSpace(axisSpace25, true);
        boolean boolean28 = horizontalAlignment11.equals((java.lang.Object) categoryPlot13);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        polarPlot4.setRadiusGridlinesVisible(true);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.LegendItemCollection legendItemCollection2 = multiplePiePlot1.getLegendItems();
        java.lang.Comparable comparable3 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        logAxis1.resizeRange((double) (short) 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        logAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent14);
        java.awt.geom.Point2D point2D16 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("Other");
        combinedDomainXYPlot4.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis19, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        double double24 = ringPlot23.getInnerSeparatorExtension();
        boolean boolean25 = ringPlot23.getIgnoreZeroValues();
        java.awt.Paint paint26 = ringPlot23.getLabelOutlinePaint();
        categoryPlot22.setRangeMinorGridlinePaint(paint26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot22.setRangeAxisLocation(7, axisLocation29, false);
        combinedDomainXYPlot4.setDomainAxisLocation(axisLocation29);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.KeyedValues keyedValues0 = null;
        try {
            org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset(keyedValues0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 12L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list4 = segmentedTimeline3.getExceptionSegments();
        boolean boolean5 = segmentedTimeline3.getAdjustForDaylightSaving();
        segmentedTimeline0.setBaseTimeline(segmentedTimeline3);
        long long7 = segmentedTimeline3.getStartTime();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208927600000L) + "'", long7 == (-2208927600000L));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        logAxis7.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer13.setSeriesOutlinePaint((int) (byte) 10, paint15, false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D1.drawRangeLine(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) logAxis7, rectangle2D11, (double) (short) 0, paint15, stroke18);
        boolean boolean20 = logAxis7.isAxisLineVisible();
        boolean boolean21 = borderArrangement0.equals((java.lang.Object) logAxis7);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D23);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis3D23.getCategoryStart(3, (int) (byte) 10, rectangle2D27, rectangleEdge28);
        java.awt.Font font31 = categoryAxis3D23.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle22.setFont(font31);
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot();
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) textTitle22, (java.lang.Object) piePlot33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        combinedDomainXYPlot4.setRangeZeroBaselineVisible(true);
        java.util.List list16 = combinedDomainXYPlot4.getSubplots();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        java.awt.Font font12 = labelBlock11.getFont();
        labelBlock11.setWidth((double) 0.5f);
        java.lang.String str15 = labelBlock11.getToolTipText();
        java.lang.String str16 = labelBlock11.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot4.getDomainAxis();
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainCrosshairStroke();
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape14 = legendItem13.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection15, valueAxis17, polarItemRenderer18);
        xYSeriesCollection15.validateObject();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection15, false);
        legendItem13.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection15);
        java.awt.Paint paint24 = legendItem13.getLinePaint();
        try {
            combinedDomainXYPlot4.setQuadrantPaint(15, paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (15) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) (short) 0);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        intervalMarker8.notifyListeners(markerChangeEvent9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer11);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Image image2 = ringPlot0.getBackgroundImage();
        boolean boolean3 = ringPlot0.getSimpleLabels();
        boolean boolean4 = ringPlot0.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        int int18 = jFreeChart16.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection22 = chartRenderingInfo21.getEntityCollection();
        jFreeChart16.handleClick((int) 'a', (int) 'a', chartRenderingInfo21);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart16.addProgressListener(chartProgressListener24);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(entityCollection22);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        int int5 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = null;
        try {
            timeSeries1.add(timeSeriesDataItem6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot0.getDrawingSupplier();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        ringPlot0.datasetChanged(datasetChangeEvent6);
        int int8 = ringPlot0.getPieIndex();
        ringPlot0.setIgnoreNullValues(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) (short) 0);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer16.setSeriesOutlinePaint((int) (byte) 10, paint18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D4.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) logAxis10, rectangle2D14, (double) (short) 0, paint18, stroke21);
        boolean boolean23 = logAxis10.isAxisLineVisible();
        java.awt.Paint paint24 = logAxis10.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = logAxis10.getTickLabelInsets();
        logAxis10.configure();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        logAxis30.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot33 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis30);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = combinedDomainXYPlot33.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis36 = combinedDomainXYPlot33.getDomainAxis(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat39 = numberAxis3D38.getNumberFormatOverride();
        int int40 = combinedDomainXYPlot33.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D38);
        boolean boolean41 = valueAxis28.hasListener((java.util.EventListener) combinedDomainXYPlot33);
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNull(xYItemRenderer34);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNull(numberFormat39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot4.getDomainAxis();
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = combinedDomainXYPlot4.getAxisOffset();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = labelBlock11.getTextAnchor();
        labelBlock11.setToolTipText("0.58");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = null;
        boolean boolean2 = strokeMap0.equals(obj1);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(paint4);
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) blockBorder5);
        boolean boolean7 = strokeMap0.equals((java.lang.Object) blockBorder5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        ringPlot7.setCircular(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, valueAxis13, polarItemRenderer14);
        boolean boolean17 = polarPlot15.equals((java.lang.Object) 100.0f);
        java.awt.Color color18 = java.awt.Color.lightGray;
        polarPlot15.setAngleGridlinePaint((java.awt.Paint) color18);
        ringPlot7.setLabelOutlinePaint((java.awt.Paint) color18);
        java.lang.String str21 = org.jfree.chart.util.PaintUtilities.colorToString(color18);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "lightGray" + "'", str21.equals("lightGray"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        polarPlot4.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        polarPlot4.setRenderer(polarItemRenderer9);
        try {
            polarPlot4.zoom((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        xYItemRendererState9.setProcessVisibleItemsOnly(true);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        xYItemRendererState9.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState15 = new org.jfree.chart.plot.XYCrosshairState();
        xYItemRendererState9.setCrosshairState(xYCrosshairState15);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        boolean boolean9 = polarPlot7.equals((java.lang.Object) 100.0f);
        java.awt.Color color10 = java.awt.Color.lightGray;
        polarPlot7.setAngleGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font2, (java.awt.Paint) color10);
        java.awt.Font font13 = labelBlock12.getFont();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("item", font13);
        java.lang.String str15 = textTitle14.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "item" + "'", str15.equals("item"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot4.removeDomainMarker(marker8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        try {
            combinedDomainXYPlot4.zoomRangeAxes(0.0d, (double) 15, plotRenderingInfo12, point2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "item", true, false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(100, (int) '4', (int) (byte) 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        boolean boolean19 = logAxis6.isAxisLineVisible();
        java.awt.Paint paint20 = logAxis6.getAxisLinePaint();
        org.jfree.chart.util.LogFormat logFormat27 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean28 = logFormat27.isParseIntegerOnly();
        java.text.ParsePosition parsePosition30 = null;
        java.lang.Object obj31 = logFormat27.parseObject("", parsePosition30);
        int int32 = logFormat27.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat37 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean38 = logFormat37.isParseIntegerOnly();
        java.text.ParsePosition parsePosition40 = null;
        java.lang.Object obj41 = logFormat37.parseObject("", parsePosition40);
        int int42 = logFormat37.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator43 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat27, (java.text.NumberFormat) logFormat37);
        logFormat27.setParseIntegerOnly(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit(1.0E8d, (java.text.NumberFormat) logFormat27);
        logAxis6.setTickUnit(numberTickUnit46);
        java.awt.Shape shape48 = logAxis6.getRightArrow();
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D50 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D50);
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = categoryAxis3D50.getCategoryStart(3, (int) (byte) 10, rectangle2D54, rectangleEdge55);
        java.awt.Font font58 = categoryAxis3D50.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle49.setFont(font58);
        java.awt.Paint paint60 = textTitle49.getPaint();
        textTitle49.visible = true;
        org.jfree.chart.entity.TitleEntity titleEntity65 = new org.jfree.chart.entity.TitleEntity(shape48, (org.jfree.chart.title.Title) textTitle49, "PieLabelLinkStyle.STANDARD", "");
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        java.lang.Object obj2 = legendItemCollection0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = xYStepRenderer0.lookupLegendTextFont(0);
        xYStepRenderer0.setDefaultEntityRadius(100);
        java.lang.Object obj5 = xYStepRenderer0.clone();
        java.awt.Stroke stroke6 = xYStepRenderer0.getBaseStroke();
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getURLGenerator();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        double double8 = ringPlot7.getInnerSeparatorExtension();
        boolean boolean9 = ringPlot7.getIgnoreZeroValues();
        java.awt.Paint paint10 = ringPlot7.getLabelOutlinePaint();
        double double11 = ringPlot7.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = ringPlot7.getLegendLabelURLGenerator();
        boolean boolean13 = ringPlot0.equals((java.lang.Object) ringPlot7);
        java.lang.Class<?> wildcardClass14 = ringPlot7.getClass();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.14d + "'", double11 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(5.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYStepRenderer3.setSeriesURLGenerator(100, xYURLGenerator5);
        xYStepRenderer3.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        boolean boolean11 = xYStepRenderer3.hasListener((java.util.EventListener) ringPlot10);
        java.awt.Color color13 = java.awt.Color.lightGray;
        xYStepRenderer3.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color13);
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color13, (float) 100L, textMeasurer16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock17.calculateDimensions(graphics2D18);
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection24, valueAxis26, polarItemRenderer27);
        boolean boolean30 = polarPlot28.equals((java.lang.Object) 100.0f);
        java.awt.Color color31 = java.awt.Color.lightGray;
        polarPlot28.setAngleGridlinePaint((java.awt.Paint) color31);
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font23, (java.awt.Paint) color31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = labelBlock33.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) 1, (double) (short) 0, rectangleAnchor34);
        rectangleInsets0.trim(rectangle2D35);
        double double38 = rectangleInsets0.calculateTopInset((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        xYSeriesCollection8.setIntervalWidth(0.0d);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list17 = segmentedTimeline16.getExceptionSegments();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, list17, true);
        try {
            java.lang.Number number22 = xYSeriesCollection8.getEndY((int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        legendItem1.setLineVisible(true);
        java.awt.Stroke stroke5 = legendItem1.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        java.lang.Comparable comparable2 = categoryPlot0.getDomainCrosshairRowKey();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray25 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray26 = new double[][] { doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset27, true);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range31 = barRenderer3D0.findRangeBounds(categoryDataset27);
        try {
            org.jfree.data.general.PieDataset pieDataset33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset27, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYStepRenderer6.setSeriesURLGenerator(100, xYURLGenerator8);
        xYStepRenderer6.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        boolean boolean14 = xYStepRenderer6.hasListener((java.util.EventListener) ringPlot13);
        java.awt.Color color16 = java.awt.Color.lightGray;
        xYStepRenderer6.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color16);
        xYStepRenderer0.setBaseOutlinePaint((java.awt.Paint) color16, true);
        boolean boolean20 = xYStepRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        jFreeChart16.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean22 = segmentedTimeline20.containsDomainValue((long) 7);
        int int23 = segmentedTimeline20.getSegmentsExcluded();
        org.jfree.data.time.TimeSeries timeSeries24 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection(timeSeries24);
        int int26 = timeSeriesCollection25.getSeriesCount();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor27 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        timeSeriesCollection25.setXPosition(timePeriodAnchor27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list30 = categoryPlot29.getAnnotations();
        org.jfree.data.Range range32 = timeSeriesCollection25.getDomainBounds(list30, true);
        segmentedTimeline20.addExceptions(list30);
        jFreeChart16.setSubtitles(list30);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 68 + "'", int23 == 68);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor27);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(range32);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        ringPlot7.setCircular(true);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        double double12 = ringPlot11.getInnerSeparatorExtension();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = ringPlot11.getDrawingSupplier();
        ringPlot11.setAutoPopulateSectionOutlineStroke(true);
        float float16 = ringPlot11.getBackgroundImageAlpha();
        ringPlot11.setStartAngle((double) 10L);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        ringPlot11.setDataset(pieDataset19);
        java.awt.Paint paint21 = ringPlot11.getLabelPaint();
        ringPlot7.setLabelBackgroundPaint(paint21);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        ringPlot0.setExplodePercent((java.lang.Comparable) "rect", (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        java.lang.Object obj7 = xYStepRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepRenderer0.getSeriesPositiveItemLabelPosition(0);
        xYStepRenderer0.setAutoPopulateSeriesStroke(false);
        java.awt.Stroke stroke13 = xYStepRenderer0.lookupSeriesStroke(15);
        java.awt.Color color14 = java.awt.Color.orange;
        xYStepRenderer0.setBasePaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = xYItemRendererState1.getInfo();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState3 = null;
        xYItemRendererState1.setCrosshairState(xYCrosshairState3);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection();
        xYItemRendererState1.startSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection5, (-1), 68, 8, 15, (int) (byte) 0);
        try {
            java.lang.Number number14 = timeSeriesCollection5.getStartY(6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        logAxis4.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedDomainXYPlot7.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot7.getDomainAxis(3);
        combinedDomainXYPlot7.setDomainCrosshairValue(0.0d, false);
        combinedDomainXYPlot7.setRangePannable(true);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot7);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = barRenderer3D0.getSeriesItemLabelGenerator(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3D6.setBaseToolTipGenerator(categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        logAxis12.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer18.setSeriesOutlinePaint((int) (byte) 10, paint20, false);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D6.drawRangeLine(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D16, (double) (short) 0, paint20, stroke23);
        combinedDomainXYPlot4.setRangeZeroBaselineStroke(stroke23);
        combinedDomainXYPlot4.clearRangeMarkers();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = ringPlot0.getLabelDistributor();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord6 = null;
        try {
            abstractPieLabelDistributor5.addPieLabelRecord(pieLabelRecord6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        java.awt.Stroke stroke10 = polarPlot4.getRadiusGridlineStroke();
        try {
            polarPlot4.zoom((double) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Other");
        java.util.TimeZone timeZone2 = null;
        try {
            dateAxis1.setTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.XYPlot xYPlot11 = xYAreaRenderer0.getPlot();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            xYAreaRenderer0.addAnnotation(xYAnnotation12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(xYPlot11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D4.setTickLabelsVisible(true);
        boolean boolean7 = logAxis3.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape10 = xYAreaRenderer8.lookupSeriesShape((int) (short) -1);
        logAxis3.setDownArrow(shape10);
        boolean boolean12 = blockBorder1.equals((java.lang.Object) shape10);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        int int1 = categoryAxis3D0.getMaximumCategoryLabelLines();
        boolean boolean2 = categoryAxis3D0.isVisible();
        categoryAxis3D0.setCategoryMargin((double) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int3 = java.awt.Color.HSBtoRGB((float) 7, (float) 0L, (float) 10L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-10) + "'", int3 == (-10));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float float5 = categoryAxis3D0.getTickMarkInsideLength();
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) "ChartChangeEventType.NEW_DATASET", "");
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        int int10 = categoryPlot9.getDatasetCount();
        int int11 = categoryPlot9.getCrosshairDatasetIndex();
        categoryAxis3D0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        categoryPlot9.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        combinedDomainXYPlot4.select(generalPath5, rectangle2D6, renderingSource7);
        combinedDomainXYPlot4.clearRangeMarkers((int) (short) 0);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        double double15 = logAxis13.calculateValue((double) 8);
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray25 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray29 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray33 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray37 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray21, doubleArray25, doubleArray29, doubleArray33, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, true);
        logAxis13.setDefaultAutoRange(range41);
        double double43 = logAxis13.getFixedAutoRange();
        logAxis13.setRangeAboutValue(8.0d, (double) 10.0f);
        combinedDomainXYPlot4.setDomainAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) logAxis13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E8d + "'", double15 == 1.0E8d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        boolean boolean2 = paintList0.equals((java.lang.Object) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        intervalMarker3.notifyListeners(markerChangeEvent4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        intervalMarker3.notifyListeners(markerChangeEvent6);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.LegendItemCollection legendItemCollection2 = multiplePiePlot1.getLegendItems();
        java.util.Iterator iterator3 = legendItemCollection2.iterator();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer4.setSeriesOutlinePaint((int) (byte) 10, paint6, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection9, valueAxis11, polarItemRenderer12);
        boolean boolean15 = polarPlot13.equals((java.lang.Object) 100.0f);
        polarPlot13.clearCornerTextItems();
        xYStepRenderer4.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot13);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = polarPlot13.getLegendItems();
        legendItemCollection2.addAll(legendItemCollection18);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection18);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 10L);
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        timeSeriesDataItem2.setValue((java.lang.Number) 1L);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10L + "'", number3.equals(10L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        java.lang.Object obj11 = textTitle0.clone();
        boolean boolean12 = textTitle0.getExpandToFitSpace();
        boolean boolean13 = textTitle0.getNotify();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        java.util.List list3 = categoryPlot0.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection6, valueAxis8, polarItemRenderer9);
        boolean boolean11 = polarPlot10.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        polarPlot10.zoomDomainAxes((double) 100.0f, plotRenderingInfo13, point2D14);
        java.awt.Stroke stroke16 = polarPlot10.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        logAxis20.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = combinedDomainXYPlot23.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis26 = combinedDomainXYPlot23.getDomainAxis(3);
        combinedDomainXYPlot23.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D30 = combinedDomainXYPlot23.getQuadrantOrigin();
        polarPlot10.zoomDomainAxes(5.0d, plotRenderingInfo18, point2D30, false);
        categoryPlot0.zoomRangeAxes(10.0d, plotRenderingInfo5, point2D30);
        boolean boolean34 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYItemRenderer24);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries(comparable0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer0.setUseFillPaint(false);
        xYStepRenderer0.setUseOutlinePaint(true);
        java.awt.Stroke stroke12 = xYStepRenderer0.getSeriesStroke(0);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYStepRenderer0.setBaseItemLabelFont(font13);
        xYStepRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        int int17 = xYStepRenderer0.getPassCount();
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle17.setMargin(rectangleInsets18);
        textTitle17.setVisible(false);
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        java.awt.Color color23 = java.awt.Color.WHITE;
        jFreeChart16.setBackgroundPaint((java.awt.Paint) color23);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot3.setLegendLabelURLGenerator(pieURLGenerator4);
        ringPlot3.setInnerSeparatorExtension(0.0d);
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo0, (java.lang.Object) ringPlot3);
        org.jfree.chart.RenderingSource renderingSource9 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource9);
        org.jfree.chart.entity.EntityCollection entityCollection11 = chartRenderingInfo0.getEntityCollection();
        chartRenderingInfo0.clear();
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(entityCollection11);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double1 = xYSeriesCollection0.getIntervalWidth();
        java.lang.Object obj2 = xYSeriesCollection0.clone();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            java.lang.Number number6 = xYSeriesCollection0.getStartY(8, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        logAxis4.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedDomainXYPlot7.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot7.getDomainAxis(3);
        combinedDomainXYPlot7.setDomainCrosshairValue(0.0d, false);
        combinedDomainXYPlot7.setRangePannable(true);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot7);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(categoryAxis17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(7, axisLocation7, false);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        java.awt.Paint paint12 = categoryPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedDomainXYPlot4.clearDomainMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = combinedDomainXYPlot13.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis16 = combinedDomainXYPlot13.getDomainAxis(3);
        combinedDomainXYPlot13.setDomainCrosshairValue(0.0d, false);
        combinedDomainXYPlot13.setRangePannable(true);
        categoryPlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) categoryPlot6);
        combinedDomainXYPlot4.rendererChanged(rendererChangeEvent23);
        int int25 = combinedDomainXYPlot4.getRendererCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = categoryPlot26.getDatasetRenderingOrder();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection28 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection28, valueAxis30, polarItemRenderer31);
        boolean boolean33 = polarPlot32.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        polarPlot32.zoomDomainAxes((double) 100.0f, plotRenderingInfo35, point2D36);
        org.jfree.data.xy.XYDataset xYDataset38 = polarPlot32.getDataset();
        boolean boolean39 = datasetRenderingOrder27.equals((java.lang.Object) xYDataset38);
        java.lang.String str40 = datasetRenderingOrder27.toString();
        combinedDomainXYPlot4.setDatasetRenderingOrder(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(xYItemRenderer14);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(xYDataset38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str40.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        logAxis1.setNegativeArrowVisible(false);
        logAxis1.setAutoRangeMinimumSize(4.0d);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) logAxis1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        double double4 = logAxis2.calculateValue((double) 8);
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 100);
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 10L);
        logAxis2.setRange(range7, true, false);
        org.jfree.data.Range range14 = org.jfree.data.Range.scale(range7, (double) 3);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = null;
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        java.lang.String str18 = range17.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.RANGE;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(0.0d, range7, lengthConstraintType15, (double) 500, range17, lengthConstraintType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E8d + "'", double4 == 1.0E8d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Range[0.0,1.0]" + "'", str18.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType19);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        ringPlot1.setInnerSeparatorExtension(0.0d);
        boolean boolean6 = ringPlot1.getSimpleLabels();
        boolean boolean7 = ringPlot1.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        int int3 = crosshairState0.getRangeAxisIndex();
        double double4 = crosshairState0.getAnchorY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = xYItemRendererState1.getInfo();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState3 = null;
        xYItemRendererState1.setCrosshairState(xYCrosshairState3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        double double6 = xYSeriesCollection5.getIntervalWidth();
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        xYItemRendererState1.startSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection5, 6, 10, (int) (short) 0, (int) (short) 100, 0);
        double double14 = xYSeriesCollection5.getIntervalWidth();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState15 = xYSeriesCollection5.getSelectionState();
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        boolean boolean6 = logAxis1.isVerticalTickLabels();
        float float7 = logAxis1.getMinorTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer3D1.setBaseToolTipGenerator(categoryToolTipGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        logAxis7.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer13.setSeriesOutlinePaint((int) (byte) 10, paint15, false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D1.drawRangeLine(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) logAxis7, rectangle2D11, (double) (short) 0, paint15, stroke18);
        boolean boolean20 = logAxis7.isAxisLineVisible();
        boolean boolean21 = borderArrangement0.equals((java.lang.Object) logAxis7);
        logAxis7.centerRange((double) 'a');
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape8 = xYAreaRenderer6.lookupSeriesShape((int) (short) -1);
        logAxis1.setDownArrow(shape8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.data.xy.XYDataItem xYDataItem15 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape8, pieDataset10, (int) (short) 0, 0, (java.lang.Comparable) xYDataItem15, "org.jfree.data.UnknownKeyException: hi!", "HorizontalAlignment.CENTER");
        java.lang.String str19 = pieSectionEntity18.getShapeType();
        java.lang.String str20 = pieSectionEntity18.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "rect" + "'", str19.equals("rect"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieSection: 0, 0([0.0, 100.0])" + "'", str20.equals("PieSection: 0, 0([0.0, 100.0])"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 100L, Double.NaN, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot4.getDomainAxis();
        java.awt.Paint paint10 = null;
        try {
            combinedDomainXYPlot4.setRangeCrosshairPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(valueAxis9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape8 = xYAreaRenderer6.lookupSeriesShape((int) (short) -1);
        logAxis1.setDownArrow(shape8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = logAxis1.getTickUnit();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(numberTickUnit10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer1.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = xYAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState10 = xYAreaRenderer1.initialise(graphics2D5, rectangle2D6, xYPlot7, xYDataset8, plotRenderingInfo9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer1.getBasePositiveItemLabelPosition();
        boolean boolean12 = itemLabelAnchor0.equals((java.lang.Object) xYAreaRenderer1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = null;
        xYAreaRenderer1.setSeriesItemLabelGenerator(0, xYItemLabelGenerator14, false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.data.Range range18 = xYAreaRenderer1.findRangeBounds(xYDataset17);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(xYToolTipGenerator4);
        org.junit.Assert.assertNotNull(xYItemRendererState10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("RangeType.FULL");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer16.setSeriesOutlinePaint((int) (byte) 10, paint18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D4.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) logAxis10, rectangle2D14, (double) (short) 0, paint18, stroke21);
        boolean boolean23 = logAxis10.isAxisLineVisible();
        java.awt.Paint paint24 = logAxis10.getAxisLinePaint();
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle26.setMargin(rectangleInsets27);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot30 = categoryAxis3D29.getPlot();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer36 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = null;
        xYStepRenderer36.setSeriesURLGenerator(100, xYURLGenerator38);
        xYStepRenderer36.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot(pieDataset42);
        boolean boolean44 = xYStepRenderer36.hasListener((java.util.EventListener) ringPlot43);
        java.awt.Color color46 = java.awt.Color.lightGray;
        xYStepRenderer36.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color46);
        org.jfree.chart.text.TextMeasurer textMeasurer49 = null;
        org.jfree.chart.text.TextBlock textBlock50 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, (java.awt.Paint) color46, (float) 100L, textMeasurer49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.util.Size2D size2D52 = textBlock50.calculateDimensions(graphics2D51);
        java.awt.Font font56 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection57 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection57);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection57, valueAxis59, polarItemRenderer60);
        boolean boolean63 = polarPlot61.equals((java.lang.Object) 100.0f);
        java.awt.Color color64 = java.awt.Color.lightGray;
        polarPlot61.setAngleGridlinePaint((java.awt.Paint) color64);
        org.jfree.chart.block.LabelBlock labelBlock66 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font56, (java.awt.Paint) color64);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = labelBlock66.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D68 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) 1, (double) (short) 0, rectangleAnchor67);
        rectangleInsets33.trim(rectangle2D68);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle70.setMargin(rectangleInsets71);
        textTitle70.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = textTitle70.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = textTitle70.getPosition();
        org.jfree.chart.axis.AxisState axisState78 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState78.setMax(0.0d);
        axisState78.cursorDown(1.0E8d);
        categoryAxis3D29.drawTickMarks(graphics2D31, (double) 0L, rectangle2D68, rectangleEdge76, axisState78);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType84 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D86 = rectangleInsets27.createAdjustedRectangle(rectangle2D68, lengthAdjustmentType84, lengthAdjustmentType85);
        org.jfree.chart.title.TextTitle textTitle87 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets88 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle87.setMargin(rectangleInsets88);
        textTitle87.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets92 = textTitle87.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = textTitle87.getPosition();
        double double94 = logAxis10.lengthToJava2D((double) (-2208960000000L), rectangle2D68, rectangleEdge93);
        try {
            double double95 = logAxis1.lengthToJava2D((double) (byte) 10, rectangle2D3, rectangleEdge93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(textBlock50);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(lengthAdjustmentType84);
        org.junit.Assert.assertNotNull(lengthAdjustmentType85);
        org.junit.Assert.assertNotNull(rectangle2D86);
        org.junit.Assert.assertNotNull(rectangleInsets88);
        org.junit.Assert.assertNotNull(rectangleInsets92);
        org.junit.Assert.assertNotNull(rectangleEdge93);
        org.junit.Assert.assertEquals((double) double94, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYStepRenderer8.setSeriesURLGenerator(100, xYURLGenerator10);
        xYStepRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        boolean boolean16 = xYStepRenderer8.hasListener((java.util.EventListener) ringPlot15);
        java.awt.Color color18 = java.awt.Color.lightGray;
        xYStepRenderer8.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color18);
        xYStepRenderer2.setBaseOutlinePaint((java.awt.Paint) color18, true);
        java.lang.Class<?> wildcardClass22 = xYStepRenderer2.getClass();
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass22);
        java.io.InputStream inputStream24 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("index.html", (java.lang.Class) wildcardClass22);
        boolean boolean25 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(uRL23);
        org.junit.Assert.assertNull(inputStream24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        double double12 = labelBlock11.getContentYOffset();
        java.awt.Font font13 = labelBlock11.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(7, axisLocation7, false);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYSeries1.equals((java.lang.Object) xYStepRenderer8);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer8.setSeriesItemLabelFont(8, font11, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator16 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str19 = legendItem18.getURLText();
        java.awt.Paint paint20 = legendItem18.getLabelPaint();
        boolean boolean21 = standardXYURLGenerator16.equals((java.lang.Object) legendItem18);
        xYStepRenderer8.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot4.getDomainAxis();
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainCrosshairStroke();
        combinedDomainXYPlot4.clearDomainMarkers(2);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D16.setTickLabelsVisible(true);
        boolean boolean19 = logAxis15.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape22 = xYAreaRenderer20.lookupSeriesShape((int) (short) -1);
        logAxis15.setDownArrow(shape22);
        logAxis15.setNegativeArrowVisible(false);
        try {
            combinedDomainXYPlot4.setDomainAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) logAxis15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        crosshairState0.updateCrosshairY((double) 1L, (int) (byte) -1);
        crosshairState0.setCrosshairX(0.12d);
        int int8 = crosshairState0.getRangeAxisIndex();
        crosshairState0.updateCrosshairX((double) 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100);
        double double4 = range2.constrain((double) (short) -1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        boolean boolean3 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        barRenderer3D0.setShadowYOffset((double) 900000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(itemLabelPosition4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Other", graphics2D1, (float) (short) 1, (float) 15, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Shape shape11 = xYAreaRenderer0.getLegendArea();
        xYAreaRenderer0.removeAnnotations();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) 100);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) 0);
        segmentedTimeline0.setAdjustForDaylightSaving(true);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segment4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        ringPlot7.setCircular(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, valueAxis13, polarItemRenderer14);
        boolean boolean17 = polarPlot15.equals((java.lang.Object) 100.0f);
        java.awt.Color color18 = java.awt.Color.lightGray;
        polarPlot15.setAngleGridlinePaint((java.awt.Paint) color18);
        ringPlot7.setLabelOutlinePaint((java.awt.Paint) color18);
        double double21 = ringPlot7.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-5d + "'", double21 == 1.0E-5d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        int int16 = timeSeriesCollection13.getSeriesCount();
        int int17 = timeSeriesCollection13.getSeriesCount();
        org.jfree.data.Range range19 = timeSeriesCollection13.getDomainBounds(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        java.util.List list3 = categoryPlot0.getCategories();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = xYAreaRenderer0.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        chartEntity5.setURLText("index.html");
        java.lang.String str8 = chartEntity5.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartEntity: tooltip = -∞" + "'", str8.equals("ChartEntity: tooltip = -∞"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Font font7 = xYStepRenderer0.getLegendTextFont(7);
        boolean boolean8 = xYStepRenderer0.getBaseShapesFilled();
        java.awt.Paint paint10 = xYStepRenderer0.getSeriesFillPaint((int) (byte) -1);
        xYStepRenderer0.setBaseShapesVisible(false);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        java.lang.String str2 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str2.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = null;
        boolean boolean2 = strokeMap0.equals(obj1);
        java.awt.Stroke stroke4 = strokeMap0.getStroke((java.lang.Comparable) Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        boolean boolean9 = polarPlot7.equals((java.lang.Object) 100.0f);
        java.awt.Color color10 = java.awt.Color.lightGray;
        polarPlot7.setAngleGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font2, (java.awt.Paint) color10);
        java.awt.Paint paint13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("hi!", font2, paint13);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            double double3 = timeSeriesCollection0.getEndYValue((int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        combinedDomainXYPlot4.setRangeZeroBaselineVisible(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        int int18 = xYSeriesCollection16.indexOf((java.lang.Comparable) (short) 0);
        double double20 = xYSeriesCollection16.getRangeUpperBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedDomainXYPlot4.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint24);
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        logAxis27.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = combinedDomainXYPlot30.getRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D32 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = null;
        barRenderer3D32.setBaseToolTipGenerator(categoryToolTipGenerator33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = null;
        org.jfree.chart.axis.LogAxis logAxis38 = new org.jfree.chart.axis.LogAxis("");
        logAxis38.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot41 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis38);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer44 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint46 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer44.setSeriesOutlinePaint((int) (byte) 10, paint46, false);
        java.awt.Stroke stroke49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D32.drawRangeLine(graphics2D35, categoryPlot36, (org.jfree.chart.axis.ValueAxis) logAxis38, rectangle2D42, (double) (short) 0, paint46, stroke49);
        combinedDomainXYPlot30.setRangeZeroBaselineStroke(stroke49);
        intervalMarker25.setStroke(stroke49);
        combinedDomainXYPlot4.setRangeMinorGridlineStroke(stroke49);
        java.util.List list54 = combinedDomainXYPlot4.getSubplots();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.axis.LogAxis logAxis58 = new org.jfree.chart.axis.LogAxis("");
        logAxis58.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot61 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis58);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = combinedDomainXYPlot61.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis64 = combinedDomainXYPlot61.getDomainAxis(3);
        combinedDomainXYPlot61.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D68 = combinedDomainXYPlot61.getQuadrantOrigin();
        try {
            combinedDomainXYPlot4.zoomRangeAxes(0.0d, plotRenderingInfo56, point2D68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(xYItemRenderer31);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNull(xYItemRenderer62);
        org.junit.Assert.assertNull(valueAxis64);
        org.junit.Assert.assertNotNull(point2D68);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        double double5 = ringPlot1.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot1.getLegendLabelURLGenerator();
        boolean boolean7 = gradientXYBarPainter0.equals((java.lang.Object) pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.14d + "'", double5 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("item");
        java.awt.Font font3 = textFragment2.getFont();
        java.awt.Font font4 = textFragment2.getFont();
        textLine0.removeFragment(textFragment2);
        org.jfree.chart.text.TextFragment textFragment6 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(textFragment6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        java.util.List list3 = categoryPlot0.getCategories();
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(list3);
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        categoryPlot0.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace12);
        int int14 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 100L, (float) 8, textAnchor4, 0.2d, textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        java.awt.Stroke stroke19 = logAxis6.getTickMarkStroke();
        java.lang.String str20 = logAxis6.getLabel();
        logAxis6.zoomRange(0.14d, 8.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false, false);
        double double4 = xYSeries3.getMinY();
        xYSeries3.add(0.12d, (double) (-10));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 7);
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot4.getDomainMinorGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot4.getRangeAxis(12);
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis();
        logAxis10.setLowerBound((double) 5);
        combinedDomainXYPlot4.setRangeAxis(68, (org.jfree.chart.axis.ValueAxis) logAxis10);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        labelBlock11.setPadding(0.0d, (-1.0d), 0.0d, 1.0E-8d);
        double double17 = labelBlock11.getContentYOffset();
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        labelBlock11.setFont(font18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, (double) 2);
        try {
            org.jfree.chart.util.Size2D size2D24 = labelBlock11.arrange(graphics2D20, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape8 = xYAreaRenderer6.lookupSeriesShape((int) (short) -1);
        logAxis1.setDownArrow(shape8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.data.xy.XYDataItem xYDataItem15 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape8, pieDataset10, (int) (short) 0, 0, (java.lang.Comparable) xYDataItem15, "org.jfree.data.UnknownKeyException: hi!", "HorizontalAlignment.CENTER");
        java.lang.Comparable comparable19 = pieSectionEntity18.getSectionKey();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(comparable19);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Font font7 = xYStepRenderer0.getLegendTextFont(7);
        boolean boolean8 = xYStepRenderer0.getBaseShapesFilled();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean7 = logFormat6.isParseIntegerOnly();
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Object obj10 = logFormat6.parseObject("", parsePosition9);
        int int11 = logFormat6.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean17 = logFormat16.isParseIntegerOnly();
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat16.parseObject("", parsePosition19);
        int int21 = logFormat16.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat16);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator22, xYURLGenerator23);
        java.awt.Paint paint25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean26 = standardXYToolTipGenerator22.equals((java.lang.Object) paint25);
        java.lang.Object obj27 = standardXYToolTipGenerator22.clone();
        boolean boolean29 = standardXYToolTipGenerator22.equals((java.lang.Object) 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 0, (double) 0.0f, 0.0d, (double) (short) 100);
        org.jfree.data.RangeType rangeType5 = org.jfree.data.RangeType.NEGATIVE;
        boolean boolean6 = blockBorder4.equals((java.lang.Object) rangeType5);
        org.jfree.chart.util.LogFormat logFormat13 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean14 = logFormat13.isParseIntegerOnly();
        java.text.ParsePosition parsePosition16 = null;
        java.lang.Object obj17 = logFormat13.parseObject("", parsePosition16);
        int int18 = logFormat13.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat23 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean24 = logFormat23.isParseIntegerOnly();
        java.text.ParsePosition parsePosition26 = null;
        java.lang.Object obj27 = logFormat23.parseObject("", parsePosition26);
        int int28 = logFormat23.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator29 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat13, (java.text.NumberFormat) logFormat23);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer31 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator29, xYURLGenerator30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean33 = standardXYToolTipGenerator29.equals((java.lang.Object) paint32);
        boolean boolean34 = rangeType5.equals((java.lang.Object) boolean33);
        org.junit.Assert.assertNotNull(rangeType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent14);
        java.awt.geom.Point2D point2D16 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("Other");
        combinedDomainXYPlot4.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis19, false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries23.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries23.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Date date32 = year30.getStart();
        dateAxis19.setMinimumDate(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32);
        java.lang.String str35 = day34.toString();
        long long36 = day34.getFirstMillisecond();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1-January-2019" + "'", str35.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean7 = logFormat6.isParseIntegerOnly();
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Object obj10 = logFormat6.parseObject("", parsePosition9);
        int int11 = logFormat6.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean17 = logFormat16.isParseIntegerOnly();
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat16.parseObject("", parsePosition19);
        int int21 = logFormat16.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat16);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator22, xYURLGenerator23);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator27 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str30 = legendItem29.getURLText();
        java.awt.Paint paint31 = legendItem29.getLabelPaint();
        boolean boolean32 = standardXYURLGenerator27.equals((java.lang.Object) legendItem29);
        try {
            xYAreaRenderer24.setSeriesURLGenerator((-5), (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        boolean boolean3 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        int int5 = barRenderer3D0.getRowCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        double double4 = ringPlot3.getInnerSeparatorExtension();
        boolean boolean5 = ringPlot3.getIgnoreZeroValues();
        java.awt.Paint paint6 = ringPlot3.getLabelOutlinePaint();
        categoryPlot2.setRangeMinorGridlinePaint(paint6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot2.removeDomainMarker(0, marker9, layer10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot14.getIgnoreZeroValues();
        boolean boolean16 = ringPlot14.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        ringPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = ringPlot14.getDrawingSupplier();
        org.jfree.data.xy.XYDataItem xYDataItem22 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        java.lang.Number number23 = xYDataItem22.getX();
        java.awt.Stroke stroke24 = null;
        ringPlot14.setSectionOutlineStroke((java.lang.Comparable) xYDataItem22, stroke24);
        categoryPlot2.setDomainCrosshairColumnKey((java.lang.Comparable) xYDataItem22, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot29 = categoryAxis3D28.getPlot();
        categoryPlot2.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D28);
        double double31 = categoryAxis3D28.getLowerMargin();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepRenderer2.getSeriesPositiveItemLabelPosition(5);
        java.awt.Color color10 = java.awt.Color.green;
        boolean boolean11 = xYStepRenderer2.equals((java.lang.Object) color10);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYBarRenderer0.getPositiveItemLabelPositionFallback();
        double double2 = xYBarRenderer0.getShadowYOffset();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        intervalMarker3.notifyListeners(markerChangeEvent4);
        double double6 = intervalMarker3.getStartValue();
        org.jfree.chart.util.StrokeMap strokeMap7 = new org.jfree.chart.util.StrokeMap();
        java.awt.Stroke stroke9 = null;
        strokeMap7.put((java.lang.Comparable) 0.05d, stroke9);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle11.setMargin(rectangleInsets12);
        java.awt.Font font14 = textTitle11.getFont();
        boolean boolean15 = strokeMap7.equals((java.lang.Object) font14);
        intervalMarker3.setLabelFont(font14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot0.getDrawingSupplier();
        boolean boolean6 = ringPlot0.getSimpleLabels();
        ringPlot0.setBackgroundImageAlignment((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        xYStepRenderer0.setBaseSeriesVisibleInLegend(false, true);
        xYStepRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        double double6 = textTitle0.getContentYOffset();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYStepRenderer8.setSeriesURLGenerator(100, xYURLGenerator10);
        xYStepRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        boolean boolean16 = xYStepRenderer8.hasListener((java.util.EventListener) ringPlot15);
        ringPlot15.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        ringPlot15.handleClick(1, (int) 'a', plotRenderingInfo21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot15);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle24.setMargin(rectangleInsets25);
        textTitle24.setVisible(false);
        jFreeChart23.removeSubtitle((org.jfree.chart.title.Title) textTitle24);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis3D30.getCategoryStart(3, (int) (byte) 10, rectangle2D34, rectangleEdge35);
        java.awt.Font font38 = categoryAxis3D30.getTickLabelFont((java.lang.Comparable) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent39 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D30);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = axisChangeEvent39.getType();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection42 = chartRenderingInfo41.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot(pieDataset43);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator45 = null;
        ringPlot44.setLegendLabelURLGenerator(pieURLGenerator45);
        ringPlot44.setInnerSeparatorExtension(0.0d);
        boolean boolean49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo41, (java.lang.Object) ringPlot44);
        java.awt.Paint paint50 = ringPlot44.getLabelShadowPaint();
        boolean boolean51 = chartChangeEventType40.equals((java.lang.Object) paint50);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle0, jFreeChart23, chartChangeEventType40);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(chartChangeEventType40);
        org.junit.Assert.assertNotNull(entityCollection42);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = xYStepRenderer0.lookupLegendTextFont(0);
        xYStepRenderer0.setDefaultEntityRadius(100);
        boolean boolean5 = xYStepRenderer0.getUseFillPaint();
        xYStepRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYStepRenderer0.getSeriesItemLabelGenerator((int) (byte) 0);
        xYStepRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        java.lang.Object obj11 = textTitle0.clone();
        boolean boolean12 = textTitle0.getExpandToFitSpace();
        textTitle0.setExpandToFitSpace(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = xYItemRendererState1.getInfo();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState3 = null;
        xYItemRendererState1.setCrosshairState(xYCrosshairState3);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection();
        xYItemRendererState1.startSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection5, (-1), 68, 8, 15, (int) (byte) 0);
        try {
            timeSeriesCollection5.setSelected((int) (byte) 1, 0, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        polarPlot7.zoomDomainAxes((double) 100.0f, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = combinedDomainXYPlot17.getRenderer();
        java.awt.Stroke stroke19 = combinedDomainXYPlot17.getDomainMinorGridlineStroke();
        polarPlot7.setRadiusGridlineStroke(stroke19);
        categoryPlot0.setRangeZeroBaselineStroke(stroke19);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        barRenderer3D22.setBaseToolTipGenerator(categoryToolTipGenerator23);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = barRenderer3D22.getGradientPaintTransformer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = barRenderer3D22.getBaseURLGenerator();
        boolean boolean27 = categoryPlot0.equals((java.lang.Object) barRenderer3D22);
        double double28 = barRenderer3D22.getShadowXOffset();
        java.awt.Paint paint30 = barRenderer3D22.getLegendTextPaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer25);
        org.junit.Assert.assertNull(categoryURLGenerator26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
        org.junit.Assert.assertNull(paint30);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer3D0.getBaseURLGenerator();
        java.awt.Font font5 = barRenderer3D0.getLegendTextFont(9999);
        java.lang.Boolean boolean7 = barRenderer3D0.getSeriesItemLabelsVisible(2958465);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getLibraries();
        java.awt.Image image2 = null;
        projectInfo0.setLogo(image2);
        java.awt.Image image4 = projectInfo0.getLogo();
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        logAxis2.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis2);
        logAxis2.setLowerMargin(0.05d);
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean13 = logFormat12.isParseIntegerOnly();
        java.text.ParsePosition parsePosition15 = null;
        java.lang.Object obj16 = logFormat12.parseObject("", parsePosition15);
        int int17 = logFormat12.getMinimumIntegerDigits();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean20 = xYStepRenderer18.getSeriesLinesVisible((int) (byte) 0);
        java.lang.String str21 = logFormat12.format((java.lang.Object) (byte) 0);
        logAxis2.setNumberFormatOverride((java.text.NumberFormat) logFormat12);
        org.jfree.chart.util.LogFormat logFormat27 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean28 = logFormat27.isParseIntegerOnly();
        java.text.ParsePosition parsePosition30 = null;
        java.lang.Object obj31 = logFormat27.parseObject("", parsePosition30);
        java.lang.Object obj32 = null;
        boolean boolean33 = logFormat27.equals(obj32);
        logFormat27.setParseIntegerOnly(true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("0.58", (java.text.NumberFormat) logFormat12, (java.text.NumberFormat) logFormat27);
        boolean boolean37 = logFormat27.isGroupingUsed();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-∞" + "'", str21.equals("-∞"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        java.awt.Stroke stroke19 = logAxis6.getTickMarkStroke();
        java.lang.String str20 = logAxis6.getLabel();
        org.jfree.data.Range range21 = null;
        try {
            logAxis6.setRangeWithMargins(range21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        xYStepRenderer0.drawRangeMarker(graphics2D1, xYPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Paint paint7 = xYStepRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries16);
        int int18 = timeSeriesCollection17.getSeriesCount();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor19 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        timeSeriesCollection17.setXPosition(timePeriodAnchor19);
        timeSeriesCollection13.setXPosition(timePeriodAnchor19);
        try {
            int int23 = timeSeriesCollection13.getItemCount((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor19);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("-∞", graphics2D1, (float) 1, (float) 644288400000L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot4.getDomainMarkers(layer12);
        combinedDomainXYPlot4.configureDomainAxes();
        java.awt.Paint paint15 = combinedDomainXYPlot4.getDomainTickBandPaint();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle0.getPosition();
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        boolean boolean3 = barRenderer3D0.getBaseSeriesVisible();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator4, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape6 = xYStepRenderer0.getLegendLine();
        boolean boolean7 = xYStepRenderer0.getBaseShapesFilled();
        boolean boolean8 = xYStepRenderer0.getBaseShapesFilled();
        xYStepRenderer0.setDrawOutlines(true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        java.awt.Paint paint22 = barRenderer3D0.getItemPaint((int) (byte) 1, (int) (short) 1, false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean6 = xYStepRenderer0.getUseFillPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        int int9 = xYSeriesCollection7.indexOf((java.lang.Comparable) (short) 0);
        double double10 = xYSeriesCollection7.getIntervalWidth();
        org.jfree.data.Range range11 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        try {
            int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection7, (int) (short) 1, 5.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean3 = xYSeries2.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries6 = xYSeries2.createCopy(2, 0);
        double[][] doubleArray7 = xYSeries2.toArray();
        xYSeries2.setDescription("Other");
        boolean boolean10 = dateTickMarkPosition0.equals((java.lang.Object) xYSeries2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(xYSeries6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean7 = polarPlot6.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot6.zoomDomainAxes((double) 100.0f, plotRenderingInfo9, point2D10);
        org.jfree.data.xy.XYDataset xYDataset12 = polarPlot6.getDataset();
        boolean boolean13 = datasetRenderingOrder1.equals((java.lang.Object) xYDataset12);
        java.lang.String str14 = datasetRenderingOrder1.toString();
        java.lang.Object obj15 = null;
        boolean boolean16 = datasetRenderingOrder1.equals(obj15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str14.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        try {
            double double16 = xYSeriesCollection8.getEndYValue((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        java.awt.Paint paint3 = multiplePiePlot1.getAggregatedItemsPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot6 = categoryAxis3D5.getPlot();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        xYStepRenderer12.setSeriesURLGenerator(100, xYURLGenerator14);
        xYStepRenderer12.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset18);
        boolean boolean20 = xYStepRenderer12.hasListener((java.util.EventListener) ringPlot19);
        java.awt.Color color22 = java.awt.Color.lightGray;
        xYStepRenderer12.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color22);
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font11, (java.awt.Paint) color22, (float) 100L, textMeasurer25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = textBlock26.calculateDimensions(graphics2D27);
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection33 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection33);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection33, valueAxis35, polarItemRenderer36);
        boolean boolean39 = polarPlot37.equals((java.lang.Object) 100.0f);
        java.awt.Color color40 = java.awt.Color.lightGray;
        polarPlot37.setAngleGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.block.LabelBlock labelBlock42 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font32, (java.awt.Paint) color40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = labelBlock42.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D44 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, (double) 1, (double) (short) 0, rectangleAnchor43);
        rectangleInsets9.trim(rectangle2D44);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle46.setMargin(rectangleInsets47);
        textTitle46.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = textTitle46.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = textTitle46.getPosition();
        org.jfree.chart.axis.AxisState axisState54 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState54.setMax(0.0d);
        axisState54.cursorDown(1.0E8d);
        categoryAxis3D5.drawTickMarks(graphics2D7, (double) 0L, rectangle2D44, rectangleEdge52, axisState54);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        int int61 = categoryPlot60.getDatasetCount();
        int int62 = categoryPlot60.getCrosshairDatasetIndex();
        java.util.List list63 = categoryPlot60.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection66 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range67 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection66);
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer69 = null;
        org.jfree.chart.plot.PolarPlot polarPlot70 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection66, valueAxis68, polarItemRenderer69);
        boolean boolean71 = polarPlot70.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Point2D point2D74 = null;
        polarPlot70.zoomDomainAxes((double) 100.0f, plotRenderingInfo73, point2D74);
        java.awt.Stroke stroke76 = polarPlot70.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        org.jfree.chart.axis.LogAxis logAxis80 = new org.jfree.chart.axis.LogAxis("");
        logAxis80.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot83 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis80);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer84 = combinedDomainXYPlot83.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis86 = combinedDomainXYPlot83.getDomainAxis(3);
        combinedDomainXYPlot83.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D90 = combinedDomainXYPlot83.getQuadrantOrigin();
        polarPlot70.zoomDomainAxes(5.0d, plotRenderingInfo78, point2D90, false);
        categoryPlot60.zoomRangeAxes(10.0d, plotRenderingInfo65, point2D90);
        org.jfree.chart.plot.PlotState plotState94 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo95 = null;
        try {
            multiplePiePlot1.draw(graphics2D4, rectangle2D44, point2D90, plotState94, plotRenderingInfo95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNull(list63);
        org.junit.Assert.assertNull(range67);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNull(xYItemRenderer84);
        org.junit.Assert.assertNull(valueAxis86);
        org.junit.Assert.assertNotNull(point2D90);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(0, marker7, layer8);
        double[] doubleArray15 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray19 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray23 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray27 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray31 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray32 = new double[][] { doubleArray15, doubleArray19, doubleArray23, doubleArray27, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray32);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset33, true);
        int int36 = categoryPlot0.indexOf(categoryDataset33);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = null;
        try {
            categoryPlot0.setInsets(rectangleInsets39, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle17.setMargin(rectangleInsets18);
        textTitle17.setVisible(false);
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        boolean boolean23 = jFreeChart16.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        boolean boolean25 = textTitle24.isVisible();
        jFreeChart16.addSubtitle((org.jfree.chart.title.Title) textTitle24);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str4 = legendItem3.getURLText();
        java.awt.Paint paint5 = legendItem3.getLabelPaint();
        boolean boolean6 = standardXYURLGenerator1.equals((java.lang.Object) legendItem3);
        java.awt.Paint paint7 = legendItem3.getFillPaint();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D9.getCategoryStart(3, (int) (byte) 10, rectangle2D13, rectangleEdge14);
        java.awt.Font font17 = categoryAxis3D9.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle8.setFont(font17);
        java.lang.Object obj19 = textTitle8.clone();
        boolean boolean20 = legendItem3.equals(obj19);
        boolean boolean21 = legendItem3.isShapeOutlineVisible();
        java.text.AttributedString attributedString22 = legendItem3.getAttributedLabel();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(attributedString22);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        java.lang.String str1 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.END" + "'", str1.equals("TimePeriodAnchor.END"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=255,b=255]");
        textTitle1.setToolTipText("java.awt.Color[r=128,g=255,b=255]");
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine0.calculateDimensions(graphics2D3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, 4.0d, Double.NaN, rectangleAnchor7);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("0.58", "0.58", "0.58", "index.html", "item");
        basicProjectInfo5.setLicenceName("HorizontalAlignment.CENTER");
        basicProjectInfo5.setInfo("0.58");
        java.lang.String str10 = basicProjectInfo5.getVersion();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.58" + "'", str10.equals("0.58"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str4 = legendItem3.getURLText();
        java.awt.Paint paint5 = legendItem3.getLabelPaint();
        boolean boolean6 = standardXYURLGenerator1.equals((java.lang.Object) legendItem3);
        java.text.AttributedString attributedString7 = legendItem3.getAttributedLabel();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(attributedString7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Shape shape5 = xYAreaRenderer0.getLegendShape((int) ' ');
        java.awt.Paint paint6 = xYAreaRenderer0.getBaseLegendTextPaint();
        boolean boolean7 = xYAreaRenderer0.getPlotArea();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(1.0E-5d, 2.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit3, true, false);
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) (short) 0, (int) (short) 0, false);
        double[] doubleArray10 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray14 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray18 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray22 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray26 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray27 = new double[][] { doubleArray10, doubleArray14, doubleArray18, doubleArray22, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28, true);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset28);
        org.jfree.data.Range range33 = barRenderer3D0.findRangeBounds(categoryDataset28, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.0d + "'", number31.equals(0.0d));
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        int int2 = xYSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("0.58", "0.58", "0.58", "index.html", "item");
        basicProjectInfo5.setLicenceName("HorizontalAlignment.CENTER");
        basicProjectInfo5.setInfo("0.58");
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str11 = projectInfo10.getName();
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo10.getOptionalLibraries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) projectInfo10);
        basicProjectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo10);
        basicProjectInfo5.addOptionalLibrary("TimePeriodAnchor.END");
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(libraryArray12);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean7 = logFormat6.isParseIntegerOnly();
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Object obj10 = logFormat6.parseObject("", parsePosition9);
        int int11 = logFormat6.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean17 = logFormat16.isParseIntegerOnly();
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat16.parseObject("", parsePosition19);
        int int21 = logFormat16.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat16);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator22, xYURLGenerator23);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator26 = xYAreaRenderer24.getSeriesItemLabelGenerator((-10));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(xYItemLabelGenerator26);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        int int1 = dateTickUnitType0.getCalendarField();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot2.getRenderer((int) (short) 0);
        categoryPlot2.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3D6.setBaseToolTipGenerator(categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        logAxis12.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer18.setSeriesOutlinePaint((int) (byte) 10, paint20, false);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D6.drawRangeLine(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D16, (double) (short) 0, paint20, stroke23);
        boolean boolean25 = logAxis12.isAxisLineVisible();
        java.awt.Paint paint26 = logAxis12.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = logAxis12.getTickLabelInsets();
        logAxis12.configure();
        categoryPlot2.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot2.getRangeAxis();
        boolean boolean31 = dateTickUnitType0.equals((java.lang.Object) categoryPlot2);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType33 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.text.DateFormat dateFormat35 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit36 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4, dateTickUnitType33, (int) (byte) 1, dateFormat35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTickUnitType33);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("PieSection: 0, 0([0.0, 100.0])", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = xYItemRendererState1.getInfo();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState3 = null;
        xYItemRendererState1.setCrosshairState(xYCrosshairState3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        double double6 = xYSeriesCollection5.getIntervalWidth();
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        xYItemRendererState1.startSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection5, 6, 10, (int) (short) 0, (int) (short) 100, 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        double double16 = ringPlot15.getInnerSeparatorExtension();
        boolean boolean17 = ringPlot15.getIgnoreZeroValues();
        java.awt.Paint paint18 = ringPlot15.getLabelOutlinePaint();
        categoryPlot14.setRangeMinorGridlinePaint(paint18);
        xYSeriesCollection5.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot14);
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = xYStepRenderer0.lookupLegendTextFont(0);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        logAxis5.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot8.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis11 = combinedDomainXYPlot8.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker12 = null;
        boolean boolean13 = combinedDomainXYPlot8.removeDomainMarker(marker12);
        java.awt.Stroke stroke14 = combinedDomainXYPlot8.getDomainGridlineStroke();
        xYStepRenderer0.setSeriesStroke(192, stroke14);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.lang.Object obj6 = combinedDomainXYPlot4.clone();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = combinedDomainXYPlot4.removeDomainMarker(marker7);
        combinedDomainXYPlot4.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        double double9 = logAxis7.calculateValue((double) 8);
        logAxis7.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot12.setRangeMinorGridlinePaint(paint13);
        logAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        java.lang.Object obj16 = null;
        boolean boolean17 = logAxis7.equals(obj16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        logAxis19.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis19);
        logAxis19.setLowerMargin(0.05d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat27 = numberAxis3D26.getNumberFormatOverride();
        org.jfree.data.RangeType rangeType28 = numberAxis3D26.getRangeType();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { logAxis7, logAxis19, numberAxis3D26 };
        categoryPlot0.setRangeAxes(valueAxisArray29);
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E8d + "'", double9 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(rangeType28);
        org.junit.Assert.assertNotNull(valueAxisArray29);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) (short) 0, (int) (short) 0, false);
        double double5 = barRenderer3D0.getShadowYOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer3D0.getSeriesToolTipGenerator(9999);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-5), "item", "-∞");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) timeSeries3, true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.awt.Stroke stroke2 = null;
        strokeMap0.put((java.lang.Comparable) 0.05d, stroke2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle4.setMargin(rectangleInsets5);
        java.awt.Font font7 = textTitle4.getFont();
        boolean boolean8 = strokeMap0.equals((java.lang.Object) font7);
        java.lang.Object obj9 = strokeMap0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYBarRenderer0.getPositiveItemLabelPositionFallback();
        boolean boolean2 = xYBarRenderer0.getUseYInterval();
        xYBarRenderer0.setDrawBarOutline(true);
        org.jfree.chart.LegendItem legendItem7 = xYBarRenderer0.getLegendItem(12, 6);
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter8 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        xYBarRenderer0.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter8);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedDomainXYPlot4.clearDomainMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getLegendItems();
        int int7 = legendItemCollection6.getItemCount();
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3D6.setBaseToolTipGenerator(categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        logAxis12.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer18.setSeriesOutlinePaint((int) (byte) 10, paint20, false);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D6.drawRangeLine(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D16, (double) (short) 0, paint20, stroke23);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape27 = xYAreaRenderer25.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape27, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator34 = null;
        xYStepRenderer32.setSeriesURLGenerator(100, xYURLGenerator34);
        xYStepRenderer32.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot(pieDataset38);
        boolean boolean40 = xYStepRenderer32.hasListener((java.util.EventListener) ringPlot39);
        ringPlot39.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        ringPlot39.handleClick(1, (int) 'a', plotRenderingInfo45);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot39);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity50 = new org.jfree.chart.entity.JFreeChartEntity(shape27, jFreeChart47, "Other", "");
        java.awt.Stroke stroke51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart47.setBorderStroke(stroke51);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D53 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot54 = categoryAxis3D53.getPlot();
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D53.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color56);
        try {
            org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem(attributedString0, "PlotOrientation.VERTICAL", "1-January-2019", "index.html", shape4, paint20, stroke51, (java.awt.Paint) color56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        combinedDomainXYPlot4.setRangeMinorGridlinesVisible(false);
        boolean boolean11 = combinedDomainXYPlot4.isDomainZoomable();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot3.setLegendLabelURLGenerator(pieURLGenerator4);
        ringPlot3.setInnerSeparatorExtension(0.0d);
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo0, (java.lang.Object) ringPlot3);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("item");
        java.awt.Font font11 = textFragment10.getFont();
        ringPlot3.setLabelFont(font11);
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent14);
        java.awt.geom.Point2D point2D16 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("Other");
        combinedDomainXYPlot4.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis19, false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries23.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries23.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Date date32 = year30.getStart();
        dateAxis19.setMinimumDate(date32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        logAxis35.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot38 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = combinedDomainXYPlot38.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis41 = combinedDomainXYPlot38.getDomainAxis(3);
        combinedDomainXYPlot38.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D45 = combinedDomainXYPlot38.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = combinedDomainXYPlot38.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = null;
        combinedDomainXYPlot38.plotChanged(plotChangeEvent48);
        java.awt.geom.Point2D point2D50 = combinedDomainXYPlot38.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("Other");
        combinedDomainXYPlot38.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis53, false);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries57.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries57.addAndOrUpdate(timeSeries62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        java.lang.Number number65 = timeSeries62.getValue((org.jfree.data.time.RegularTimePeriod) year64);
        java.util.Date date66 = year64.getStart();
        dateAxis53.setMinimumDate(date66);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date66);
        dateAxis19.setMaximumDate(date66);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(xYItemRenderer39);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(point2D45);
        org.junit.Assert.assertNull(xYItemRenderer47);
        org.junit.Assert.assertNotNull(point2D50);
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertNull(number65);
        org.junit.Assert.assertNotNull(date66);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer0.setUseFillPaint(false);
        xYStepRenderer0.setUseOutlinePaint(true);
        java.awt.Stroke stroke12 = xYStepRenderer0.getSeriesStroke(0);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYStepRenderer0.setBaseItemLabelFont(font13);
        xYStepRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Stroke stroke20 = xYStepRenderer0.getItemOutlineStroke(7, 192, true);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setAnchorValue((double) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            categoryPlot0.handleClick((-10), (-5), plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        java.awt.Paint paint11 = textTitle0.getPaint();
        org.jfree.chart.block.BlockFrame blockFrame12 = textTitle0.getFrame();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        double double14 = ringPlot13.getInnerSeparatorExtension();
        boolean boolean15 = ringPlot13.getIgnoreZeroValues();
        java.awt.Paint paint16 = ringPlot13.getLabelOutlinePaint();
        boolean boolean17 = textTitle0.equals((java.lang.Object) ringPlot13);
        textTitle0.setPadding(0.0d, (double) 1L, 0.0d, 0.14d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(blockFrame12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        polarPlot4.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection6);
        double double10 = xYSeriesCollection6.getDomainUpperBound(false);
        int int11 = xYSeriesCollection6.getSeriesCount();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) (short) 0);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer16.setSeriesOutlinePaint((int) (byte) 10, paint18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D4.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) logAxis10, rectangle2D14, (double) (short) 0, paint18, stroke21);
        boolean boolean23 = logAxis10.isAxisLineVisible();
        java.awt.Paint paint24 = logAxis10.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = logAxis10.getTickLabelInsets();
        logAxis10.configure();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot30 = categoryAxis3D29.getPlot();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer36 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = null;
        xYStepRenderer36.setSeriesURLGenerator(100, xYURLGenerator38);
        xYStepRenderer36.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot(pieDataset42);
        boolean boolean44 = xYStepRenderer36.hasListener((java.util.EventListener) ringPlot43);
        java.awt.Color color46 = java.awt.Color.lightGray;
        xYStepRenderer36.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color46);
        org.jfree.chart.text.TextMeasurer textMeasurer49 = null;
        org.jfree.chart.text.TextBlock textBlock50 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, (java.awt.Paint) color46, (float) 100L, textMeasurer49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.util.Size2D size2D52 = textBlock50.calculateDimensions(graphics2D51);
        java.awt.Font font56 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection57 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection57);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection57, valueAxis59, polarItemRenderer60);
        boolean boolean63 = polarPlot61.equals((java.lang.Object) 100.0f);
        java.awt.Color color64 = java.awt.Color.lightGray;
        polarPlot61.setAngleGridlinePaint((java.awt.Paint) color64);
        org.jfree.chart.block.LabelBlock labelBlock66 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font56, (java.awt.Paint) color64);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = labelBlock66.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D68 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) 1, (double) (short) 0, rectangleAnchor67);
        rectangleInsets33.trim(rectangle2D68);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle70.setMargin(rectangleInsets71);
        textTitle70.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = textTitle70.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = textTitle70.getPosition();
        org.jfree.chart.axis.AxisState axisState78 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState78.setMax(0.0d);
        axisState78.cursorDown(1.0E8d);
        categoryAxis3D29.drawTickMarks(graphics2D31, (double) 0L, rectangle2D68, rectangleEdge76, axisState78);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = null;
        double double85 = logAxis10.java2DToValue((double) 8, rectangle2D68, rectangleEdge84);
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        try {
            boolean boolean87 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D68, rectangle2D86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(textBlock50);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + Double.POSITIVE_INFINITY + "'", double85 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        int int18 = timeSeries17.getItemCount();
        int int19 = timeSeriesCollection13.indexOf(timeSeries17);
        java.lang.Number number21 = null;
        try {
            timeSeries17.update((int) (short) 0, number21);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) (short) 0);
        double double4 = xYSeriesCollection0.getDomainLowerBound(false);
        xYSeriesCollection0.clearSelection();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 10L);
        long long3 = year0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str3 = legendItem2.getURLText();
        java.awt.Paint paint4 = legendItem2.getLabelPaint();
        java.awt.Stroke stroke5 = legendItem2.getLineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem2.getFillPaintTransformer();
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer6);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getURLGenerator();
        double double7 = ringPlot0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot4.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        double double11 = logAxis9.calculateValue((double) 8);
        boolean boolean12 = pieLabelLinkStyle7.equals((java.lang.Object) logAxis9);
        combinedDomainXYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis9);
        logAxis9.setAutoTickUnitSelection(false, false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot18 = categoryAxis3D17.getPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D17.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color20);
        float float22 = categoryAxis3D17.getTickMarkInsideLength();
        java.awt.Font font24 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        categoryAxis3D17.setTickLabelFont((java.lang.Comparable) 10.0f, font24);
        logAxis9.setLabelFont(font24);
        java.lang.Object obj27 = null;
        boolean boolean28 = logAxis9.equals(obj27);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E8d + "'", double11 == 1.0E8d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.lang.Object obj10 = null;
        boolean boolean11 = logAxis1.equals(obj10);
        float float12 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState15.cursorUp((double) (byte) -1);
        double double18 = axisState15.getCursor();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot20 = categoryAxis3D19.getPlot();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font25 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer26 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        xYStepRenderer26.setSeriesURLGenerator(100, xYURLGenerator28);
        xYStepRenderer26.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot(pieDataset32);
        boolean boolean34 = xYStepRenderer26.hasListener((java.util.EventListener) ringPlot33);
        java.awt.Color color36 = java.awt.Color.lightGray;
        xYStepRenderer26.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color36);
        org.jfree.chart.text.TextMeasurer textMeasurer39 = null;
        org.jfree.chart.text.TextBlock textBlock40 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, (java.awt.Paint) color36, (float) 100L, textMeasurer39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock40.calculateDimensions(graphics2D41);
        java.awt.Font font46 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection47 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection47);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection47, valueAxis49, polarItemRenderer50);
        boolean boolean53 = polarPlot51.equals((java.lang.Object) 100.0f);
        java.awt.Color color54 = java.awt.Color.lightGray;
        polarPlot51.setAngleGridlinePaint((java.awt.Paint) color54);
        org.jfree.chart.block.LabelBlock labelBlock56 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font46, (java.awt.Paint) color54);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = labelBlock56.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) 1, (double) (short) 0, rectangleAnchor57);
        rectangleInsets23.trim(rectangle2D58);
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle60.setMargin(rectangleInsets61);
        textTitle60.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = textTitle60.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = textTitle60.getPosition();
        org.jfree.chart.axis.AxisState axisState68 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState68.setMax(0.0d);
        axisState68.cursorDown(1.0E8d);
        categoryAxis3D19.drawTickMarks(graphics2D21, (double) 0L, rectangle2D58, rectangleEdge66, axisState68);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer75 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator77 = null;
        xYStepRenderer75.setSeriesURLGenerator(100, xYURLGenerator77);
        xYStepRenderer75.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset81 = null;
        org.jfree.chart.plot.RingPlot ringPlot82 = new org.jfree.chart.plot.RingPlot(pieDataset81);
        boolean boolean83 = xYStepRenderer75.hasListener((java.util.EventListener) ringPlot82);
        ringPlot82.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        ringPlot82.handleClick(1, (int) 'a', plotRenderingInfo88);
        org.jfree.chart.JFreeChart jFreeChart90 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot82);
        org.jfree.chart.title.LegendTitle legendTitle91 = jFreeChart90.getLegend();
        org.jfree.chart.util.RectangleEdge rectangleEdge92 = legendTitle91.getLegendItemGraphicEdge();
        legendTitle91.setWidth(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = legendTitle91.getLegendItemGraphicEdge();
        try {
            java.util.List list96 = logAxis1.refreshTicks(graphics2D13, axisState15, rectangle2D58, rectangleEdge95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(textBlock40);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(legendTitle91);
        org.junit.Assert.assertNotNull(rectangleEdge92);
        org.junit.Assert.assertNotNull(rectangleEdge95);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ERROR : Relative To String", dateFormat1, dateFormat2);
        java.text.DateFormat dateFormat4 = standardXYToolTipGenerator3.getYDateFormat();
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer((int) (short) 0);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer16.setSeriesOutlinePaint((int) (byte) 10, paint18, false);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D4.drawRangeLine(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) logAxis10, rectangle2D14, (double) (short) 0, paint18, stroke21);
        boolean boolean23 = logAxis10.isAxisLineVisible();
        java.awt.Paint paint24 = logAxis10.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = logAxis10.getTickLabelInsets();
        logAxis10.configure();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot0.getRangeAxis();
        java.awt.Paint paint29 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(categoryItemRenderer2);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray25 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray26 = new double[][] { doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset27, true);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range31 = barRenderer3D0.findRangeBounds(categoryDataset27);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = barRenderer3D0.getSeriesURLGenerator(9999);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(categoryURLGenerator33);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        categoryPlot0.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9, true);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D16.setTickLabelsVisible(true);
        boolean boolean19 = logAxis15.equals((java.lang.Object) true);
        logAxis15.setNegativeArrowVisible(false);
        int int22 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle17.setMargin(rectangleInsets18);
        textTitle17.setVisible(false);
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection28 = chartRenderingInfo27.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot(pieDataset29);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator31 = null;
        ringPlot30.setLegendLabelURLGenerator(pieURLGenerator31);
        ringPlot30.setInnerSeparatorExtension(0.0d);
        boolean boolean35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo27, (java.lang.Object) ringPlot30);
        org.jfree.chart.RenderingSource renderingSource36 = null;
        chartRenderingInfo27.setRenderingSource(renderingSource36);
        try {
            java.awt.image.BufferedImage bufferedImage38 = jFreeChart16.createBufferedImage(500, (-10), (double) 7, (double) (short) 10, chartRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (500) and height (-10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(entityCollection28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = null;
        xYItemRendererState1.workingLine = line2D2;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, valueAxis6, polarItemRenderer7);
        xYSeriesCollection4.validateObject();
        xYItemRendererState1.endSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection4, 12, 15, (int) 'a', (int) (short) 10, 10);
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        logAxis17.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = combinedDomainXYPlot20.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot20.setFixedRangeAxisSpace(axisSpace23);
        combinedDomainXYPlot20.setRangeMinorGridlinesVisible(false);
        xYSeriesCollection4.removeChangeListener((org.jfree.data.general.DatasetChangeListener) combinedDomainXYPlot20);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertEquals((double) number28, Double.NaN, 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment((long) (short) 0);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYStepRenderer6.setSeriesURLGenerator(100, xYURLGenerator8);
        xYStepRenderer6.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        boolean boolean14 = xYStepRenderer6.hasListener((java.util.EventListener) ringPlot13);
        java.awt.Color color16 = java.awt.Color.lightGray;
        xYStepRenderer6.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color16);
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, (java.awt.Paint) color16, (float) 100L, textMeasurer19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        textBlock20.draw(graphics2D21, 0.0f, (float) 8, textBlockAnchor24, (float) (byte) 0, 100.0f, 100.0d);
        boolean boolean29 = segment3.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent14);
        java.awt.geom.Point2D point2D16 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("Other");
        combinedDomainXYPlot4.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis19, false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries23.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries23.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Date date32 = year30.getStart();
        dateAxis19.setMinimumDate(date32);
        java.util.TimeZone timeZone34 = null;
        try {
            org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date32, timeZone34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        java.lang.Object obj12 = combinedDomainXYPlot4.clone();
        combinedDomainXYPlot4.clearAnnotations();
        boolean boolean14 = combinedDomainXYPlot4.isDomainMinorGridlinesVisible();
        java.lang.String str15 = combinedDomainXYPlot4.getPlotType();
        combinedDomainXYPlot4.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Combined_Domain_XYPlot" + "'", str15.equals("Combined_Domain_XYPlot"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        crosshairState0.updateCrosshairY((double) 1L, (int) (byte) -1);
        crosshairState0.setCrosshairX(0.12d);
        int int8 = crosshairState0.getRangeAxisIndex();
        int int9 = crosshairState0.getDomainAxisIndex();
        double double10 = crosshairState0.getCrosshairY();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        try {
            textTitle0.setVerticalAlignment(verticalAlignment6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        boolean boolean8 = polarPlot7.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        polarPlot7.zoomDomainAxes((double) 100.0f, plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = combinedDomainXYPlot17.getRenderer();
        java.awt.Stroke stroke19 = combinedDomainXYPlot17.getDomainMinorGridlineStroke();
        polarPlot7.setRadiusGridlineStroke(stroke19);
        categoryPlot0.setRangeZeroBaselineStroke(stroke19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation22);
        categoryPlot0.setRangeCrosshairValue((double) 12L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean6 = xYStepRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYStepRenderer0.setSeriesToolTipGenerator((int) (byte) 1, xYToolTipGenerator8, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        legendItem1.setLineVisible(true);
        legendItem1.setToolTipText("HorizontalAlignment.CENTER");
        legendItem1.setSeriesKey((java.lang.Comparable) "ChartEntity: tooltip = -∞");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = ringPlot0.getLabelDistributor();
        java.lang.Object obj6 = null;
        boolean boolean7 = ringPlot0.equals(obj6);
        ringPlot0.clearSectionOutlinePaints(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        java.awt.Paint paint3 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) 3);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYStepRenderer6.setSeriesURLGenerator(100, xYURLGenerator8);
        xYStepRenderer6.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepRenderer6.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator15 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer6.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator15, true);
        org.jfree.chart.util.LogFormat logFormat24 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean25 = logFormat24.isParseIntegerOnly();
        java.text.ParsePosition parsePosition27 = null;
        java.lang.Object obj28 = logFormat24.parseObject("", parsePosition27);
        int int29 = logFormat24.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat34 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean35 = logFormat34.isParseIntegerOnly();
        java.text.ParsePosition parsePosition37 = null;
        java.lang.Object obj38 = logFormat34.parseObject("", parsePosition37);
        int int39 = logFormat34.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator40 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat24, (java.text.NumberFormat) logFormat34);
        xYStepRenderer6.setSeriesToolTipGenerator((int) (short) 10, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator40, false);
        boolean boolean43 = multiplePiePlot1.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        int int46 = timeSeries45.getItemCount();
        boolean boolean47 = multiplePiePlot1.equals((java.lang.Object) timeSeries45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.util.List list1 = categoryPlot0.getAnnotations();
        categoryPlot0.setRangePannable(true);
        categoryPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.lang.Object obj10 = null;
        boolean boolean11 = logAxis1.equals(obj10);
        float float12 = logAxis1.getMinorTickMarkInsideLength();
        logAxis1.setAutoRangeMinimumSize(0.14d, false);
        java.awt.Color color16 = java.awt.Color.ORANGE;
        logAxis1.setTickMarkPaint((java.awt.Paint) color16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        double double4 = multiplePiePlot3.getLimit();
        java.awt.Paint paint5 = multiplePiePlot3.getAggregatedItemsPaint();
        boolean boolean7 = multiplePiePlot3.equals((java.lang.Object) 3);
        java.awt.Paint paint8 = multiplePiePlot3.getAggregatedItemsPaint();
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("SerialDate.weekInMonthToString(): invalid code.", font1, paint8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        xYStepRenderer0.drawRangeMarker(graphics2D1, xYPlot2, valueAxis3, marker4, rectangle2D5);
        java.awt.Paint paint8 = xYStepRenderer0.lookupSeriesOutlinePaint(10);
        boolean boolean9 = xYStepRenderer0.getDrawOutlines();
        java.lang.Boolean boolean11 = xYStepRenderer0.getSeriesVisible((int) '#');
        xYStepRenderer0.setSeriesLinesVisible(1, true);
        boolean boolean17 = xYStepRenderer0.getItemShapeVisible(0, (int) (short) -1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator19 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator((int) (byte) 1, xYItemLabelGenerator19, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 10L);
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        logAxis5.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot8.getRenderer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer3D10.setBaseToolTipGenerator(categoryToolTipGenerator11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        logAxis16.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis16);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer22.setSeriesOutlinePaint((int) (byte) 10, paint24, false);
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D10.drawRangeLine(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) logAxis16, rectangle2D20, (double) (short) 0, paint24, stroke27);
        combinedDomainXYPlot8.setRangeZeroBaselineStroke(stroke27);
        java.awt.Paint paint30 = combinedDomainXYPlot8.getRangeGridlinePaint();
        int int31 = timeSeriesDataItem2.compareTo((java.lang.Object) paint30);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10L + "'", number3.equals(10L));
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        int int1 = crosshairState0.getDomainAxisIndex();
        crosshairState0.updateCrosshairY((double) (-10), (int) (short) 1);
        double double5 = crosshairState0.getAnchorX();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = xYAreaRenderer0.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYStepRenderer7.setSeriesURLGenerator(100, xYURLGenerator9);
        xYStepRenderer7.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = xYStepRenderer7.hasListener((java.util.EventListener) ringPlot14);
        ringPlot14.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        ringPlot14.handleClick(1, (int) 'a', plotRenderingInfo20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot14);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity25 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart22, "Other", "");
        boolean boolean26 = jFreeChart22.getAntiAlias();
        org.jfree.chart.event.ChartChangeListener chartChangeListener27 = null;
        try {
            jFreeChart22.removeChangeListener(chartChangeListener27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setAnchorValue((double) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge(0);
        java.awt.Paint paint6 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        int int4 = xYSeriesCollection2.indexOf((java.lang.Comparable) (short) 0);
        double double5 = xYSeriesCollection2.getIntervalWidth();
        xYSeriesCollection2.setIntervalPositionFactor(0.0d);
        boolean boolean8 = xYSeriesCollection2.isAutoWidth();
        org.jfree.data.Range range9 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setExplodePercent((java.lang.Comparable) "", (double) (byte) 1);
        ringPlot0.setLabelGap((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        textTitle0.setMaximumLinesToDisplay((int) (short) 1);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ClassContext");
        dateAxis1.zoomRange(0.05d, (double) 192);
        java.text.DateFormat dateFormat5 = null;
        dateAxis1.setDateFormatOverride(dateFormat5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        try {
            java.util.Date date8 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainGridlineStroke();
        java.lang.String str8 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(0);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle4.setMargin(rectangleInsets5);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot8 = categoryAxis3D7.getPlot();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYStepRenderer14.setSeriesURLGenerator(100, xYURLGenerator16);
        xYStepRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        boolean boolean22 = xYStepRenderer14.hasListener((java.util.EventListener) ringPlot21);
        java.awt.Color color24 = java.awt.Color.lightGray;
        xYStepRenderer14.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color24);
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, (java.awt.Paint) color24, (float) 100L, textMeasurer27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = textBlock28.calculateDimensions(graphics2D29);
        java.awt.Font font34 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection35 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection35, valueAxis37, polarItemRenderer38);
        boolean boolean41 = polarPlot39.equals((java.lang.Object) 100.0f);
        java.awt.Color color42 = java.awt.Color.lightGray;
        polarPlot39.setAngleGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font34, (java.awt.Paint) color42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = labelBlock44.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) 1, (double) (short) 0, rectangleAnchor45);
        rectangleInsets11.trim(rectangle2D46);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle48.setMargin(rectangleInsets49);
        textTitle48.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = textTitle48.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = textTitle48.getPosition();
        org.jfree.chart.axis.AxisState axisState56 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState56.setMax(0.0d);
        axisState56.cursorDown(1.0E8d);
        categoryAxis3D7.drawTickMarks(graphics2D9, (double) 0L, rectangle2D46, rectangleEdge54, axisState56);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets5.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType62, lengthAdjustmentType63);
        categoryPlot0.setAxisOffset(rectangleInsets5);
        double double67 = rectangleInsets5.calculateBottomOutset((double) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType62);
        org.junit.Assert.assertNotNull(lengthAdjustmentType63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 4.0d + "'", double67 == 4.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        java.lang.String str2 = numberFormat0.format((long) 2);
        int int3 = numberFormat0.getMaximumFractionDigits();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2" + "'", str2.equals("2"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        int int1 = dateTickUnitType0.getCalendarField();
        java.lang.String str2 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DateTickUnitType.MINUTE" + "'", str2.equals("DateTickUnitType.MINUTE"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        combinedDomainXYPlot4.select(generalPath5, rectangle2D6, renderingSource7);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer3D9.setBaseToolTipGenerator(categoryToolTipGenerator10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = barRenderer3D9.getBaseURLGenerator();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        double double16 = ringPlot15.getInnerSeparatorExtension();
        boolean boolean17 = ringPlot15.getIgnoreZeroValues();
        java.awt.Paint paint18 = ringPlot15.getLabelOutlinePaint();
        categoryPlot14.setRangeMinorGridlinePaint(paint18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot14.getDomainMarkers((int) (short) -1, layer21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot14.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot24.getRenderer((int) (short) 0);
        categoryPlot24.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D28 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = null;
        barRenderer3D28.setBaseToolTipGenerator(categoryToolTipGenerator29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = null;
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        logAxis34.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot37 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis34);
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer40 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint42 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer40.setSeriesOutlinePaint((int) (byte) 10, paint42, false);
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D28.drawRangeLine(graphics2D31, categoryPlot32, (org.jfree.chart.axis.ValueAxis) logAxis34, rectangle2D38, (double) (short) 0, paint42, stroke45);
        boolean boolean47 = logAxis34.isAxisLineVisible();
        java.awt.Paint paint48 = logAxis34.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = logAxis34.getTickLabelInsets();
        logAxis34.configure();
        categoryPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot24.getRangeAxis();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        barRenderer3D9.drawRangeGridline(graphics2D13, categoryPlot14, valueAxis52, rectangle2D53, 10.0d);
        int int56 = combinedDomainXYPlot4.getRangeAxisIndex(valueAxis52);
        valueAxis52.pan((double) 12);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNull(categoryItemRenderer26);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(valueAxis52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getInnerSeparatorExtension();
        boolean boolean8 = ringPlot6.getIgnoreZeroValues();
        java.awt.Paint paint9 = ringPlot6.getLabelOutlinePaint();
        categoryPlot5.setRangeMinorGridlinePaint(paint9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot5.getDomainMarkers((int) (short) -1, layer12);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot5.getOrientation();
        xYCrosshairState0.updateCrosshairPoint(1.0E-5d, (double) 12L, 0.12d, (double) 0L, plotOrientation14);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(plotOrientation14);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean22 = logFormat21.isParseIntegerOnly();
        java.text.ParsePosition parsePosition24 = null;
        java.lang.Object obj25 = logFormat21.parseObject("", parsePosition24);
        int int26 = logFormat21.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator27 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat11, (java.text.NumberFormat) logFormat21);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27, xYURLGenerator28);
        xYStepRenderer0.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27);
        java.lang.Boolean boolean32 = xYStepRenderer0.getSeriesShapesFilled((int) (short) 10);
        boolean boolean36 = xYStepRenderer0.getItemCreateEntity((-1), 4, false);
        xYStepRenderer0.clearSeriesPaints(false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis7, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot9.zoomDomainAxes((double) 100.0f, plotRenderingInfo12, point2D13);
        java.awt.Stroke stroke15 = polarPlot9.getRadiusGridlineStroke();
        barRenderer3D0.setSeriesOutlineStroke((int) 'a', stroke15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = barRenderer3D0.getDrawingSupplier();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        double double21 = ringPlot20.getInnerSeparatorExtension();
        boolean boolean22 = ringPlot20.getIgnoreZeroValues();
        java.awt.Paint paint23 = ringPlot20.getLabelOutlinePaint();
        categoryPlot19.setRangeMinorGridlinePaint(paint23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot19.setRangeAxisLocation(7, axisLocation26, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot19.rendererChanged(rendererChangeEvent29);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        int int34 = categoryPlot33.getDatasetCount();
        categoryPlot33.setDomainCrosshairRowKey((java.lang.Comparable) 2);
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_YELLOW;
        categoryPlot33.setRangeZeroBaselinePaint((java.awt.Paint) color37);
        java.awt.Stroke stroke39 = null;
        try {
            barRenderer3D0.drawDomainLine(graphics2D18, categoryPlot19, rectangle2D31, (double) 2, (java.awt.Paint) color37, stroke39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(drawingSupplier17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        int int18 = jFreeChart16.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection22 = chartRenderingInfo21.getEntityCollection();
        jFreeChart16.handleClick((int) 'a', (int) 'a', chartRenderingInfo21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection28 = chartRenderingInfo27.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot(pieDataset29);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator31 = null;
        ringPlot30.setLegendLabelURLGenerator(pieURLGenerator31);
        ringPlot30.setInnerSeparatorExtension(0.0d);
        boolean boolean35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo27, (java.lang.Object) ringPlot30);
        org.jfree.chart.RenderingSource renderingSource36 = null;
        chartRenderingInfo27.setRenderingSource(renderingSource36);
        org.jfree.chart.entity.EntityCollection entityCollection38 = chartRenderingInfo27.getEntityCollection();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape41 = legendItem40.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection42, valueAxis44, polarItemRenderer45);
        xYSeriesCollection42.validateObject();
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection42, false);
        legendItem40.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection42);
        org.jfree.data.time.TimeSeries timeSeries51 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection52 = new org.jfree.data.time.TimeSeriesCollection(timeSeries51);
        int int53 = timeSeriesCollection52.getSeriesCount();
        xYSeriesCollection42.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection52);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        int int57 = timeSeries56.getItemCount();
        int int58 = timeSeriesCollection52.indexOf(timeSeries56);
        boolean boolean59 = chartRenderingInfo27.equals((java.lang.Object) timeSeries56);
        java.awt.image.BufferedImage bufferedImage60 = jFreeChart16.createBufferedImage(6, (int) (short) 10, 7, chartRenderingInfo27);
        org.jfree.chart.title.LegendTitle legendTitle61 = jFreeChart16.getLegend();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(entityCollection22);
        org.junit.Assert.assertNotNull(entityCollection28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(entityCollection38);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(bufferedImage60);
        org.junit.Assert.assertNull(legendTitle61);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        java.lang.Object obj12 = combinedDomainXYPlot4.clone();
        combinedDomainXYPlot4.clearAnnotations();
        combinedDomainXYPlot4.setGap(0.05d);
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        axisSpace16.setBottom((double) (short) -1);
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace16);
        java.lang.String str20 = combinedDomainXYPlot4.getPlotType();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Combined_Domain_XYPlot" + "'", str20.equals("Combined_Domain_XYPlot"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean2 = xYStepRenderer0.getSeriesVisible((int) ' ');
        java.awt.Paint paint4 = xYStepRenderer0.getSeriesItemLabelPaint((-5));
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot4.removeDomainMarker(marker8);
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainGridlineStroke();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = combinedDomainXYPlot4.removeDomainMarker((int) '4', marker12, layer13);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("lightGray");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        intervalMarker3.notifyListeners(markerChangeEvent4);
        double double6 = intervalMarker3.getStartValue();
        java.lang.Object obj7 = intervalMarker3.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        logAxis1.setLowerMargin(0.05d);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean19 = xYStepRenderer17.getSeriesLinesVisible((int) (byte) 0);
        java.lang.String str20 = logFormat11.format((java.lang.Object) (byte) 0);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat11);
        double double22 = logAxis1.getSmallestValue();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-∞" + "'", str20.equals("-∞"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-100d + "'", double22 == 1.0E-100d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        xYSeries1.setNotify(true);
        double double14 = xYSeries1.getMaxX();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.getIgnoreZeroValues();
        java.awt.Image image3 = ringPlot1.getBackgroundImage();
        boolean boolean4 = domainOrder0.equals((java.lang.Object) image3);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment((long) (short) 0);
        long long4 = segment3.getMillisecond();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer0.setUseFillPaint(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYStepRenderer0.setBaseToolTipGenerator(xYToolTipGenerator9);
        boolean boolean13 = xYStepRenderer0.getItemLineVisible((int) ' ', 0);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYStepRenderer18.setSeriesURLGenerator(100, xYURLGenerator20);
        xYStepRenderer18.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot(pieDataset24);
        boolean boolean26 = xYStepRenderer18.hasListener((java.util.EventListener) ringPlot25);
        java.awt.Color color28 = java.awt.Color.lightGray;
        xYStepRenderer18.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color28);
        org.jfree.chart.text.TextMeasurer textMeasurer31 = null;
        org.jfree.chart.text.TextBlock textBlock32 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, (java.awt.Paint) color28, (float) 100L, textMeasurer31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.util.Size2D size2D34 = textBlock32.calculateDimensions(graphics2D33);
        java.awt.Font font38 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection39 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer42 = null;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection39, valueAxis41, polarItemRenderer42);
        boolean boolean45 = polarPlot43.equals((java.lang.Object) 100.0f);
        java.awt.Color color46 = java.awt.Color.lightGray;
        polarPlot43.setAngleGridlinePaint((java.awt.Paint) color46);
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font38, (java.awt.Paint) color46);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = labelBlock48.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D50 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) 1, (double) (short) 0, rectangleAnchor49);
        rectangleInsets15.trim(rectangle2D50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor52);
        org.jfree.chart.axis.LogAxis logAxis55 = new org.jfree.chart.axis.LogAxis("");
        logAxis55.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot58 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis55);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = combinedDomainXYPlot58.getRenderer();
        java.awt.Stroke stroke60 = combinedDomainXYPlot58.getDomainMinorGridlineStroke();
        org.jfree.data.time.TimeSeries timeSeries61 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection62 = new org.jfree.data.time.TimeSeriesCollection(timeSeries61);
        int int63 = timeSeriesCollection62.getSeriesCount();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor64 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        timeSeriesCollection62.setXPosition(timePeriodAnchor64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState67 = xYStepRenderer0.initialise(graphics2D14, rectangle2D50, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot58, (org.jfree.data.xy.XYDataset) timeSeriesCollection62, plotRenderingInfo66);
        int int68 = xYStepRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(textBlock32);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNull(xYItemRenderer59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor64);
        org.junit.Assert.assertNotNull(xYItemRendererState67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2 + "'", int68 == 2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        int int18 = jFreeChart16.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection22 = chartRenderingInfo21.getEntityCollection();
        jFreeChart16.handleClick((int) 'a', (int) 'a', chartRenderingInfo21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection28 = chartRenderingInfo27.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot(pieDataset29);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator31 = null;
        ringPlot30.setLegendLabelURLGenerator(pieURLGenerator31);
        ringPlot30.setInnerSeparatorExtension(0.0d);
        boolean boolean35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo27, (java.lang.Object) ringPlot30);
        org.jfree.chart.RenderingSource renderingSource36 = null;
        chartRenderingInfo27.setRenderingSource(renderingSource36);
        org.jfree.chart.entity.EntityCollection entityCollection38 = chartRenderingInfo27.getEntityCollection();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape41 = legendItem40.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection42 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection42, valueAxis44, polarItemRenderer45);
        xYSeriesCollection42.validateObject();
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection42, false);
        legendItem40.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection42);
        org.jfree.data.time.TimeSeries timeSeries51 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection52 = new org.jfree.data.time.TimeSeriesCollection(timeSeries51);
        int int53 = timeSeriesCollection52.getSeriesCount();
        xYSeriesCollection42.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection52);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        int int57 = timeSeries56.getItemCount();
        int int58 = timeSeriesCollection52.indexOf(timeSeries56);
        boolean boolean59 = chartRenderingInfo27.equals((java.lang.Object) timeSeries56);
        java.awt.image.BufferedImage bufferedImage60 = jFreeChart16.createBufferedImage(6, (int) (short) 10, 7, chartRenderingInfo27);
        org.jfree.chart.event.ChartProgressListener chartProgressListener61 = null;
        jFreeChart16.removeProgressListener(chartProgressListener61);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(entityCollection22);
        org.junit.Assert.assertNotNull(entityCollection28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(entityCollection38);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(bufferedImage60);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        xYSeriesCollection3.setIntervalPositionFactor((double) (short) 0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = ringPlot0.getLabelDistributor();
        int int6 = abstractPieLabelDistributor5.getItemCount();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = java.awt.Color.getColor("0.58", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ClassContext", graphics2D1, (double) 10.0f, (float) (short) -1, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        java.awt.Paint paint3 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) 3);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYStepRenderer6.setSeriesURLGenerator(100, xYURLGenerator8);
        xYStepRenderer6.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepRenderer6.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator15 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer6.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator15, true);
        org.jfree.chart.util.LogFormat logFormat24 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean25 = logFormat24.isParseIntegerOnly();
        java.text.ParsePosition parsePosition27 = null;
        java.lang.Object obj28 = logFormat24.parseObject("", parsePosition27);
        int int29 = logFormat24.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat34 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean35 = logFormat34.isParseIntegerOnly();
        java.text.ParsePosition parsePosition37 = null;
        java.lang.Object obj38 = logFormat34.parseObject("", parsePosition37);
        int int39 = logFormat34.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator40 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat24, (java.text.NumberFormat) logFormat34);
        xYStepRenderer6.setSeriesToolTipGenerator((int) (short) 10, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator40, false);
        boolean boolean43 = multiplePiePlot1.equals((java.lang.Object) (short) 10);
        java.awt.Font font45 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font45);
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("item");
        textLine46.addFragment(textFragment48);
        java.awt.Paint paint50 = textFragment48.getPaint();
        multiplePiePlot1.setAggregatedItemsPaint(paint50);
        java.awt.Color color55 = java.awt.Color.getHSBColor((float) 10, (float) 900000L, (float) (-1));
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color55);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(color55);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        boolean boolean10 = xYStepRenderer2.hasListener((java.util.EventListener) ringPlot9);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color12);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color12, (float) 100L, textMeasurer15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean23 = timeSeries21.equals((java.lang.Object) textBlockAnchor22);
        textBlock16.draw(graphics2D17, (float) (short) 100, (float) 4, textBlockAnchor22, (float) 12, (float) 2, (double) 10.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection29 = chartRenderingInfo28.getEntityCollection();
        boolean boolean30 = textBlock16.equals((java.lang.Object) entityCollection29);
        org.jfree.chart.text.TextLine textLine31 = textBlock16.getLastLine();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(entityCollection29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(textLine31);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        logAxis1.setLowerMargin(0.05d);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean19 = xYStepRenderer17.getSeriesLinesVisible((int) (byte) 0);
        java.lang.String str20 = logFormat11.format((java.lang.Object) (byte) 0);
        logAxis1.setNumberFormatOverride((java.text.NumberFormat) logFormat11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo22);
        java.awt.geom.Line2D line2D24 = null;
        xYItemRendererState23.workingLine = line2D24;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection26, valueAxis28, polarItemRenderer29);
        xYSeriesCollection26.validateObject();
        xYItemRendererState23.endSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection26, 12, 15, (int) 'a', (int) (short) 10, 10);
        java.lang.StringBuffer stringBuffer38 = null;
        java.text.FieldPosition fieldPosition39 = null;
        try {
            java.lang.StringBuffer stringBuffer40 = logFormat11.format((java.lang.Object) xYSeriesCollection26, stringBuffer38, fieldPosition39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-∞" + "'", str20.equals("-∞"));
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, xYPlot6, xYDataset7, plotRenderingInfo8);
        boolean boolean10 = xYItemRendererState9.getProcessVisibleItemsOnly();
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState11 = new org.jfree.chart.plot.XYCrosshairState();
        int int12 = xYCrosshairState11.getDomainAxisIndex();
        xYItemRendererState9.setCrosshairState(xYCrosshairState11);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(xYItemRendererState9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double[] doubleArray5 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray22 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D24);
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        logAxis27.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis27);
        logAxis27.setLowerMargin(0.05d);
        boolean boolean33 = logAxis27.isInverted();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D34 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator38 = barRenderer3D34.getItemLabelGenerator((int) (short) 0, (int) (short) 0, false);
        double double39 = barRenderer3D34.getShadowYOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) logAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D34);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 4.0d + "'", double39 == 4.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("PlotOrientation.VERTICAL");
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double2 = logAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        boolean boolean5 = barRenderer3D0.getItemCreateEntity((int) (byte) -1, (int) '#', true);
        double double6 = barRenderer3D0.getYOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer3D0.getPositiveItemLabelPosition(3, 0, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer3D0.getNegativeItemLabelPosition(5, (int) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray25 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray26 = new double[][] { doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset27, true);
        logAxis1.setDefaultAutoRange(range29);
        double double31 = logAxis1.getFixedAutoRange();
        logAxis1.setRangeAboutValue(8.0d, (double) 10.0f);
        logAxis1.setSmallestValue((double) 60000L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }
}

