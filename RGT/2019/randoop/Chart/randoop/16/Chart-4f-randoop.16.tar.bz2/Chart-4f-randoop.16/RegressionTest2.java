import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = xYAreaRenderer0.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset6, (int) (byte) 10, (int) (short) 1, (java.lang.Comparable) 'a', "0.58", "HorizontalAlignment.CENTER");
        org.jfree.data.xy.XYDataItem xYDataItem15 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        java.lang.Number number16 = xYDataItem15.getX();
        java.lang.Number number17 = xYDataItem15.getX();
        pieSectionEntity12.setSectionKey((java.lang.Comparable) xYDataItem15);
        java.lang.String str19 = pieSectionEntity12.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0d + "'", number16.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0d + "'", number17.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PieSection: 10, 1([0.0, 100.0])" + "'", str19.equals("PieSection: 10, 1([0.0, 100.0])"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYStepRenderer0.getBaseToolTipGenerator();
        boolean boolean13 = xYStepRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint14 = xYStepRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit3, true, false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape9 = xYAreaRenderer7.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYStepRenderer14.setSeriesURLGenerator(100, xYURLGenerator16);
        xYStepRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        boolean boolean22 = xYStepRenderer14.hasListener((java.util.EventListener) ringPlot21);
        ringPlot21.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        ringPlot21.handleClick(1, (int) 'a', plotRenderingInfo27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity32 = new org.jfree.chart.entity.JFreeChartEntity(shape9, jFreeChart29, "Other", "");
        numberAxis3D1.setLeftArrow(shape9);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection34 = new org.jfree.data.xy.XYSeriesCollection();
        int int36 = xYSeriesCollection34.indexOf((java.lang.Comparable) (short) 0);
        double double37 = xYSeriesCollection34.getIntervalWidth();
        xYSeriesCollection34.setIntervalPositionFactor(0.0d);
        org.jfree.chart.entity.XYItemEntity xYItemEntity44 = new org.jfree.chart.entity.XYItemEntity(shape9, (org.jfree.data.xy.XYDataset) xYSeriesCollection34, (-1), (int) (short) 0, "index.html", "item");
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean8 = xYStepRenderer0.getItemShapeVisible((-10), 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        java.awt.Stroke stroke10 = polarPlot4.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = combinedDomainXYPlot17.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis20 = combinedDomainXYPlot17.getDomainAxis(3);
        combinedDomainXYPlot17.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D24 = combinedDomainXYPlot17.getQuadrantOrigin();
        polarPlot4.zoomDomainAxes(5.0d, plotRenderingInfo12, point2D24, false);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_RED;
        polarPlot4.setRadiusGridlinePaint((java.awt.Paint) color27);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo34 = new org.jfree.chart.ui.BasicProjectInfo("0.58", "0.58", "0.58", "index.html", "item");
        basicProjectInfo34.setLicenceName("HorizontalAlignment.CENTER");
        org.jfree.chart.ui.Library[] libraryArray37 = basicProjectInfo34.getLibraries();
        boolean boolean38 = polarPlot4.equals((java.lang.Object) libraryArray37);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(libraryArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance();
        java.lang.String str3 = numberFormat1.format((long) 2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (-2208960000000L), numberFormat1, 6);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2" + "'", str3.equals("2"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean8 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        logAxis10.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = combinedDomainXYPlot13.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis16 = combinedDomainXYPlot13.getDomainAxis(3);
        combinedDomainXYPlot13.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D20 = combinedDomainXYPlot13.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedDomainXYPlot13.getRenderer(10);
        combinedDomainXYPlot13.setRangeZeroBaselineVisible(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection25 = new org.jfree.data.xy.XYSeriesCollection();
        int int27 = xYSeriesCollection25.indexOf((java.lang.Comparable) (short) 0);
        double double29 = xYSeriesCollection25.getRangeUpperBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = combinedDomainXYPlot13.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer37 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = null;
        xYStepRenderer37.setSeriesURLGenerator(100, xYURLGenerator39);
        xYStepRenderer37.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot(pieDataset43);
        boolean boolean45 = xYStepRenderer37.hasListener((java.util.EventListener) ringPlot44);
        java.awt.Color color47 = java.awt.Color.lightGray;
        xYStepRenderer37.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color47);
        org.jfree.chart.text.TextMeasurer textMeasurer50 = null;
        org.jfree.chart.text.TextBlock textBlock51 = org.jfree.chart.text.TextUtilities.createTextBlock("", font36, (java.awt.Paint) color47, (float) 100L, textMeasurer50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.util.Size2D size2D53 = textBlock51.calculateDimensions(graphics2D52);
        java.awt.Font font57 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection58 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range59 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection58);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection58, valueAxis60, polarItemRenderer61);
        boolean boolean64 = polarPlot62.equals((java.lang.Object) 100.0f);
        java.awt.Color color65 = java.awt.Color.lightGray;
        polarPlot62.setAngleGridlinePaint((java.awt.Paint) color65);
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font57, (java.awt.Paint) color65);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = labelBlock67.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D69 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D53, (double) 1, (double) (short) 0, rectangleAnchor68);
        rectangleInsets34.trim(rectangle2D69);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D72 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D69, rectangleAnchor71);
        combinedDomainXYPlot13.zoomDomainAxes(2.0d, (double) 9999, plotRenderingInfo33, point2D72);
        try {
            combinedDomainXYPlot4.zoomRangeAxes((double) 2, 0.14d, plotRenderingInfo8, point2D72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(xYItemRenderer14);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(textBlock51);
        org.junit.Assert.assertNotNull(size2D53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNull(range59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(point2D72);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = xYStepRenderer0.lookupLegendTextFont(0);
        java.awt.Shape shape6 = xYStepRenderer0.getItemShape(9999, 1, true);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        xYSeries1.add((java.lang.Number) 1L, (java.lang.Number) 0.05d, true);
        double double10 = xYSeries1.getMaxY();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYStepRenderer8.setSeriesURLGenerator(100, xYURLGenerator10);
        xYStepRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        boolean boolean16 = xYStepRenderer8.hasListener((java.util.EventListener) ringPlot15);
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer8.setBaseItemLabelPaint(paint17, false);
        combinedDomainXYPlot4.setRangeTickBandPaint(paint17);
        java.awt.Paint paint21 = combinedDomainXYPlot4.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        logAxis23.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = combinedDomainXYPlot26.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = combinedDomainXYPlot26.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot26.setFixedRangeAxisSpace(axisSpace29);
        java.lang.Object obj31 = axisSpace29.clone();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace29, false);
        java.lang.String str34 = combinedDomainXYPlot4.getPlotType();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Combined_Domain_XYPlot" + "'", str34.equals("Combined_Domain_XYPlot"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        logAxis2.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = combinedDomainXYPlot5.getRenderer();
        java.awt.Stroke stroke7 = combinedDomainXYPlot5.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        double double12 = logAxis10.calculateValue((double) 8);
        boolean boolean13 = pieLabelLinkStyle8.equals((java.lang.Object) logAxis10);
        combinedDomainXYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis10);
        logAxis10.setAutoTickUnitSelection(false, false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot19 = categoryAxis3D18.getPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D18.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color21);
        float float23 = categoryAxis3D18.getTickMarkInsideLength();
        java.awt.Font font25 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        categoryAxis3D18.setTickLabelFont((java.lang.Comparable) 10.0f, font25);
        logAxis10.setLabelFont(font25);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        double double30 = multiplePiePlot29.getLimit();
        java.awt.Paint paint31 = multiplePiePlot29.getAggregatedItemsPaint();
        boolean boolean33 = multiplePiePlot29.equals((java.lang.Object) 3);
        java.awt.Paint paint34 = multiplePiePlot29.getAggregatedItemsPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer36 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("0.19", font25, paint34, 2.0f, textMeasurer36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0E8d + "'", double12 == 1.0E8d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean2 = xYStepRenderer0.getSeriesVisible((int) ' ');
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        logAxis4.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis4);
        combinedDomainXYPlot7.clearDomainMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot7.getLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace10 = new org.jfree.chart.axis.AxisSpace();
        axisSpace10.setBottom((double) (short) -1);
        combinedDomainXYPlot7.setFixedDomainAxisSpace(axisSpace10);
        xYStepRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedDomainXYPlot7);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getDomainMarkers((int) (short) -1, layer7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        java.lang.String str10 = plotOrientation9.toString();
        org.jfree.data.xy.XYSeries xYSeries12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean13 = xYSeries12.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries16 = xYSeries12.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        xYSeries12.addChangeListener(seriesChangeListener17);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer19 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean20 = xYSeries12.equals((java.lang.Object) xYStepRenderer19);
        java.awt.Font font22 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer19.setSeriesItemLabelFont(8, font22, true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer26 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        xYStepRenderer26.setSeriesURLGenerator(100, xYURLGenerator28);
        xYStepRenderer26.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepRenderer26.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator35 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer26.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator35, true);
        xYStepRenderer19.setSeriesURLGenerator((int) (byte) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator35, false);
        boolean boolean40 = plotOrientation9.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PlotOrientation.VERTICAL" + "'", str10.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(xYSeries16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        boolean boolean2 = xYBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            categoryPlot0.handleClick(68, (int) (short) -1, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) 100);
        java.util.Date date3 = segment2.getDate();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean22 = logFormat21.isParseIntegerOnly();
        java.text.ParsePosition parsePosition24 = null;
        java.lang.Object obj25 = logFormat21.parseObject("", parsePosition24);
        int int26 = logFormat21.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator27 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat11, (java.text.NumberFormat) logFormat21);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27, xYURLGenerator28);
        xYStepRenderer0.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        boolean boolean32 = ringPlot31.getIgnoreZeroValues();
        java.awt.Paint paint33 = ringPlot31.getBackgroundPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle34 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        ringPlot31.setLabelLinkStyle(pieLabelLinkStyle34);
        boolean boolean36 = standardXYToolTipGenerator27.equals((java.lang.Object) ringPlot31);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer38 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator40 = null;
        xYStepRenderer38.setSeriesURLGenerator(100, xYURLGenerator40);
        xYStepRenderer38.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = xYStepRenderer38.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator47 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer38.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator47, true);
        org.jfree.chart.util.LogFormat logFormat56 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean57 = logFormat56.isParseIntegerOnly();
        java.text.ParsePosition parsePosition59 = null;
        java.lang.Object obj60 = logFormat56.parseObject("", parsePosition59);
        int int61 = logFormat56.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat66 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean67 = logFormat66.isParseIntegerOnly();
        java.text.ParsePosition parsePosition69 = null;
        java.lang.Object obj70 = logFormat66.parseObject("", parsePosition69);
        int int71 = logFormat66.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator72 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat56, (java.text.NumberFormat) logFormat66);
        xYStepRenderer38.setSeriesToolTipGenerator((int) (short) 10, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator72, false);
        java.awt.Paint paint76 = xYStepRenderer38.lookupSeriesPaint(4);
        ringPlot31.setSectionPaint((java.lang.Comparable) 5, paint76);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(obj60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(obj70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(paint76);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart16.getLegend();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle17.getLegendItemGraphicEdge();
        legendTitle17.setWidth(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle17.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.Range range23 = null;
        org.jfree.data.Range range25 = org.jfree.data.Range.expandToInclude(range23, (double) 100);
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) 10L);
        double double28 = range25.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range25, (double) 3);
        org.jfree.chart.util.Size2D size2D31 = legendTitle17.arrange(graphics2D22, rectangleConstraint30);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendTitle17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(size2D31);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries3.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.addAndOrUpdate(timeSeries8);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        logAxis11.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot14.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis17 = combinedDomainXYPlot14.getDomainAxis(3);
        combinedDomainXYPlot14.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D21 = combinedDomainXYPlot14.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedDomainXYPlot14.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = null;
        combinedDomainXYPlot14.plotChanged(plotChangeEvent24);
        java.awt.geom.Point2D point2D26 = combinedDomainXYPlot14.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("Other");
        combinedDomainXYPlot14.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis29, false);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries33.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries33.addAndOrUpdate(timeSeries38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.Number number41 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) year40);
        java.util.Date date42 = year40.getStart();
        dateAxis29.setMinimumDate(date42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) day44, (org.jfree.data.time.RegularTimePeriod) year45);
        int int47 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day44);
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat3 = numberAxis3D2.getNumberFormatOverride();
        boolean boolean4 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYStepRenderer6.setSeriesURLGenerator(100, xYURLGenerator8);
        xYStepRenderer6.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        boolean boolean14 = xYStepRenderer6.hasListener((java.util.EventListener) ringPlot13);
        ringPlot13.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        ringPlot13.handleClick(1, (int) 'a', plotRenderingInfo19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot13);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle22.setMargin(rectangleInsets23);
        textTitle22.setVisible(false);
        jFreeChart21.removeSubtitle((org.jfree.chart.title.Title) textTitle22);
        boolean boolean28 = jFreeChart21.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis3D2, jFreeChart21);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart21, (int) (short) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        xYSeries1.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D12.setTickLabelsVisible(true);
        boolean boolean15 = logAxis11.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape18 = xYAreaRenderer16.lookupSeriesShape((int) (short) -1);
        logAxis11.setDownArrow(shape18);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.data.xy.XYDataItem xYDataItem25 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity28 = new org.jfree.chart.entity.PieSectionEntity(shape18, pieDataset20, (int) (short) 0, 0, (java.lang.Comparable) xYDataItem25, "org.jfree.data.UnknownKeyException: hi!", "HorizontalAlignment.CENTER");
        xYDataItem25.setY((java.lang.Number) 100);
        xYSeries1.add(xYDataItem25, false);
        xYDataItem25.setY((java.lang.Number) 0.12d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        xYAreaRenderer0.setOutline(true);
        xYAreaRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator8, false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setAnchorValue((double) '4');
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxis(12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        labelBlock11.setPadding(0.0d, (-1.0d), 0.0d, 1.0E-8d);
        double double17 = labelBlock11.getContentYOffset();
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        labelBlock11.setFont(font18);
        labelBlock11.setMargin(0.0d, (double) '4', (double) 68, (double) '4');
        double double25 = labelBlock11.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setTickLabelsVisible(true);
        categoryAxis3D0.setCategoryMargin((double) ' ');
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        logAxis6.setStandardTickUnits(tickUnitSource19);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(tickUnitSource19);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        boolean boolean10 = xYStepRenderer2.hasListener((java.util.EventListener) ringPlot9);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color12);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color12, (float) 100L, textMeasurer15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = textBlock16.calculateDimensions(graphics2D17);
        java.awt.Font font22 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection23 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection23, valueAxis25, polarItemRenderer26);
        boolean boolean29 = polarPlot27.equals((java.lang.Object) 100.0f);
        java.awt.Color color30 = java.awt.Color.lightGray;
        polarPlot27.setAngleGridlinePaint((java.awt.Paint) color30);
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font22, (java.awt.Paint) color30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = labelBlock32.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, (double) 1, (double) (short) 0, rectangleAnchor33);
        java.lang.Object obj35 = size2D18.clone();
        double double36 = size2D18.getHeight();
        size2D18.width = (byte) 1;
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYBarRenderer0.getPositiveItemLabelPositionFallback();
        boolean boolean2 = xYBarRenderer0.getUseYInterval();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter3 = xYBarRenderer0.getBarPainter();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(xYBarPainter3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        logAxis4.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedDomainXYPlot7.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedDomainXYPlot7.getDomainAxis(3);
        combinedDomainXYPlot7.setDomainCrosshairValue(0.0d, false);
        combinedDomainXYPlot7.setRangePannable(true);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot7);
        boolean boolean17 = combinedDomainXYPlot7.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        logAxis20.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = combinedDomainXYPlot23.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis26 = combinedDomainXYPlot23.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker27 = null;
        boolean boolean28 = combinedDomainXYPlot23.removeDomainMarker(marker27);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis("");
        logAxis33.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot36 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = combinedDomainXYPlot36.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis39 = combinedDomainXYPlot36.getDomainAxis(3);
        combinedDomainXYPlot36.configureRangeAxes();
        java.awt.Font font44 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer45 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator47 = null;
        xYStepRenderer45.setSeriesURLGenerator(100, xYURLGenerator47);
        xYStepRenderer45.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.RingPlot ringPlot52 = new org.jfree.chart.plot.RingPlot(pieDataset51);
        boolean boolean53 = xYStepRenderer45.hasListener((java.util.EventListener) ringPlot52);
        java.awt.Color color55 = java.awt.Color.lightGray;
        xYStepRenderer45.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color55);
        org.jfree.chart.text.TextMeasurer textMeasurer58 = null;
        org.jfree.chart.text.TextBlock textBlock59 = org.jfree.chart.text.TextUtilities.createTextBlock("", font44, (java.awt.Paint) color55, (float) 100L, textMeasurer58);
        java.awt.Graphics2D graphics2D60 = null;
        org.jfree.chart.util.Size2D size2D61 = textBlock59.calculateDimensions(graphics2D60);
        java.awt.Font font65 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection66 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range67 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection66);
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer69 = null;
        org.jfree.chart.plot.PolarPlot polarPlot70 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection66, valueAxis68, polarItemRenderer69);
        boolean boolean72 = polarPlot70.equals((java.lang.Object) 100.0f);
        java.awt.Color color73 = java.awt.Color.lightGray;
        polarPlot70.setAngleGridlinePaint((java.awt.Paint) color73);
        org.jfree.chart.block.LabelBlock labelBlock75 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font65, (java.awt.Paint) color73);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor76 = labelBlock75.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D77 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D61, (double) 1, (double) (short) 0, rectangleAnchor76);
        org.jfree.chart.RenderingSource renderingSource78 = null;
        combinedDomainXYPlot36.select((double) 5, (double) 2958465, rectangle2D77, renderingSource78);
        java.awt.geom.Rectangle2D rectangle2D80 = rectangleInsets31.createInsetRectangle(rectangle2D77);
        org.jfree.chart.RenderingSource renderingSource81 = null;
        combinedDomainXYPlot23.select((double) (byte) 1, (double) (byte) 1, rectangle2D77, renderingSource81);
        try {
            combinedDomainXYPlot7.drawBackground(graphics2D18, rectangle2D77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(xYItemRenderer24);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(xYItemRenderer37);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(textBlock59);
        org.junit.Assert.assertNotNull(size2D61);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNull(range67);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(rectangleAnchor76);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangle2D80);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint2 = ringPlot0.getBackgroundPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        ringPlot0.setLabelLinkStyle(pieLabelLinkStyle3);
        ringPlot0.setStartAngle((double) (-1));
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot0.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment((long) 100);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment((long) 0);
        long long6 = segmentedTimeline0.toTimelineValue((long) (short) 10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 644288400000L + "'", long6 == 644288400000L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        jFreeChart16.clearSubtitles();
        int int18 = jFreeChart16.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection22 = chartRenderingInfo21.getEntityCollection();
        jFreeChart16.handleClick((int) 'a', (int) 'a', chartRenderingInfo21);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.setRangeCrosshairVisible(false);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot24);
        jFreeChart16.addLegend(legendTitle27);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(entityCollection22);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ClassContext");
        dateAxis1.zoomRange(0.05d, (double) 192);
        java.text.DateFormat dateFormat5 = null;
        dateAxis1.setDateFormatOverride(dateFormat5);
        dateAxis1.configure();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries9.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries9.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Date date18 = year16.getStart();
        dateAxis1.setMaximumDate(date18);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        int int16 = timeSeriesCollection13.getSeriesCount();
        org.jfree.data.Range range18 = timeSeriesCollection13.getDomainBounds(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.Comparable comparable4 = legendItemEntity3.getSeriesKey();
        legendItemEntity3.setSeriesKey((java.lang.Comparable) "java.awt.Color[r=128,g=255,b=255]");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(comparable4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        labelBlock11.setPadding(0.0d, (-1.0d), 0.0d, 1.0E-8d);
        double double17 = labelBlock11.getContentYOffset();
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        labelBlock11.setFont(font18);
        labelBlock11.setMargin(0.0d, (double) '4', (double) 68, (double) '4');
        labelBlock11.setURLText("NOID");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis7, polarItemRenderer8);
        boolean boolean10 = polarPlot9.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot9.zoomDomainAxes((double) 100.0f, plotRenderingInfo12, point2D13);
        java.awt.Stroke stroke15 = polarPlot9.getRadiusGridlineStroke();
        barRenderer3D0.setSeriesOutlineStroke((int) 'a', stroke15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = barRenderer3D0.getDrawingSupplier();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = barRenderer3D0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(drawingSupplier17);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        boolean boolean19 = logAxis6.isAxisLineVisible();
        java.awt.Paint paint20 = logAxis6.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = logAxis6.getTickLabelInsets();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape24 = legendItem23.getLine();
        logAxis6.setUpArrow(shape24);
        java.io.ObjectOutputStream objectOutputStream26 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape24, objectOutputStream26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean6 = polarPlot4.equals((java.lang.Object) 100.0f);
        polarPlot4.clearCornerTextItems();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        polarPlot4.setAxis(valueAxis8);
        boolean boolean10 = polarPlot4.isAngleLabelsVisible();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setPlotArea(true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        xYStepRenderer0.setSeriesShapesVisible((int) (short) 10, (java.lang.Boolean) false);
        java.awt.Shape shape9 = xYStepRenderer0.lookupSeriesShape((int) (short) 1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        java.awt.Stroke stroke7 = categoryPlot0.getRangeGridlineStroke();
        double double8 = categoryPlot0.getAnchorValue();
        categoryPlot0.setRangeCrosshairValue((double) 4, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = xYStepRenderer0.lookupLegendTextFont(0);
        xYStepRenderer0.setDefaultEntityRadius(100);
        java.lang.Object obj5 = xYStepRenderer0.clone();
        xYStepRenderer0.setSeriesVisibleInLegend(2958465, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = xYAreaRenderer0.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYStepRenderer7.setSeriesURLGenerator(100, xYURLGenerator9);
        xYStepRenderer7.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = xYStepRenderer7.hasListener((java.util.EventListener) ringPlot14);
        ringPlot14.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        ringPlot14.handleClick(1, (int) 'a', plotRenderingInfo20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot14);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity25 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart22, "Other", "");
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart22.setBorderStroke(stroke26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart22.setBorderStroke(stroke28);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYSeries1.equals((java.lang.Object) xYStepRenderer8);
        java.awt.Paint paint11 = xYStepRenderer8.getSeriesFillPaint(192);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent14);
        java.awt.geom.Point2D point2D16 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("Other");
        combinedDomainXYPlot4.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis19, false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries23.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries23.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Date date32 = year30.getStart();
        dateAxis19.setMinimumDate(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer35 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean37 = xYStepRenderer35.getSeriesLinesVisible((int) (byte) 0);
        xYStepRenderer35.clearSeriesStrokes(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator43 = xYStepRenderer35.getToolTipGenerator(2, 0, true);
        int int44 = day34.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar45 = null;
        try {
            long long46 = day34.getFirstMillisecond(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(boolean37);
        org.junit.Assert.assertNull(xYToolTipGenerator43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean6 = logFormat5.isParseIntegerOnly();
        java.text.ParsePosition parsePosition8 = null;
        java.lang.Object obj9 = logFormat5.parseObject("", parsePosition8);
        java.lang.Object obj10 = null;
        boolean boolean11 = logFormat5.equals(obj10);
        logFormat5.setParseIntegerOnly(true);
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        logAxis16.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis16);
        logAxis16.setLowerMargin(0.05d);
        org.jfree.chart.util.LogFormat logFormat26 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean27 = logFormat26.isParseIntegerOnly();
        java.text.ParsePosition parsePosition29 = null;
        java.lang.Object obj30 = logFormat26.parseObject("", parsePosition29);
        int int31 = logFormat26.getMinimumIntegerDigits();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer32 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.lang.Boolean boolean34 = xYStepRenderer32.getSeriesLinesVisible((int) (byte) 0);
        java.lang.String str35 = logFormat26.format((java.lang.Object) (byte) 0);
        logAxis16.setNumberFormatOverride((java.text.NumberFormat) logFormat26);
        org.jfree.chart.util.LogFormat logFormat41 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean42 = logFormat41.isParseIntegerOnly();
        java.text.ParsePosition parsePosition44 = null;
        java.lang.Object obj45 = logFormat41.parseObject("", parsePosition44);
        java.lang.Object obj46 = null;
        boolean boolean47 = logFormat41.equals(obj46);
        logFormat41.setParseIntegerOnly(true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator50 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("0.58", (java.text.NumberFormat) logFormat26, (java.text.NumberFormat) logFormat41);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator51 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Other", (java.text.NumberFormat) logFormat5, (java.text.NumberFormat) logFormat26);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-∞" + "'", str35.equals("-∞"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 500, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        xYSeriesCollection3.setIntervalPositionFactor(0.0d);
        java.lang.Object obj14 = xYSeriesCollection3.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedWidth(Double.NaN);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean6 = polarPlot4.equals((java.lang.Object) 100.0f);
        polarPlot4.clearCornerTextItems();
        polarPlot4.addCornerTextItem("RangeType.FULL");
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("Other");
        java.lang.Object obj12 = numberAxis11.clone();
        boolean boolean13 = polarPlot4.equals(obj12);
        boolean boolean14 = polarPlot4.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = polarPlot4.getOrientation();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        double double15 = intervalXYDelegate14.getIntervalWidth();
        intervalXYDelegate14.setAutoWidth(false);
        try {
            intervalXYDelegate14.setIntervalPositionFactor((double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray25 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray26 = new double[][] { doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset27, true);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range31 = barRenderer3D0.findRangeBounds(categoryDataset27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.util.TableOrder tableOrder33 = multiplePiePlot32.getDataExtractOrder();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(tableOrder33);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.Font font11 = combinedDomainXYPlot4.getNoDataMessageFont();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart16.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendTitle17.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendTitle17.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendTitle17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape8 = xYAreaRenderer6.lookupSeriesShape((int) (short) -1);
        logAxis1.setDownArrow(shape8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.data.xy.XYDataItem xYDataItem15 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape8, pieDataset10, (int) (short) 0, 0, (java.lang.Comparable) xYDataItem15, "org.jfree.data.UnknownKeyException: hi!", "HorizontalAlignment.CENTER");
        java.lang.String str19 = pieSectionEntity18.getURLText();
        org.jfree.data.general.PieDataset pieDataset20 = pieSectionEntity18.getDataset();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "HorizontalAlignment.CENTER" + "'", str19.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNull(pieDataset20);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        boolean boolean3 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYStepRenderer5.setSeriesURLGenerator(100, xYURLGenerator7);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        boolean boolean13 = xYStepRenderer5.hasListener((java.util.EventListener) ringPlot12);
        ringPlot12.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        ringPlot12.handleClick(1, (int) 'a', plotRenderingInfo18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot12);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle21.setMargin(rectangleInsets22);
        textTitle21.setVisible(false);
        jFreeChart20.removeSubtitle((org.jfree.chart.title.Title) textTitle21);
        boolean boolean27 = jFreeChart20.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis3D1, jFreeChart20);
        org.jfree.chart.util.LogFormat logFormat33 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        numberAxis3D1.setNumberFormatOverride((java.text.NumberFormat) logFormat33);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean7 = logFormat6.isParseIntegerOnly();
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Object obj10 = logFormat6.parseObject("", parsePosition9);
        int int11 = logFormat6.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean17 = logFormat16.isParseIntegerOnly();
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat16.parseObject("", parsePosition19);
        int int21 = logFormat16.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat16);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator22, xYURLGenerator23);
        java.text.DateFormat dateFormat27 = null;
        java.text.DateFormat dateFormat28 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator29 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ERROR : Relative To String", dateFormat27, dateFormat28);
        xYAreaRenderer24.setSeriesToolTipGenerator(12, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator29);
        xYAreaRenderer24.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Shape shape34 = xYAreaRenderer24.getLegendShape(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(shape34);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        boolean boolean19 = logAxis6.isAxisLineVisible();
        java.awt.Paint paint20 = logAxis6.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = logAxis6.getTickLabelInsets();
        double double22 = rectangleInsets21.getTop();
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getLegendLabelURLGenerator();
        ringPlot0.setMinimumArcAngleToDraw((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        double double12 = xYSeriesCollection3.getIntervalPositionFactor();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5d + "'", double12 == 0.5d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        combinedDomainXYPlot4.setRangeZeroBaselineVisible(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        int int18 = xYSeriesCollection16.indexOf((java.lang.Comparable) (short) 0);
        double double20 = xYSeriesCollection16.getRangeUpperBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedDomainXYPlot4.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font27 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = null;
        xYStepRenderer28.setSeriesURLGenerator(100, xYURLGenerator30);
        xYStepRenderer28.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot(pieDataset34);
        boolean boolean36 = xYStepRenderer28.hasListener((java.util.EventListener) ringPlot35);
        java.awt.Color color38 = java.awt.Color.lightGray;
        xYStepRenderer28.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color38);
        org.jfree.chart.text.TextMeasurer textMeasurer41 = null;
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, (java.awt.Paint) color38, (float) 100L, textMeasurer41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.Size2D size2D44 = textBlock42.calculateDimensions(graphics2D43);
        java.awt.Font font48 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection49 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection49, valueAxis51, polarItemRenderer52);
        boolean boolean55 = polarPlot53.equals((java.lang.Object) 100.0f);
        java.awt.Color color56 = java.awt.Color.lightGray;
        polarPlot53.setAngleGridlinePaint((java.awt.Paint) color56);
        org.jfree.chart.block.LabelBlock labelBlock58 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font48, (java.awt.Paint) color56);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = labelBlock58.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D44, (double) 1, (double) (short) 0, rectangleAnchor59);
        rectangleInsets25.trim(rectangle2D60);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D63 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D60, rectangleAnchor62);
        combinedDomainXYPlot4.zoomDomainAxes(2.0d, (double) 9999, plotRenderingInfo24, point2D63);
        java.awt.Paint paint65 = combinedDomainXYPlot4.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(textBlock42);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D63);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        int int3 = crosshairState0.getRangeAxisIndex();
        crosshairState0.updateCrosshairX((double) 900000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean6 = xYStepRenderer0.getUseFillPaint();
        boolean boolean7 = xYStepRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 0L, (double) (-1), (double) (-2208927600000L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer3D3.setBaseToolTipGenerator(categoryToolTipGenerator4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        logAxis9.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer15.setSeriesOutlinePaint((int) (byte) 10, paint17, false);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D3.drawRangeLine(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D13, (double) (short) 0, paint17, stroke20);
        boolean boolean22 = logAxis9.isAxisLineVisible();
        java.awt.Paint paint23 = logAxis9.getAxisLinePaint();
        org.jfree.chart.util.LogFormat logFormat30 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean31 = logFormat30.isParseIntegerOnly();
        java.text.ParsePosition parsePosition33 = null;
        java.lang.Object obj34 = logFormat30.parseObject("", parsePosition33);
        int int35 = logFormat30.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat40 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean41 = logFormat40.isParseIntegerOnly();
        java.text.ParsePosition parsePosition43 = null;
        java.lang.Object obj44 = logFormat40.parseObject("", parsePosition43);
        int int45 = logFormat40.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator46 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat30, (java.text.NumberFormat) logFormat40);
        logFormat30.setParseIntegerOnly(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit49 = new org.jfree.chart.axis.NumberTickUnit(1.0E8d, (java.text.NumberFormat) logFormat30);
        logAxis9.setTickUnit(numberTickUnit49);
        java.lang.String str52 = numberTickUnit49.valueToString((double) 2);
        numberAxis0.setTickUnit(numberTickUnit49);
        numberAxis0.setLabelAngle((double) 900000L);
        java.awt.Shape shape56 = numberAxis0.getRightArrow();
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0.19" + "'", str52.equals("0.19"));
        org.junit.Assert.assertNotNull(shape56);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        combinedDomainXYPlot4.setRangeZeroBaselineVisible(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        int int18 = xYSeriesCollection16.indexOf((java.lang.Comparable) (short) 0);
        double double20 = xYSeriesCollection16.getRangeUpperBound(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedDomainXYPlot4.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16, false);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot4.getDomainMarkers(layer12);
        int int14 = combinedDomainXYPlot4.getRendererCount();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent15);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        barRenderer3D18.setBaseToolTipGenerator(categoryToolTipGenerator19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        logAxis24.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis24);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer30 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer30.setSeriesOutlinePaint((int) (byte) 10, paint32, false);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D18.drawRangeLine(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) logAxis24, rectangle2D28, (double) (short) 0, paint32, stroke35);
        boolean boolean37 = logAxis24.isAxisLineVisible();
        java.awt.Paint paint38 = logAxis24.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = logAxis24.getTickLabelInsets();
        combinedDomainXYPlot4.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) logAxis24);
        combinedDomainXYPlot4.setDomainGridlinesVisible(false);
        java.awt.Color color43 = java.awt.Color.CYAN;
        combinedDomainXYPlot4.setDomainGridlinePaint((java.awt.Paint) color43);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        java.awt.Font font12 = labelBlock11.getFont();
        labelBlock11.setWidth((double) 0.5f);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = labelBlock11.getContentAlignmentPoint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        java.awt.Paint paint3 = multiplePiePlot1.getAggregatedItemsPaint();
        boolean boolean5 = multiplePiePlot1.equals((java.lang.Object) 3);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYStepRenderer6.setSeriesURLGenerator(100, xYURLGenerator8);
        xYStepRenderer6.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepRenderer6.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator15 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer6.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator15, true);
        org.jfree.chart.util.LogFormat logFormat24 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean25 = logFormat24.isParseIntegerOnly();
        java.text.ParsePosition parsePosition27 = null;
        java.lang.Object obj28 = logFormat24.parseObject("", parsePosition27);
        int int29 = logFormat24.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat34 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean35 = logFormat34.isParseIntegerOnly();
        java.text.ParsePosition parsePosition37 = null;
        java.lang.Object obj38 = logFormat34.parseObject("", parsePosition37);
        int int39 = logFormat34.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator40 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat24, (java.text.NumberFormat) logFormat34);
        xYStepRenderer6.setSeriesToolTipGenerator((int) (short) 10, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator40, false);
        boolean boolean43 = multiplePiePlot1.equals((java.lang.Object) (short) 10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        multiplePiePlot1.datasetChanged(datasetChangeEvent44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYStepRenderer3.setSeriesURLGenerator(100, xYURLGenerator5);
        xYStepRenderer3.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        boolean boolean11 = xYStepRenderer3.hasListener((java.util.EventListener) ringPlot10);
        java.awt.Color color13 = java.awt.Color.lightGray;
        xYStepRenderer3.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color13);
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color13, (float) 100L, textMeasurer16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = textBlock17.calculateDimensions(graphics2D18);
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection24, valueAxis26, polarItemRenderer27);
        boolean boolean30 = polarPlot28.equals((java.lang.Object) 100.0f);
        java.awt.Color color31 = java.awt.Color.lightGray;
        polarPlot28.setAngleGridlinePaint((java.awt.Paint) color31);
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font23, (java.awt.Paint) color31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = labelBlock33.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, (double) 1, (double) (short) 0, rectangleAnchor34);
        rectangleInsets0.trim(rectangle2D35);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle37.setMargin(rectangleInsets38);
        textTitle37.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = textTitle37.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = textTitle37.getPosition();
        double double44 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D35, rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 4.0d + "'", double44 == 4.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent6);
        boolean boolean8 = combinedDomainXYPlot4.isDomainZeroBaselineVisible();
        java.lang.String str9 = combinedDomainXYPlot4.getPlotType();
        combinedDomainXYPlot4.setRangePannable(false);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Combined_Domain_XYPlot" + "'", str9.equals("Combined_Domain_XYPlot"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        java.util.List list3 = categoryPlot0.getCategories();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(list3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYStepRenderer8.setSeriesURLGenerator(100, xYURLGenerator10);
        xYStepRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        boolean boolean16 = xYStepRenderer8.hasListener((java.util.EventListener) ringPlot15);
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer8.setBaseItemLabelPaint(paint17, false);
        combinedDomainXYPlot4.setRangeTickBandPaint(paint17);
        java.awt.Paint paint21 = combinedDomainXYPlot4.getRangeMinorGridlinePaint();
        boolean boolean22 = combinedDomainXYPlot4.canSelectByRegion();
        java.awt.Paint paint23 = combinedDomainXYPlot4.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str4 = legendItem3.getURLText();
        java.awt.Paint paint5 = legendItem3.getLabelPaint();
        boolean boolean6 = standardXYURLGenerator1.equals((java.lang.Object) legendItem3);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D7.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color9, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer3D7.getLegendItemLabelGenerator();
        boolean boolean13 = standardXYURLGenerator1.equals((java.lang.Object) barRenderer3D7);
        java.awt.Paint paint14 = barRenderer3D7.getBaseLegendTextPaint();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo12);
        java.awt.geom.Line2D line2D14 = null;
        xYItemRendererState13.workingLine = line2D14;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection16, valueAxis18, polarItemRenderer19);
        xYSeriesCollection16.validateObject();
        xYItemRendererState13.endSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection16, 12, 15, (int) 'a', (int) (short) 10, 10);
        xYSeriesCollection8.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("");
        logAxis3.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = combinedDomainXYPlot6.getRenderer();
        java.awt.Stroke stroke8 = combinedDomainXYPlot6.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color1, stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 'a', false);
        boolean boolean4 = rotation0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        double double15 = intervalXYDelegate14.getIntervalPositionFactor();
        double double16 = intervalXYDelegate14.getFixedIntervalWidth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean6 = xYStepRenderer0.getBaseCreateEntities();
        xYStepRenderer0.setDrawSeriesLineAsPath(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) 9999, jFreeChart2, (int) (byte) 0, 0);
        boolean boolean6 = seriesRenderingOrder0.equals((java.lang.Object) 9999);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.awt.Color color0 = java.awt.Color.CYAN;
        float[] floatArray10 = new float[] { 100L, 10L, (byte) 10, 900000L, 100.0f, (short) 100 };
        float[] floatArray11 = java.awt.Color.RGBtoHSB(0, (-5), (-1), floatArray10);
        float[] floatArray12 = color0.getRGBComponents(floatArray10);
        int int13 = color0.getRed();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYStepRenderer14.setSeriesURLGenerator(100, xYURLGenerator16);
        xYStepRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer20 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = null;
        xYStepRenderer20.setSeriesURLGenerator(100, xYURLGenerator22);
        xYStepRenderer20.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot(pieDataset26);
        boolean boolean28 = xYStepRenderer20.hasListener((java.util.EventListener) ringPlot27);
        java.awt.Color color30 = java.awt.Color.lightGray;
        xYStepRenderer20.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color30);
        xYStepRenderer14.setBaseOutlinePaint((java.awt.Paint) color30, true);
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color0, (java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        xYSeries1.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D12.setTickLabelsVisible(true);
        boolean boolean15 = logAxis11.equals((java.lang.Object) true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape18 = xYAreaRenderer16.lookupSeriesShape((int) (short) -1);
        logAxis11.setDownArrow(shape18);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.data.xy.XYDataItem xYDataItem25 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity28 = new org.jfree.chart.entity.PieSectionEntity(shape18, pieDataset20, (int) (short) 0, 0, (java.lang.Comparable) xYDataItem25, "org.jfree.data.UnknownKeyException: hi!", "HorizontalAlignment.CENTER");
        xYDataItem25.setY((java.lang.Number) 100);
        xYSeries1.add(xYDataItem25, false);
        org.jfree.chart.util.BooleanList booleanList33 = new org.jfree.chart.util.BooleanList();
        boolean boolean34 = xYDataItem25.equals((java.lang.Object) booleanList33);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        combinedDomainXYPlot4.setRangeMinorGridlinesVisible(false);
        java.lang.Object obj11 = combinedDomainXYPlot4.clone();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("0.19");
        boolean boolean2 = legendItem1.isShapeFilled();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedDomainXYPlot4.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent14);
        java.awt.geom.Point2D point2D16 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("Other");
        combinedDomainXYPlot4.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) dateAxis19, false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries23.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries23.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Date date32 = year30.getStart();
        dateAxis19.setMinimumDate(date32);
        dateAxis19.configure();
        double double35 = dateAxis19.getLowerMargin();
        dateAxis19.setLabelAngle((double) 15);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer3D3.setBaseToolTipGenerator(categoryToolTipGenerator4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        logAxis9.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis9);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer15.setSeriesOutlinePaint((int) (byte) 10, paint17, false);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D3.drawRangeLine(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D13, (double) (short) 0, paint17, stroke20);
        boolean boolean22 = logAxis9.isAxisLineVisible();
        java.awt.Paint paint23 = logAxis9.getAxisLinePaint();
        org.jfree.chart.util.LogFormat logFormat30 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean31 = logFormat30.isParseIntegerOnly();
        java.text.ParsePosition parsePosition33 = null;
        java.lang.Object obj34 = logFormat30.parseObject("", parsePosition33);
        int int35 = logFormat30.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat40 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean41 = logFormat40.isParseIntegerOnly();
        java.text.ParsePosition parsePosition43 = null;
        java.lang.Object obj44 = logFormat40.parseObject("", parsePosition43);
        int int45 = logFormat40.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator46 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat30, (java.text.NumberFormat) logFormat40);
        logFormat30.setParseIntegerOnly(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit49 = new org.jfree.chart.axis.NumberTickUnit(1.0E8d, (java.text.NumberFormat) logFormat30);
        logAxis9.setTickUnit(numberTickUnit49);
        java.lang.String str52 = numberTickUnit49.valueToString((double) 2);
        numberAxis0.setTickUnit(numberTickUnit49);
        int int54 = numberTickUnit49.getMinorTickCount();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo60 = new org.jfree.chart.ui.BasicProjectInfo("0.58", "0.58", "0.58", "index.html", "item");
        basicProjectInfo60.setLicenceName("HorizontalAlignment.CENTER");
        basicProjectInfo60.setInfo("0.58");
        java.lang.String str65 = basicProjectInfo60.getName();
        int int66 = numberTickUnit49.compareTo((java.lang.Object) basicProjectInfo60);
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape69 = legendItem68.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection70 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range71 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection70);
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer73 = null;
        org.jfree.chart.plot.PolarPlot polarPlot74 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection70, valueAxis72, polarItemRenderer73);
        xYSeriesCollection70.validateObject();
        org.jfree.data.Range range77 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection70, false);
        legendItem68.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection70);
        java.awt.Paint paint79 = legendItem68.getLinePaint();
        java.lang.String str80 = legendItem68.getLabel();
        int int81 = numberTickUnit49.compareTo((java.lang.Object) str80);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0.19" + "'", str52.equals("0.19"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "0.58" + "'", str65.equals("0.58"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNull(range71);
        org.junit.Assert.assertNull(range77);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "index.html" + "'", str80.equals("index.html"));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false);
        xYStepRenderer0.setUseFillPaint(false);
        xYStepRenderer0.setUseOutlinePaint(true);
        java.awt.Stroke stroke12 = xYStepRenderer0.getSeriesStroke(0);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYStepRenderer0.setBaseItemLabelFont(font13);
        xYStepRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        java.lang.Object obj17 = xYStepRenderer0.clone();
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot4.getDomainMarkers(layer12);
        boolean boolean14 = combinedDomainXYPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(7, axisLocation7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace10.add((double) 1, rectangleEdge12);
        categoryPlot0.setFixedDomainAxisSpace(axisSpace10, true);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        boolean boolean10 = xYStepRenderer2.hasListener((java.util.EventListener) ringPlot9);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color12);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color12, (float) 100L, textMeasurer15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        textBlock16.draw(graphics2D17, 0.0f, (float) 8, textBlockAnchor20, (float) (byte) 0, 100.0f, 100.0d);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.Size2D size2D26 = textBlock16.calculateDimensions(graphics2D25);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(size2D26);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        double double4 = ringPlot3.getInnerSeparatorExtension();
        boolean boolean5 = ringPlot3.getIgnoreZeroValues();
        java.awt.Paint paint6 = ringPlot3.getLabelOutlinePaint();
        categoryPlot2.setRangeMinorGridlinePaint(paint6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot2.removeDomainMarker(0, marker9, layer10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot14.getIgnoreZeroValues();
        boolean boolean16 = ringPlot14.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        ringPlot14.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = ringPlot14.getDrawingSupplier();
        org.jfree.data.xy.XYDataItem xYDataItem22 = new org.jfree.data.xy.XYDataItem((double) 0.0f, (double) 100L);
        java.lang.Number number23 = xYDataItem22.getX();
        java.awt.Stroke stroke24 = null;
        ringPlot14.setSectionOutlineStroke((java.lang.Comparable) xYDataItem22, stroke24);
        categoryPlot2.setDomainCrosshairColumnKey((java.lang.Comparable) xYDataItem22, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot29 = categoryAxis3D28.getPlot();
        categoryPlot2.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D28);
        int int31 = categoryAxis3D28.getMaximumCategoryLabelLines();
        categoryAxis3D28.setMaximumCategoryLabelLines((int) (byte) 10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        crosshairState0.updateCrosshairY((double) 1L, (int) (byte) -1);
        double double6 = crosshairState0.getAnchorY();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries9.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries9.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries7.addAndOrUpdate(timeSeries9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries9.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        java.awt.Stroke stroke3 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries16);
        int int18 = timeSeriesCollection17.getSeriesCount();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor19 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        timeSeriesCollection17.setXPosition(timePeriodAnchor19);
        timeSeriesCollection13.setXPosition(timePeriodAnchor19);
        try {
            java.lang.Number number24 = timeSeriesCollection13.getStartX((int) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor19);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine0.calculateDimensions(graphics2D3);
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine0.removeFragment(textFragment5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textLine0.calculateDimensions(graphics2D7);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(size2D8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot4.getDomainMarkers(layer12);
        combinedDomainXYPlot4.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace15.add((double) 1, rectangleEdge17);
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace15);
        axisSpace15.setRight(8.0d);
        java.awt.Font font24 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        double double27 = ringPlot26.getInnerSeparatorExtension();
        boolean boolean28 = ringPlot26.getIgnoreZeroValues();
        java.awt.Paint paint29 = ringPlot26.getLabelOutlinePaint();
        categoryPlot25.setRangeMinorGridlinePaint(paint29);
        org.jfree.chart.plot.Marker marker32 = null;
        org.jfree.chart.util.Layer layer33 = null;
        boolean boolean34 = categoryPlot25.removeDomainMarker(0, marker32, layer33);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", font24, (org.jfree.chart.plot.Plot) categoryPlot25, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot25.getDomainAxisEdge((int) (short) 100);
        axisSpace15.add(0.05d, rectangleEdge38);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean5 = logFormat4.isParseIntegerOnly();
        java.text.ParsePosition parsePosition7 = null;
        java.lang.Object obj8 = logFormat4.parseObject("", parsePosition7);
        java.lang.Object obj9 = null;
        boolean boolean10 = logFormat4.equals(obj9);
        logFormat4.setParseIntegerOnly(true);
        logFormat4.setGroupingUsed(true);
        int int15 = logFormat4.getMaximumFractionDigits();
        logFormat4.setMaximumFractionDigits((int) '4');
        java.text.NumberFormat numberFormat18 = logFormat4.getExponentFormat();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(numberFormat18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        boolean boolean5 = barRenderer3D0.getItemCreateEntity((int) (byte) -1, (int) '#', true);
        double double6 = barRenderer3D0.getYOffset();
        barRenderer3D0.setShadowXOffset((double) 12);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            barRenderer3D0.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        combinedDomainXYPlot4.clearDomainMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getLegendItems();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot4.getRangeAxisForDataset((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 100 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot4.getDomainMinorGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedDomainXYPlot4.getRangeAxis(12);
        boolean boolean9 = combinedDomainXYPlot4.isDomainZoomable();
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        intervalMarker13.notifyListeners(markerChangeEvent14);
        java.lang.String str16 = intervalMarker13.getLabel();
        boolean boolean17 = combinedDomainXYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint2, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis7, polarItemRenderer8);
        boolean boolean11 = polarPlot9.equals((java.lang.Object) 100.0f);
        polarPlot9.clearCornerTextItems();
        xYStepRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot9);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        boolean boolean17 = itemLabelAnchor15.equals((java.lang.Object) 9999);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor18, textAnchor19, textAnchor20, (double) (-1.0f));
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor19, textAnchor23, (double) 8);
        xYStepRenderer0.setSeriesPositiveItemLabelPosition(5, itemLabelPosition25, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor23);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        boolean boolean3 = textTitle0.visible;
        double double4 = textTitle0.getContentYOffset();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.awt.Color color0 = java.awt.Color.red;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint2);
        java.awt.Stroke stroke4 = intervalMarker3.getOutlineStroke();
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection7, valueAxis9, polarItemRenderer10);
        boolean boolean13 = polarPlot11.equals((java.lang.Object) 100.0f);
        java.awt.Color color14 = java.awt.Color.lightGray;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color14);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font6, (java.awt.Paint) color14);
        intervalMarker3.setLabelFont(font6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection7, valueAxis9, polarItemRenderer10);
        boolean boolean12 = polarPlot11.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        polarPlot11.zoomDomainAxes((double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        logAxis18.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedDomainXYPlot21.getRenderer();
        java.awt.Stroke stroke23 = combinedDomainXYPlot21.getDomainMinorGridlineStroke();
        polarPlot11.setRadiusGridlineStroke(stroke23);
        categoryPlot0.setRangeCrosshairStroke(stroke23);
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        ringPlot1.setInnerSeparatorExtension(0.0d);
        boolean boolean6 = ringPlot1.getSimpleLabels();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = ringPlot1.getLabelLinkStyle();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = ringPlot0.getDrawingSupplier();
        ringPlot0.setAutoPopulateSectionOutlineStroke(true);
        float float5 = ringPlot0.getBackgroundImageAlpha();
        ringPlot0.setStartAngle((double) 10L);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        ringPlot0.setDataset(pieDataset8);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        logAxis11.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis11);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        xYStepRenderer15.setSeriesURLGenerator(100, xYURLGenerator17);
        xYStepRenderer15.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot(pieDataset21);
        boolean boolean23 = xYStepRenderer15.hasListener((java.util.EventListener) ringPlot22);
        ringPlot22.setCircular(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection26, valueAxis28, polarItemRenderer29);
        boolean boolean32 = polarPlot30.equals((java.lang.Object) 100.0f);
        java.awt.Color color33 = java.awt.Color.lightGray;
        polarPlot30.setAngleGridlinePaint((java.awt.Paint) color33);
        ringPlot22.setLabelOutlinePaint((java.awt.Paint) color33);
        combinedDomainXYPlot14.setRangeZeroBaselinePaint((java.awt.Paint) color33);
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color33);
        ringPlot0.setSectionOutlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        org.jfree.chart.axis.Axis axis2 = axisChangeEvent1.getAxis();
        org.jfree.chart.axis.Axis axis3 = axisChangeEvent1.getAxis();
        org.junit.Assert.assertNotNull(axis2);
        org.junit.Assert.assertNotNull(axis3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        xYStepRenderer4.setSeriesURLGenerator(100, xYURLGenerator6);
        xYStepRenderer4.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot(pieDataset10);
        boolean boolean12 = xYStepRenderer4.hasListener((java.util.EventListener) ringPlot11);
        java.awt.Color color14 = java.awt.Color.lightGray;
        xYStepRenderer4.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color14);
        org.jfree.chart.text.TextMeasurer textMeasurer17 = null;
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color14, (float) 100L, textMeasurer17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = textBlock18.calculateDimensions(graphics2D19);
        java.awt.Font font24 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection25 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection25, valueAxis27, polarItemRenderer28);
        boolean boolean31 = polarPlot29.equals((java.lang.Object) 100.0f);
        java.awt.Color color32 = java.awt.Color.lightGray;
        polarPlot29.setAngleGridlinePaint((java.awt.Paint) color32);
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font24, (java.awt.Paint) color32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = labelBlock34.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (double) 1, (double) (short) 0, rectangleAnchor35);
        rectangleInsets1.trim(rectangle2D36);
        try {
            boolean boolean38 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) (short) 0, (int) (short) 0, false);
        java.awt.Paint paint8 = barRenderer3D0.getItemPaint((-5), 0, true);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = barRenderer3D0.getLegendItems();
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str12 = legendItem11.getURLText();
        int int13 = legendItem11.getSeriesIndex();
        legendItemCollection9.add(legendItem11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries4.removeAgedItems(100L, false);
        int int8 = timeSeries4.getItemCount();
        int int9 = timeSeriesDataItem2.compareTo((java.lang.Object) timeSeries4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        java.awt.Color color1 = java.awt.Color.CYAN;
        float[] floatArray11 = new float[] { 100L, 10L, (byte) 10, 900000L, 100.0f, (short) 100 };
        float[] floatArray12 = java.awt.Color.RGBtoHSB(0, (-5), (-1), floatArray11);
        float[] floatArray13 = color1.getRGBComponents(floatArray11);
        float[] floatArray14 = color0.getRGBComponents(floatArray13);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedDomainXYPlot4.removeDomainMarker(marker8);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        double double13 = logAxis11.calculateValue((double) 8);
        double[] doubleArray19 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray23 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray27 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray31 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray35 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray36 = new double[][] { doubleArray19, doubleArray23, doubleArray27, doubleArray31, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray36);
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset37, true);
        logAxis11.setDefaultAutoRange(range39);
        java.awt.Stroke stroke41 = logAxis11.getTickMarkStroke();
        combinedDomainXYPlot4.setDomainMinorGridlineStroke(stroke41);
        combinedDomainXYPlot4.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E8d + "'", double13 == 1.0E8d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setTickLabelsVisible(true);
        boolean boolean3 = categoryAxis3D0.isVisible();
        double double4 = categoryAxis3D0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedDomainXYPlot4.getDomainAxis();
        java.awt.Stroke stroke10 = combinedDomainXYPlot4.getDomainCrosshairStroke();
        combinedDomainXYPlot4.clearDomainMarkers(2);
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint16);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D18.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = barRenderer3D18.getGradientPaintTransformer();
        boolean boolean22 = intervalMarker17.equals((java.lang.Object) gradientPaintTransformer21);
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean24 = combinedDomainXYPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker17, layer23);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(valueAxis9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot0.getDrawingSupplier();
        ringPlot0.setCircular(false);
        org.jfree.chart.util.Rotation rotation8 = ringPlot0.getDirection();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(rotation8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer3D0.getPositiveItemLabelPositionFallback();
        barRenderer3D0.setBaseSeriesVisible(false);
        org.junit.Assert.assertNull(itemLabelPosition3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        double double3 = ringPlot2.getInnerSeparatorExtension();
        boolean boolean4 = ringPlot2.getIgnoreZeroValues();
        java.awt.Paint paint5 = ringPlot2.getLabelOutlinePaint();
        double double6 = ringPlot2.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = ringPlot2.getLabelDistributor();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat10 = numberAxis3D9.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D9.setTickUnit(numberTickUnit11, true, false);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font16);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("item");
        textLine17.addFragment(textFragment19);
        java.awt.Paint paint21 = textFragment19.getPaint();
        ringPlot2.setSectionPaint((java.lang.Comparable) numberTickUnit11, paint21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        try {
            org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("Category Plot", font1, paint21, rectangleEdge23, horizontalAlignment24, verticalAlignment25, rectangleInsets26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
        org.junit.Assert.assertNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(verticalAlignment25);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart16.getLegend();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        logAxis20.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = combinedDomainXYPlot23.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = combinedDomainXYPlot23.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace26 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot23.setFixedRangeAxisSpace(axisSpace26);
        combinedDomainXYPlot23.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke30 = combinedDomainXYPlot23.getDomainMinorGridlineStroke();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot33 = categoryAxis3D32.getPlot();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font38 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer39 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = null;
        xYStepRenderer39.setSeriesURLGenerator(100, xYURLGenerator41);
        xYStepRenderer39.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot(pieDataset45);
        boolean boolean47 = xYStepRenderer39.hasListener((java.util.EventListener) ringPlot46);
        java.awt.Color color49 = java.awt.Color.lightGray;
        xYStepRenderer39.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color49);
        org.jfree.chart.text.TextMeasurer textMeasurer52 = null;
        org.jfree.chart.text.TextBlock textBlock53 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, (java.awt.Paint) color49, (float) 100L, textMeasurer52);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.util.Size2D size2D55 = textBlock53.calculateDimensions(graphics2D54);
        java.awt.Font font59 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection60 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range61 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection60);
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = null;
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection60, valueAxis62, polarItemRenderer63);
        boolean boolean66 = polarPlot64.equals((java.lang.Object) 100.0f);
        java.awt.Color color67 = java.awt.Color.lightGray;
        polarPlot64.setAngleGridlinePaint((java.awt.Paint) color67);
        org.jfree.chart.block.LabelBlock labelBlock69 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font59, (java.awt.Paint) color67);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = labelBlock69.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D71 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D55, (double) 1, (double) (short) 0, rectangleAnchor70);
        rectangleInsets36.trim(rectangle2D71);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle73.setMargin(rectangleInsets74);
        textTitle73.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = textTitle73.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = textTitle73.getPosition();
        org.jfree.chart.axis.AxisState axisState81 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState81.setMax(0.0d);
        axisState81.cursorDown(1.0E8d);
        categoryAxis3D32.drawTickMarks(graphics2D34, (double) 0L, rectangle2D71, rectangleEdge79, axisState81);
        java.util.List list87 = null;
        combinedDomainXYPlot23.drawDomainTickBands(graphics2D31, rectangle2D71, list87);
        java.lang.Object obj89 = null;
        try {
            java.lang.Object obj90 = legendTitle17.draw(graphics2D18, rectangle2D71, obj89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendTitle17);
        org.junit.Assert.assertNull(xYItemRenderer24);
        org.junit.Assert.assertNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(textBlock53);
        org.junit.Assert.assertNotNull(size2D55);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNull(range61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangleInsets78);
        org.junit.Assert.assertNotNull(rectangleEdge79);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = xYAreaRenderer0.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYStepRenderer7.setSeriesURLGenerator(100, xYURLGenerator9);
        xYStepRenderer7.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = xYStepRenderer7.hasListener((java.util.EventListener) ringPlot14);
        ringPlot14.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        ringPlot14.handleClick(1, (int) 'a', plotRenderingInfo20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot14);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity25 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart22, "Other", "");
        java.lang.Object obj26 = jFreeChartEntity25.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment((long) (short) 0);
        long long4 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86400000L + "'", long4 == 86400000L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle2.setMargin(rectangleInsets3);
        textTitle2.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle2.getMargin();
        double double8 = textTitle2.getContentYOffset();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle2.setPaint(paint9);
        paintList0.setPaint(0, paint9);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.0d + "'", double8 == 5.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.awt.Stroke stroke6 = combinedDomainXYPlot4.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        double double11 = logAxis9.calculateValue((double) 8);
        boolean boolean12 = pieLabelLinkStyle7.equals((java.lang.Object) logAxis9);
        combinedDomainXYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis9);
        java.awt.Shape shape14 = logAxis9.getDownArrow();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E8d + "'", double11 == 1.0E8d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        double double6 = ringPlot5.getInnerSeparatorExtension();
        boolean boolean7 = ringPlot5.getIgnoreZeroValues();
        java.awt.Paint paint8 = ringPlot5.getLabelOutlinePaint();
        categoryPlot4.setRangeMinorGridlinePaint(paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot4.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation((int) (short) 1, axisLocation11);
        java.lang.Object obj13 = null;
        boolean boolean14 = categoryPlot0.equals(obj13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis4, polarItemRenderer5);
        boolean boolean8 = polarPlot6.equals((java.lang.Object) 100.0f);
        java.awt.Color color9 = java.awt.Color.lightGray;
        polarPlot6.setAngleGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font1, (java.awt.Paint) color9);
        java.awt.Font font12 = labelBlock11.getFont();
        labelBlock11.setWidth((double) 0.5f);
        java.lang.String str15 = labelBlock11.getToolTipText();
        java.awt.Font font16 = labelBlock11.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D0.getCategoryStart(3, (int) (byte) 10, rectangle2D4, rectangleEdge5);
        int int7 = categoryAxis3D0.getMaximumCategoryLabelLines();
        double double8 = categoryAxis3D0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        int int1 = crosshairState0.getDomainAxisIndex();
        crosshairState0.updateCrosshairY((double) (-10), (int) (short) 1);
        int int5 = crosshairState0.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYStepRenderer5.setSeriesURLGenerator(100, xYURLGenerator7);
        xYStepRenderer5.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        boolean boolean13 = xYStepRenderer5.hasListener((java.util.EventListener) ringPlot12);
        ringPlot12.setCircular(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection16, valueAxis18, polarItemRenderer19);
        boolean boolean22 = polarPlot20.equals((java.lang.Object) 100.0f);
        java.awt.Color color23 = java.awt.Color.lightGray;
        polarPlot20.setAngleGridlinePaint((java.awt.Paint) color23);
        ringPlot12.setLabelOutlinePaint((java.awt.Paint) color23);
        combinedDomainXYPlot4.setRangeZeroBaselinePaint((java.awt.Paint) color23);
        java.lang.Object obj27 = combinedDomainXYPlot4.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = combinedDomainXYPlot4.getRenderer((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNull(xYItemRenderer29);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = xYStepRenderer0.lookupLegendTextFont(0);
        xYStepRenderer0.setDefaultEntityRadius(100);
        boolean boolean5 = xYStepRenderer0.getUseFillPaint();
        xYStepRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYStepRenderer0.getSeriesItemLabelGenerator((int) (byte) 0);
        java.awt.Stroke stroke11 = xYStepRenderer0.lookupSeriesOutlineStroke(15);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ThreadContext, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray25 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray26 = new double[][] { doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset27, true);
        logAxis1.setDefaultAutoRange(range29);
        java.awt.Stroke stroke31 = logAxis1.getTickMarkStroke();
        java.awt.Font font32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        logAxis1.setLabelFont(font32);
        java.awt.Font font34 = logAxis1.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = timeSeries1.equals((java.lang.Object) textBlockAnchor2);
        timeSeries1.setMaximumItemAge((long) (short) 1);
        timeSeries1.setMaximumItemAge((long) 12);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font2 = xYStepRenderer0.lookupLegendTextFont(0);
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYStepRenderer0.setBaseOutlineStroke(stroke3, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYStepRenderer0.getItemLabelGenerator((int) (byte) 100, (int) (short) -1, false);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str4 = legendItem3.getURLText();
        java.awt.Paint paint5 = legendItem3.getLabelPaint();
        boolean boolean6 = standardXYURLGenerator1.equals((java.lang.Object) legendItem3);
        java.awt.Paint paint7 = legendItem3.getFillPaint();
        java.awt.Font font8 = legendItem3.getLabelFont();
        boolean boolean9 = legendItem3.isShapeVisible();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range2 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, (double) 2958465);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Other");
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot8 = categoryAxis3D7.getPlot();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYStepRenderer14.setSeriesURLGenerator(100, xYURLGenerator16);
        xYStepRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        boolean boolean22 = xYStepRenderer14.hasListener((java.util.EventListener) ringPlot21);
        java.awt.Color color24 = java.awt.Color.lightGray;
        xYStepRenderer14.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color24);
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font13, (java.awt.Paint) color24, (float) 100L, textMeasurer27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = textBlock28.calculateDimensions(graphics2D29);
        java.awt.Font font34 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection35 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection35, valueAxis37, polarItemRenderer38);
        boolean boolean41 = polarPlot39.equals((java.lang.Object) 100.0f);
        java.awt.Color color42 = java.awt.Color.lightGray;
        polarPlot39.setAngleGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font34, (java.awt.Paint) color42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = labelBlock44.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) 1, (double) (short) 0, rectangleAnchor45);
        rectangleInsets11.trim(rectangle2D46);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle48.setMargin(rectangleInsets49);
        textTitle48.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = textTitle48.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = textTitle48.getPosition();
        org.jfree.chart.axis.AxisState axisState56 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState56.setMax(0.0d);
        axisState56.cursorDown(1.0E8d);
        categoryAxis3D7.drawTickMarks(graphics2D9, (double) 0L, rectangle2D46, rectangleEdge54, axisState56);
        double double62 = categoryAxis3D7.getCategoryMargin();
        java.awt.Font font63 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        categoryAxis3D7.setTickLabelFont(font63);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand65 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) (byte) -1, 0.05d, 0.4d, (double) (-2208927600000L), font63);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.2d + "'", double62 == 0.2d);
        org.junit.Assert.assertNotNull(font63);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        java.awt.Stroke stroke10 = polarPlot4.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = combinedDomainXYPlot17.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis20 = combinedDomainXYPlot17.getDomainAxis(3);
        combinedDomainXYPlot17.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D24 = combinedDomainXYPlot17.getQuadrantOrigin();
        polarPlot4.zoomDomainAxes(5.0d, plotRenderingInfo12, point2D24, false);
        polarPlot4.removeCornerTextItem("rect");
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYSeries1.equals((java.lang.Object) xYStepRenderer8);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer8.setSeriesItemLabelFont(8, font11, true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        xYStepRenderer15.setSeriesURLGenerator(100, xYURLGenerator17);
        xYStepRenderer15.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepRenderer15.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator24 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer15.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator24, true);
        xYStepRenderer8.setSeriesURLGenerator((int) (byte) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator24, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = xYStepRenderer8.getBaseToolTipGenerator();
        boolean boolean30 = xYStepRenderer8.getDrawOutlines();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(xYToolTipGenerator29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries9.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries9.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries7.addAndOrUpdate(timeSeries9);
        java.lang.Class class17 = timeSeries9.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(class17);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYSeries1.equals((java.lang.Object) xYStepRenderer8);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer8.setSeriesItemLabelFont(8, font11, true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        xYStepRenderer15.setSeriesURLGenerator(100, xYURLGenerator17);
        xYStepRenderer15.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepRenderer15.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator24 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer15.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator24, true);
        xYStepRenderer8.setSeriesURLGenerator((int) (byte) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator24, false);
        xYStepRenderer8.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator32 = xYStepRenderer8.getSeriesItemLabelGenerator((-5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNull(xYItemLabelGenerator32);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        ringPlot3.setLegendLabelURLGenerator(pieURLGenerator4);
        ringPlot3.setInnerSeparatorExtension(0.0d);
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartRenderingInfo0, (java.lang.Object) ringPlot3);
        org.jfree.chart.RenderingSource renderingSource9 = null;
        chartRenderingInfo0.setRenderingSource(renderingSource9);
        org.jfree.chart.entity.EntityCollection entityCollection11 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape14 = legendItem13.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection15, valueAxis17, polarItemRenderer18);
        xYSeriesCollection15.validateObject();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection15, false);
        legendItem13.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection15);
        org.jfree.data.time.TimeSeries timeSeries24 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection(timeSeries24);
        int int26 = timeSeriesCollection25.getSeriesCount();
        xYSeriesCollection15.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection25);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        int int30 = timeSeries29.getItemCount();
        int int31 = timeSeriesCollection25.indexOf(timeSeries29);
        boolean boolean32 = chartRenderingInfo0.equals((java.lang.Object) timeSeries29);
        java.lang.Object obj33 = chartRenderingInfo0.clone();
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(entityCollection11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        double double4 = ringPlot3.getInnerSeparatorExtension();
        boolean boolean5 = ringPlot3.getIgnoreZeroValues();
        java.awt.Paint paint6 = ringPlot3.getLabelOutlinePaint();
        categoryPlot2.setRangeMinorGridlinePaint(paint6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot2.removeDomainMarker(0, marker9, layer10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        boolean boolean14 = categoryPlot2.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        java.lang.Object obj12 = combinedDomainXYPlot4.clone();
        combinedDomainXYPlot4.clearAnnotations();
        boolean boolean14 = combinedDomainXYPlot4.isDomainMinorGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedDomainXYPlot4.getRangeAxisLocation(3);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer3D5.setBaseToolTipGenerator(categoryToolTipGenerator6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = barRenderer3D5.getBaseURLGenerator();
        categoryPlot0.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(categoryURLGenerator8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        categoryPlot0.configureDomainAxes();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Other");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list3 = segmentedTimeline2.getExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline2.getSegment((long) (short) 0);
        dateAxis1.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline2);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(segment5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        combinedDomainXYPlot4.setRangeMinorGridlinesVisible(false);
        boolean boolean11 = combinedDomainXYPlot4.isDomainPannable();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) ' ', "ERROR : Relative To String", "{0}: ({1}, {2})", true);
        boolean boolean5 = logFormat4.isGroupingUsed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.configureRangeAxes();
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        xYStepRenderer13.setSeriesURLGenerator(100, xYURLGenerator15);
        xYStepRenderer13.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot(pieDataset19);
        boolean boolean21 = xYStepRenderer13.hasListener((java.util.EventListener) ringPlot20);
        java.awt.Color color23 = java.awt.Color.lightGray;
        xYStepRenderer13.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color23);
        org.jfree.chart.text.TextMeasurer textMeasurer26 = null;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, (java.awt.Paint) color23, (float) 100L, textMeasurer26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = textBlock27.calculateDimensions(graphics2D28);
        java.awt.Font font33 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection34 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection34, valueAxis36, polarItemRenderer37);
        boolean boolean40 = polarPlot38.equals((java.lang.Object) 100.0f);
        java.awt.Color color41 = java.awt.Color.lightGray;
        polarPlot38.setAngleGridlinePaint((java.awt.Paint) color41);
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font33, (java.awt.Paint) color41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = labelBlock43.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, (double) 1, (double) (short) 0, rectangleAnchor44);
        org.jfree.chart.RenderingSource renderingSource46 = null;
        combinedDomainXYPlot4.select((double) 5, (double) 2958465, rectangle2D45, renderingSource46);
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D45, "SerialDate.weekInMonthToString(): invalid code.", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getDatasetCount();
        int int3 = categoryPlot1.getCrosshairDatasetIndex();
        java.util.List list4 = categoryPlot1.getCategories();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        categoryPlot1.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot7.setRangeMinorGridlinePaint(paint8);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection10, valueAxis12, polarItemRenderer13);
        boolean boolean15 = polarPlot14.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        polarPlot14.zoomDomainAxes((double) 100.0f, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        logAxis21.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = combinedDomainXYPlot24.getRenderer();
        java.awt.Stroke stroke26 = combinedDomainXYPlot24.getDomainMinorGridlineStroke();
        polarPlot14.setRadiusGridlineStroke(stroke26);
        categoryPlot7.setRangeZeroBaselineStroke(stroke26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot7.setDomainAxisLocation(axisLocation29);
        categoryPlot1.setRangeAxisLocation(axisLocation29, false);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("1-January-2019", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment((long) (short) 0);
        boolean boolean4 = segment3.inIncludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        logAxis11.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedDomainXYPlot14.getRenderer();
        java.awt.Stroke stroke16 = combinedDomainXYPlot14.getDomainMinorGridlineStroke();
        polarPlot4.setRadiusGridlineStroke(stroke16);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        polarPlot4.setRenderer(polarItemRenderer18);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer0.getBaseToolTipGenerator();
        xYAreaRenderer0.setOutline(false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        boolean boolean19 = logAxis6.isAxisLineVisible();
        java.awt.Shape shape20 = logAxis6.getRightArrow();
        logAxis6.setLabelURL("");
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle0.setHorizontalAlignment(horizontalAlignment11);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYStepRenderer14.setSeriesURLGenerator(100, xYURLGenerator16);
        xYStepRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        boolean boolean22 = xYStepRenderer14.hasListener((java.util.EventListener) ringPlot21);
        ringPlot21.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        ringPlot21.handleClick(1, (int) 'a', plotRenderingInfo27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot21);
        jFreeChart29.clearSubtitles();
        int int31 = jFreeChart29.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection35 = chartRenderingInfo34.getEntityCollection();
        jFreeChart29.handleClick((int) 'a', (int) 'a', chartRenderingInfo34);
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        jFreeChart29.setTitle("PlotOrientation.VERTICAL");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNotNull(entityCollection35);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        boolean boolean5 = barRenderer3D0.getItemCreateEntity((int) (byte) -1, (int) '#', true);
        double double6 = barRenderer3D0.getYOffset();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D0.getURLGenerator((int) (short) 10, 8, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        boolean boolean19 = logAxis6.isAxisLineVisible();
        java.awt.Paint paint20 = logAxis6.getAxisLinePaint();
        org.jfree.chart.util.LogFormat logFormat27 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean28 = logFormat27.isParseIntegerOnly();
        java.text.ParsePosition parsePosition30 = null;
        java.lang.Object obj31 = logFormat27.parseObject("", parsePosition30);
        int int32 = logFormat27.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat37 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean38 = logFormat37.isParseIntegerOnly();
        java.text.ParsePosition parsePosition40 = null;
        java.lang.Object obj41 = logFormat37.parseObject("", parsePosition40);
        int int42 = logFormat37.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator43 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat27, (java.text.NumberFormat) logFormat37);
        logFormat27.setParseIntegerOnly(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = new org.jfree.chart.axis.NumberTickUnit(1.0E8d, (java.text.NumberFormat) logFormat27);
        logAxis6.setTickUnit(numberTickUnit46);
        java.awt.Shape shape48 = logAxis6.getRightArrow();
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.axis.AxisSpace axisSpace51 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace51.add((double) 1, rectangleEdge53);
        try {
            double double55 = logAxis6.exponentLengthToJava2D((double) 10L, rectangle2D50, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        boolean boolean8 = xYSeries1.getAutoSort();
        boolean boolean9 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean12 = xYSeries11.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries15 = xYSeries11.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        xYSeries11.addChangeListener(seriesChangeListener16);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        double double19 = xYSeriesCollection18.getIntervalWidth();
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection18);
        xYSeries11.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection18);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18, true);
        xYSeriesCollection18.setIntervalWidth(0.0d);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list27 = segmentedTimeline26.getExceptionSegments();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18, list27, true);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection18);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState31 = null;
        xYSeriesCollection18.setSelectionState(xYDatasetSelectionState31);
        org.jfree.data.DomainOrder domainOrder33 = xYSeriesCollection18.getDomainOrder();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYSeries15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(segmentedTimeline26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(domainOrder33);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        int int18 = timeSeries17.getItemCount();
        int int19 = timeSeriesCollection13.indexOf(timeSeries17);
        java.util.List list20 = null;
        try {
            org.jfree.data.Range range22 = timeSeriesCollection13.getDomainBounds(list20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        waferMapPlot1.setRenderer(waferMapRenderer2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        boolean boolean3 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder5 = categoryPlot4.getDatasetRenderingOrder();
        java.awt.Paint paint6 = categoryPlot4.getRangeMinorGridlinePaint();
        barRenderer3D0.setShadowPaint(paint6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.isShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        int int1 = dateTickUnitType0.getCalendarField();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot2.getRenderer((int) (short) 0);
        categoryPlot2.clearRangeMarkers();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer3D6.setBaseToolTipGenerator(categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        logAxis12.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis12);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer18.setSeriesOutlinePaint((int) (byte) 10, paint20, false);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D6.drawRangeLine(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D16, (double) (short) 0, paint20, stroke23);
        boolean boolean25 = logAxis12.isAxisLineVisible();
        java.awt.Paint paint26 = logAxis12.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = logAxis12.getTickLabelInsets();
        logAxis12.configure();
        categoryPlot2.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot2.getRangeAxis();
        boolean boolean31 = dateTickUnitType0.equals((java.lang.Object) categoryPlot2);
        java.text.DateFormat dateFormat33 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit34 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 0, dateFormat33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle0.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle0.getPosition();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (short) 10);
        java.lang.Object obj4 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNull(attributedString3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("ERROR : Relative To String");
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getDatasetCount();
        int int2 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        double double6 = ringPlot5.getInnerSeparatorExtension();
        boolean boolean7 = ringPlot5.getIgnoreZeroValues();
        java.awt.Paint paint8 = ringPlot5.getLabelOutlinePaint();
        categoryPlot4.setRangeMinorGridlinePaint(paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot4.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation((int) (short) 1, axisLocation11);
        categoryPlot0.clearRangeMarkers((-10));
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        logAxis17.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedDomainXYPlot20.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis23 = combinedDomainXYPlot20.getDomainAxis(3);
        combinedDomainXYPlot20.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D27 = combinedDomainXYPlot20.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = combinedDomainXYPlot20.getRenderer(10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent30 = null;
        combinedDomainXYPlot20.plotChanged(plotChangeEvent30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle33.setMargin(rectangleInsets34);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot37 = categoryAxis3D36.getPlot();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font42 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator45 = null;
        xYStepRenderer43.setSeriesURLGenerator(100, xYURLGenerator45);
        xYStepRenderer43.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        boolean boolean51 = xYStepRenderer43.hasListener((java.util.EventListener) ringPlot50);
        java.awt.Color color53 = java.awt.Color.lightGray;
        xYStepRenderer43.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color53);
        org.jfree.chart.text.TextMeasurer textMeasurer56 = null;
        org.jfree.chart.text.TextBlock textBlock57 = org.jfree.chart.text.TextUtilities.createTextBlock("", font42, (java.awt.Paint) color53, (float) 100L, textMeasurer56);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.util.Size2D size2D59 = textBlock57.calculateDimensions(graphics2D58);
        java.awt.Font font63 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection64 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range65 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection64);
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer67 = null;
        org.jfree.chart.plot.PolarPlot polarPlot68 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection64, valueAxis66, polarItemRenderer67);
        boolean boolean70 = polarPlot68.equals((java.lang.Object) 100.0f);
        java.awt.Color color71 = java.awt.Color.lightGray;
        polarPlot68.setAngleGridlinePaint((java.awt.Paint) color71);
        org.jfree.chart.block.LabelBlock labelBlock73 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font63, (java.awt.Paint) color71);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = labelBlock73.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D75 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, (double) 1, (double) (short) 0, rectangleAnchor74);
        rectangleInsets40.trim(rectangle2D75);
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle77.setMargin(rectangleInsets78);
        textTitle77.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = textTitle77.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = textTitle77.getPosition();
        org.jfree.chart.axis.AxisState axisState85 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState85.setMax(0.0d);
        axisState85.cursorDown(1.0E8d);
        categoryAxis3D36.drawTickMarks(graphics2D38, (double) 0L, rectangle2D75, rectangleEdge83, axisState85);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType91 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType92 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D93 = rectangleInsets34.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType91, lengthAdjustmentType92);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo94 = null;
        combinedDomainXYPlot20.drawAnnotations(graphics2D32, rectangle2D75, plotRenderingInfo94);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo97 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState98 = null;
        try {
            boolean boolean99 = categoryPlot0.render(graphics2D15, rectangle2D75, (-1), plotRenderingInfo97, categoryCrosshairState98);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(textBlock57);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNull(range65);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangleInsets78);
        org.junit.Assert.assertNotNull(rectangleInsets82);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertNotNull(lengthAdjustmentType91);
        org.junit.Assert.assertNotNull(lengthAdjustmentType92);
        org.junit.Assert.assertNotNull(rectangle2D93);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYSeries1.equals((java.lang.Object) xYStepRenderer8);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer8.setSeriesItemLabelFont(8, font11, true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        xYStepRenderer15.setSeriesURLGenerator(100, xYURLGenerator17);
        xYStepRenderer15.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepRenderer15.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator24 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        xYStepRenderer15.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator24, true);
        xYStepRenderer8.setSeriesURLGenerator((int) (byte) 0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator24, false);
        xYStepRenderer8.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        xYStepRenderer8.setBaseOutlinePaint((java.awt.Paint) color31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        boolean boolean8 = xYSeries1.getAutoSort();
        boolean boolean9 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean12 = xYSeries11.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries15 = xYSeries11.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        xYSeries11.addChangeListener(seriesChangeListener16);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        double double19 = xYSeriesCollection18.getIntervalWidth();
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection18);
        xYSeries11.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection18);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18, true);
        xYSeriesCollection18.setIntervalWidth(0.0d);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list27 = segmentedTimeline26.getExceptionSegments();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18, list27, true);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection18);
        double double31 = xYSeries1.getMinY();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYSeries15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(segmentedTimeline26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (-1), (double) 12);
        java.util.Date date3 = dateRange2.getLowerDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean5 = logFormat4.isParseIntegerOnly();
        java.text.ParsePosition parsePosition7 = null;
        java.lang.Object obj8 = logFormat4.parseObject("", parsePosition7);
        java.lang.Object obj9 = null;
        boolean boolean10 = logFormat4.equals(obj9);
        logFormat4.setParseIntegerOnly(true);
        logFormat4.setGroupingUsed(true);
        java.text.ParsePosition parsePosition16 = null;
        java.lang.Object obj17 = logFormat4.parseObject("HorizontalAlignment.CENTER", parsePosition16);
        java.lang.Object obj18 = logFormat4.clone();
        logFormat4.setMinimumFractionDigits(5);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color2, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator5);
        barRenderer3D0.setDrawBarOutline(false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot10.getDatasetRenderingOrder();
        categoryPlot10.setAnchorValue((double) '4');
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D16.setTickLabelsVisible(true);
        boolean boolean19 = logAxis15.equals((java.lang.Object) true);
        logAxis15.pan((double) (-2208960000000L));
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot23 = categoryAxis3D22.getPlot();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font28 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer29 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator31 = null;
        xYStepRenderer29.setSeriesURLGenerator(100, xYURLGenerator31);
        xYStepRenderer29.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot(pieDataset35);
        boolean boolean37 = xYStepRenderer29.hasListener((java.util.EventListener) ringPlot36);
        java.awt.Color color39 = java.awt.Color.lightGray;
        xYStepRenderer29.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color39);
        org.jfree.chart.text.TextMeasurer textMeasurer42 = null;
        org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("", font28, (java.awt.Paint) color39, (float) 100L, textMeasurer42);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.util.Size2D size2D45 = textBlock43.calculateDimensions(graphics2D44);
        java.awt.Font font49 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection50 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer53 = null;
        org.jfree.chart.plot.PolarPlot polarPlot54 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection50, valueAxis52, polarItemRenderer53);
        boolean boolean56 = polarPlot54.equals((java.lang.Object) 100.0f);
        java.awt.Color color57 = java.awt.Color.lightGray;
        polarPlot54.setAngleGridlinePaint((java.awt.Paint) color57);
        org.jfree.chart.block.LabelBlock labelBlock59 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font49, (java.awt.Paint) color57);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = labelBlock59.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, (double) 1, (double) (short) 0, rectangleAnchor60);
        rectangleInsets26.trim(rectangle2D61);
        org.jfree.chart.title.TextTitle textTitle63 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle63.setMargin(rectangleInsets64);
        textTitle63.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = textTitle63.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = textTitle63.getPosition();
        org.jfree.chart.axis.AxisState axisState71 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState71.setMax(0.0d);
        axisState71.cursorDown(1.0E8d);
        categoryAxis3D22.drawTickMarks(graphics2D24, (double) 0L, rectangle2D61, rectangleEdge69, axisState71);
        barRenderer3D0.drawRangeGridline(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) logAxis15, rectangle2D61, (double) 10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(textBlock43);
        org.junit.Assert.assertNotNull(size2D45);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        barRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        logAxis6.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setSeriesOutlinePaint((int) (byte) 10, paint14, false);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D0.drawRangeLine(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, rectangle2D10, (double) (short) 0, paint14, stroke17);
        java.awt.Stroke stroke19 = logAxis6.getTickMarkStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = new org.jfree.chart.axis.NumberTickUnit((double) 68);
        logAxis6.setTickUnit(numberTickUnit21, true, false);
        org.jfree.data.Range range25 = logAxis6.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        org.jfree.chart.util.LogFormat logFormat11 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean12 = logFormat11.isParseIntegerOnly();
        java.text.ParsePosition parsePosition14 = null;
        java.lang.Object obj15 = logFormat11.parseObject("", parsePosition14);
        int int16 = logFormat11.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat21 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean22 = logFormat21.isParseIntegerOnly();
        java.text.ParsePosition parsePosition24 = null;
        java.lang.Object obj25 = logFormat21.parseObject("", parsePosition24);
        int int26 = logFormat21.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator27 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat11, (java.text.NumberFormat) logFormat21);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27, xYURLGenerator28);
        xYStepRenderer0.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator27);
        java.lang.Boolean boolean32 = xYStepRenderer0.getSeriesShapesFilled((int) (short) 10);
        xYStepRenderer0.setBaseLinesVisible(false);
        java.awt.Font font36 = xYStepRenderer0.getLegendTextFont(10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertNull(font36);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint2);
        java.awt.Stroke stroke4 = intervalMarker3.getOutlineStroke();
        java.awt.Paint paint5 = intervalMarker3.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        double double8 = ringPlot7.getInnerSeparatorExtension();
        boolean boolean9 = ringPlot7.getIgnoreZeroValues();
        java.awt.Paint paint10 = ringPlot7.getLabelOutlinePaint();
        categoryPlot6.setRangeMinorGridlinePaint(paint10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot6.getAxisOffset();
        java.awt.Stroke stroke13 = categoryPlot6.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D15 = new org.jfree.chart.renderer.category.BarRenderer3D();
        categoryPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D15, true);
        intervalMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float float5 = categoryAxis3D0.getTickMarkInsideLength();
        categoryAxis3D0.configure();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.Plot plot8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        numberAxis9.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = combinedDomainXYPlot17.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis20 = combinedDomainXYPlot17.getDomainAxis(3);
        combinedDomainXYPlot17.configureRangeAxes();
        java.awt.Font font25 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer26 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        xYStepRenderer26.setSeriesURLGenerator(100, xYURLGenerator28);
        xYStepRenderer26.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot(pieDataset32);
        boolean boolean34 = xYStepRenderer26.hasListener((java.util.EventListener) ringPlot33);
        java.awt.Color color36 = java.awt.Color.lightGray;
        xYStepRenderer26.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color36);
        org.jfree.chart.text.TextMeasurer textMeasurer39 = null;
        org.jfree.chart.text.TextBlock textBlock40 = org.jfree.chart.text.TextUtilities.createTextBlock("", font25, (java.awt.Paint) color36, (float) 100L, textMeasurer39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock40.calculateDimensions(graphics2D41);
        java.awt.Font font46 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection47 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection47);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        org.jfree.chart.plot.PolarPlot polarPlot51 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection47, valueAxis49, polarItemRenderer50);
        boolean boolean53 = polarPlot51.equals((java.lang.Object) 100.0f);
        java.awt.Color color54 = java.awt.Color.lightGray;
        polarPlot51.setAngleGridlinePaint((java.awt.Paint) color54);
        org.jfree.chart.block.LabelBlock labelBlock56 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font46, (java.awt.Paint) color54);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = labelBlock56.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D58 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D42, (double) 1, (double) (short) 0, rectangleAnchor57);
        org.jfree.chart.RenderingSource renderingSource59 = null;
        combinedDomainXYPlot17.select((double) 5, (double) 2958465, rectangle2D58, renderingSource59);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle61.setMargin(rectangleInsets62);
        textTitle61.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = textTitle61.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = textTitle61.getPosition();
        double double68 = numberAxis9.java2DToValue(0.2d, rectangle2D58, rectangleEdge67);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot71 = new org.jfree.chart.plot.RingPlot();
        double double72 = ringPlot71.getInnerSeparatorExtension();
        boolean boolean73 = ringPlot71.getIgnoreZeroValues();
        java.awt.Paint paint74 = ringPlot71.getLabelOutlinePaint();
        categoryPlot70.setRangeMinorGridlinePaint(paint74);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot70.setRangeAxisLocation(7, axisLocation77, false);
        org.jfree.chart.axis.AxisSpace axisSpace80 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace80.add((double) 1, rectangleEdge82);
        categoryPlot70.setFixedDomainAxisSpace(axisSpace80, true);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace86 = categoryAxis3D0.reserveSpace(graphics2D7, plot8, rectangle2D58, rectangleEdge69, axisSpace80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(textBlock40);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.NEGATIVE_INFINITY + "'", double68 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.2d + "'", double72 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(rectangleEdge82);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        java.lang.String str2 = horizontalAlignment0.toString();
        java.lang.String str3 = horizontalAlignment0.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment4, (double) (-10), 10.0d);
        java.awt.Font font9 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        double double12 = ringPlot11.getInnerSeparatorExtension();
        boolean boolean13 = ringPlot11.getIgnoreZeroValues();
        java.awt.Paint paint14 = ringPlot11.getLabelOutlinePaint();
        categoryPlot10.setRangeMinorGridlinePaint(paint14);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot10.removeDomainMarker(0, marker17, layer18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", font9, (org.jfree.chart.plot.Plot) categoryPlot10, false);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle22.setMargin(rectangleInsets23);
        textTitle22.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle22.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = textTitle22.getPosition();
        jFreeChart21.setTitle(textTitle22);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYBarRenderer30.getPositiveItemLabelPositionFallback();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection32 = new org.jfree.data.xy.XYSeriesCollection();
        int int34 = xYSeriesCollection32.indexOf((java.lang.Comparable) (short) 0);
        double double35 = xYSeriesCollection32.getIntervalWidth();
        xYSeriesCollection32.setIntervalPositionFactor(0.0d);
        boolean boolean38 = xYSeriesCollection32.isAutoWidth();
        org.jfree.data.Range range39 = xYBarRenderer30.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection32);
        columnArrangement7.add((org.jfree.chart.block.Block) textTitle22, (java.lang.Object) xYBarRenderer30);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean7 = logFormat6.isParseIntegerOnly();
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Object obj10 = logFormat6.parseObject("", parsePosition9);
        int int11 = logFormat6.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat16 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean17 = logFormat16.isParseIntegerOnly();
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat16.parseObject("", parsePosition19);
        int int21 = logFormat16.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator22 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat6, (java.text.NumberFormat) logFormat16);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator22, xYURLGenerator23);
        java.text.DateFormat dateFormat27 = null;
        java.text.DateFormat dateFormat28 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator29 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ERROR : Relative To String", dateFormat27, dateFormat28);
        xYAreaRenderer24.setSeriesToolTipGenerator(12, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator29);
        boolean boolean31 = xYAreaRenderer24.getPlotLines();
        boolean boolean32 = xYAreaRenderer24.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer3D4.setBaseToolTipGenerator(categoryToolTipGenerator5);
        boolean boolean7 = barRenderer3D4.getBaseSeriesVisible();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D8.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = barRenderer3D8.getGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer3D8.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer3D8.getLegendItemLabelGenerator();
        barRenderer3D4.setLegendItemURLGenerator(categorySeriesLabelGenerator13);
        barRenderer3D0.setLegendItemURLGenerator(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
        org.junit.Assert.assertNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint2);
        java.awt.Stroke stroke4 = intervalMarker3.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor5 = intervalMarker3.getLabelTextAnchor();
        java.lang.String str6 = intervalMarker3.getLabel();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.awt.Shape shape0 = null;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getInnerSeparatorExtension();
        boolean boolean6 = ringPlot4.getIgnoreZeroValues();
        java.awt.Paint paint7 = ringPlot4.getLabelOutlinePaint();
        categoryPlot3.setRangeMinorGridlinePaint(paint7);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot3.removeDomainMarker(0, marker10, layer11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ChartChangeEventType.NEW_DATASET", font2, (org.jfree.chart.plot.Plot) categoryPlot3, false);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle15.setMargin(rectangleInsets16);
        textTitle15.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle15.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = textTitle15.getPosition();
        jFreeChart14.setTitle(textTitle15);
        try {
            org.jfree.chart.entity.TitleEntity titleEntity24 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) textTitle15, "SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.lang.Object obj10 = null;
        boolean boolean11 = logAxis1.equals(obj10);
        float float12 = logAxis1.getMinorTickMarkInsideLength();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape15 = legendItem14.getLine();
        logAxis1.setUpArrow(shape15);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = logAxis1.getTickUnit();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        double double4 = logAxis2.calculateValue((double) 8);
        double[] doubleArray10 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray14 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray18 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray22 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray26 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray27 = new double[][] { doubleArray10, doubleArray14, doubleArray18, doubleArray22, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset28, true);
        logAxis2.setDefaultAutoRange(range30);
        logAxis0.setRange(range30);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E8d + "'", double4 == 1.0E8d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Image image2 = ringPlot0.getBackgroundImage();
        boolean boolean3 = ringPlot0.getSimpleLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        ringPlot0.setLabelPadding(rectangleInsets4);
        ringPlot0.setLabelLinkMargin((double) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent6);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYStepRenderer8.setSeriesURLGenerator(100, xYURLGenerator10);
        xYStepRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        boolean boolean16 = xYStepRenderer8.hasListener((java.util.EventListener) ringPlot15);
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer8.setBaseItemLabelPaint(paint17, false);
        combinedDomainXYPlot4.setRangeTickBandPaint(paint17);
        org.jfree.chart.plot.Plot plot21 = combinedDomainXYPlot4.getRootPlot();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = combinedDomainXYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.lang.String str9 = axisSpace7.toString();
        axisSpace7.setTop((double) 0.8f);
        axisSpace7.setRight((double) (short) 10);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("{0}: ({1}, {2})");
        java.awt.Paint paint2 = periodAxis1.getMinorTickMarkPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint2 = ringPlot0.getBackgroundPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        ringPlot0.setLabelLinkStyle(pieLabelLinkStyle3);
        ringPlot0.setStartAngle((double) (-1));
        ringPlot0.clearSectionPaints(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        java.lang.Object obj6 = combinedDomainXYPlot4.clone();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = combinedDomainXYPlot4.removeDomainMarker(marker7);
        combinedDomainXYPlot4.setDomainCrosshairLockedOnData(false);
        combinedDomainXYPlot4.setDomainCrosshairValue((double) 6);
        boolean boolean13 = combinedDomainXYPlot4.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) '4', (double) 100);
        long long3 = dateRange2.getLowerMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = null;
        xYItemRendererState1.workingLine = line2D2;
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = xYItemRendererState1.getSelectionState();
        org.junit.Assert.assertNull(xYDatasetSelectionState4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreNullValues();
        ringPlot1.setAutoPopulateSectionPaint(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D0.getCategoryStart(3, (int) (byte) 10, rectangle2D4, rectangleEdge5);
        java.awt.Font font8 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) (byte) 10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        double double10 = categoryAxis3D0.getCategoryMargin();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle16.setMargin(rectangleInsets17);
        textTitle16.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle16.getMargin();
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets21.getUnitType();
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle23.setMargin(rectangleInsets24);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot27 = categoryAxis3D26.getPlot();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer33 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = null;
        xYStepRenderer33.setSeriesURLGenerator(100, xYURLGenerator35);
        xYStepRenderer33.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.RingPlot ringPlot40 = new org.jfree.chart.plot.RingPlot(pieDataset39);
        boolean boolean41 = xYStepRenderer33.hasListener((java.util.EventListener) ringPlot40);
        java.awt.Color color43 = java.awt.Color.lightGray;
        xYStepRenderer33.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color43);
        org.jfree.chart.text.TextMeasurer textMeasurer46 = null;
        org.jfree.chart.text.TextBlock textBlock47 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, (java.awt.Paint) color43, (float) 100L, textMeasurer46);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.util.Size2D size2D49 = textBlock47.calculateDimensions(graphics2D48);
        java.awt.Font font53 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection54 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection54);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer57 = null;
        org.jfree.chart.plot.PolarPlot polarPlot58 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection54, valueAxis56, polarItemRenderer57);
        boolean boolean60 = polarPlot58.equals((java.lang.Object) 100.0f);
        java.awt.Color color61 = java.awt.Color.lightGray;
        polarPlot58.setAngleGridlinePaint((java.awt.Paint) color61);
        org.jfree.chart.block.LabelBlock labelBlock63 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font53, (java.awt.Paint) color61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = labelBlock63.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D65 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, (double) 1, (double) (short) 0, rectangleAnchor64);
        rectangleInsets30.trim(rectangle2D65);
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle67.setMargin(rectangleInsets68);
        textTitle67.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = textTitle67.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = textTitle67.getPosition();
        org.jfree.chart.axis.AxisState axisState75 = new org.jfree.chart.axis.AxisState((double) (-1));
        axisState75.setMax(0.0d);
        axisState75.cursorDown(1.0E8d);
        categoryAxis3D26.drawTickMarks(graphics2D28, (double) 0L, rectangle2D65, rectangleEdge73, axisState75);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType81 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType82 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D83 = rectangleInsets24.createAdjustedRectangle(rectangle2D65, lengthAdjustmentType81, lengthAdjustmentType82);
        rectangleInsets21.trim(rectangle2D65);
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = null;
        double double86 = categoryAxis3D0.getCategorySeriesMiddle(68, (int) 'a', 12, (int) (byte) -1, (double) 5, rectangle2D65, rectangleEdge85);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(textBlock47);
        org.junit.Assert.assertNotNull(size2D49);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(lengthAdjustmentType81);
        org.junit.Assert.assertNotNull(lengthAdjustmentType82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        long long7 = segmentedTimeline0.getExceptionSegmentCount(10L, (long) (-5));
        long long9 = segmentedTimeline0.getTimeFromLong(1546329600000L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.awt.Color color1 = java.awt.Color.pink;
        boolean boolean2 = pieLabelLinkStyle0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        java.awt.Color color10 = java.awt.Color.lightGray;
        xYStepRenderer0.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = xYStepRenderer0.getBaseToolTipGenerator();
        xYStepRenderer0.setSeriesShapesFilled((int) (byte) 10, true);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        xYStepRenderer16.setSeriesURLGenerator(100, xYURLGenerator18);
        xYStepRenderer16.setAutoPopulateSeriesStroke(true);
        java.awt.Font font23 = xYStepRenderer16.getLegendTextFont(7);
        boolean boolean24 = xYStepRenderer16.getBaseShapesFilled();
        java.awt.Paint paint26 = xYStepRenderer16.getSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = xYStepRenderer16.getLegendItemLabelGenerator();
        xYStepRenderer0.setLegendItemLabelGenerator(xYSeriesLabelGenerator27);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYToolTipGenerator12);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator27);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX((double) 2.0f);
        crosshairState0.updateCrosshairY((double) 1L, (int) (byte) -1);
        crosshairState0.updateCrosshairY((double) '#', (-1));
        double double9 = crosshairState0.getCrosshairDistance();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("index.html");
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str4 = legendItem3.getURLText();
        java.awt.Paint paint5 = legendItem3.getLabelPaint();
        boolean boolean6 = standardXYURLGenerator1.equals((java.lang.Object) legendItem3);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer3D7.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color9, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer3D7.getLegendItemLabelGenerator();
        boolean boolean13 = standardXYURLGenerator1.equals((java.lang.Object) barRenderer3D7);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = barRenderer3D7.getLegendItems();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NOID", "org.jfree.data.UnknownKeyException: hi!", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("{0}: ({1}, {2})", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeSeries12);
        int int14 = timeSeriesCollection13.getSeriesCount();
        xYSeriesCollection3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection13);
        xYSeriesCollection3.removeAllSeries();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setLowerBound((double) 5);
        java.lang.String str3 = logAxis0.getLabelURL();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 192);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", graphics2D1, (float) (byte) 10, (float) 2958465, (double) 2, (float) 1, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        polarPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo7, point2D8);
        java.awt.Stroke stroke10 = polarPlot4.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = combinedDomainXYPlot17.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis20 = combinedDomainXYPlot17.getDomainAxis(3);
        combinedDomainXYPlot17.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D24 = combinedDomainXYPlot17.getQuadrantOrigin();
        polarPlot4.zoomDomainAxes(5.0d, plotRenderingInfo12, point2D24, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        polarPlot4.rendererChanged(rendererChangeEvent27);
        java.awt.Paint paint29 = polarPlot4.getAngleLabelPaint();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("SerialDate.weekInMonthToString(): invalid code.");
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit3, true, false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape9 = xYAreaRenderer7.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer14 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        xYStepRenderer14.setSeriesURLGenerator(100, xYURLGenerator16);
        xYStepRenderer14.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        boolean boolean22 = xYStepRenderer14.hasListener((java.util.EventListener) ringPlot21);
        ringPlot21.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        ringPlot21.handleClick(1, (int) 'a', plotRenderingInfo27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity32 = new org.jfree.chart.entity.JFreeChartEntity(shape9, jFreeChart29, "Other", "");
        numberAxis3D1.setLeftArrow(shape9);
        java.awt.Font font40 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection41 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection41);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection41, valueAxis43, polarItemRenderer44);
        boolean boolean47 = polarPlot45.equals((java.lang.Object) 100.0f);
        java.awt.Color color48 = java.awt.Color.lightGray;
        polarPlot45.setAngleGridlinePaint((java.awt.Paint) color48);
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font40, (java.awt.Paint) color48);
        java.awt.Font font51 = labelBlock50.getFont();
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("item", font51);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) 3, 0.0d, (double) 0.8f, 0.0d, font51);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreZeroValues();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = ringPlot0.getDrawingSupplier();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        ringPlot0.datasetChanged(datasetChangeEvent6);
        int int8 = ringPlot0.getPieIndex();
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape11 = legendItem10.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection12, valueAxis14, polarItemRenderer15);
        xYSeriesCollection12.validateObject();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection12, false);
        legendItem10.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection12);
        org.jfree.data.time.TimeSeries timeSeries21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeSeries21);
        int int23 = timeSeriesCollection22.getSeriesCount();
        xYSeriesCollection12.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection22);
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("");
        logAxis26.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot29 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = combinedDomainXYPlot29.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis32 = combinedDomainXYPlot29.getDomainAxis(3);
        org.jfree.chart.axis.ValueAxis valueAxis34 = combinedDomainXYPlot29.getDomainAxis((int) (byte) 1);
        org.jfree.chart.axis.LogAxis logAxis36 = new org.jfree.chart.axis.LogAxis("");
        logAxis36.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot39 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis36);
        int int40 = combinedDomainXYPlot29.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis36);
        boolean boolean41 = xYSeriesCollection12.hasListener((java.util.EventListener) combinedDomainXYPlot29);
        ringPlot0.setParent((org.jfree.chart.plot.Plot) combinedDomainXYPlot29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "Other", "RectangleAnchor.TOP");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 1.0f + "'", comparable4.equals(1.0f));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 0.2d, (java.lang.Number) 0L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot6.getDomainAxisEdge((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        numberAxis3D1.setNegativeArrowVisible(false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.Plot plot1 = categoryAxis3D0.getPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) '4', (java.awt.Paint) color3);
        float float5 = categoryAxis3D0.getTickMarkInsideLength();
        categoryAxis3D0.configure();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis3D0.getCategorySeriesMiddle((int) (byte) -1, (int) (short) 10, 7, (int) ' ', (double) 1, rectangle2D12, rectangleEdge13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        logAxis24.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = combinedDomainXYPlot27.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis30 = combinedDomainXYPlot27.getDomainAxis(3);
        combinedDomainXYPlot27.configureRangeAxes();
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer36 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = null;
        xYStepRenderer36.setSeriesURLGenerator(100, xYURLGenerator38);
        xYStepRenderer36.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot(pieDataset42);
        boolean boolean44 = xYStepRenderer36.hasListener((java.util.EventListener) ringPlot43);
        java.awt.Color color46 = java.awt.Color.lightGray;
        xYStepRenderer36.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color46);
        org.jfree.chart.text.TextMeasurer textMeasurer49 = null;
        org.jfree.chart.text.TextBlock textBlock50 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, (java.awt.Paint) color46, (float) 100L, textMeasurer49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.util.Size2D size2D52 = textBlock50.calculateDimensions(graphics2D51);
        java.awt.Font font56 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection57 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection57);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        org.jfree.chart.plot.PolarPlot polarPlot61 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection57, valueAxis59, polarItemRenderer60);
        boolean boolean63 = polarPlot61.equals((java.lang.Object) 100.0f);
        java.awt.Color color64 = java.awt.Color.lightGray;
        polarPlot61.setAngleGridlinePaint((java.awt.Paint) color64);
        org.jfree.chart.block.LabelBlock labelBlock66 = new org.jfree.chart.block.LabelBlock("ChartChangeEventType.NEW_DATASET", font56, (java.awt.Paint) color64);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = labelBlock66.getTextAnchor();
        java.awt.geom.Rectangle2D rectangle2D68 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, (double) 1, (double) (short) 0, rectangleAnchor67);
        org.jfree.chart.RenderingSource renderingSource69 = null;
        combinedDomainXYPlot27.select((double) 5, (double) 2958465, rectangle2D68, renderingSource69);
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle71.setMargin(rectangleInsets72);
        textTitle71.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = textTitle71.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = textTitle71.getPosition();
        double double78 = numberAxis19.java2DToValue(0.2d, rectangle2D68, rectangleEdge77);
        try {
            double double79 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor15, (int) (byte) 10, (int) (short) 10, rectangle2D18, rectangleEdge77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(textBlock50);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + Double.NEGATIVE_INFINITY + "'", double78 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle0.setMargin(rectangleInsets1);
        textTitle0.setVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            textTitle0.setMargin(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) 100);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 10L);
        logAxis1.setRange(range6, true, false);
        boolean boolean13 = range6.contains(1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D0.getItemLabelGenerator((int) (short) 0, (int) (short) 0, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = barRenderer3D0.getDrawingSupplier();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer3D0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator7, true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNull(drawingSupplier5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        combinedDomainXYPlot4.select(generalPath5, rectangle2D6, renderingSource7);
        combinedDomainXYPlot4.clearRangeMarkers((int) (short) 0);
        combinedDomainXYPlot4.setRangeCrosshairValue(1.0E8d, false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("item");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4, textAnchor5, (double) (-1.0f));
        try {
            float float8 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str2 = legendItem1.getURLText();
        java.awt.Paint paint3 = legendItem1.getLabelPaint();
        java.awt.Paint paint4 = legendItem1.getLinePaint();
        legendItem1.setLineVisible(true);
        boolean boolean7 = legendItem1.isShapeOutlineVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 2.0f);
        boolean boolean2 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries1.createCopy(2, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        xYSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        double double9 = xYSeriesCollection8.getIntervalWidth();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        xYSeries1.removeChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection8);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection8);
        double double15 = intervalXYDelegate14.getIntervalWidth();
        intervalXYDelegate14.setAutoWidth(false);
        try {
            java.lang.Number number20 = intervalXYDelegate14.getEndX((-10), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.awt.Paint paint2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint2);
        java.awt.Stroke stroke4 = intervalMarker3.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor5 = intervalMarker3.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        intervalMarker3.setLabelOffsetType(lengthAdjustmentType6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = intervalMarker3.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYStepRenderer2.setSeriesURLGenerator(100, xYURLGenerator4);
        xYStepRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        boolean boolean10 = xYStepRenderer2.hasListener((java.util.EventListener) ringPlot9);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYStepRenderer2.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color12);
        org.jfree.chart.text.TextMeasurer textMeasurer15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, (java.awt.Paint) color12, (float) 100L, textMeasurer15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean23 = timeSeries21.equals((java.lang.Object) textBlockAnchor22);
        textBlock16.draw(graphics2D17, (float) (short) 100, (float) 4, textBlockAnchor22, (float) 12, (float) 2, (double) 10.0f);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        textBlock16.draw(graphics2D28, 10.0f, (float) 'a', textBlockAnchor31, (float) (byte) 100, (float) 2958465, (double) 500);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.List list37 = segmentedTimeline36.getExceptionSegments();
        java.lang.Object obj38 = segmentedTimeline36.clone();
        boolean boolean39 = textBlock16.equals(obj38);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertNotNull(segmentedTimeline36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, valueAxis5, polarItemRenderer6);
        xYSeriesCollection3.validateObject();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        java.awt.Paint paint12 = legendItem1.getLinePaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D13);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis3D13.getCategoryStart(3, (int) (byte) 10, rectangle2D17, rectangleEdge18);
        java.awt.Font font21 = categoryAxis3D13.getTickLabelFont((java.lang.Comparable) (byte) 10);
        legendItem1.setLabelFont(font21);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", paint24);
        legendItem1.setLabelPaint(paint24);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.lang.Object obj1 = null;
        boolean boolean2 = xYStepAreaRenderer0.equals(obj1);
        xYStepAreaRenderer0.setShapesFilled(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        boolean boolean7 = xYStepAreaRenderer0.equals((java.lang.Object) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        double double8 = xYStepAreaRenderer0.getRangeBase();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot0.setRangeMinorGridlinePaint(paint1);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) 10, (double) 1L, paint6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        intervalMarker7.notifyListeners(markerChangeEvent8);
        double double10 = intervalMarker7.getStartValue();
        float float11 = intervalMarker7.getAlpha();
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        logAxis13.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedDomainXYPlot16.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = combinedDomainXYPlot16.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        combinedDomainXYPlot16.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = combinedDomainXYPlot16.getDomainAxis();
        java.awt.Stroke stroke22 = combinedDomainXYPlot16.getDomainCrosshairStroke();
        intervalMarker7.setOutlineStroke(stroke22);
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = categoryPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker7, layer24, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.8f + "'", float11 == 0.8f);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(valueAxis21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(0, marker7, layer8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot0.getRangeMarkers(layer10);
        boolean boolean12 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.LegendItemCollection legendItemCollection2 = multiplePiePlot1.getLegendItems();
        java.util.Iterator iterator3 = legendItemCollection2.iterator();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer4 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        xYStepRenderer4.setSeriesURLGenerator(100, xYURLGenerator6);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean16 = logFormat15.isParseIntegerOnly();
        java.text.ParsePosition parsePosition18 = null;
        java.lang.Object obj19 = logFormat15.parseObject("", parsePosition18);
        int int20 = logFormat15.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean26 = logFormat25.isParseIntegerOnly();
        java.text.ParsePosition parsePosition28 = null;
        java.lang.Object obj29 = logFormat25.parseObject("", parsePosition28);
        int int30 = logFormat25.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator31 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat25);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator32 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer33 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator31, xYURLGenerator32);
        xYStepRenderer4.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator31);
        java.lang.Boolean boolean36 = xYStepRenderer4.getSeriesShapesFilled((int) (short) 10);
        xYStepRenderer4.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, true);
        boolean boolean41 = legendItemCollection2.equals((java.lang.Object) false);
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
        double double43 = ringPlot42.getInnerSeparatorExtension();
        boolean boolean44 = ringPlot42.getIgnoreZeroValues();
        java.awt.Paint paint45 = ringPlot42.getLabelOutlinePaint();
        double double46 = ringPlot42.getMaximumLabelWidth();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor47 = ringPlot42.getLabelDistributor();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator49 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset50 = null;
        java.lang.String str52 = standardPieSectionLabelGenerator49.generateSectionLabel(pieDataset50, (java.lang.Comparable) 1);
        ringPlot42.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator49);
        boolean boolean54 = legendItemCollection2.equals((java.lang.Object) ringPlot42);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(iterator3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.14d + "'", double46 == 0.14d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor47);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        logAxis5.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedDomainXYPlot8.getRenderer();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        combinedDomainXYPlot8.plotChanged(plotChangeEvent10);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer12 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        xYStepRenderer12.setSeriesURLGenerator(100, xYURLGenerator14);
        xYStepRenderer12.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset18);
        boolean boolean20 = xYStepRenderer12.hasListener((java.util.EventListener) ringPlot19);
        java.awt.Paint paint21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer12.setBaseItemLabelPaint(paint21, false);
        combinedDomainXYPlot8.setRangeTickBandPaint(paint21);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(0.2d, 0.0d, 100.0d, (double) 68, paint21);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        timeSeries1.removeAgedItems(100L, false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        boolean boolean9 = timeSeries1.equals((java.lang.Object) 6);
        java.util.List list10 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedDomainXYPlot4.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis7 = combinedDomainXYPlot4.getDomainAxis(3);
        combinedDomainXYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D11 = combinedDomainXYPlot4.getQuadrantOrigin();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot4.getDomainMarkers(layer12);
        int int14 = combinedDomainXYPlot4.getRendererCount();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        combinedDomainXYPlot4.plotChanged(plotChangeEvent15);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D18 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        barRenderer3D18.setBaseToolTipGenerator(categoryToolTipGenerator19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        logAxis24.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot27 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis24);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer30 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepRenderer30.setSeriesOutlinePaint((int) (byte) 10, paint32, false);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer3D18.drawRangeLine(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) logAxis24, rectangle2D28, (double) (short) 0, paint32, stroke35);
        boolean boolean37 = logAxis24.isAxisLineVisible();
        java.awt.Paint paint38 = logAxis24.getAxisLinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = logAxis24.getTickLabelInsets();
        combinedDomainXYPlot4.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) logAxis24);
        combinedDomainXYPlot4.setDomainGridlinesVisible(false);
        combinedDomainXYPlot4.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNull(xYItemRenderer5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateValue((double) 8);
        logAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot6.setRangeMinorGridlinePaint(paint7);
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D12.setTickLabelsVisible(true);
        boolean boolean15 = logAxis11.equals((java.lang.Object) true);
        int int16 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis11);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E8d + "'", double3 == 1.0E8d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getInnerSeparatorExtension();
        boolean boolean3 = ringPlot1.getIgnoreZeroValues();
        java.awt.Paint paint4 = ringPlot1.getLabelOutlinePaint();
        categoryPlot0.setRangeMinorGridlinePaint(paint4);
        boolean boolean6 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYStepRenderer7.setSeriesURLGenerator(100, xYURLGenerator9);
        xYStepRenderer7.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYStepRenderer7.getSeriesPositiveItemLabelPosition(5);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot15.setRangeMinorGridlinePaint(paint16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        logAxis19.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedDomainXYPlot22.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis25 = combinedDomainXYPlot22.getDomainAxis(3);
        combinedDomainXYPlot22.setDomainCrosshairValue(0.0d, false);
        combinedDomainXYPlot22.setRangePannable(true);
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) categoryPlot15);
        xYStepRenderer7.notifyListeners(rendererChangeEvent32);
        categoryPlot0.rendererChanged(rendererChangeEvent32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = barRenderer3D0.getGradientPaintTransformer();
        double[] doubleArray9 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray13 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray17 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray21 = new double[] { 2958465, (short) 1, 0 };
        double[] doubleArray25 = new double[] { 2958465, (short) 1, 0 };
        double[][] doubleArray26 = new double[][] { doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ChartChangeEventType.NEW_DATASET", doubleArray26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset27, true);
        java.lang.Number number30 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range31 = barRenderer3D0.findRangeBounds(categoryDataset27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot32 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot33 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepRenderer1.setSeriesURLGenerator(100, xYURLGenerator3);
        xYStepRenderer1.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = xYStepRenderer1.hasListener((java.util.EventListener) ringPlot8);
        ringPlot8.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        ringPlot8.handleClick(1, (int) 'a', plotRenderingInfo14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle17.setMargin(rectangleInsets18);
        textTitle17.setVisible(false);
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle17);
        jFreeChart16.fireChartChanged();
        java.awt.RenderingHints renderingHints24 = jFreeChart16.getRenderingHints();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(renderingHints24);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean5 = logFormat4.isParseIntegerOnly();
        java.text.ParsePosition parsePosition7 = null;
        java.lang.Object obj8 = logFormat4.parseObject("", parsePosition7);
        java.lang.Object obj9 = null;
        boolean boolean10 = logFormat4.equals(obj9);
        logFormat4.setParseIntegerOnly(true);
        logFormat4.setGroupingUsed(true);
        java.text.ParsePosition parsePosition16 = null;
        java.lang.Object obj17 = logFormat4.parseObject("HorizontalAlignment.CENTER", parsePosition16);
        java.lang.Object obj18 = logFormat4.clone();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint22 = xYAreaRenderer20.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = xYAreaRenderer20.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState29 = xYAreaRenderer20.initialise(graphics2D24, rectangle2D25, xYPlot26, xYDataset27, plotRenderingInfo28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYAreaRenderer20.getBasePositiveItemLabelPosition();
        boolean boolean31 = itemLabelAnchor19.equals((java.lang.Object) xYAreaRenderer20);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator33 = null;
        xYAreaRenderer20.setSeriesItemLabelGenerator(0, xYItemLabelGenerator33, false);
        java.util.Collection collection36 = xYAreaRenderer20.getAnnotations();
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator37 = logFormat4.formatToCharacterIterator((java.lang.Object) xYAreaRenderer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(xYToolTipGenerator23);
        org.junit.Assert.assertNotNull(xYItemRendererState29);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(collection36);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = xYAreaRenderer0.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        chartEntity5.setArea(shape7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) chartEntity5, true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getIgnoreZeroValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        double double4 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getLegendLabelURLGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = ringPlot0.getURLGenerator();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        double double8 = ringPlot7.getInnerSeparatorExtension();
        boolean boolean9 = ringPlot7.getIgnoreZeroValues();
        java.awt.Paint paint10 = ringPlot7.getLabelOutlinePaint();
        double double11 = ringPlot7.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = ringPlot7.getLegendLabelURLGenerator();
        boolean boolean13 = ringPlot0.equals((java.lang.Object) ringPlot7);
        ringPlot0.setSectionDepth(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.14d + "'", double11 == 0.14d);
        org.junit.Assert.assertNull(pieURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, true);
        java.util.Collection collection3 = xYLineAndShapeRenderer2.getAnnotations();
        xYLineAndShapeRenderer2.setDefaultEntityRadius(5);
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textLine0.calculateDimensions(graphics2D3);
        double double5 = size2D4.height;
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("{0}: ({1}, {2})");
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("");
        logAxis3.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis3);
        boolean boolean7 = periodAxis1.equals((java.lang.Object) logAxis3);
        java.lang.Class class8 = periodAxis1.getMinorTickTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        double double2 = multiplePiePlot1.getLimit();
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot1.getDataset();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape6 = xYAreaRenderer4.lookupSeriesShape((int) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "-∞", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = null;
        xYStepRenderer11.setSeriesURLGenerator(100, xYURLGenerator13);
        xYStepRenderer11.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        boolean boolean19 = xYStepRenderer11.hasListener((java.util.EventListener) ringPlot18);
        ringPlot18.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        ringPlot18.handleClick(1, (int) 'a', plotRenderingInfo24);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot18);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity29 = new org.jfree.chart.entity.JFreeChartEntity(shape6, jFreeChart26, "Other", "");
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart26.setBorderStroke(stroke30);
        multiplePiePlot1.setPieChart(jFreeChart26);
        jFreeChart26.setNotify(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 15, (int) (short) 0, 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = segmentedTimeline3.getBaseTimeline();
        org.junit.Assert.assertNull(segmentedTimeline4);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("{0}: ({1}, {2})");
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("");
        logAxis3.setPositiveArrowVisible(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis3);
        boolean boolean7 = periodAxis1.equals((java.lang.Object) logAxis3);
        java.awt.Paint paint8 = periodAxis1.getMinorTickMarkPaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setTickLabelsVisible(true);
        boolean boolean5 = logAxis1.equals((java.lang.Object) true);
        logAxis1.setNegativeArrowVisible(false);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        logAxis1.setAxisLineStroke(stroke8);
        double double10 = logAxis1.getFixedAutoRange();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D11.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = barRenderer3D11.getGradientPaintTransformer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection16, valueAxis18, polarItemRenderer19);
        boolean boolean21 = polarPlot20.isAngleGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        polarPlot20.zoomDomainAxes((double) 100.0f, plotRenderingInfo23, point2D24);
        java.awt.Stroke stroke26 = polarPlot20.getRadiusGridlineStroke();
        barRenderer3D11.setSeriesOutlineStroke((int) 'a', stroke26);
        logAxis1.setAxisLineStroke(stroke26);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getIgnoreNullValues();
        ringPlot1.clearSectionOutlineStrokes(true);
        boolean boolean5 = ringPlot1.getSectionOutlinesVisible();
        double double6 = ringPlot1.getLabelGap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("PieLabelLinkStyle.STANDARD");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("index.html");
        java.lang.String str2 = legendItem1.getURLText();
        java.awt.Paint paint3 = legendItem1.getLabelPaint();
        java.awt.Paint paint4 = legendItem1.getLinePaint();
        java.lang.String str5 = legendItem1.getToolTipText();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.Marker marker4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        xYStepRenderer0.drawRangeMarker(graphics2D1, xYPlot2, valueAxis3, marker4, rectangle2D5);
        org.jfree.chart.util.LogFormat logFormat12 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean13 = logFormat12.isParseIntegerOnly();
        java.text.ParsePosition parsePosition15 = null;
        java.lang.Object obj16 = logFormat12.parseObject("", parsePosition15);
        int int17 = logFormat12.getMinimumIntegerDigits();
        org.jfree.chart.util.LogFormat logFormat22 = new org.jfree.chart.util.LogFormat((double) '#', "", "", false);
        boolean boolean23 = logFormat22.isParseIntegerOnly();
        java.text.ParsePosition parsePosition25 = null;
        java.lang.Object obj26 = logFormat22.parseObject("", parsePosition25);
        int int27 = logFormat22.getMinimumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator28 = new org.jfree.chart.labels.StandardXYToolTipGenerator("index.html", (java.text.NumberFormat) logFormat12, (java.text.NumberFormat) logFormat22);
        xYStepRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator28, false);
        java.text.NumberFormat numberFormat31 = standardXYToolTipGenerator28.getYFormat();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(numberFormat31);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis3D1.getCategoryStart(3, (int) (byte) 10, rectangle2D5, rectangleEdge6);
        java.awt.Font font9 = categoryAxis3D1.getTickLabelFont((java.lang.Comparable) (byte) 10);
        textTitle0.setFont(font9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        textTitle0.draw(graphics2D11, rectangle2D12);
        textTitle0.setURLText("index.html");
        textTitle0.setNotify(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getName();
        java.util.Locale locale2 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) tickUnitSource3);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getName();
        java.awt.Image image7 = null;
        projectInfo5.setLogo(image7);
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo5.getOptionalLibraries();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
        java.lang.String str11 = projectInfo0.toString();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull" + "'", str11.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (null).\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYStepRenderer0.setSeriesURLGenerator(100, xYURLGenerator2);
        xYStepRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = xYStepRenderer0.hasListener((java.util.EventListener) ringPlot7);
        float float9 = ringPlot7.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }
}

