import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.lang.String str21 = year20.toString();
//        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
//        boolean boolean23 = timeSeries3.getNotify();
//        java.util.List list24 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond30.getMiddleMillisecond(calendar34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (double) 9999);
//        boolean boolean39 = fixedMillisecond30.equals((java.lang.Object) day36);
//        timeSeries28.setKey((java.lang.Comparable) fixedMillisecond30);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        int int42 = year41.getYear();
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year41, (double) 10.0f);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        java.lang.String str46 = year45.toString();
//        java.lang.Number number47 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) year45);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 0);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day54, (double) 9999);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        long long58 = year57.getSerialIndex();
//        java.util.Date date59 = year57.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, 0.0d);
//        timeSeriesDataItem61.setSelected(true);
//        int int64 = timeSeriesDataItem56.compareTo((java.lang.Object) timeSeriesDataItem61);
//        timeSeries53.add(timeSeriesDataItem56);
//        timeSeries53.clear();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) day67, (java.lang.Number) 7);
//        long long70 = day67.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = day67.previous();
//        boolean boolean72 = timeSeriesDataItem49.equals((java.lang.Object) regularTimePeriod71);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries3.addOrUpdate(timeSeriesDataItem49);
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day78, (double) 9999);
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year();
//        long long82 = year81.getSerialIndex();
//        java.util.Date date83 = year81.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year81, 0.0d);
//        timeSeriesDataItem85.setSelected(true);
//        int int88 = timeSeriesDataItem80.compareTo((java.lang.Object) timeSeriesDataItem85);
//        timeSeries77.add(timeSeriesDataItem80);
//        timeSeries77.clear();
//        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day();
//        timeSeries77.add((org.jfree.data.time.RegularTimePeriod) day91, (java.lang.Number) 7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = day91.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = timeSeries3.getDataItem(regularTimePeriod94);
//        java.lang.Comparable comparable96 = timeSeries3.getKey();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2019" + "'", str46.equals("2019"));
//        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 10.0d + "'", number47.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 43626L + "'", long70 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem73);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 2019L + "'", long82 == 2019L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem95);
//        org.junit.Assert.assertNotNull(comparable96);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, 0.0d);
        timeSeriesDataItem31.setSelected(true);
        int int34 = timeSeriesDataItem26.compareTo((java.lang.Object) timeSeriesDataItem31);
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.clear();
        java.util.Collection collection37 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        timeSeries23.setNotify(false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(collection37);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        int int17 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) 9999);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, 0.0d);
        timeSeriesDataItem29.setSelected(true);
        int int32 = timeSeriesDataItem24.compareTo((java.lang.Object) timeSeriesDataItem29);
        timeSeries21.add(timeSeriesDataItem24);
        timeSeries21.clear();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        long long42 = fixedMillisecond39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.lang.String str44 = timeSeries21.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries3.addAndOrUpdate(timeSeries21);
        double double46 = timeSeries3.getMinY();
        java.lang.String str47 = timeSeries3.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond53.getMiddleMillisecond(calendar54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond53.next();
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond53.getMiddleMillisecond(calendar57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day59, (double) 9999);
        boolean boolean62 = fixedMillisecond53.equals((java.lang.Object) day59);
        timeSeries51.setKey((java.lang.Comparable) fixedMillisecond53);
        java.util.Date date64 = fixedMillisecond53.getTime();
        java.lang.String str65 = fixedMillisecond53.toString();
        long long66 = fixedMillisecond53.getLastMillisecond();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) (-61851744000000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str44.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 7.0d + "'", double46 == 7.0d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019" + "'", str47.equals("2019"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 10L + "'", long58 == 10L);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str65.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, 0.0d);
        timeSeriesDataItem31.setSelected(true);
        int int34 = timeSeriesDataItem26.compareTo((java.lang.Object) timeSeriesDataItem31);
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.clear();
        java.util.Collection collection37 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        boolean boolean38 = timeSeries3.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries3.addChangeListener(seriesChangeListener39);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond46.next();
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond46.getMiddleMillisecond(calendar50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day52, (double) 9999);
        boolean boolean55 = fixedMillisecond46.equals((java.lang.Object) day52);
        timeSeries44.setKey((java.lang.Comparable) fixedMillisecond46);
        double double57 = timeSeries44.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries44.removeChangeListener(seriesChangeListener58);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries44.createCopy(8, (int) (short) 10);
        long long63 = timeSeries62.getMaximumItemAge();
        java.util.Collection collection64 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries62);
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = fixedMillisecond70.next();
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond70.getMiddleMillisecond(calendar74);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day76, (double) 9999);
        boolean boolean79 = fixedMillisecond70.equals((java.lang.Object) day76);
        timeSeries68.setKey((java.lang.Comparable) fixedMillisecond70);
        double double81 = timeSeries68.getMaxY();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
        int int83 = year82.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException85 = new org.jfree.data.time.TimePeriodFormatException("");
        int int86 = year82.compareTo((java.lang.Object) timePeriodFormatException85);
        timeSeries68.add((org.jfree.data.time.RegularTimePeriod) year82, (double) 100, true);
        org.jfree.data.time.Month month92 = new org.jfree.data.time.Month(1, 10);
        java.lang.String str93 = month92.toString();
        java.lang.String str94 = month92.toString();
        timeSeries68.update((org.jfree.data.time.RegularTimePeriod) month92, (java.lang.Number) 1546329600000L);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month92, (java.lang.Number) 2147483647, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 9223372036854775807L + "'", long63 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection64);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertEquals((double) double81, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2019 + "'", int83 == 2019);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "January 10" + "'", str93.equals("January 10"));
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "January 10" + "'", str94.equals("January 10"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Year year11 = month10.getYear();
        boolean boolean13 = month10.equals((java.lang.Object) 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month10.next();
        long long15 = month10.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24229L + "'", long15 == 24229L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.lang.Class<?> wildcardClass25 = timeSeries3.getClass();
        boolean boolean26 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries3.removeChangeListener(seriesChangeListener27);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 9999);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) day15);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond9);
        double double20 = timeSeries7.getMaxY();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        int int25 = year21.compareTo((java.lang.Object) timePeriodFormatException24);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year21, (double) 100, true);
        boolean boolean29 = year0.equals((java.lang.Object) year21);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = year0.getMiddleMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond17.next();
        java.util.Calendar calendar24 = null;
        fixedMillisecond17.peg(calendar24);
        long long26 = fixedMillisecond17.getLastMillisecond();
        java.util.Calendar calendar27 = null;
        fixedMillisecond17.peg(calendar27);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9999.0d + "'", number20.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.List list21 = timeSeries3.getItems();
        java.lang.String str22 = timeSeries3.getDescription();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9999.0d + "'", number20.equals(9999.0d));
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNull(str22);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        timeSeries3.fireSeriesChanged();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond19);
        java.lang.Object obj24 = timeSeries3.clone();
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day38, (double) 9999);
        boolean boolean41 = fixedMillisecond32.equals((java.lang.Object) day38);
        timeSeries30.setKey((java.lang.Comparable) fixedMillisecond32);
        double double43 = timeSeries30.getMaxY();
        java.lang.Object obj44 = timeSeries30.clone();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getMiddleMillisecond(calendar51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond50.next();
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond50.getMiddleMillisecond(calendar54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day56, (double) 9999);
        boolean boolean59 = fixedMillisecond50.equals((java.lang.Object) day56);
        timeSeries48.setKey((java.lang.Comparable) fixedMillisecond50);
        java.util.Date date61 = fixedMillisecond50.getTime();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) 11);
        int int64 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 10L + "'", long52 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        double double36 = timeSeries3.getMinY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener37);
//        java.lang.String str39 = timeSeries3.getDescription();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
//        org.junit.Assert.assertNull(str39);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getMiddleMillisecond(calendar12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) 9999);
        boolean boolean17 = fixedMillisecond8.equals((java.lang.Object) day14);
        timeSeries6.setKey((java.lang.Comparable) fixedMillisecond8);
        boolean boolean19 = timeSeries6.isEmpty();
        int int20 = month2.compareTo((java.lang.Object) timeSeries6);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        java.util.Date date23 = year21.getStart();
        java.lang.String str24 = year21.toString();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries6.createCopy((int) (short) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (-1L));
        boolean boolean5 = timeSeriesDataItem3.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        java.util.Date date8 = year6.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        int int11 = timeSeriesDataItem3.compareTo((java.lang.Object) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.previous();
        java.util.Calendar calendar13 = null;
        try {
            day10.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        long long4 = fixedMillisecond3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond10.getMiddleMillisecond(calendar14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 9999);
        boolean boolean19 = fixedMillisecond10.equals((java.lang.Object) day16);
        timeSeries8.setKey((java.lang.Comparable) fixedMillisecond10);
        double double21 = timeSeries8.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries8.removeChangeListener(seriesChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries8.createCopy(8, (int) (short) 10);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.next();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond34.getMiddleMillisecond(calendar38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day40, (double) 9999);
        boolean boolean43 = fixedMillisecond34.equals((java.lang.Object) day40);
        timeSeries32.setKey((java.lang.Comparable) fixedMillisecond34);
        double double45 = timeSeries32.getMaxY();
        java.lang.Object obj46 = timeSeries32.clone();
        double double47 = timeSeries32.getMinY();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries26.addAndOrUpdate(timeSeries32);
        int int49 = fixedMillisecond3.compareTo((java.lang.Object) timeSeries26);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(12, 1);
        long long53 = month52.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month52.next();
        timeSeries26.add(regularTimePeriod54, (double) 1L, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = null;
        try {
            timeSeries26.add(regularTimePeriod58, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62106883200000L) + "'", long53 == (-62106883200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
        int int3 = day0.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (double) 9999);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, 0.0d);
        timeSeriesDataItem15.setSelected(true);
        int int18 = timeSeriesDataItem10.compareTo((java.lang.Object) timeSeriesDataItem15);
        timeSeries7.add(timeSeriesDataItem10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        java.lang.Number number24 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        int int25 = day0.compareTo((java.lang.Object) fixedMillisecond21);
        org.jfree.data.time.SerialDate serialDate26 = day0.getSerialDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
        java.util.Calendar calendar29 = null;
        try {
            long long30 = day27.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 9999.0d + "'", number24.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, 0.0d);
        timeSeriesDataItem31.setSelected(true);
        int int34 = timeSeriesDataItem26.compareTo((java.lang.Object) timeSeriesDataItem31);
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.clear();
        java.util.Collection collection37 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        java.lang.Class<?> wildcardClass38 = timeSeries23.getClass();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "2019", "January 10");
//        double double4 = timeSeries3.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond10.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 9999);
//        boolean boolean19 = fixedMillisecond10.equals((java.lang.Object) day16);
//        timeSeries8.setKey((java.lang.Comparable) fixedMillisecond10);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        int int22 = year21.getYear();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year21, (double) 10.0f);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.next();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond29.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (double) 9999);
//        boolean boolean38 = fixedMillisecond29.equals((java.lang.Object) day35);
//        java.lang.String str39 = day35.toString();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day35.previous();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, 0.0d);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560184313264L + "'", long2 == 1560184313264L);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
        java.lang.String str3 = month2.toString();
        boolean boolean5 = month2.equals((java.lang.Object) 2019);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries3.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
        double double37 = timeSeries24.getMaxY();
        java.lang.Object obj38 = timeSeries24.clone();
        double double39 = timeSeries24.getMinY();
        timeSeries24.setMaximumItemAge(1577865599999L);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.addAndOrUpdate(timeSeries24);
        double double43 = timeSeries24.getMaxY();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 10);
        int int3 = month2.getMonth();
        long long4 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61833427200000L) + "'", long4 == (-61833427200000L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.clear();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        long long24 = fixedMillisecond21.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond21.getMiddleMillisecond(calendar26);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        java.lang.Class class19 = timeSeries3.getTimePeriodClass();
        int int20 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) (short) -1, false);
        try {
            org.jfree.data.time.TimeSeries timeSeries28 = timeSeries3.createCopy((int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.Year year3 = month2.getYear();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) 9999);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        timeSeriesDataItem16.setSelected(true);
        int int19 = timeSeriesDataItem11.compareTo((java.lang.Object) timeSeriesDataItem16);
        timeSeries8.add(timeSeriesDataItem11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.lang.Number number25 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        long long26 = fixedMillisecond22.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond22.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond22.next();
        java.lang.Number number29 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod28, number29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem30.getPeriod();
        boolean boolean32 = month2.equals((java.lang.Object) regularTimePeriod31);
        long long33 = month2.getSerialIndex();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 1" + "'", str4.equals("December 1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 9999.0d + "'", number25.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24L + "'", long33 == 24L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
        int int3 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge(1577865599999L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 8);
        java.lang.Number number23 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        timeSeries3.setKey((java.lang.Comparable) timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries3.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
        double double37 = timeSeries24.getMaxY();
        java.lang.Object obj38 = timeSeries24.clone();
        double double39 = timeSeries24.getMinY();
        timeSeries24.setMaximumItemAge(1577865599999L);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.addAndOrUpdate(timeSeries24);
        java.lang.String str43 = timeSeries42.getRangeDescription();
        long long44 = timeSeries42.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Value" + "'", str43.equals("Value"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMinY();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries3.removeChangeListener(seriesChangeListener21);
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.createCopy((int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        timeSeries3.fireSeriesChanged();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo18);
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException7);
        boolean boolean9 = month2.equals((java.lang.Object) seriesException7);
        java.lang.Object obj10 = null;
        int int11 = month2.compareTo(obj10);
        long long12 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getMiddleMillisecond(calendar22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        boolean boolean27 = fixedMillisecond18.equals((java.lang.Object) day24);
        timeSeries16.setKey((java.lang.Comparable) fixedMillisecond18);
        double double29 = timeSeries16.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries16.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries16.createCopy(8, (int) (short) 10);
        long long35 = timeSeries34.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond37.next();
        long long41 = fixedMillisecond37.getSerialIndex();
        long long42 = fixedMillisecond37.getLastMillisecond();
        long long43 = fixedMillisecond37.getSerialIndex();
        boolean boolean45 = fixedMillisecond37.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100]");
        long long46 = fixedMillisecond37.getLastMillisecond();
        java.lang.Number number47 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        int int48 = month2.compareTo((java.lang.Object) timeSeries34);
        long long49 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 24L + "'", long49 == 24L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getSerialIndex();
        java.util.Calendar calendar22 = null;
        fixedMillisecond17.peg(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond17.previous();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9999.0d + "'", number20.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "2019", "January 10");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 9999);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) day15);
//        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond9);
//        double double20 = timeSeries7.getMaxY();
//        java.lang.Object obj21 = timeSeries7.clone();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(1, 10);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 1.0d);
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.next();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getMiddleMillisecond(calendar39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day41, (double) 9999);
//        boolean boolean44 = fixedMillisecond35.equals((java.lang.Object) day41);
//        timeSeries33.setKey((java.lang.Comparable) fixedMillisecond35);
//        double double46 = timeSeries33.getMaxY();
//        java.lang.Object obj47 = timeSeries33.clone();
//        double double48 = timeSeries33.getMaxY();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
//        java.lang.Class<?> wildcardClass51 = seriesChangeEvent50.getClass();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        long long53 = year52.getSerialIndex();
//        java.util.Date date54 = year52.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date54);
//        java.util.TimeZone timeZone57 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date54, timeZone57);
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date54);
//        timeSeries33.setKey((java.lang.Comparable) date54);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        long long62 = year61.getSerialIndex();
//        java.util.Date date63 = year61.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
//        long long66 = year65.getSerialIndex();
//        java.util.Date date67 = year65.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year65, 0.0d);
//        timeSeriesDataItem69.setValue((java.lang.Number) 100.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = timeSeriesDataItem69.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, regularTimePeriod72);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day74, (double) 9999);
//        int int77 = day74.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day74.next();
//        long long79 = day74.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries73.getDataItem((org.jfree.data.time.RegularTimePeriod) day74);
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) day74, (java.lang.Number) (byte) 100);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2019L + "'", long53 == 2019L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 2019L + "'", long62 == 2019L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 43626L + "'", long79 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem80);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond3.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond3.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond3.getLastMillisecond(calendar9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        int int17 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) 9999);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, 0.0d);
        timeSeriesDataItem29.setSelected(true);
        int int32 = timeSeriesDataItem24.compareTo((java.lang.Object) timeSeriesDataItem29);
        timeSeries21.add(timeSeriesDataItem24);
        timeSeries21.clear();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        long long42 = fixedMillisecond39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.lang.String str44 = timeSeries21.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries3.addAndOrUpdate(timeSeries21);
        double double46 = timeSeries3.getMinY();
        java.lang.String str47 = timeSeries3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener48);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str44.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 7.0d + "'", double46 == 7.0d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019" + "'", str47.equals("2019"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, 10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1.0d);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener23);
        java.lang.String str25 = timeSeries3.getRangeDescription();
        java.lang.Object obj26 = timeSeries3.clone();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 9999);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) day15);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond9);
        double double20 = timeSeries7.getMaxY();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        int int25 = year21.compareTo((java.lang.Object) timePeriodFormatException24);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year21, (double) 100, true);
        boolean boolean29 = year0.equals((java.lang.Object) year21);
        java.lang.String str30 = year0.toString();
        java.lang.String str31 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries3.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
        double double37 = timeSeries24.getMaxY();
        java.lang.Object obj38 = timeSeries24.clone();
        double double39 = timeSeries24.getMinY();
        timeSeries24.setMaximumItemAge(1577865599999L);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond48.next();
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getMiddleMillisecond(calendar52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day54, (double) 9999);
        boolean boolean57 = fixedMillisecond48.equals((java.lang.Object) day54);
        timeSeries46.setKey((java.lang.Comparable) fixedMillisecond48);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        int int60 = year59.getYear();
        boolean boolean62 = year59.equals((java.lang.Object) 9999.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) year59);
        java.lang.Comparable comparable64 = timeSeries46.getKey();
        java.util.Collection collection65 = timeSeries42.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        timeSeries42.setMaximumItemCount(9);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(comparable64);
        org.junit.Assert.assertNotNull(collection65);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.clear();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        long long24 = fixedMillisecond21.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        long long26 = fixedMillisecond21.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
//        int int3 = day0.getYear();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (double) 9999);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getSerialIndex();
//        java.util.Date date13 = year11.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, 0.0d);
//        timeSeriesDataItem15.setSelected(true);
//        int int18 = timeSeriesDataItem10.compareTo((java.lang.Object) timeSeriesDataItem15);
//        timeSeries7.add(timeSeriesDataItem10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
//        java.lang.Number number24 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        int int25 = day0.compareTo((java.lang.Object) fixedMillisecond21);
//        org.jfree.data.time.SerialDate serialDate26 = day0.getSerialDate();
//        java.lang.String str27 = day0.toString();
//        int int28 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 9999.0d + "'", number24.equals(9999.0d));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10-June-2019" + "'", str27.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "2019", "January 10");
        double double4 = timeSeries3.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 10, year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries3.addAndOrUpdate(timeSeries12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries12.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, 0.0d);
        timeSeriesDataItem31.setSelected(true);
        int int34 = timeSeriesDataItem26.compareTo((java.lang.Object) timeSeriesDataItem31);
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.clear();
        java.util.Collection collection37 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        timeSeries3.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(collection37);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        java.util.Date date16 = fixedMillisecond5.getTime();
        java.lang.String str17 = fixedMillisecond5.toString();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond5.getFirstMillisecond(calendar18);
        long long20 = fixedMillisecond5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str17.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, 10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1.0d);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener23);
        java.lang.String str25 = timeSeries3.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        long long30 = fixedMillisecond27.getSerialIndex();
        java.lang.Number number31 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        timeSeries3.setMaximumItemAge(0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1.0d + "'", number31.equals(1.0d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, 10);
        java.lang.Number number29 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month28);
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = month31.getLastMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (short) 100 + "'", number29.equals((short) 100));
        org.junit.Assert.assertNotNull(date30);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        long long36 = day30.getLastMillisecond();
//        long long37 = day30.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        java.lang.Object obj16 = null;
        boolean boolean17 = timeSeries3.equals(obj16);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        boolean boolean19 = year16.equals((java.lang.Object) 9999.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year16);
        java.lang.Comparable comparable21 = timeSeries3.getKey();
        java.lang.Object obj22 = timeSeries3.clone();
        java.lang.String str23 = timeSeries3.getDescription();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.util.List list25 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond31.next();
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond31.getMiddleMillisecond(calendar35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (double) 9999);
        boolean boolean40 = fixedMillisecond31.equals((java.lang.Object) day37);
        timeSeries29.setKey((java.lang.Comparable) fixedMillisecond31);
        double double42 = timeSeries29.getMaxY();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        int int44 = year43.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("");
        int int47 = year43.compareTo((java.lang.Object) timePeriodFormatException46);
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) year43, (double) 100, true);
        long long51 = year43.getSerialIndex();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year43);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 10);
        int int3 = month2.getMonth();
        long long4 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 128L + "'", long4 == 128L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, 10);
        java.lang.Number number29 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month28);
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (short) 100 + "'", number29.equals((short) 100));
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        try {
            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.createCopy(11, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9999.0d + "'", number20.equals(9999.0d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        boolean boolean7 = fixedMillisecond3.equals((java.lang.Object) Double.NaN);
        long long8 = fixedMillisecond3.getSerialIndex();
        long long9 = fixedMillisecond3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "2019", "January 10");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 9999);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) day15);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond9);
        double double20 = timeSeries7.getMaxY();
        java.lang.Object obj21 = timeSeries7.clone();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(1, 10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 1.0d);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries7);
        timeSeries7.setDomainDescription("Value");
        int int32 = timeSeries7.getItemCount();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.createCopy(1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        timeSeries3.removeAgedItems((long) 2019, true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries3.addChangeListener(seriesChangeListener27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getSerialIndex();
        java.util.Date date31 = year29.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
        long long33 = fixedMillisecond32.getLastMillisecond();
        java.util.Calendar calendar34 = null;
        fixedMillisecond32.peg(calendar34);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) ' ');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.clear();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getNextTimePeriod();
        java.lang.Comparable comparable21 = timeSeries3.getKey();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        int int26 = year22.compareTo((java.lang.Object) timePeriodFormatException25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year22.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries3.getDataItem(regularTimePeriod27);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (double) 9999);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getSerialIndex();
        java.util.Date date38 = year36.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, 0.0d);
        timeSeriesDataItem40.setSelected(true);
        int int43 = timeSeriesDataItem35.compareTo((java.lang.Object) timeSeriesDataItem40);
        timeSeries32.add(timeSeriesDataItem35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        java.lang.Number number49 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getSerialIndex();
        java.util.Date date52 = year50.getStart();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date52);
        boolean boolean54 = timeSeries32.equals((java.lang.Object) year53);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str60 = timePeriodFormatException59.toString();
        org.jfree.data.general.SeriesException seriesException62 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException59.addSuppressed((java.lang.Throwable) seriesException62);
        boolean boolean64 = month57.equals((java.lang.Object) seriesException62);
        java.lang.Object obj65 = null;
        int int66 = month57.compareTo(obj65);
        int int67 = year53.compareTo((java.lang.Object) month57);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month57);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (byte) 1 + "'", comparable21.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 9999.0d + "'", number49.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str60.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
//        java.lang.String str3 = month2.toString();
//        boolean boolean5 = month2.equals((java.lang.Object) 2019);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond14.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (double) 9999);
//        boolean boolean23 = fixedMillisecond14.equals((java.lang.Object) day20);
//        timeSeries12.setKey((java.lang.Comparable) fixedMillisecond14);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        int int26 = year25.getYear();
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year25, (double) 10.0f);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.next();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond33.getMiddleMillisecond(calendar37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) 9999);
//        boolean boolean42 = fixedMillisecond33.equals((java.lang.Object) day39);
//        java.lang.String str43 = day39.toString();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.String str45 = timeSeries12.getDescription();
//        java.util.Collection collection46 = timeSeries12.getTimePeriods();
//        boolean boolean47 = month2.equals((java.lang.Object) timeSeries12);
//        long long48 = month2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61851744000000L) + "'", long48 == (-61851744000000L));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date24, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date24);
        timeSeries3.setKey((java.lang.Comparable) date24);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        java.util.Date date33 = year31.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getSerialIndex();
        java.util.Date date37 = year35.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, 0.0d);
        timeSeriesDataItem39.setValue((java.lang.Number) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeriesDataItem39.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, regularTimePeriod42);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond49.getMiddleMillisecond(calendar50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond49.next();
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond49.getMiddleMillisecond(calendar53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day55, (double) 9999);
        boolean boolean58 = fixedMillisecond49.equals((java.lang.Object) day55);
        timeSeries47.setKey((java.lang.Comparable) fixedMillisecond49);
        java.util.Date date60 = fixedMillisecond49.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        boolean boolean62 = timeSeries43.equals((java.lang.Object) date60);
        java.util.TimeZone timeZone63 = null;
        try {
            org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date60, timeZone63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 10L + "'", long54 == 10L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, year1);
        long long3 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, 4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184318149L + "'", long1 == 1560184318149L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560184318149L + "'", long3 == 1560184318149L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        int int17 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) 9999);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, 0.0d);
        timeSeriesDataItem29.setSelected(true);
        int int32 = timeSeriesDataItem24.compareTo((java.lang.Object) timeSeriesDataItem29);
        timeSeries21.add(timeSeriesDataItem24);
        timeSeries21.clear();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        long long42 = fixedMillisecond39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.lang.String str44 = timeSeries21.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries3.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (double) 9999);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getSerialIndex();
        java.util.Date date55 = year53.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year53, 0.0d);
        timeSeriesDataItem57.setSelected(true);
        int int60 = timeSeriesDataItem52.compareTo((java.lang.Object) timeSeriesDataItem57);
        timeSeries49.add(timeSeriesDataItem52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar64 = null;
        long long65 = fixedMillisecond63.getMiddleMillisecond(calendar64);
        java.lang.Number number66 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        long long67 = fixedMillisecond63.getSerialIndex();
        java.util.Calendar calendar68 = null;
        fixedMillisecond63.peg(calendar68);
        try {
            timeSeries3.setKey((java.lang.Comparable) calendar68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str44.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 10L + "'", long65 == 10L);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 9999.0d + "'", number66.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 10L + "'", long67 == 10L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) ' ');
        int int5 = year0.compareTo((java.lang.Object) '4');
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) ' ');
        int int11 = year6.compareTo((java.lang.Object) '4');
        boolean boolean12 = year0.equals((java.lang.Object) year6);
        int int13 = year6.getYear();
        java.lang.String str14 = year6.toString();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year6.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        int int4 = year0.compareTo((java.lang.Object) timePeriodFormatException3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getLastMillisecond();
        java.lang.String str7 = year0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, 0.0d);
        timeSeriesDataItem4.setValue((java.lang.Number) 100.0d);
        java.lang.Object obj7 = timeSeriesDataItem4.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj7);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.String str36 = timeSeries3.getDescription();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int39 = day37.compareTo((java.lang.Object) '#');
//        int int40 = day37.getYear();
//        long long41 = day37.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem42.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeriesDataItem42.getPeriod();
//        java.lang.Number number45 = timeSeriesDataItem42.getValue();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560150000000L + "'", long41 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 10.0d + "'", number45.equals(10.0d));
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        long long4 = fixedMillisecond3.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getMiddleMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) '#');
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        int int17 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) 9999);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, 0.0d);
        timeSeriesDataItem29.setSelected(true);
        int int32 = timeSeriesDataItem24.compareTo((java.lang.Object) timeSeriesDataItem29);
        timeSeries21.add(timeSeriesDataItem24);
        timeSeries21.clear();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        long long42 = fixedMillisecond39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.lang.String str44 = timeSeries21.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries3.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, (double) 9999);
        java.lang.Class<?> wildcardClass49 = timeSeriesDataItem48.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries3.addOrUpdate(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str44.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        boolean boolean16 = timeSeries3.isEmpty();
        java.lang.Class class17 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        java.lang.String str20 = year18.toString();
        java.lang.String str21 = year18.toString();
        int int23 = year18.compareTo((java.lang.Object) (byte) 1);
        int int24 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 9999);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) day7);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond1.getMiddleMillisecond(calendar11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0);
        int int26 = timeSeriesDataItem24.compareTo((java.lang.Object) 1546329600000L);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        java.lang.String str30 = year27.toString();
        boolean boolean31 = timeSeriesDataItem24.equals((java.lang.Object) str30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem24.getPeriod();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.Year year3 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("December 1");
        java.lang.Class<?> wildcardClass2 = seriesException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        java.util.Date date23 = year20.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.previous();
        long long25 = year20.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.Year year3 = month2.getYear();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) 9999);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        timeSeriesDataItem16.setSelected(true);
        int int19 = timeSeriesDataItem11.compareTo((java.lang.Object) timeSeriesDataItem16);
        timeSeries8.add(timeSeriesDataItem11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.lang.Number number25 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        long long26 = fixedMillisecond22.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond22.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond22.next();
        java.lang.Number number29 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod28, number29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem30.getPeriod();
        boolean boolean32 = month2.equals((java.lang.Object) regularTimePeriod31);
        org.jfree.data.time.Year year33 = month2.getYear();
        java.lang.String str34 = year33.toString();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 1" + "'", str4.equals("December 1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 9999.0d + "'", number25.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
//        timeSeriesDataItem11.setSelected(true);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.clear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
//        long long20 = day17.getSerialIndex();
//        long long21 = day17.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate22 = day17.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day23.getMiddleMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate22);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        int int36 = month22.getYearValue();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond6.getMiddleMillisecond(calendar10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) 9999);
        boolean boolean15 = fixedMillisecond6.equals((java.lang.Object) day12);
        timeSeries4.setKey((java.lang.Comparable) fixedMillisecond6);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year17, (double) 10.0f);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(1, year17);
        java.util.Calendar calendar22 = null;
        try {
            year17.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 10");
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
        timeSeries22.setKey((java.lang.Comparable) fixedMillisecond24);
        double double35 = timeSeries22.getMaxY();
        int int36 = timeSeries22.getItemCount();
        timeSeries22.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries3.addAndOrUpdate(timeSeries22);
        timeSeries22.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:00 PST 1969");
        java.lang.String str41 = timeSeries22.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str41.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.lang.Class<?> wildcardClass25 = timeSeries3.getClass();
        timeSeries3.setMaximumItemCount(7);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.next();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond33.getMiddleMillisecond(calendar37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) 9999);
        boolean boolean42 = fixedMillisecond33.equals((java.lang.Object) day39);
        timeSeries31.setKey((java.lang.Comparable) fixedMillisecond33);
        double double44 = timeSeries31.getMaxY();
        java.lang.Object obj45 = timeSeries31.clone();
        double double46 = timeSeries31.getMinY();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getMiddleMillisecond(calendar53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond52.next();
        java.util.Calendar calendar56 = null;
        long long57 = fixedMillisecond52.getMiddleMillisecond(calendar56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day58, (double) 9999);
        boolean boolean61 = fixedMillisecond52.equals((java.lang.Object) day58);
        timeSeries50.setKey((java.lang.Comparable) fixedMillisecond52);
        double double63 = timeSeries50.getMaxY();
        int int64 = timeSeries50.getItemCount();
        timeSeries50.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries31.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        long long68 = year67.getSerialIndex();
        java.util.Date date69 = year67.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year67, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = timeSeriesDataItem71.getPeriod();
        timeSeries50.add(timeSeriesDataItem71, true);
        try {
            timeSeries3.add(timeSeriesDataItem71, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 10L + "'", long54 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond3.getMiddleMillisecond();
        java.util.Date date7 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        java.util.Date date5 = year3.getStart();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, "org.jfree.data.event.SeriesChangeEvent[source=100]", "January 10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries3.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.createCopy(8, (int) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond27.next();
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond27.getMiddleMillisecond(calendar31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (double) 9999);
        boolean boolean36 = fixedMillisecond27.equals((java.lang.Object) day33);
        timeSeries25.setKey((java.lang.Comparable) fixedMillisecond27);
        timeSeries25.setMaximumItemAge((long) (short) 0);
        java.lang.String str40 = timeSeries25.getDescription();
        boolean boolean41 = timeSeries3.equals((java.lang.Object) timeSeries25);
        java.util.List list42 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(list42);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        int int21 = year17.compareTo((java.lang.Object) timePeriodFormatException20);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (double) 100, true);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        int int29 = year17.compareTo((java.lang.Object) year26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 8);
        timeSeriesDataItem31.setSelected(true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.String str36 = timeSeries3.getDescription();
//        java.util.Collection collection37 = timeSeries3.getTimePeriods();
//        java.util.Collection collection38 = timeSeries3.getTimePeriods();
//        java.lang.Comparable comparable39 = timeSeries3.getKey();
//        timeSeries3.setNotify(true);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertNotNull(comparable39);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries3.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.createCopy(8, (int) (short) 10);
        long long22 = timeSeries21.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getSerialIndex();
        long long29 = fixedMillisecond24.getLastMillisecond();
        long long30 = fixedMillisecond24.getSerialIndex();
        boolean boolean32 = fixedMillisecond24.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100]");
        long long33 = fixedMillisecond24.getLastMillisecond();
        java.lang.Number number34 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        int int35 = timeSeries21.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        java.util.Date date8 = year6.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
        java.util.Date date13 = year12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond41.next();
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond41.getMiddleMillisecond(calendar45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day47, (double) 9999);
//        boolean boolean50 = fixedMillisecond41.equals((java.lang.Object) day47);
//        timeSeries39.setKey((java.lang.Comparable) fixedMillisecond41);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        int int53 = year52.getYear();
//        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) year52, (double) 10.0f);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day60, (double) 9999);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
//        long long64 = year63.getSerialIndex();
//        java.util.Date date65 = year63.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year63, 0.0d);
//        timeSeriesDataItem67.setSelected(true);
//        int int70 = timeSeriesDataItem62.compareTo((java.lang.Object) timeSeriesDataItem67);
//        timeSeries59.add(timeSeriesDataItem62);
//        timeSeries59.clear();
//        java.util.Collection collection73 = timeSeries39.getTimePeriodsUniqueToOtherSeries(timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries3.addAndOrUpdate(timeSeries39);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 2019L + "'", long64 == 2019L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertNotNull(collection73);
//        org.junit.Assert.assertNotNull(timeSeries74);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
//        java.lang.String str3 = month2.toString();
//        boolean boolean5 = month2.equals((java.lang.Object) 2019);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond14.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (double) 9999);
//        boolean boolean23 = fixedMillisecond14.equals((java.lang.Object) day20);
//        timeSeries12.setKey((java.lang.Comparable) fixedMillisecond14);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        int int26 = year25.getYear();
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year25, (double) 10.0f);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.next();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond33.getMiddleMillisecond(calendar37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) 9999);
//        boolean boolean42 = fixedMillisecond33.equals((java.lang.Object) day39);
//        java.lang.String str43 = day39.toString();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.String str45 = timeSeries12.getDescription();
//        java.util.Collection collection46 = timeSeries12.getTimePeriods();
//        boolean boolean47 = month2.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond53.getMiddleMillisecond(calendar54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond53.next();
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond53.getMiddleMillisecond(calendar57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day59, (double) 9999);
//        boolean boolean62 = fixedMillisecond53.equals((java.lang.Object) day59);
//        timeSeries51.setKey((java.lang.Comparable) fixedMillisecond53);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
//        int int65 = year64.getYear();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) year64, (double) 10.0f);
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar73 = null;
//        long long74 = fixedMillisecond72.getMiddleMillisecond(calendar73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond72.next();
//        java.util.Calendar calendar76 = null;
//        long long77 = fixedMillisecond72.getMiddleMillisecond(calendar76);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day78, (double) 9999);
//        boolean boolean81 = fixedMillisecond72.equals((java.lang.Object) day78);
//        java.lang.String str82 = day78.toString();
//        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) month70, (org.jfree.data.time.RegularTimePeriod) day78);
//        java.lang.String str84 = timeSeries51.getDescription();
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
//        int int87 = day85.compareTo((java.lang.Object) '#');
//        int int88 = day85.getYear();
//        long long89 = day85.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) day85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = day85.next();
//        java.lang.Number number92 = timeSeries12.getValue(regularTimePeriod91);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 10L + "'", long58 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 10L + "'", long74 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "10-June-2019" + "'", str82.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries83);
//        org.junit.Assert.assertNull(str84);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2019 + "'", int88 == 2019);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1560150000000L + "'", long89 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertTrue("'" + number92 + "' != '" + 10.0d + "'", number92.equals(10.0d));
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond28.previous();
        long long34 = fixedMillisecond28.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        int int17 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) 9999);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, 0.0d);
        timeSeriesDataItem29.setSelected(true);
        int int32 = timeSeriesDataItem24.compareTo((java.lang.Object) timeSeriesDataItem29);
        timeSeries21.add(timeSeriesDataItem24);
        timeSeries21.clear();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        long long42 = fixedMillisecond39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.lang.String str44 = timeSeries21.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries3.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = null;
        try {
            timeSeries21.add(regularTimePeriod46, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str44.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNotNull(timeSeries45);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 9999);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) day15);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond9);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year20, (double) 10.0f);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.lang.String str25 = year24.toString();
        java.lang.Number number26 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) year24);
        timeSeries7.update((int) (byte) 0, (java.lang.Number) (short) 100);
        timeSeries7.removeAgedItems(1577865599999L, false);
        timeSeries7.clear();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(1, 10);
        org.jfree.data.time.Year year37 = month36.getYear();
        long long38 = month36.getFirstMillisecond();
        org.jfree.data.time.Year year39 = month36.getYear();
        java.lang.Number number40 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month36);
        java.lang.String str41 = month36.toString();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (-61820208000001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 10.0d + "'", number26.equals(10.0d));
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61851744000000L) + "'", long38 == (-61851744000000L));
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "January 10" + "'", str41.equals("January 10"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries3.removeChangeListener(seriesChangeListener19);
        double double21 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond41.next();
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond41.getMiddleMillisecond(calendar45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day47, (double) 9999);
//        boolean boolean50 = fixedMillisecond41.equals((java.lang.Object) day47);
//        timeSeries39.setKey((java.lang.Comparable) fixedMillisecond41);
//        double double52 = timeSeries39.getMaxY();
//        int int53 = timeSeries39.getItemCount();
//        boolean boolean54 = day30.equals((java.lang.Object) timeSeries39);
//        java.util.Calendar calendar55 = null;
//        try {
//            long long56 = day30.getFirstMillisecond(calendar55);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "2019", "January 10");
        double double4 = timeSeries3.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 10, year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries3.addAndOrUpdate(timeSeries12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries13.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "2019", "January 10");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 9999);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) day15);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond9);
        double double20 = timeSeries7.getMaxY();
        java.lang.Object obj21 = timeSeries7.clone();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(1, 10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 1.0d);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries7);
        timeSeries7.setMaximumItemCount(2);
        java.lang.String str32 = timeSeries7.getDomainDescription();
        timeSeries7.removeAgedItems((long) 11, true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str32.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.lang.String str21 = year20.toString();
//        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
//        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, 10);
//        java.lang.Number number29 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month28);
//        java.lang.String str30 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (double) 9999);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        long long39 = year38.getSerialIndex();
//        java.util.Date date40 = year38.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, 0.0d);
//        timeSeriesDataItem42.setSelected(true);
//        int int45 = timeSeriesDataItem37.compareTo((java.lang.Object) timeSeriesDataItem42);
//        timeSeries34.add(timeSeriesDataItem37);
//        timeSeries34.clear();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 7);
//        long long51 = day48.getSerialIndex();
//        long long52 = day48.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate53 = day48.getSerialDate();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate53);
//        java.lang.Number number55 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day54);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (short) 100 + "'", number29.equals((short) 100));
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43626L + "'", long51 == 43626L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 43626L + "'", long52 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (short) 100 + "'", number55.equals((short) 100));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        java.util.Date date16 = fixedMillisecond5.getTime();
        long long17 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "December 1", "10-June-2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 1560236399999L);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.next();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond28.getMiddleMillisecond(calendar32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (double) 9999);
        boolean boolean37 = fixedMillisecond28.equals((java.lang.Object) day34);
        timeSeries26.setKey((java.lang.Comparable) fixedMillisecond28);
        double double39 = timeSeries26.getMaxY();
        timeSeries26.setMaximumItemCount((int) '#');
        timeSeries26.setRangeDescription("2019");
        boolean boolean44 = timeSeriesDataItem22.equals((java.lang.Object) timeSeries26);
        timeSeries26.setDescription("org.jfree.data.general.SeriesException: 2019");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.util.List list25 = timeSeries3.getItems();
        timeSeries3.setMaximumItemCount(2147483647);
        try {
            timeSeries3.delete(6, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
        int int3 = day0.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (double) 9999);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, 0.0d);
        timeSeriesDataItem15.setSelected(true);
        int int18 = timeSeriesDataItem10.compareTo((java.lang.Object) timeSeriesDataItem15);
        timeSeries7.add(timeSeriesDataItem10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        java.lang.Number number24 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        int int25 = day0.compareTo((java.lang.Object) fixedMillisecond21);
        org.jfree.data.time.SerialDate serialDate26 = day0.getSerialDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 9999.0d + "'", number24.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        boolean boolean16 = timeSeries3.isEmpty();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        int int21 = year17.compareTo((java.lang.Object) timePeriodFormatException20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.next();
        long long23 = year17.getLastMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year17);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year17.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, 0.0d);
        timeSeriesDataItem4.setValue((java.lang.Number) 100.0d);
        timeSeriesDataItem4.setValue((java.lang.Number) 0.0d);
        java.lang.Object obj9 = timeSeriesDataItem4.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        double double16 = timeSeries3.getMaxY();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        int int18 = year17.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        int int21 = year17.compareTo((java.lang.Object) timePeriodFormatException20);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (double) 100, true);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(1, 10);
//        java.lang.String str28 = month27.toString();
//        java.lang.String str29 = month27.toString();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.next();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getMiddleMillisecond(calendar39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day41, (double) 9999);
//        boolean boolean44 = fixedMillisecond35.equals((java.lang.Object) day41);
//        timeSeries33.setKey((java.lang.Comparable) fixedMillisecond35);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        int int47 = year46.getYear();
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year46, (double) 10.0f);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.next();
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond54.getMiddleMillisecond(calendar58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day60, (double) 9999);
//        boolean boolean63 = fixedMillisecond54.equals((java.lang.Object) day60);
//        java.lang.String str64 = day60.toString();
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) day60);
//        java.lang.String str66 = timeSeries33.getDescription();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        int int69 = day67.compareTo((java.lang.Object) '#');
//        int int70 = day67.getYear();
//        long long71 = day67.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) day67);
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) day67);
//        double double74 = timeSeries3.getMaxY();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January 10" + "'", str28.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "January 10" + "'", str29.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10-June-2019" + "'", str64.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNull(str66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560150000000L + "'", long71 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 100.0d + "'", double74 == 100.0d);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        java.util.Date date8 = year6.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date8);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.Year year3 = month2.getYear();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) 9999);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        timeSeriesDataItem16.setSelected(true);
        int int19 = timeSeriesDataItem11.compareTo((java.lang.Object) timeSeriesDataItem16);
        timeSeries8.add(timeSeriesDataItem11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.lang.Number number25 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        long long26 = fixedMillisecond22.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond22.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond22.next();
        java.lang.Number number29 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod28, number29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem30.getPeriod();
        boolean boolean32 = month2.equals((java.lang.Object) regularTimePeriod31);
        java.util.Date date33 = month2.getEnd();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 1" + "'", str4.equals("December 1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 9999.0d + "'", number25.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.String str36 = timeSeries3.getDescription();
//        java.util.Collection collection37 = timeSeries3.getTimePeriods();
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond45.getMiddleMillisecond(calendar46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond45.next();
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond45.getMiddleMillisecond(calendar49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) 9999);
//        boolean boolean54 = fixedMillisecond45.equals((java.lang.Object) day51);
//        timeSeries43.setKey((java.lang.Comparable) fixedMillisecond45);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        int int57 = year56.getYear();
//        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) year56, (double) 10.0f);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar65 = null;
//        long long66 = fixedMillisecond64.getMiddleMillisecond(calendar65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond64.next();
//        java.util.Calendar calendar68 = null;
//        long long69 = fixedMillisecond64.getMiddleMillisecond(calendar68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day70, (double) 9999);
//        boolean boolean73 = fixedMillisecond64.equals((java.lang.Object) day70);
//        java.lang.String str74 = day70.toString();
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) month62, (org.jfree.data.time.RegularTimePeriod) day70);
//        double double76 = timeSeries43.getMinY();
//        boolean boolean77 = timeSeries3.equals((java.lang.Object) double76);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 10L + "'", long69 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "10-June-2019" + "'", str74.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 10.0d + "'", double76 == 10.0d);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getLastMillisecond();
        long long5 = year3.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        double double16 = timeSeries3.getMaxY();
//        java.lang.Object obj17 = timeSeries3.clone();
//        double double18 = timeSeries3.getMaxY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
//        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
//        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        int int38 = year37.getYear();
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year37, (double) 10.0f);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        java.lang.String str42 = year41.toString();
//        java.lang.Number number43 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) year41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year41, (java.lang.Number) 0);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (double) 9999);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        long long54 = year53.getSerialIndex();
//        java.util.Date date55 = year53.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year53, 0.0d);
//        timeSeriesDataItem57.setSelected(true);
//        int int60 = timeSeriesDataItem52.compareTo((java.lang.Object) timeSeriesDataItem57);
//        timeSeries49.add(timeSeriesDataItem52);
//        timeSeries49.clear();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) day63, (java.lang.Number) 7);
//        long long66 = day63.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day63.previous();
//        boolean boolean68 = timeSeriesDataItem45.equals((java.lang.Object) regularTimePeriod67);
//        timeSeries3.add(regularTimePeriod67, (java.lang.Number) (-1));
//        java.lang.Class<?> wildcardClass71 = timeSeries3.getClass();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent73 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
//        java.lang.Class<?> wildcardClass74 = seriesChangeEvent73.getClass();
//        java.util.Date date75 = null;
//        java.util.TimeZone timeZone76 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date75, timeZone76);
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
//        long long79 = year78.getSerialIndex();
//        java.util.Date date80 = year78.getStart();
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date80);
//        java.util.TimeZone timeZone82 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date80, timeZone82);
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date80);
//        java.util.Date date85 = year84.getStart();
//        java.util.TimeZone timeZone86 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date85, timeZone86);
//        try {
//            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent88 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeZone86);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019" + "'", str42.equals("2019"));
//        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 10.0d + "'", number43.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 43626L + "'", long66 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertNotNull(wildcardClass74);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 2019L + "'", long79 == 2019L);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.util.List list24 = timeSeries3.getItems();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener25);
        timeSeries3.setRangeDescription("Mon Jun 10 09:31:50 PDT 2019");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.next();
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond23.getMiddleMillisecond(calendar27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 9999);
        boolean boolean32 = fixedMillisecond23.equals((java.lang.Object) day29);
        timeSeries21.setKey((java.lang.Comparable) fixedMillisecond23);
        java.util.Date date34 = fixedMillisecond23.getTime();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 11);
        try {
            timeSeries3.update((int) ' ', (java.lang.Number) (-62106883200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date34);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        double double16 = timeSeries3.getMaxY();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        int int18 = year17.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        int int21 = year17.compareTo((java.lang.Object) timePeriodFormatException20);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (double) 100, true);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(1, 10);
//        java.lang.String str28 = month27.toString();
//        java.lang.String str29 = month27.toString();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.next();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getMiddleMillisecond(calendar39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day41, (double) 9999);
//        boolean boolean44 = fixedMillisecond35.equals((java.lang.Object) day41);
//        timeSeries33.setKey((java.lang.Comparable) fixedMillisecond35);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        int int47 = year46.getYear();
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year46, (double) 10.0f);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.next();
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond54.getMiddleMillisecond(calendar58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day60, (double) 9999);
//        boolean boolean63 = fixedMillisecond54.equals((java.lang.Object) day60);
//        java.lang.String str64 = day60.toString();
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) day60);
//        java.lang.String str66 = timeSeries33.getDescription();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        int int69 = day67.compareTo((java.lang.Object) '#');
//        int int70 = day67.getYear();
//        long long71 = day67.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) day67);
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) day67);
//        timeSeries73.setMaximumItemAge((long) '4');
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January 10" + "'", str28.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "January 10" + "'", str29.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10-June-2019" + "'", str64.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNull(str66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560150000000L + "'", long71 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.lang.Class<?> wildcardClass25 = timeSeries3.getClass();
        timeSeries3.setMaximumItemCount(7);
        java.util.List list28 = timeSeries3.getItems();
        boolean boolean29 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.clear();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getNextTimePeriod();
        java.lang.Comparable comparable21 = timeSeries3.getKey();
        java.util.List list22 = timeSeries3.getItems();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
        timeSeriesDataItem27.setValue((java.lang.Number) 100.0d);
        timeSeriesDataItem27.setSelected(false);
        timeSeriesDataItem27.setValue((java.lang.Number) 11);
        try {
            timeSeries3.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (byte) 1 + "'", comparable21.equals((byte) 1));
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge(1577865599999L);
        try {
            java.lang.Number number22 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener20);
        java.lang.Object obj22 = timeSeries3.clone();
        timeSeries3.setNotify(true);
        timeSeries3.setDescription("");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
        timeSeries3.removeAgedItems(1577865599999L, false);
        timeSeries3.clear();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(1, 10);
        org.jfree.data.time.Year year33 = month32.getYear();
        long long34 = month32.getFirstMillisecond();
        org.jfree.data.time.Year year35 = month32.getYear();
        java.lang.Number number36 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str42 = timePeriodFormatException41.toString();
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException41.addSuppressed((java.lang.Throwable) seriesException44);
        boolean boolean46 = month39.equals((java.lang.Object) seriesException44);
        java.lang.Object obj47 = null;
        int int48 = month39.compareTo(obj47);
        long long49 = month39.getSerialIndex();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) 1560184264038L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61851744000000L) + "'", long34 == (-61851744000000L));
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str42.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 24L + "'", long49 == 24L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, 10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1.0d);
        long long23 = month20.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.lang.String str4 = year3.toString();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond10.getMiddleMillisecond(calendar14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) 9999);
        boolean boolean19 = fixedMillisecond10.equals((java.lang.Object) day16);
        timeSeries8.setKey((java.lang.Comparable) fixedMillisecond10);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year21, (double) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 9999);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, 0.0d);
        timeSeriesDataItem36.setSelected(true);
        int int39 = timeSeriesDataItem31.compareTo((java.lang.Object) timeSeriesDataItem36);
        timeSeries28.add(timeSeriesDataItem31);
        timeSeries28.clear();
        java.util.Collection collection42 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        boolean boolean43 = timeSeries8.isEmpty();
        int int44 = timeSeries8.getItemCount();
        timeSeries8.removeAgedItems((long) '4', true);
        int int48 = year3.compareTo((java.lang.Object) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.lang.Class<?> wildcardClass25 = timeSeries3.getClass();
        double double26 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) '#');
//        int int3 = day0.getYear();
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        int int6 = day0.getYear();
//        long long7 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, 0.0d);
        timeSeriesDataItem4.setValue((java.lang.Number) 100.0d);
        timeSeriesDataItem4.setValue((java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond10.getMiddleMillisecond(calendar14);
        long long16 = fixedMillisecond10.getMiddleMillisecond();
        int int17 = timeSeriesDataItem4.compareTo((java.lang.Object) fixedMillisecond10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.previous();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond28);
        long long33 = fixedMillisecond28.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
//        int int3 = day0.getYear();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (double) 9999);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        long long12 = year11.getSerialIndex();
//        java.util.Date date13 = year11.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, 0.0d);
//        timeSeriesDataItem15.setSelected(true);
//        int int18 = timeSeriesDataItem10.compareTo((java.lang.Object) timeSeriesDataItem15);
//        timeSeries7.add(timeSeriesDataItem10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
//        java.lang.Number number24 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        int int25 = day0.compareTo((java.lang.Object) fixedMillisecond21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day0.previous();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo27);
//        int int29 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 9999.0d + "'", number24.equals(9999.0d));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (double) 9999);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getSerialIndex();
        java.util.Date date32 = year30.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, 0.0d);
        timeSeriesDataItem34.setSelected(true);
        int int37 = timeSeriesDataItem29.compareTo((java.lang.Object) timeSeriesDataItem34);
        timeSeries26.add(timeSeriesDataItem29);
        timeSeries26.clear();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
        long long47 = fixedMillisecond44.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        java.lang.Number number49 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        timeSeries3.setDomainDescription("10-June-2019");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-1L) + "'", number49.equals((-1L)));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timeSeries3.getNotify();
        timeSeries3.clear();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        double double16 = timeSeries3.getMaxY();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener17);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.createCopy(8, (int) (short) 10);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
//        int int27 = day24.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day24.next();
//        long long29 = day24.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) (-9999));
//        java.lang.String str32 = day24.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        long long35 = year34.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
//        int int37 = day24.compareTo((java.lang.Object) year34);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
//        timeSeriesDataItem11.setSelected(true);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.clear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
//        long long20 = day17.getSerialIndex();
//        long long21 = day17.getSerialIndex();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day17.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        java.util.Date date8 = year6.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date8);
        java.lang.Object obj14 = null;
        boolean boolean15 = month13.equals(obj14);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        timeSeries3.fireSeriesChanged();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond19);
        java.lang.Object obj24 = timeSeries3.clone();
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        java.lang.Class class19 = timeSeries3.getTimePeriodClass();
        int int20 = timeSeries3.getMaximumItemCount();
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("1");
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.lang.Class<?> wildcardClass25 = timeSeries3.getClass();
        timeSeries3.setDescription("hi!");
        java.lang.String str28 = timeSeries3.getDescription();
        java.lang.String str29 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getSerialIndex();
        java.util.Date date32 = year30.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, 0.0d);
        timeSeriesDataItem34.setValue((java.lang.Number) 100.0d);
        timeSeriesDataItem34.setSelected(false);
        timeSeriesDataItem34.setValue((java.lang.Number) 2147483647);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getSerialIndex();
        java.util.Date date43 = year41.getStart();
        int int44 = timeSeriesDataItem34.compareTo((java.lang.Object) year41);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getMiddleMillisecond(calendar51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond50.next();
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond50.getMiddleMillisecond(calendar54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day56, (double) 9999);
        boolean boolean59 = fixedMillisecond50.equals((java.lang.Object) day56);
        timeSeries48.setKey((java.lang.Comparable) fixedMillisecond50);
        java.util.Date date61 = fixedMillisecond50.getTime();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date61);
        java.util.Date date63 = year62.getStart();
        long long64 = year62.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = fixedMillisecond70.next();
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond70.getMiddleMillisecond(calendar74);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day76, (double) 9999);
        boolean boolean79 = fixedMillisecond70.equals((java.lang.Object) day76);
        timeSeries68.setKey((java.lang.Comparable) fixedMillisecond70);
        boolean boolean81 = timeSeries68.isEmpty();
        java.lang.Class class82 = timeSeries68.getTimePeriodClass();
        timeSeries68.clear();
        int int84 = year62.compareTo((java.lang.Object) timeSeries68);
        try {
            org.jfree.data.time.TimeSeries timeSeries85 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year41, (org.jfree.data.time.RegularTimePeriod) year62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 10L + "'", long52 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 28799999L + "'", long64 == 28799999L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNull(class82);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        long long5 = fixedMillisecond1.getSerialIndex();
        long long6 = fixedMillisecond1.getLastMillisecond();
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond14.getMiddleMillisecond(calendar18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (double) 9999);
        boolean boolean23 = fixedMillisecond14.equals((java.lang.Object) day20);
        timeSeries12.setKey((java.lang.Comparable) fixedMillisecond14);
        double double25 = timeSeries12.getMaxY();
        int int26 = timeSeries12.getItemCount();
        int int27 = timeSeries12.getMaximumItemCount();
        java.util.Collection collection28 = timeSeries12.getTimePeriods();
        java.util.List list29 = timeSeries12.getItems();
        double double30 = timeSeries12.getMaxY();
        int int31 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
//        int int3 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
//        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getSerialIndex();
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
//        java.util.TimeZone timeZone8 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone8);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.Year year11 = month10.getYear();
//        long long12 = month10.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) 9999);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getSerialIndex();
//        java.util.Date date22 = year20.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, 0.0d);
//        timeSeriesDataItem24.setSelected(true);
//        int int27 = timeSeriesDataItem19.compareTo((java.lang.Object) timeSeriesDataItem24);
//        timeSeries16.add(timeSeriesDataItem19);
//        timeSeries16.clear();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 7);
//        long long33 = day30.getSerialIndex();
//        long long34 = day30.getLastMillisecond();
//        long long35 = day30.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long35);
//        boolean boolean37 = month10.equals((java.lang.Object) long35);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43626L + "'", long35 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond17.next();
        java.util.Date date24 = fixedMillisecond17.getStart();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.Year year29 = month28.getYear();
        java.lang.String str30 = month28.toString();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) ' ');
        int int35 = month28.compareTo((java.lang.Object) ' ');
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (-1.0f), false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9999.0d + "'", number20.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "December 1" + "'", str30.equals("December 1"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.next();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond28.getMiddleMillisecond(calendar32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (double) 9999);
        boolean boolean37 = fixedMillisecond28.equals((java.lang.Object) day34);
        timeSeries26.setKey((java.lang.Comparable) fixedMillisecond28);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int40 = year39.getYear();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year39, (double) 10.0f);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        java.lang.String str44 = year43.toString();
        java.lang.Number number45 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) year43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 0);
        int int48 = timeSeriesDataItem21.compareTo((java.lang.Object) 0);
        java.lang.Number number49 = timeSeriesDataItem21.getValue();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 10.0d + "'", number45.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-1L) + "'", number49.equals((-1L)));
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
//        timeSeriesDataItem11.setSelected(true);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.clear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
//        long long20 = day17.getSerialIndex();
//        long long21 = day17.getLastMillisecond();
//        long long22 = day17.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.next();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond25.getMiddleMillisecond(calendar29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (double) 9999);
//        boolean boolean34 = fixedMillisecond25.equals((java.lang.Object) day31);
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        int int17 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) 9999);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, 0.0d);
        timeSeriesDataItem29.setSelected(true);
        int int32 = timeSeriesDataItem24.compareTo((java.lang.Object) timeSeriesDataItem29);
        timeSeries21.add(timeSeriesDataItem24);
        timeSeries21.clear();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        long long42 = fixedMillisecond39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.lang.String str44 = timeSeries21.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries3.addAndOrUpdate(timeSeries21);
        timeSeries45.removeAgedItems((long) (byte) -1, true);
        java.lang.String str49 = timeSeries45.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str44.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Time" + "'", str49.equals("Time"));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries35.clear();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries35.setRangeDescription("Wed Dec 31 16:00:00 PST 1969");
//        timeSeries35.clear();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge(1577865599999L);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
        java.util.Date date37 = fixedMillisecond26.getTime();
        long long38 = fixedMillisecond26.getFirstMillisecond();
        java.lang.Number number39 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries3.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertNull(number39);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1L + "'", obj2.equals(1L));
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        boolean boolean16 = timeSeries3.isEmpty();
        java.lang.Class class17 = timeSeries3.getTimePeriodClass();
        long long18 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int20 = year19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) ' ');
        int int24 = year19.compareTo((java.lang.Object) '4');
        long long25 = year19.getLastMillisecond();
        long long26 = year19.getLastMillisecond();
        int int28 = year19.compareTo((java.lang.Object) (short) -1);
        boolean boolean29 = timeSeries3.equals((java.lang.Object) int28);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries3.addChangeListener(seriesChangeListener30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.getDataItem(regularTimePeriod32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timeSeries3.getNotify();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
        timeSeriesDataItem27.setSelected(true);
        timeSeries3.setKey((java.lang.Comparable) true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (-1L));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getMiddleMillisecond(calendar12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) 9999);
        boolean boolean17 = fixedMillisecond8.equals((java.lang.Object) day14);
        timeSeries6.setKey((java.lang.Comparable) fixedMillisecond8);
        boolean boolean19 = timeSeries6.isEmpty();
        int int20 = month2.compareTo((java.lang.Object) timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
        java.util.Date date37 = fixedMillisecond26.getTime();
        long long38 = fixedMillisecond26.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond26, "December 1", "10-June-2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1560236399999L);
        long long44 = fixedMillisecond26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 100.0d);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        double double16 = timeSeries3.getMaxY();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        int int18 = year17.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        int int21 = year17.compareTo((java.lang.Object) timePeriodFormatException20);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year17, (double) 100, true);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(1, 10);
//        java.lang.String str28 = month27.toString();
//        java.lang.String str29 = month27.toString();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.next();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getMiddleMillisecond(calendar39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day41, (double) 9999);
//        boolean boolean44 = fixedMillisecond35.equals((java.lang.Object) day41);
//        timeSeries33.setKey((java.lang.Comparable) fixedMillisecond35);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        int int47 = year46.getYear();
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year46, (double) 10.0f);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.next();
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond54.getMiddleMillisecond(calendar58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day60, (double) 9999);
//        boolean boolean63 = fixedMillisecond54.equals((java.lang.Object) day60);
//        java.lang.String str64 = day60.toString();
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) day60);
//        java.lang.String str66 = timeSeries33.getDescription();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        int int69 = day67.compareTo((java.lang.Object) '#');
//        int int70 = day67.getYear();
//        long long71 = day67.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) day67);
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) day67);
//        java.util.Calendar calendar74 = null;
//        try {
//            long long75 = day67.getLastMillisecond(calendar74);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January 10" + "'", str28.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "January 10" + "'", str29.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10-June-2019" + "'", str64.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNull(str66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560150000000L + "'", long71 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeries73);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        timeSeries3.fireSeriesChanged();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo18);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = seriesChangeEvent19.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = seriesChangeEvent19.getSummary();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(seriesChangeInfo20);
        org.junit.Assert.assertNull(seriesChangeInfo21);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, 0.0d);
        timeSeriesDataItem4.setValue((java.lang.Number) 100.0d);
        timeSeriesDataItem4.setSelected(false);
        timeSeriesDataItem4.setValue((java.lang.Number) 11);
        boolean boolean12 = timeSeriesDataItem4.equals((java.lang.Object) 9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        timeSeries3.setMaximumItemCount((int) '#');
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.Year year22 = month21.getYear();
        java.lang.String str23 = month21.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 9999);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, 0.0d);
        timeSeriesDataItem36.setSelected(true);
        int int39 = timeSeriesDataItem31.compareTo((java.lang.Object) timeSeriesDataItem36);
        timeSeries28.add(timeSeriesDataItem31);
        timeSeries28.clear();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 7);
        int int46 = day42.compareTo((java.lang.Object) Double.NaN);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) 9999);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getSerialIndex();
        java.util.Date date56 = year54.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year54, 0.0d);
        timeSeriesDataItem58.setSelected(true);
        int int61 = timeSeriesDataItem53.compareTo((java.lang.Object) timeSeriesDataItem58);
        timeSeries50.add(timeSeriesDataItem53);
        timeSeries50.clear();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) day64, (java.lang.Number) 7);
        int int67 = day42.compareTo((java.lang.Object) timeSeries50);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day42);
        java.util.Calendar calendar69 = null;
        try {
            long long70 = day42.getLastMillisecond(calendar69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "December 1" + "'", str23.equals("December 1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        java.util.Date date23 = year21.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        boolean boolean25 = timeSeries3.equals((java.lang.Object) year24);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str31 = timePeriodFormatException30.toString();
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) seriesException33);
        boolean boolean35 = month28.equals((java.lang.Object) seriesException33);
        java.lang.Object obj36 = null;
        int int37 = month28.compareTo(obj36);
        int int38 = year24.compareTo((java.lang.Object) month28);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getSerialIndex();
        java.util.Date date41 = year39.getStart();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        boolean boolean43 = month28.equals((java.lang.Object) date41);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9999.0d + "'", number20.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str3.equals("org.jfree.data.general.SeriesException: 2019"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 12);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 12" + "'", str3.equals("June 12"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.String str36 = timeSeries3.getRangeDescription();
//        double double37 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond43.next();
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond43.getMiddleMillisecond(calendar47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day49, (double) 9999);
//        boolean boolean52 = fixedMillisecond43.equals((java.lang.Object) day49);
//        timeSeries41.setKey((java.lang.Comparable) fixedMillisecond43);
//        double double54 = timeSeries41.getMaxY();
//        java.lang.Object obj55 = timeSeries41.clone();
//        double double56 = timeSeries41.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getMiddleMillisecond(calendar63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond62.next();
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond62.getMiddleMillisecond(calendar66);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day68, (double) 9999);
//        boolean boolean71 = fixedMillisecond62.equals((java.lang.Object) day68);
//        timeSeries60.setKey((java.lang.Comparable) fixedMillisecond62);
//        double double73 = timeSeries60.getMaxY();
//        int int74 = timeSeries60.getItemCount();
//        timeSeries60.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries41.addAndOrUpdate(timeSeries60);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
//        long long78 = year77.getSerialIndex();
//        java.util.Date date79 = year77.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year77, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = timeSeriesDataItem81.getPeriod();
//        timeSeries60.add(timeSeriesDataItem81, true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries3.addOrUpdate(timeSeriesDataItem81);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj55);
//        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 10L + "'", long64 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 10L + "'", long67 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertNotNull(timeSeries76);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 2019L + "'", long78 == 2019L);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem85);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        java.util.Date date25 = year23.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
        timeSeriesDataItem27.setValue((java.lang.Number) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem27.getPeriod();
        java.lang.Number number31 = timeSeriesDataItem27.getValue();
        try {
            timeSeries3.add(timeSeriesDataItem27, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 100.0d + "'", number31.equals(100.0d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date24, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date24);
        timeSeries3.setKey((java.lang.Comparable) date24);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        java.util.Date date33 = year31.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getSerialIndex();
        java.util.Date date37 = year35.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, 0.0d);
        timeSeriesDataItem39.setValue((java.lang.Number) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeriesDataItem39.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, regularTimePeriod42);
        timeSeries43.setMaximumItemAge((long) 6);
        boolean boolean46 = timeSeries43.getNotify();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.String str36 = day30.toString();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries3.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.createCopy(8, (int) (short) 10);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.next();
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond29.getMiddleMillisecond(calendar33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (double) 9999);
        boolean boolean38 = fixedMillisecond29.equals((java.lang.Object) day35);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond29);
        double double40 = timeSeries27.getMaxY();
        java.lang.Object obj41 = timeSeries27.clone();
        double double42 = timeSeries27.getMinY();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries21.addAndOrUpdate(timeSeries27);
        timeSeries27.setDomainDescription("December 1");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries43);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
//        timeSeriesDataItem11.setSelected(true);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.clear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
//        long long20 = day17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        long long22 = day17.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.next();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond23.getMiddleMillisecond(calendar27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 9999);
//        boolean boolean32 = fixedMillisecond23.equals((java.lang.Object) day29);
//        timeSeries21.setKey((java.lang.Comparable) fixedMillisecond23);
//        double double34 = timeSeries21.getMaxY();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        int int36 = year35.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("");
//        int int39 = year35.compareTo((java.lang.Object) timePeriodFormatException38);
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) year35, (double) 100, true);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(1, 10);
//        java.lang.String str46 = month45.toString();
//        java.lang.String str47 = month45.toString();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond53.getMiddleMillisecond(calendar54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond53.next();
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond53.getMiddleMillisecond(calendar57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day59, (double) 9999);
//        boolean boolean62 = fixedMillisecond53.equals((java.lang.Object) day59);
//        timeSeries51.setKey((java.lang.Comparable) fixedMillisecond53);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
//        int int65 = year64.getYear();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) year64, (double) 10.0f);
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar73 = null;
//        long long74 = fixedMillisecond72.getMiddleMillisecond(calendar73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond72.next();
//        java.util.Calendar calendar76 = null;
//        long long77 = fixedMillisecond72.getMiddleMillisecond(calendar76);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day78, (double) 9999);
//        boolean boolean81 = fixedMillisecond72.equals((java.lang.Object) day78);
//        java.lang.String str82 = day78.toString();
//        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) month70, (org.jfree.data.time.RegularTimePeriod) day78);
//        java.lang.String str84 = timeSeries51.getDescription();
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
//        int int87 = day85.compareTo((java.lang.Object) '#');
//        int int88 = day85.getYear();
//        long long89 = day85.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) day85);
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month45, (org.jfree.data.time.RegularTimePeriod) day85);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day85);
//        java.lang.Object obj93 = null;
//        int int94 = day85.compareTo(obj93);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "January 10" + "'", str46.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "January 10" + "'", str47.equals("January 10"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 10L + "'", long58 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 10L + "'", long74 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "10-June-2019" + "'", str82.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries83);
//        org.junit.Assert.assertNull(str84);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2019 + "'", int88 == 2019);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1560150000000L + "'", long89 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
//        org.junit.Assert.assertNotNull(timeSeries91);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries3.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.createCopy(8, (int) (short) 10);
        long long22 = timeSeries21.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        long long28 = fixedMillisecond24.getSerialIndex();
        long long29 = fixedMillisecond24.getLastMillisecond();
        long long30 = fixedMillisecond24.getSerialIndex();
        boolean boolean32 = fixedMillisecond24.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100]");
        long long33 = fixedMillisecond24.getLastMillisecond();
        java.lang.Number number34 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.next();
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond40.getMiddleMillisecond(calendar44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, (double) 9999);
        boolean boolean49 = fixedMillisecond40.equals((java.lang.Object) day46);
        timeSeries38.setKey((java.lang.Comparable) fixedMillisecond40);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        int int52 = year51.getYear();
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) year51, (double) 10.0f);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.lang.String str56 = year55.toString();
        java.lang.Number number57 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) year55);
        boolean boolean58 = timeSeries38.getNotify();
        java.lang.String str59 = timeSeries38.getDescription();
        java.lang.Class<?> wildcardClass60 = timeSeries38.getClass();
        timeSeries38.setDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = timeSeries38.getNextTimePeriod();
        timeSeries21.add(regularTimePeriod63, (-9999.0d));
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass68 = seriesChangeEvent67.getClass();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        long long70 = year69.getSerialIndex();
        java.util.Date date71 = year69.getStart();
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date71, timeZone72);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(date71);
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date71);
        try {
            timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month76, (java.lang.Number) 12L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 10.0d + "'", number57.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNull(regularTimePeriod73);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        timeSeriesDataItem2.setValue((java.lang.Number) (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, 10);
        java.lang.Number number29 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month28);
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        java.util.TimeZone timeZone32 = null;
        java.util.Locale locale33 = null;
        try {
            org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date30, timeZone32, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (short) 100 + "'", number29.equals((short) 100));
        org.junit.Assert.assertNotNull(date30);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) '#');
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.lang.Class<?> wildcardClass25 = timeSeries3.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        java.util.Date date28 = year26.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, 0.0d);
        timeSeriesDataItem30.setValue((java.lang.Number) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem30.getPeriod();
        java.lang.Object obj34 = timeSeriesDataItem30.clone();
        boolean boolean35 = timeSeries3.equals((java.lang.Object) timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException7);
        boolean boolean9 = month2.equals((java.lang.Object) seriesException7);
        java.lang.String str10 = month2.toString();
        org.jfree.data.time.Year year11 = month2.getYear();
        java.lang.String str12 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getMiddleMillisecond(calendar22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        boolean boolean27 = fixedMillisecond18.equals((java.lang.Object) day24);
        timeSeries16.setKey((java.lang.Comparable) fixedMillisecond18);
        double double29 = timeSeries16.getMaxY();
        java.lang.Object obj30 = timeSeries16.clone();
        double double31 = timeSeries16.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries16.removeChangeListener(seriesChangeListener32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond39.next();
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond39.getMiddleMillisecond(calendar43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day45, (double) 9999);
        boolean boolean48 = fixedMillisecond39.equals((java.lang.Object) day45);
        timeSeries37.setKey((java.lang.Comparable) fixedMillisecond39);
        double double50 = timeSeries37.getMaxY();
        java.lang.Object obj51 = timeSeries37.clone();
        double double52 = timeSeries37.getMinY();
        timeSeries37.setMaximumItemAge(1577865599999L);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries16.addAndOrUpdate(timeSeries37);
        java.util.List list56 = timeSeries37.getItems();
        int int57 = month2.compareTo((java.lang.Object) list56);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent59 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo60 = null;
        seriesChangeEvent59.setSummary(seriesChangeInfo60);
        java.lang.Object obj62 = seriesChangeEvent59.getSource();
        boolean boolean63 = month2.equals(obj62);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 1" + "'", str10.equals("December 1"));
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "December 1" + "'", str12.equals("December 1"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + obj62 + "' != '" + (byte) 100 + "'", obj62.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries3.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.createCopy(8, (int) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries3.removeChangeListener(seriesChangeListener22);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Date date21 = fixedMillisecond17.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9999.0d + "'", number20.equals(9999.0d));
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries3.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
        double double37 = timeSeries24.getMaxY();
        java.lang.Object obj38 = timeSeries24.clone();
        double double39 = timeSeries24.getMinY();
        timeSeries24.setMaximumItemAge(1577865599999L);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond48.next();
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond48.getMiddleMillisecond(calendar52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day54, (double) 9999);
        boolean boolean57 = fixedMillisecond48.equals((java.lang.Object) day54);
        timeSeries46.setKey((java.lang.Comparable) fixedMillisecond48);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        int int60 = year59.getYear();
        boolean boolean62 = year59.equals((java.lang.Object) 9999.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) year59);
        java.lang.Comparable comparable64 = timeSeries46.getKey();
        java.util.Collection collection65 = timeSeries42.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        timeSeries42.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(comparable64);
        org.junit.Assert.assertNotNull(collection65);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 9999);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) day7);
        long long11 = fixedMillisecond1.getSerialIndex();
        java.util.Date date12 = fixedMillisecond1.getTime();
        long long13 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond1.getMiddleMillisecond(calendar14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
        java.lang.String str3 = month2.toString();
        java.lang.Object obj4 = null;
        boolean boolean5 = month2.equals(obj4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond11.next();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond11.getMiddleMillisecond(calendar15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) 9999);
        boolean boolean20 = fixedMillisecond11.equals((java.lang.Object) day17);
        timeSeries9.setKey((java.lang.Comparable) fixedMillisecond11);
        double double22 = timeSeries9.getMaxY();
        timeSeries9.setMaximumItemCount((int) '#');
        boolean boolean25 = month2.equals((java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, 0.0d);
        timeSeriesDataItem31.setSelected(true);
        int int34 = timeSeriesDataItem26.compareTo((java.lang.Object) timeSeriesDataItem31);
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.clear();
        java.util.Collection collection37 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        boolean boolean38 = timeSeries3.isEmpty();
        java.lang.String str39 = timeSeries3.getDescription();
        java.lang.String str40 = timeSeries3.getDescription();
        int int41 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 9999);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) day7);
        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getMiddleMillisecond(calendar12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) 9999);
        boolean boolean17 = fixedMillisecond8.equals((java.lang.Object) day14);
        timeSeries6.setKey((java.lang.Comparable) fixedMillisecond8);
        boolean boolean19 = timeSeries6.isEmpty();
        int int20 = month2.compareTo((java.lang.Object) timeSeries6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month2.previous();
        java.util.Date date22 = regularTimePeriod21.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException7);
        boolean boolean9 = month2.equals((java.lang.Object) seriesException7);
        java.lang.String str10 = month2.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 1" + "'", str10.equals("December 1"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond7.getMiddleMillisecond(calendar11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) 9999);
        boolean boolean16 = fixedMillisecond7.equals((java.lang.Object) day13);
        timeSeries5.setKey((java.lang.Comparable) fixedMillisecond7);
        java.util.Date date18 = fixedMillisecond7.getTime();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=1]");
        int int21 = fixedMillisecond7.compareTo((java.lang.Object) timePeriodFormatException20);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException20.getSuppressed();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.lang.String str5 = month4.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 2019" + "'", str5.equals("January 2019"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.next();
        java.lang.Object obj5 = null;
        int int6 = fixedMillisecond3.compareTo(obj5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        int int4 = year0.compareTo((java.lang.Object) timePeriodFormatException3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        java.lang.String str8 = year0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getMiddleMillisecond(calendar12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) 9999);
        boolean boolean17 = fixedMillisecond8.equals((java.lang.Object) day14);
        timeSeries6.setKey((java.lang.Comparable) fixedMillisecond8);
        boolean boolean19 = timeSeries6.isEmpty();
        int int20 = month2.compareTo((java.lang.Object) timeSeries6);
        timeSeries6.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        double double18 = timeSeries3.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries3.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
        double double37 = timeSeries24.getMaxY();
        java.lang.Object obj38 = timeSeries24.clone();
        double double39 = timeSeries24.getMinY();
        timeSeries24.setMaximumItemAge(1577865599999L);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.addAndOrUpdate(timeSeries24);
        long long43 = timeSeries24.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        boolean boolean19 = year16.equals((java.lang.Object) 9999.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.List list21 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        boolean boolean23 = timeSeries3.getNotify();
        java.lang.String str24 = timeSeries3.getDescription();
        java.lang.Class<?> wildcardClass25 = timeSeries3.getClass();
        timeSeries3.setDescription("hi!");
        java.lang.String str28 = timeSeries3.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = null;
        try {
            timeSeries3.delete(regularTimePeriod29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
//        timeSeriesDataItem11.setSelected(true);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.clear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
//        long long20 = day17.getSerialIndex();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = day17.equals(obj21);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.lang.Number number20 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond17.next();
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod23, number24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
        boolean boolean27 = timeSeriesDataItem25.isSelected();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9999.0d + "'", number20.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
        timeSeries3.removeAgedItems(1577865599999L, false);
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.next();
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond35.getMiddleMillisecond(calendar39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day41, (double) 9999);
        boolean boolean44 = fixedMillisecond35.equals((java.lang.Object) day41);
        timeSeries33.setKey((java.lang.Comparable) fixedMillisecond35);
        double double46 = timeSeries33.getMaxY();
        java.lang.Object obj47 = timeSeries33.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries33.removeChangeListener(seriesChangeListener48);
        java.lang.Object obj50 = timeSeries33.clone();
        java.util.List list51 = timeSeries33.getItems();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 10, year53);
        java.lang.String str55 = year53.toString();
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 1577865599999L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year53.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod58);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
        java.lang.String str3 = month2.toString();
        long long4 = month2.getLastMillisecond();
        long long5 = month2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61851744000000L) + "'", long5 == (-61851744000000L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        java.lang.Object obj17 = timeSeries3.clone();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, 10);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1.0d);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener23);
        java.util.List list25 = timeSeries3.getItems();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Class<?> wildcardClass28 = seriesChangeEvent27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date34);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod37);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
        java.lang.String str3 = month2.toString();
        long long4 = month2.getLastMillisecond();
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        double double16 = timeSeries3.getMaxY();
//        java.lang.Object obj17 = timeSeries3.clone();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.next();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond23.getMiddleMillisecond(calendar27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) 9999);
//        boolean boolean32 = fixedMillisecond23.equals((java.lang.Object) day29);
//        timeSeries21.setKey((java.lang.Comparable) fixedMillisecond23);
//        java.util.Date date34 = fixedMillisecond23.getTime();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 11);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond42.next();
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond42.getMiddleMillisecond(calendar46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day48, (double) 9999);
//        boolean boolean51 = fixedMillisecond42.equals((java.lang.Object) day48);
//        timeSeries40.setKey((java.lang.Comparable) fixedMillisecond42);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        int int54 = year53.getYear();
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year53, (double) 10.0f);
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond61.getMiddleMillisecond(calendar62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond61.next();
//        java.util.Calendar calendar65 = null;
//        long long66 = fixedMillisecond61.getMiddleMillisecond(calendar65);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day67, (double) 9999);
//        boolean boolean70 = fixedMillisecond61.equals((java.lang.Object) day67);
//        java.lang.String str71 = day67.toString();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) month59, (org.jfree.data.time.RegularTimePeriod) day67);
//        int int73 = fixedMillisecond23.compareTo((java.lang.Object) timeSeries40);
//        timeSeries40.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 10L + "'", long63 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "10-June-2019" + "'", str71.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 9999);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, 0.0d);
        timeSeriesDataItem31.setSelected(true);
        int int34 = timeSeriesDataItem26.compareTo((java.lang.Object) timeSeriesDataItem31);
        timeSeries23.add(timeSeriesDataItem26);
        timeSeries23.clear();
        java.util.Collection collection37 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        boolean boolean38 = timeSeries3.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries3.addChangeListener(seriesChangeListener39);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond46.next();
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond46.getMiddleMillisecond(calendar50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day52, (double) 9999);
        boolean boolean55 = fixedMillisecond46.equals((java.lang.Object) day52);
        timeSeries44.setKey((java.lang.Comparable) fixedMillisecond46);
        double double57 = timeSeries44.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries44.removeChangeListener(seriesChangeListener58);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries44.createCopy(8, (int) (short) 10);
        long long63 = timeSeries62.getMaximumItemAge();
        java.util.Collection collection64 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries62);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        int int66 = year65.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year65, (double) ' ');
        boolean boolean70 = timeSeriesDataItem68.equals((java.lang.Object) (-9999));
        timeSeries3.setKey((java.lang.Comparable) timeSeriesDataItem68);
        boolean boolean72 = timeSeriesDataItem68.isSelected();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 9223372036854775807L + "'", long63 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 9999);
//        java.lang.Class<?> wildcardClass3 = day0.getClass();
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getMonth();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
//        timeSeriesDataItem11.setSelected(true);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.clear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
//        long long20 = day17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day17, "Time", "org.jfree.data.time.TimePeriodFormatException: ");
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
//        timeSeriesDataItem11.setSelected(true);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
//        timeSeries3.add(timeSeriesDataItem6);
//        timeSeries3.clear();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
//        long long20 = day17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day17.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getMiddleMillisecond(calendar12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) 9999);
        boolean boolean17 = fixedMillisecond8.equals((java.lang.Object) day14);
        timeSeries6.setKey((java.lang.Comparable) fixedMillisecond8);
        boolean boolean19 = timeSeries6.isEmpty();
        int int20 = month2.compareTo((java.lang.Object) timeSeries6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month2.previous();
        java.util.Date date22 = month2.getStart();
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 9999);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) day7);
        java.util.Calendar calendar11 = null;
        fixedMillisecond1.peg(calendar11);
        java.lang.String str13 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries3.update((int) (byte) 0, (java.lang.Number) (short) 100);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        java.lang.Object obj28 = seriesChangeEvent27.getSource();
        boolean boolean29 = timeSeries3.equals((java.lang.Object) seriesChangeEvent27);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(1, 10);
        org.jfree.data.time.Year year33 = month32.getYear();
        long long34 = month32.getFirstMillisecond();
        long long35 = month32.getSerialIndex();
        java.util.Date date36 = month32.getStart();
        int int37 = month32.getMonth();
        int int38 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 10.0d + "'", number22.equals(10.0d));
        org.junit.Assert.assertTrue("'" + obj28 + "' != '" + (byte) 100 + "'", obj28.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61851744000000L) + "'", long34 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 121L + "'", long35 == 121L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) '#');
//        int int3 = day0.getYear();
//        long long4 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        long long5 = fixedMillisecond1.getSerialIndex();
        long long6 = fixedMillisecond1.getLastMillisecond();
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        java.util.Date date9 = fixedMillisecond1.getTime();
        long long10 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        double double16 = timeSeries3.getMaxY();
        int int17 = timeSeries3.getItemCount();
        int int18 = timeSeries3.getMaximumItemCount();
        java.lang.Object obj19 = timeSeries3.clone();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        long long23 = year20.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.next();
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond29.getMiddleMillisecond(calendar33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (double) 9999);
        boolean boolean38 = fixedMillisecond29.equals((java.lang.Object) day35);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond29);
        double double40 = timeSeries27.getMaxY();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("");
        int int45 = year41.compareTo((java.lang.Object) timePeriodFormatException44);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year41, (double) 100, true);
        boolean boolean49 = year20.equals((java.lang.Object) year41);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year41, (java.lang.Number) 1560184273118L);
        long long52 = year41.getLastMillisecond();
        java.util.Calendar calendar53 = null;
        try {
            long long54 = year41.getFirstMillisecond(calendar53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "2019", "January 10");
        double double4 = timeSeries3.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 10, year8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries3.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (double) 9999);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        java.util.Date date23 = year21.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, 0.0d);
        timeSeriesDataItem25.setSelected(true);
        int int28 = timeSeriesDataItem20.compareTo((java.lang.Object) timeSeriesDataItem25);
        timeSeries17.add(timeSeriesDataItem20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
        java.lang.Number number34 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        long long35 = fixedMillisecond31.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond31.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod37, (double) 24L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries3.addOrUpdate(timeSeriesDataItem39);
        double double41 = timeSeries3.getMaxY();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 9999.0d + "'", number34.equals(9999.0d));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 24.0d + "'", double41 == 24.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
        timeSeries3.fireSeriesChanged();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond19);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.next();
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond29.getMiddleMillisecond(calendar33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (double) 9999);
        boolean boolean38 = fixedMillisecond29.equals((java.lang.Object) day35);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond29);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        int int41 = year40.getYear();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year40, (double) 10.0f);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        java.lang.String str45 = year44.toString();
        java.lang.Number number46 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) year44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 0);
        int int50 = timeSeriesDataItem48.compareTo((java.lang.Object) 1546329600000L);
        java.lang.Number number51 = timeSeriesDataItem48.getValue();
        timeSeries3.add(timeSeriesDataItem48, true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 10.0d + "'", number46.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 0 + "'", number51.equals(0));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond7.getMiddleMillisecond(calendar11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) 9999);
        boolean boolean16 = fixedMillisecond7.equals((java.lang.Object) day13);
        timeSeries5.setKey((java.lang.Comparable) fixedMillisecond7);
        java.util.Date date18 = fixedMillisecond7.getTime();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=1]");
        int int21 = fixedMillisecond7.compareTo((java.lang.Object) timePeriodFormatException20);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timePeriodFormatException20, seriesChangeInfo23);
        java.lang.Throwable throwable25 = null;
        try {
            timePeriodFormatException20.addSuppressed(throwable25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("6");
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 10);
        java.lang.String str3 = month2.toString();
        long long4 = month2.getLastMillisecond();
        long long5 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year6 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61851744000000L) + "'", long5 == (-61851744000000L));
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 9999);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) day15);
        timeSeries7.setKey((java.lang.Comparable) fixedMillisecond9);
        java.util.Date date20 = fixedMillisecond9.getTime();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=1]");
        int int23 = fixedMillisecond9.compareTo((java.lang.Object) timePeriodFormatException22);
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo25 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timePeriodFormatException22, seriesChangeInfo25);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) 9999);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, 0.0d);
        timeSeriesDataItem11.setSelected(true);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeriesDataItem11);
        timeSeries3.add(timeSeriesDataItem6);
        timeSeries3.clear();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 7);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(10L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) 9999);
        boolean boolean35 = fixedMillisecond26.equals((java.lang.Object) day32);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond26);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        int int38 = year37.getYear();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year37, (double) 10.0f);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(1, year37);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month41, (double) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        int int17 = year16.getYear();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year16, (double) 10.0f);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) 9999);
//        boolean boolean33 = fixedMillisecond24.equals((java.lang.Object) day30);
//        java.lang.String str34 = day30.toString();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) day30);
//        java.lang.String str36 = timeSeries3.getRangeDescription();
//        double double37 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond43.next();
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond43.getMiddleMillisecond(calendar47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day49, (double) 9999);
//        boolean boolean52 = fixedMillisecond43.equals((java.lang.Object) day49);
//        timeSeries41.setKey((java.lang.Comparable) fixedMillisecond43);
//        java.util.Collection collection54 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(collection54);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) 9999);
//        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) day11);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond5);
//        double double16 = timeSeries3.getMaxY();
//        java.lang.Object obj17 = timeSeries3.clone();
//        double double18 = timeSeries3.getMaxY();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1L);
//        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getSerialIndex();
//        java.util.Date date24 = year22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date24, timeZone27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date24);
//        timeSeries3.setKey((java.lang.Comparable) date24);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getSerialIndex();
//        java.util.Date date33 = year31.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getSerialIndex();
//        java.util.Date date37 = year35.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, 0.0d);
//        timeSeriesDataItem39.setValue((java.lang.Number) 100.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeriesDataItem39.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, regularTimePeriod42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (double) 9999);
//        int int47 = day44.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day44.next();
//        long long49 = day44.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 1, "org.jfree.data.event.SeriesChangeEvent[source=1]", "2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond(10L);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond56.getMiddleMillisecond(calendar57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond56.next();
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond56.getMiddleMillisecond(calendar60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day62, (double) 9999);
//        boolean boolean65 = fixedMillisecond56.equals((java.lang.Object) day62);
//        timeSeries54.setKey((java.lang.Comparable) fixedMillisecond56);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        int int68 = year67.getYear();
//        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) year67, (double) 10.0f);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
//        java.lang.String str72 = year71.toString();
//        java.lang.Number number73 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) year71);
//        boolean boolean74 = timeSeries54.getNotify();
//        java.lang.String str75 = timeSeries54.getDescription();
//        java.util.List list76 = timeSeries54.getItems();
//        timeSeries54.setMaximumItemCount(2147483647);
//        java.util.Collection collection79 = timeSeries43.getTimePeriodsUniqueToOtherSeries(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 10L + "'", long58 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 10L + "'", long61 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "2019" + "'", str72.equals("2019"));
//        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 10.0d + "'", number73.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNull(str75);
//        org.junit.Assert.assertNotNull(list76);
//        org.junit.Assert.assertNotNull(collection79);
//    }
//}

