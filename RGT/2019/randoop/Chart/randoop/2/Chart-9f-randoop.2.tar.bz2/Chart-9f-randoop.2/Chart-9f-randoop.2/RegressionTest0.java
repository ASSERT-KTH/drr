import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '#', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        try {
            timeSeries2.removeAgedItems(0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', (int) (short) 1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries2.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-1), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) ' ', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        java.lang.String str16 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            timeSeries2.add(timeSeriesDataItem9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        timeSeries4.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        int int20 = fixedMillisecond18.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass21 = fixedMillisecond18.getClass();
        java.util.Calendar calendar22 = null;
        fixedMillisecond18.peg(calendar22);
        java.lang.Number number24 = null;
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond6.equals(obj10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        boolean boolean14 = fixedMillisecond6.equals((java.lang.Object) year12);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year12, (double) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        try {
            timeSeries4.delete((int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        boolean boolean18 = timeSeries4.getNotify();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
        int int27 = fixedMillisecond25.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar28 = null;
        fixedMillisecond25.peg(calendar28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 2);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond25.getLastMillisecond(calendar32);
        java.lang.Number number34 = null;
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month20.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.createCopy(regularTimePeriod19, (org.jfree.data.time.RegularTimePeriod) year20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.setMaximumItemCount(2958465);
        try {
            timeSeries2.removeAgedItems((long) 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        try {
            timeSeries2.delete(3, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries15 = null;
        try {
            java.util.Collection collection16 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        long long6 = fixedMillisecond5.getFirstMillisecond();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 100L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        boolean boolean6 = timeSeries4.equals((java.lang.Object) "hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        long long9 = day7.getSerialIndex();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
//        boolean boolean12 = day7.equals((java.lang.Object) regularTimePeriod11);
//        try {
//            timeSeries4.add(regularTimePeriod11, (double) (byte) 10, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.getDataItem(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek((-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        timeSeries4.clear();
        timeSeries4.removeAgedItems(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = null;
        try {
            timeSeries4.add(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        timeSeries4.clear();
        timeSeries4.removeAgedItems(true);
        try {
            timeSeries4.update(4, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16);
        long long21 = month20.getSerialIndex();
        java.util.Calendar calendar22 = null;
        try {
            month20.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 23640L + "'", long21 == 23640L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        boolean boolean5 = day0.equals((java.lang.Object) regularTimePeriod4);
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        long long18 = year16.getMiddleMillisecond();
        long long19 = year16.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
        int int23 = fixedMillisecond21.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar24 = null;
        fixedMillisecond21.peg(calendar24);
        long long26 = fixedMillisecond21.getFirstMillisecond();
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond21.getLastMillisecond(calendar27);
        long long29 = fixedMillisecond21.getLastMillisecond();
        try {
            org.jfree.data.time.TimeSeries timeSeries30 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (int) (byte) -1, (-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(9999, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        boolean boolean18 = timeSeries4.getNotify();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class22);
        boolean boolean25 = timeSeries23.equals((java.lang.Object) "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        long long28 = fixedMillisecond27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond27.next();
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number30);
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(0L);
        int int40 = fixedMillisecond38.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar41 = null;
        fixedMillisecond38.peg(calendar41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 2);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond38.getLastMillisecond(calendar45);
        try {
            org.jfree.data.time.TimeSeries timeSeries47 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) year7);
        long long10 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate2);
        java.lang.String str4 = serialDate3.toString();
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate3.getNearestDayOfWeek((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "7-January-1900" + "'", str4.equals("7-January-1900"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int7 = spreadsheetDate6.toSerial();
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) int7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries2.setRangeDescription("7-January-1900");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar6 = null;
        fixedMillisecond3.peg(calendar6);
        long long8 = fixedMillisecond3.getFirstMillisecond();
        boolean boolean9 = month0.equals((java.lang.Object) fixedMillisecond3);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -458");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) (byte) 1);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond1.getFirstMillisecond(calendar11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        long long9 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        serialDate3.setDescription("");
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = serialDate3.getFollowingDayOfWeek((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        timeSeries4.setMaximumItemAge((long) 9999);
        try {
            java.lang.Number number8 = timeSeries4.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        int int4 = timeSeries2.getItemCount();
        java.util.List list5 = timeSeries2.getItems();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-459));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        try {
            timeSeries2.delete((-458), 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -458");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate2 = null;
        try {
            boolean boolean3 = spreadsheetDate1.isOn(serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date16, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day22.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447) + "'", int1 == (-447));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int4 = spreadsheetDate3.toSerial();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) "Nearest");
        try {
            org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getPreviousDayOfWeek(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        boolean boolean16 = timeSeries4.isEmpty();
        try {
            timeSeries4.removeAgedItems((long) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        java.lang.Comparable comparable0 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int5 = spreadsheetDate4.toSerial();
//        int int6 = spreadsheetDate4.getMonth();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        int int9 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        serialDate10.setDescription("");
//        java.lang.String str13 = serialDate10.toString();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate16);
//        boolean boolean19 = spreadsheetDate4.isInRange(serialDate10, serialDate16, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int22 = spreadsheetDate21.toSerial();
//        int int23 = spreadsheetDate21.getMonth();
//        boolean boolean24 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int30 = fixedMillisecond28.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, "7-January-1900", "org.jfree.data.general.SeriesException: Time", class32);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries(comparable0, "10-June-2019", "2019", class32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        spreadsheetDate1.setDescription("");
//        try {
//            org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate1.getNearestDayOfWeek((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        int int24 = fixedMillisecond22.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar25 = null;
        fixedMillisecond22.peg(calendar25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries20.getNextTimePeriod();
        long long30 = regularTimePeriod29.getMiddleMillisecond();
        try {
            timeSeries4.add(regularTimePeriod29, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int51 = spreadsheetDate50.toSerial();
//        boolean boolean52 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int57 = spreadsheetDate56.toSerial();
//        boolean boolean58 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        int int59 = spreadsheetDate54.getDayOfWeek();
//        boolean boolean61 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate54, 6);
//        org.jfree.data.time.SerialDate serialDate62 = null;
//        try {
//            int int63 = spreadsheetDate54.compare(serialDate62);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        int int15 = fixedMillisecond13.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date28, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date28);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date28, timeZone33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date9, timeZone33);
        java.util.Calendar calendar36 = null;
        try {
            month35.peg(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeZone33);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-447));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Tuesday" + "'", str1.equals("Tuesday"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        int int4 = year1.compareTo((java.lang.Object) 1.0d);
        java.lang.Object obj5 = null;
        boolean boolean6 = year1.equals(obj5);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        spreadsheetDate1.setDescription("");
//        org.jfree.data.time.SerialDate serialDate19 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
//        java.util.Date date24 = fixedMillisecond21.getTime();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
//        int int27 = day26.getYear();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int30 = spreadsheetDate29.toSerial();
//        int int31 = spreadsheetDate29.getMonth();
//        boolean boolean32 = day26.equals((java.lang.Object) spreadsheetDate29);
//        try {
//            boolean boolean34 = spreadsheetDate1.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate29, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        boolean boolean16 = timeSeries4.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries4.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) (short) 10);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar6 = null;
        fixedMillisecond3.peg(calendar6);
        long long8 = fixedMillisecond3.getFirstMillisecond();
        int int9 = month0.compareTo((java.lang.Object) fixedMillisecond3);
        long long10 = fixedMillisecond3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        spreadsheetDate2.setDescription("");
//        try {
//            org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(11, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        boolean boolean18 = timeSeries4.getNotify();
        try {
            timeSeries4.removeAgedItems((long) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        try {
//            org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate18.getPreviousDayOfWeek(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int2 = spreadsheetDate1.toSerial();
        int int3 = spreadsheetDate1.getMonth();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) year7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        try {
            java.lang.Number number9 = timeSeries4.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ERROR : Relative To String" + "'", str7.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        try {
//            timeSeries4.update(1, (java.lang.Number) (-457));
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        timeSeries2.setDescription("");
        timeSeries2.setDescription("Time");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: Time" + "'", str3.equals("org.jfree.data.general.SeriesException: Time"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        long long4 = timeSeries2.getMaximumItemAge();
        java.util.Collection collection5 = timeSeries2.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        long long11 = fixedMillisecond7.getMiddleMillisecond();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        timeSeries4.setNotify(true);
        timeSeries4.setMaximumItemAge((long) 12);
        try {
            timeSeries4.delete(1969, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        boolean boolean14 = timeSeries4.isEmpty();
        timeSeries4.setDescription("ERROR : Relative To String");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener17);
        try {
            timeSeries4.delete(3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        java.util.List list5 = timeSeries4.getItems();
//        boolean boolean6 = timeSeries4.getNotify();
//        timeSeries4.setMaximumItemCount(6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
//        java.lang.String str12 = day9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day9, regularTimePeriod13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond2.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1559372400000L);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        int int21 = fixedMillisecond19.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar22 = null;
        fixedMillisecond19.peg(calendar22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (short) 10);
        java.lang.Number number28 = timeSeriesDataItem27.getValue();
        try {
            timeSeries6.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period Wed Dec 31 16:00:00 PST 1969 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) 10 + "'", number28.equals((short) 10));
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.toSerial();
//        int int21 = spreadsheetDate19.getMonth();
//        boolean boolean22 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int25 = spreadsheetDate24.toSerial();
//        int int26 = spreadsheetDate24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getSerialIndex();
//        int int29 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        serialDate30.setDescription("");
//        java.lang.String str33 = serialDate30.toString();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate36);
//        boolean boolean39 = spreadsheetDate24.isInRange(serialDate30, serialDate36, (int) (short) 10);
//        int int40 = spreadsheetDate24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate44);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate45);
//        boolean boolean47 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, serialDate45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int52 = spreadsheetDate51.toSerial();
//        boolean boolean53 = spreadsheetDate49.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int58 = spreadsheetDate57.toSerial();
//        boolean boolean59 = spreadsheetDate55.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        int int60 = spreadsheetDate55.getDayOfWeek();
//        boolean boolean62 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate51, (org.jfree.data.time.SerialDate) spreadsheetDate55, 6);
//        try {
//            org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths((-457), (org.jfree.data.time.SerialDate) spreadsheetDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 10 + "'", int58 == 10);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy(regularTimePeriod21, (org.jfree.data.time.RegularTimePeriod) month22);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries23.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        int int3 = month0.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date20, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date20);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        boolean boolean28 = month0.equals((java.lang.Object) day26);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = day26.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate9.toSerial();
        int int11 = spreadsheetDate9.getMonth();
        boolean boolean12 = day6.equals((java.lang.Object) spreadsheetDate9);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        int int21 = fixedMillisecond19.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar22 = null;
        fixedMillisecond19.peg(calendar22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (short) 10);
        try {
            int int28 = spreadsheetDate9.compareTo((java.lang.Object) fixedMillisecond19);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        java.util.List list5 = timeSeries4.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -459");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.String str2 = month0.toString();
        int int3 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate9.toSerial();
        int int11 = spreadsheetDate9.getMonth();
        boolean boolean12 = day6.equals((java.lang.Object) spreadsheetDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day6.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day6.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date16);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        timeSeries4.setMaximumItemAge((long) 9999);
        java.lang.String str15 = timeSeries4.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.createCopy((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) year7);
        java.lang.String str10 = year7.toString();
        java.util.Calendar calendar11 = null;
        try {
            year7.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        timeSeries4.clear();
        timeSeries4.removeAgedItems(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year25 = month24.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int30 = fixedMillisecond28.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass31);
//        int int33 = year25.compareTo((java.lang.Object) timeSeries32);
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass39 = fixedMillisecond36.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getEnd();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date44, timeZone45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
//        java.util.Date date51 = fixedMillisecond48.getTime();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date51, timeZone53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date51);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int64 = fixedMillisecond62.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar65 = null;
//        fixedMillisecond62.peg(calendar65);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        boolean boolean70 = timeSeries60.isEmpty();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
//        long long73 = day71.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day71, (double) (byte) 1);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        long long77 = day76.getSerialIndex();
//        long long78 = day76.getSerialIndex();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
//        boolean boolean81 = day76.equals((java.lang.Object) regularTimePeriod80);
//        long long82 = day76.getLastMillisecond();
//        boolean boolean83 = day71.equals((java.lang.Object) long82);
//        long long84 = day71.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (org.jfree.data.time.RegularTimePeriod) day71);
//        timeSeries21.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 43626L + "'", long73 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 43626L + "'", long77 == 43626L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 43626L + "'", long78 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560236399999L + "'", long82 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560150000000L + "'", long84 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries85);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(0L);
        int int6 = fixedMillisecond4.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone15);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries(comparable0, "ERROR : Relative To String", "2019", (java.lang.Class) wildcardClass7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-458));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ERROR : Relative To String" + "'", str7.equals("ERROR : Relative To String"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("31-December-1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
//        java.lang.String str3 = timeSeries2.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timeSeries2.getRangeDescription();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year8 = month7.getYear();
//        long long9 = year8.getSerialIndex();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.next();
//        int int13 = year8.compareTo((java.lang.Object) regularTimePeriod12);
//        try {
//            timeSeries2.add(regularTimePeriod12, (double) 'a', true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int2 = spreadsheetDate1.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getPreviousDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        long long4 = timeSeries2.getMaximumItemAge();
        java.util.Collection collection5 = timeSeries2.getTimePeriods();
        java.util.Collection collection6 = timeSeries2.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries2.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-458));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int4 = spreadsheetDate3.toSerial();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date22, timeZone24);
        boolean boolean26 = spreadsheetDate3.equals((java.lang.Object) wildcardClass10);
        org.jfree.data.time.SerialDate serialDate27 = null;
        try {
            boolean boolean28 = spreadsheetDate3.isOn(serialDate27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year25 = month24.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int30 = fixedMillisecond28.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass31);
//        int int33 = year25.compareTo((java.lang.Object) timeSeries32);
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass39 = fixedMillisecond36.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getEnd();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date44, timeZone45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
//        java.util.Date date51 = fixedMillisecond48.getTime();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date51, timeZone53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date51);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int64 = fixedMillisecond62.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar65 = null;
//        fixedMillisecond62.peg(calendar65);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        boolean boolean70 = timeSeries60.isEmpty();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
//        long long73 = day71.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day71, (double) (byte) 1);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        long long77 = day76.getSerialIndex();
//        long long78 = day76.getSerialIndex();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
//        boolean boolean81 = day76.equals((java.lang.Object) regularTimePeriod80);
//        long long82 = day76.getLastMillisecond();
//        boolean boolean83 = day71.equals((java.lang.Object) long82);
//        long long84 = day71.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (org.jfree.data.time.RegularTimePeriod) day71);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond87 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar88 = null;
//        long long89 = fixedMillisecond87.getMiddleMillisecond(calendar88);
//        java.util.Date date90 = fixedMillisecond87.getTime();
//        java.util.Calendar calendar91 = null;
//        fixedMillisecond87.peg(calendar91);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = fixedMillisecond87.next();
//        long long94 = fixedMillisecond87.getMiddleMillisecond();
//        try {
//            timeSeries21.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond87, (double) 43626L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 43626L + "'", long73 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 43626L + "'", long77 == 43626L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 43626L + "'", long78 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560236399999L + "'", long82 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560150000000L + "'", long84 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries85);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
//        org.junit.Assert.assertNotNull(date90);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 0L + "'", long94 == 0L);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.toSerial();
//        int int21 = spreadsheetDate19.getMonth();
//        boolean boolean22 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int25 = spreadsheetDate24.toSerial();
//        int int26 = spreadsheetDate24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getSerialIndex();
//        int int29 = day27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        serialDate30.setDescription("");
//        java.lang.String str33 = serialDate30.toString();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate36);
//        boolean boolean39 = spreadsheetDate24.isInRange(serialDate30, serialDate36, (int) (short) 10);
//        int int40 = spreadsheetDate24.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate44);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate45);
//        boolean boolean47 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, serialDate45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int52 = spreadsheetDate51.toSerial();
//        boolean boolean53 = spreadsheetDate49.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int58 = spreadsheetDate57.toSerial();
//        boolean boolean59 = spreadsheetDate55.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        int int60 = spreadsheetDate55.getDayOfWeek();
//        boolean boolean62 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate51, (org.jfree.data.time.SerialDate) spreadsheetDate55, 6);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        long long64 = day63.getSerialIndex();
//        int int65 = day63.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate66 = day63.getSerialDate();
//        serialDate66.setDescription("");
//        boolean boolean69 = spreadsheetDate24.isAfter(serialDate66);
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 10 + "'", int58 == 10);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3 + "'", int60 == 3);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 43626L + "'", long64 == 43626L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(serialDate70);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        java.lang.Object obj20 = timeSeriesDataItem19.clone();
//        java.lang.Class<?> wildcardClass21 = obj20.getClass();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.createCopy((int) (short) 10, (-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, (int) (short) 100, (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class5);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
        try {
            timeSeries6.removeAgedItems(1577865599999L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy(regularTimePeriod21, (org.jfree.data.time.RegularTimePeriod) month22);
        java.util.Calendar calendar24 = null;
        long long25 = regularTimePeriod21.getMiddleMillisecond(calendar24);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("10-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("10-June-2019");
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException6);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(0L);
        int int6 = fixedMillisecond4.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond4.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass7);
        int int9 = year1.compareTo((java.lang.Object) timeSeries8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        timeSeries4.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener17);
        timeSeries4.setMaximumItemAge(0L);
        java.lang.String str21 = timeSeries4.getDescription();
        timeSeries4.setMaximumItemAge((long) ' ');
        boolean boolean24 = timeSeries4.getNotify();
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        boolean boolean16 = timeSeries4.isEmpty();
        timeSeries4.clear();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int15 = spreadsheetDate14.toSerial();
        boolean boolean16 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean18 = spreadsheetDate12.equals((java.lang.Object) "Nearest");
        java.lang.String str19 = spreadsheetDate12.getDescription();
        spreadsheetDate12.setDescription("Time");
        int int22 = fixedMillisecond1.compareTo((java.lang.Object) "Time");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int4 = spreadsheetDate3.toSerial();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        java.lang.Comparable comparable0 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.toSerial();
//        int int21 = spreadsheetDate19.getMonth();
//        boolean boolean22 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int28 = fixedMillisecond26.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass29 = fixedMillisecond26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate2, "7-January-1900", "org.jfree.data.general.SeriesException: Time", class30);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries(comparable0, class30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        int int18 = spreadsheetDate2.getDayOfMonth();
//        try {
//            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        java.lang.String str16 = timeSeries4.getDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(str16);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.toSerial();
//        int int21 = spreadsheetDate19.getMonth();
//        boolean boolean22 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        try {
//            org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number9);
        long long11 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) "hi!");
        timeSeries4.setMaximumItemCount(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass9 = fixedMillisecond6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date21, timeZone23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date21);
        int int27 = fixedMillisecond1.compareTo((java.lang.Object) date21);
        long long28 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar29 = null;
        fixedMillisecond1.peg(calendar29);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -460");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int51 = spreadsheetDate50.toSerial();
//        boolean boolean52 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int57 = spreadsheetDate56.toSerial();
//        boolean boolean58 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        int int59 = spreadsheetDate54.getDayOfWeek();
//        boolean boolean61 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate54, 6);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        long long63 = day62.getSerialIndex();
//        int int64 = day62.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate65 = day62.getSerialDate();
//        serialDate65.setDescription("");
//        boolean boolean68 = spreadsheetDate23.isAfter(serialDate65);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int72 = fixedMillisecond70.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass73 = fixedMillisecond70.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar76 = null;
//        long long77 = fixedMillisecond75.getMiddleMillisecond(calendar76);
//        java.util.Date date78 = fixedMillisecond75.getEnd();
//        java.util.TimeZone timeZone79 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date78, timeZone79);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar83 = null;
//        long long84 = fixedMillisecond82.getMiddleMillisecond(calendar83);
//        java.util.Date date85 = fixedMillisecond82.getTime();
//        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.createInstance(date85);
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date85, timeZone87);
//        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month(date85);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond90 = new org.jfree.data.time.FixedMillisecond(date85);
//        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.createInstance(date85);
//        boolean boolean92 = spreadsheetDate23.isBefore(serialDate91);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 43626L + "'", long63 == 43626L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 10 + "'", int64 == 10);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(serialDate91);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1.0d + "'", obj2.equals(1.0d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jan" + "'", str2.equals("Jan"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year25 = month24.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int30 = fixedMillisecond28.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass31);
//        int int33 = year25.compareTo((java.lang.Object) timeSeries32);
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year25);
//        int int36 = year25.compareTo((java.lang.Object) 5);
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = year25.getFirstMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond6.equals(obj10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        boolean boolean14 = fixedMillisecond6.equals((java.lang.Object) year12);
        java.lang.Number number15 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        long long16 = fixedMillisecond6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int26 = spreadsheetDate25.toSerial();
//        int int27 = spreadsheetDate25.getMonth();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getSerialIndex();
//        int int30 = day28.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        serialDate31.setDescription("");
//        java.lang.String str34 = serialDate31.toString();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate37);
//        boolean boolean40 = spreadsheetDate25.isInRange(serialDate31, serialDate37, (int) (short) 10);
//        java.lang.String str41 = spreadsheetDate25.toString();
//        timeSeries21.setKey((java.lang.Comparable) str41);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-January-1900" + "'", str41.equals("9-January-1900"));
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass20 = fixedMillisecond17.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 1559372400000L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        java.util.Date date32 = fixedMillisecond29.getTime();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32);
        java.lang.String str35 = day34.toString();
        long long36 = day34.getLastMillisecond();
        long long37 = day34.getLastMillisecond();
        java.lang.String str38 = day34.toString();
        try {
            org.jfree.data.time.TimeSeries timeSeries39 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (org.jfree.data.time.RegularTimePeriod) day34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-1969" + "'", str35.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28799999L + "'", long36 == 28799999L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 28799999L + "'", long37 == 28799999L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31-December-1969" + "'", str38.equals("31-December-1969"));
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getSerialIndex();
//        int int3 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate4);
//        serialDate5.setDescription("Tuesday");
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) day20);
//        java.util.Calendar calendar24 = null;
//        try {
//            day20.peg(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int4 = spreadsheetDate3.toSerial();
        boolean boolean5 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) "Nearest");
        java.lang.String str8 = spreadsheetDate1.getDescription();
        spreadsheetDate1.setDescription("Time");
        try {
            org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getPreviousDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        boolean boolean14 = timeSeries4.isEmpty();
        boolean boolean15 = timeSeries4.isEmpty();
        try {
            timeSeries4.setMaximumItemAge((long) (-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        boolean boolean4 = month0.equals((java.lang.Object) regularTimePeriod3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Nearest");
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1900);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date4, timeZone7);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = month9.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Date date4 = day0.getStart();
//        int int5 = day0.getMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(0L);
        int int6 = fixedMillisecond4.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond4.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass7);
        int int9 = year1.compareTo((java.lang.Object) timeSeries8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries8.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int6 = spreadsheetDate5.toSerial();
//        int int7 = spreadsheetDate5.getMonth();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        int int10 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
//        serialDate11.setDescription("");
//        java.lang.String str14 = serialDate11.toString();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate17);
//        boolean boolean20 = spreadsheetDate5.isInRange(serialDate11, serialDate17, (int) (short) 10);
//        int int21 = spreadsheetDate5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
//        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        try {
//            org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate5.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "31-December-1969", "Last", (java.lang.Class) wildcardClass8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries10.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int51 = spreadsheetDate50.toSerial();
//        boolean boolean52 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int57 = spreadsheetDate56.toSerial();
//        boolean boolean58 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        int int59 = spreadsheetDate54.getDayOfWeek();
//        boolean boolean61 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate54, 6);
//        try {
//            org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate23.getPreviousDayOfWeek((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        timeSeries4.setNotify(false);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getSerialIndex();
//        int int18 = day16.getDayOfMonth();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 2147483647, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year25 = month24.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int30 = fixedMillisecond28.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass31);
//        int int33 = year25.compareTo((java.lang.Object) timeSeries32);
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass39 = fixedMillisecond36.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getEnd();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date44, timeZone45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
//        java.util.Date date51 = fixedMillisecond48.getTime();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date51, timeZone53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date51);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int64 = fixedMillisecond62.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar65 = null;
//        fixedMillisecond62.peg(calendar65);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        boolean boolean70 = timeSeries60.isEmpty();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
//        long long73 = day71.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day71, (double) (byte) 1);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        long long77 = day76.getSerialIndex();
//        long long78 = day76.getSerialIndex();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
//        boolean boolean81 = day76.equals((java.lang.Object) regularTimePeriod80);
//        long long82 = day76.getLastMillisecond();
//        boolean boolean83 = day71.equals((java.lang.Object) long82);
//        long long84 = day71.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (org.jfree.data.time.RegularTimePeriod) day71);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond87 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int89 = fixedMillisecond87.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass90 = fixedMillisecond87.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond92 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar93 = null;
//        long long94 = fixedMillisecond92.getMiddleMillisecond(calendar93);
//        java.util.Date date95 = fixedMillisecond92.getEnd();
//        java.util.TimeZone timeZone96 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass90, date95, timeZone96);
//        org.jfree.data.time.TimeSeries timeSeries98 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day71, (java.lang.Class) wildcardClass90);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 43626L + "'", long73 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 43626L + "'", long77 == 43626L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 43626L + "'", long78 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560236399999L + "'", long82 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560150000000L + "'", long84 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries85);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass90);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 0L + "'", long94 == 0L);
//        org.junit.Assert.assertNotNull(date95);
//        org.junit.Assert.assertNull(regularTimePeriod97);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond5.getTime();
//        long long9 = fixedMillisecond5.getMiddleMillisecond();
//        boolean boolean10 = day0.equals((java.lang.Object) fixedMillisecond5);
//        long long11 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate9.toSerial();
        int int11 = spreadsheetDate9.getMonth();
        boolean boolean12 = day6.equals((java.lang.Object) spreadsheetDate9);
        java.util.Date date13 = spreadsheetDate9.toDate();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class15);
        java.lang.String str17 = timeSeries16.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        timeSeries16.removeAgedItems(true);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        long long24 = year22.getMiddleMillisecond();
        long long25 = year22.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 1.0f);
        long long28 = year22.getLastMillisecond();
        long long29 = year22.getSerialIndex();
        try {
            int int30 = spreadsheetDate9.compareTo((java.lang.Object) long29);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int51 = spreadsheetDate50.toSerial();
//        boolean boolean52 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int57 = spreadsheetDate56.toSerial();
//        boolean boolean58 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        int int59 = spreadsheetDate54.getDayOfWeek();
//        boolean boolean61 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate54, 6);
//        int int62 = spreadsheetDate23.getDayOfMonth();
//        int int63 = spreadsheetDate23.toSerial();
//        org.jfree.data.time.SerialDate serialDate64 = null;
//        try {
//            boolean boolean65 = spreadsheetDate23.isBefore(serialDate64);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 9 + "'", int62 == 9);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        long long22 = day20.getSerialIndex();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        boolean boolean25 = day20.equals((java.lang.Object) regularTimePeriod24);
//        long long26 = day20.getLastMillisecond();
//        boolean boolean27 = day15.equals((java.lang.Object) long26);
//        int int28 = day15.getMonth();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) day20);
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day20.getMiddleMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        long long9 = fixedMillisecond1.getLastMillisecond();
        long long10 = fixedMillisecond1.getMiddleMillisecond();
        long long11 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        long long8 = day6.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            day6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        java.util.List list5 = timeSeries4.getItems();
        boolean boolean6 = timeSeries4.getNotify();
        timeSeries4.setDomainDescription("Value");
        try {
            timeSeries4.delete((int) ' ', (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class5);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.createCopy((-447), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        timeSeries4.setNotify(true);
        timeSeries4.setMaximumItemAge((long) 12);
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        timeSeries21.setDomainDescription("Value");
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class29);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries30.removePropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries30);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeries33.getTimePeriod((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            java.lang.Number number9 = timeSeries2.getValue(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.Year year21 = month20.getYear();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month20.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year21);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Jan");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1964 + "'", int1 == 1964);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass14 = fixedMillisecond11.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond16.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date26, timeZone28);
        boolean boolean30 = spreadsheetDate7.equals((java.lang.Object) wildcardClass14);
        boolean boolean31 = month0.equals((java.lang.Object) spreadsheetDate7);
        long long32 = month0.getFirstMillisecond();
        java.util.Calendar calendar33 = null;
        try {
            long long34 = month0.getFirstMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1559372400000L + "'", long32 == 1559372400000L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 5, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date23, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date4, timeZone25);
        long long28 = month27.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28799999L + "'", long28 == 28799999L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ERROR : Relative To String");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        int int8 = timeSeries2.getItemCount();
        java.lang.String str9 = timeSeries2.getDomainDescription();
        java.util.List list10 = timeSeries2.getItems();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date16);
        java.util.Calendar calendar23 = null;
        try {
            month22.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Date date4 = day0.getStart();
//        int int5 = day0.getMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int51 = spreadsheetDate50.toSerial();
//        boolean boolean52 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int57 = spreadsheetDate56.toSerial();
//        boolean boolean58 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        int int59 = spreadsheetDate54.getDayOfWeek();
//        boolean boolean61 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate54, 6);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class63);
//        java.lang.String str65 = timeSeries64.getDomainDescription();
//        boolean boolean66 = timeSeries64.isEmpty();
//        timeSeries64.setRangeDescription("ERROR : Relative To String");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int72 = fixedMillisecond70.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass73 = fixedMillisecond70.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar76 = null;
//        long long77 = fixedMillisecond75.getMiddleMillisecond(calendar76);
//        java.util.Date date78 = fixedMillisecond75.getEnd();
//        java.util.TimeZone timeZone79 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date78, timeZone79);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar83 = null;
//        long long84 = fixedMillisecond82.getMiddleMillisecond(calendar83);
//        java.util.Date date85 = fixedMillisecond82.getTime();
//        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.createInstance(date85);
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date85, timeZone87);
//        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month(date85);
//        org.jfree.data.time.Year year90 = month89.getYear();
//        timeSeries64.delete((org.jfree.data.time.RegularTimePeriod) year90);
//        boolean boolean92 = spreadsheetDate50.equals((java.lang.Object) year90);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(year90);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.lang.String str9 = timeSeries2.getRangeDescription();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        long long11 = month10.getFirstMillisecond();
        java.lang.String str12 = month10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int18 = spreadsheetDate17.toSerial();
        boolean boolean19 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
        int int23 = fixedMillisecond21.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getEnd();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond33.getTime();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date36, timeZone38);
        boolean boolean40 = spreadsheetDate17.equals((java.lang.Object) wildcardClass24);
        boolean boolean41 = month10.equals((java.lang.Object) spreadsheetDate17);
        long long42 = month10.getFirstMillisecond();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class45);
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class48);
        java.lang.String str50 = timeSeries49.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries49.addPropertyChangeListener(propertyChangeListener51);
        java.lang.String str53 = timeSeries49.getRangeDescription();
        java.util.Collection collection54 = timeSeries46.getTimePeriodsUniqueToOtherSeries(timeSeries49);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries2.addAndOrUpdate(timeSeries46);
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timeSeries46.removePropertyChangeListener(propertyChangeListener56);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1559372400000L + "'", long42 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Time" + "'", str50.equals("Time"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Value" + "'", str53.equals("Value"));
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        try {
            timeSeries4.update((int) (short) 0, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        java.lang.Number number20 = timeSeriesDataItem19.getValue();
//        timeSeriesDataItem19.setValue((java.lang.Number) 100.0d);
//        java.lang.Number number23 = timeSeriesDataItem19.getValue();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2.0d + "'", number20.equals(2.0d));
//        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 100.0d + "'", number23.equals(100.0d));
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1.0f);
        long long14 = timeSeries2.getMaximumItemAge();
        java.lang.Class class15 = timeSeries2.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNull(class15);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        boolean boolean5 = timeSeries4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.Year year21 = month20.getYear();
        long long22 = year21.getLastMillisecond();
        java.util.Calendar calendar23 = null;
        try {
            year21.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            year1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        boolean boolean14 = timeSeries4.isEmpty();
        java.lang.Object obj15 = null;
        boolean boolean16 = timeSeries4.equals(obj15);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        java.lang.String str14 = regularTimePeriod13.toString();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str14.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2958465) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("10-June-2019");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        int int7 = year0.compareTo((java.lang.Object) seriesException3);
        java.lang.Throwable throwable8 = null;
        try {
            seriesException3.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 16:00:00 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(0L);
        int int6 = fixedMillisecond4.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar7 = null;
        fixedMillisecond4.peg(calendar7);
        long long9 = fixedMillisecond4.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond4.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond4.equals((java.lang.Object) (byte) 1);
        boolean boolean14 = month0.equals((java.lang.Object) boolean13);
        int int15 = month0.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        timeSeries21.setDomainDescription("Value");
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class29);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries30.removePropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries30);
//        boolean boolean34 = timeSeries30.isEmpty();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries4.addChangeListener(seriesChangeListener15);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class18);
        java.lang.String str20 = timeSeries19.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        boolean boolean24 = timeSeries4.isEmpty();
        try {
            java.lang.Number number26 = timeSeries4.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        boolean boolean5 = timeSeries4.isEmpty();
        java.util.List list6 = timeSeries4.getItems();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        int int15 = fixedMillisecond13.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar16 = null;
        fixedMillisecond13.peg(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
        java.lang.Number number22 = timeSeriesDataItem21.getValue();
        try {
            timeSeries4.add(timeSeriesDataItem21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 10 + "'", number22.equals((short) 10));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class5);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            timeSeries10.delete(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        long long8 = day6.getLastMillisecond();
        long long9 = day6.getLastMillisecond();
        java.lang.String str10 = day6.toString();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.toSerial();
//        int int21 = spreadsheetDate19.getMonth();
//        boolean boolean22 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        int int23 = spreadsheetDate19.getYYYY();
//        try {
//            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int49 = spreadsheetDate48.toSerial();
//        int int50 = spreadsheetDate48.getMonth();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        long long52 = day51.getSerialIndex();
//        int int53 = day51.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate54 = day51.getSerialDate();
//        serialDate54.setDescription("");
//        java.lang.String str57 = serialDate54.toString();
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate60);
//        boolean boolean63 = spreadsheetDate48.isInRange(serialDate54, serialDate60, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int66 = spreadsheetDate65.toSerial();
//        int int67 = spreadsheetDate65.getMonth();
//        boolean boolean68 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
//        int int69 = spreadsheetDate48.getDayOfWeek();
//        boolean boolean70 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 43626L + "'", long52 == 43626L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "10-June-2019" + "'", str57.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 10 + "'", int66 == 10);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 3 + "'", int69 == 3);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        int int13 = fixedMillisecond1.compareTo((java.lang.Object) year11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass14 = fixedMillisecond11.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond16.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date26, timeZone28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date26);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date26, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        boolean boolean34 = year7.equals((java.lang.Object) regularTimePeriod33);
        long long35 = year7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(0L);
        int int6 = fixedMillisecond4.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond4.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond16.getTime();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date19, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date19);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(0L);
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar33 = null;
        fixedMillisecond30.peg(calendar33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries28.removeChangeListener(seriesChangeListener37);
        int int39 = timeSeries28.getItemCount();
        timeSeries28.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(0L);
        long long44 = fixedMillisecond43.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond43.next();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries28.createCopy(regularTimePeriod45, (org.jfree.data.time.RegularTimePeriod) month46);
        boolean boolean48 = month23.equals((java.lang.Object) timeSeries28);
        boolean boolean49 = month0.equals((java.lang.Object) month23);
        java.util.Calendar calendar50 = null;
        try {
            long long51 = month23.getFirstMillisecond(calendar50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getSerialIndex();
//        int int3 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        serialDate4.setDescription("");
//        java.lang.String str7 = serialDate4.getDescription();
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '#', serialDate4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        int int8 = day6.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        java.util.List list5 = timeSeries4.getItems();
        boolean boolean6 = timeSeries4.getNotify();
        timeSeries4.setDomainDescription("Jan");
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        timeSeries4.setMaximumItemAge((long) 9999);
        java.lang.String str15 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("June 2019");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getFirstMillisecond();
        int int21 = month18.compareTo((java.lang.Object) (short) 0);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 1559372400000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-459));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        int int18 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int20 = spreadsheetDate2.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate24);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate25);
//        boolean boolean27 = spreadsheetDate2.isOnOrBefore(serialDate25);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        int int18 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int20 = spreadsheetDate2.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int27 = spreadsheetDate26.toSerial();
//        int int28 = spreadsheetDate26.getMonth();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getSerialIndex();
//        int int31 = day29.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        serialDate32.setDescription("");
//        java.lang.String str35 = serialDate32.toString();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate38);
//        boolean boolean41 = spreadsheetDate26.isInRange(serialDate32, serialDate38, (int) (short) 10);
//        boolean boolean42 = spreadsheetDate2.isInRange(serialDate23, serialDate38);
//        try {
//            org.jfree.data.time.SerialDate serialDate44 = serialDate23.getPreviousDayOfWeek(1964);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond2.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1559372400000L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getEnd();
        java.lang.Number number18 = null;
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number18);
        java.util.Date date20 = fixedMillisecond14.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class5);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
        int int11 = timeSeries10.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        timeSeries2.setRangeDescription("ERROR : Relative To String");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date23, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.Year year28 = month27.getYear();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) year28);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
        int int38 = fixedMillisecond36.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar39 = null;
        fixedMillisecond36.peg(calendar39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (short) 10);
        java.lang.Number number45 = timeSeriesDataItem44.getValue();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        boolean boolean47 = timeSeriesDataItem44.equals((java.lang.Object) month46);
        try {
            timeSeries2.add(timeSeriesDataItem44, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (short) 10 + "'", number45.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        timeSeries21.setDomainDescription("Value");
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.getDataItem((-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        int int3 = month0.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date20, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date20);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        boolean boolean28 = month0.equals((java.lang.Object) day26);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = month0.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int51 = spreadsheetDate50.toSerial();
//        boolean boolean52 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int57 = spreadsheetDate56.toSerial();
//        boolean boolean58 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        int int59 = spreadsheetDate54.getDayOfWeek();
//        boolean boolean61 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate54, 6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int64 = spreadsheetDate63.toSerial();
//        int int65 = spreadsheetDate63.getMonth();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        long long67 = day66.getSerialIndex();
//        int int68 = day66.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate69 = day66.getSerialDate();
//        serialDate69.setDescription("");
//        java.lang.String str72 = serialDate69.toString();
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate75);
//        boolean boolean78 = spreadsheetDate63.isInRange(serialDate69, serialDate75, (int) (short) 10);
//        boolean boolean79 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 10 + "'", int64 == 10);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 43626L + "'", long67 == 43626L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 10 + "'", int68 == 10);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "10-June-2019" + "'", str72.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Jan");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class5);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            timeSeries6.add(regularTimePeriod11, (double) 1577865599999L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.lang.String str9 = timeSeries2.getRangeDescription();
        timeSeries2.setNotify(true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: 10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10, (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener6);
        timeSeries2.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getEnd();
        java.lang.Object obj15 = null;
        boolean boolean16 = fixedMillisecond11.equals(obj15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        boolean boolean19 = fixedMillisecond11.equals((java.lang.Object) year17);
        boolean boolean21 = fixedMillisecond11.equals((java.lang.Object) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, regularTimePeriod22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        int int3 = month0.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (int) (byte) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        long long4 = timeSeries2.getMaximumItemAge();
        java.util.Collection collection5 = timeSeries2.getTimePeriods();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries2.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "31-December-1969", "Last", (java.lang.Class) wildcardClass8);
        int int11 = timeSeries10.getItemCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        boolean boolean6 = timeSeries4.equals((java.lang.Object) "hi!");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond1.peg(calendar4);
//        long long6 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond1.peg(calendar7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        int int11 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day9.getSerialDate();
//        int int13 = fixedMillisecond1.compareTo((java.lang.Object) day9);
//        long long14 = day9.getFirstMillisecond();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day9.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate20 = day15.getSerialDate();
//        java.lang.Class<?> wildcardClass21 = serialDate20.getClass();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        timeSeries4.setMaximumItemAge((long) 9999);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Time");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) day20);
//        java.lang.Object obj24 = timeSeriesDataItem19.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem19.getPeriod();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond18.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond25.getTime();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date28, timeZone30);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date28);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date28, timeZone33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date9, timeZone33);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        long long37 = day36.getSerialIndex();
//        int int38 = day36.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day36.getSerialDate();
//        java.util.Date date40 = day36.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond42.getTime();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int51 = fixedMillisecond49.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass52 = fixedMillisecond49.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
//        java.util.Date date57 = fixedMillisecond54.getEnd();
//        java.util.TimeZone timeZone58 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date57, timeZone58);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond61.getMiddleMillisecond(calendar62);
//        java.util.Date date64 = fixedMillisecond61.getTime();
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(date64);
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date64, timeZone66);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date45, timeZone66);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date40, timeZone66);
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date9, timeZone66);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond2.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1559372400000L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getEnd();
        java.lang.Number number18 = null;
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number18);
        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesException: Time");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(1900);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((-435), serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int51 = spreadsheetDate50.toSerial();
//        boolean boolean52 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int57 = spreadsheetDate56.toSerial();
//        boolean boolean58 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        int int59 = spreadsheetDate54.getDayOfWeek();
//        boolean boolean61 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate54, 6);
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate65);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate66);
//        boolean boolean68 = spreadsheetDate23.isAfter(serialDate66);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 10 + "'", int57 == 10);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass14 = fixedMillisecond11.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond16.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date26, timeZone28);
        boolean boolean30 = spreadsheetDate7.equals((java.lang.Object) wildcardClass14);
        boolean boolean31 = month0.equals((java.lang.Object) spreadsheetDate7);
        long long32 = month0.getFirstMillisecond();
        java.lang.Object obj33 = null;
        int int34 = month0.compareTo(obj33);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1559372400000L + "'", long32 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        int int3 = month0.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date20, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date20);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        boolean boolean28 = month0.equals((java.lang.Object) day26);
        java.util.Calendar calendar29 = null;
        try {
            day26.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7);
        try {
            timeSeries8.delete(12, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) year7);
        long long10 = year7.getFirstMillisecond();
        long long11 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries4.addChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("7-January-1900");
        timeSeries4.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9-June-2019]");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        java.lang.Number number20 = timeSeriesDataItem19.getValue();
//        timeSeriesDataItem19.setValue((java.lang.Number) 100.0d);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = fixedMillisecond24.equals(obj27);
//        int int29 = timeSeriesDataItem19.compareTo(obj27);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2.0d + "'", number20.equals(2.0d));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        long long9 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date10 = fixedMillisecond1.getTime();
        java.util.Calendar calendar11 = null;
        fixedMillisecond1.peg(calendar11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        timeSeries4.setNotify(true);
        timeSeries4.setDescription("9-January-1900");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond1.peg(calendar4);
//        long long6 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
//        long long9 = fixedMillisecond1.getLastMillisecond();
//        long long10 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        int int13 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
//        java.util.Date date15 = day11.getStart();
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date15, timeZone18);
//        boolean boolean21 = fixedMillisecond1.equals((java.lang.Object) date15);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond1.getFirstMillisecond(calendar22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int28 = spreadsheetDate27.toSerial();
//        boolean boolean29 = spreadsheetDate25.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int33 = fixedMillisecond31.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass34 = fixedMillisecond31.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
//        java.util.Date date39 = fixedMillisecond36.getEnd();
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date39, timeZone40);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
//        java.util.Date date46 = fixedMillisecond43.getTime();
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date46, timeZone48);
//        boolean boolean50 = spreadsheetDate27.equals((java.lang.Object) wildcardClass34);
//        boolean boolean51 = fixedMillisecond1.equals((java.lang.Object) spreadsheetDate27);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int20 = spreadsheetDate19.toSerial();
//        int int21 = spreadsheetDate19.getMonth();
//        boolean boolean22 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        int int23 = spreadsheetDate19.getYYYY();
//        try {
//            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 1964, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
//        java.lang.String str3 = timeSeries2.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
//        timeSeries2.removeAgedItems(true);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        int int9 = year8.getYear();
//        long long10 = year8.getMiddleMillisecond();
//        long long11 = year8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1.0f);
//        long long14 = timeSeries2.getMaximumItemAge();
//        int int15 = timeSeries2.getMaximumItemCount();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getSerialIndex();
//        long long18 = day16.getSerialIndex();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        boolean boolean21 = day16.equals((java.lang.Object) regularTimePeriod20);
//        long long22 = day16.getLastMillisecond();
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 2958465);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries2.getDataItem(regularTimePeriod25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.lang.Comparable comparable4 = timeSeries2.getKey();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (byte) 0 + "'", comparable4.equals((byte) 0));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-435) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1.0f);
        long long14 = timeSeries2.getMaximumItemAge();
        timeSeries2.setKey((java.lang.Comparable) (short) 100);
        timeSeries2.fireSeriesChanged();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class20);
        java.lang.String str22 = timeSeries21.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries21.addPropertyChangeListener(propertyChangeListener23);
        timeSeries21.removeAgedItems(true);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = year27.getYear();
        long long29 = year27.getMiddleMillisecond();
        long long30 = year27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 1.0f);
        long long33 = year27.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getEnd();
        java.lang.Object obj39 = null;
        boolean boolean40 = fixedMillisecond35.equals(obj39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getFirstMillisecond();
        boolean boolean43 = fixedMillisecond35.equals((java.lang.Object) year41);
        java.lang.String str44 = year41.toString();
        long long45 = year41.getLastMillisecond();
        int int46 = year27.compareTo((java.lang.Object) year41);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(7, year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.next();
        try {
            timeSeries2.add(regularTimePeriod48, (java.lang.Number) (-460), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1562097599999L + "'", long29 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar6 = null;
        fixedMillisecond3.peg(calendar6);
        long long8 = fixedMillisecond3.getFirstMillisecond();
        int int9 = month0.compareTo((java.lang.Object) fixedMillisecond3);
        int int10 = month0.getYearValue();
        int int11 = month0.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesException: Time");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        java.lang.String str8 = day6.toString();
        int int10 = day6.compareTo((java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.String str17 = spreadsheetDate1.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int21 = spreadsheetDate20.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int41 = spreadsheetDate40.toSerial();
//        int int42 = spreadsheetDate40.getMonth();
//        boolean boolean43 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int46 = spreadsheetDate45.toSerial();
//        int int47 = spreadsheetDate45.getMonth();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        long long49 = day48.getSerialIndex();
//        int int50 = day48.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
//        serialDate51.setDescription("");
//        java.lang.String str54 = serialDate51.toString();
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate57);
//        boolean boolean60 = spreadsheetDate45.isInRange(serialDate51, serialDate57, (int) (short) 10);
//        int int61 = spreadsheetDate45.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate65);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate66);
//        boolean boolean68 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, serialDate66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int73 = spreadsheetDate72.toSerial();
//        boolean boolean74 = spreadsheetDate70.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate72);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int79 = spreadsheetDate78.toSerial();
//        boolean boolean80 = spreadsheetDate76.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate78);
//        int int81 = spreadsheetDate76.getDayOfWeek();
//        boolean boolean83 = spreadsheetDate45.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate72, (org.jfree.data.time.SerialDate) spreadsheetDate76, 6);
//        int int84 = spreadsheetDate45.getDayOfMonth();
//        int int85 = spreadsheetDate45.toSerial();
//        int int86 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean88 = spreadsheetDate1.isOnOrAfter(serialDate87);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-January-1900" + "'", str17.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10-June-2019" + "'", str54.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 9 + "'", int61 == 9);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 10 + "'", int79 == 10);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 3 + "'", int81 == 3);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 9 + "'", int84 == 9);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 10 + "'", int85 == 10);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1.0f);
        java.lang.String str14 = year8.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        java.lang.String str5 = timeSeries2.getDomainDescription();
        try {
            timeSeries2.delete(4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(2019L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        java.lang.String str5 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day6);
        try {
            java.lang.Number number10 = timeSeries2.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        int int4 = year1.compareTo((java.lang.Object) 1.0d);
        long long5 = year1.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getEnd();
        boolean boolean11 = year1.equals((java.lang.Object) date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year1.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        boolean boolean14 = timeSeries4.isEmpty();
        timeSeries4.setDescription("ERROR : Relative To String");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener17);
        java.lang.Class class19 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        int int24 = year21.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year21, regularTimePeriod25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        timeSeries21.setDomainDescription("Value");
//        try {
//            timeSeries21.removeAgedItems((long) 1900, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond1.peg(calendar4);
//        long long6 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond1.peg(calendar7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        int int11 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day9.getSerialDate();
//        int int13 = fixedMillisecond1.compareTo((java.lang.Object) day9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day9.previous();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1L);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class5);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        int int8 = timeSeries6.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) propertyChangeListener9);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(9999, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-458));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int4 = spreadsheetDate3.toSerial();
//        int int5 = spreadsheetDate3.getMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        serialDate9.setDescription("");
//        java.lang.String str12 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate15);
//        boolean boolean18 = spreadsheetDate3.isInRange(serialDate9, serialDate15, (int) (short) 10);
//        int int19 = spreadsheetDate3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date21 = spreadsheetDate3.toDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-458), (org.jfree.data.time.SerialDate) spreadsheetDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        int int15 = fixedMillisecond13.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date28, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date28);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date28, timeZone33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date9, timeZone33);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeZone33);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.util.Calendar calendar7 = null;
        try {
            day6.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        long long7 = month6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 23640L + "'", long7 == 23640L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy(regularTimePeriod21, (org.jfree.data.time.RegularTimePeriod) month22);
        java.util.Calendar calendar24 = null;
        try {
            month22.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getStart();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560189927441L + "'", long2 == 1560189927441L);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        timeSeries4.setMaximumItemAge((long) 9999);
        java.lang.String str15 = timeSeries4.getDomainDescription();
        timeSeries4.setDomainDescription("June 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        int int25 = day24.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int28 = spreadsheetDate27.toSerial();
        int int29 = spreadsheetDate27.getMonth();
        boolean boolean30 = day24.equals((java.lang.Object) spreadsheetDate27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day24.next();
        timeSeries4.update(regularTimePeriod31, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Second" + "'", str1.equals("Second"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries4.addChangeListener(seriesChangeListener15);
        java.util.List list17 = timeSeries4.getItems();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        int int8 = timeSeries2.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener9);
        timeSeries2.clear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries2.add(regularTimePeriod12, (double) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) (short) 10);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        boolean boolean17 = timeSeriesDataItem14.equals((java.lang.Object) month16);
        java.lang.Object obj18 = timeSeriesDataItem14.clone();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 10 + "'", number15.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate9.toSerial();
        int int11 = spreadsheetDate9.getMonth();
        boolean boolean12 = day6.equals((java.lang.Object) spreadsheetDate9);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 100.0f);
        java.lang.Object obj16 = timeSeriesDataItem15.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.lang.Object obj21 = null;
        boolean boolean22 = fixedMillisecond18.equals(obj21);
        java.util.Date date23 = fixedMillisecond18.getEnd();
        boolean boolean24 = timeSeriesDataItem15.equals((java.lang.Object) date23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) year7);
        java.lang.String str10 = year7.toString();
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (-460));
        long long14 = year7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1.0f);
        long long14 = timeSeries2.getMaximumItemAge();
        int int15 = timeSeries2.getMaximumItemCount();
        boolean boolean16 = timeSeries2.getNotify();
        try {
            timeSeries2.setMaximumItemAge((long) (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy(regularTimePeriod21, (org.jfree.data.time.RegularTimePeriod) month22);
        timeSeries23.clear();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getSerialIndex();
//        int int3 = day1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        serialDate4.setDescription("");
//        java.lang.String str7 = serialDate4.toString();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        long long9 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getMiddleMillisecond(calendar10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 1, 1964);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getYear();
//        int int4 = day0.getYear();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        int int3 = month0.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date20, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date20);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        boolean boolean28 = month0.equals((java.lang.Object) day26);
        long long29 = day26.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28799999L + "'", long29 == 28799999L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond2.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date17, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(0L);
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass33 = fixedMillisecond30.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getEnd();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date38, timeZone39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
        java.util.Date date45 = fixedMillisecond42.getTime();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date45, timeZone47);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date26, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date17, timeZone47);
        java.lang.Class<?> wildcardClass51 = date17.getClass();
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(class52);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1969);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class5);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        try {
            timeSeries10.update((int) (byte) 10, (java.lang.Number) 28799999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        java.util.List list14 = timeSeries4.getItems();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(0L);
        int int23 = fixedMillisecond21.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar24 = null;
        fixedMillisecond21.peg(calendar24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 2);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond21.getLastMillisecond(calendar28);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class32);
        java.lang.String str34 = timeSeries33.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener35);
        timeSeries33.removeAgedItems(true);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int40 = year39.getYear();
        long long41 = year39.getMiddleMillisecond();
        long long42 = year39.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 1.0f);
        long long45 = year39.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getEnd();
        java.lang.Object obj51 = null;
        boolean boolean52 = fixedMillisecond47.equals(obj51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getFirstMillisecond();
        boolean boolean55 = fixedMillisecond47.equals((java.lang.Object) year53);
        java.lang.String str56 = year53.toString();
        long long57 = year53.getLastMillisecond();
        int int58 = year39.compareTo((java.lang.Object) year53);
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(7, year39);
        try {
            org.jfree.data.time.TimeSeries timeSeries60 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) year39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year25 = month24.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int30 = fixedMillisecond28.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass31);
//        int int33 = year25.compareTo((java.lang.Object) timeSeries32);
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year25);
//        int int36 = year25.compareTo((java.lang.Object) 5);
//        int int37 = year25.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond2.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        timeSeries6.setDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        boolean boolean5 = timeSeries4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries4.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar15 = null;
        fixedMillisecond12.peg(calendar15);
        long long17 = fixedMillisecond12.getFirstMillisecond();
        int int18 = month9.compareTo((java.lang.Object) fixedMillisecond12);
        int int19 = month9.getYearValue();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        timeSeries4.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=9-June-2019]");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int11 = spreadsheetDate10.toSerial();
//        int int12 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
//        serialDate16.setDescription("");
//        java.lang.String str19 = serialDate16.toString();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate22);
//        boolean boolean25 = spreadsheetDate10.isInRange(serialDate16, serialDate22, (int) (short) 10);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class29);
//        boolean boolean31 = timeSeries30.isEmpty();
//        boolean boolean32 = spreadsheetDate10.equals((java.lang.Object) timeSeries30);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year34 = month33.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int39 = fixedMillisecond37.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass40 = fixedMillisecond37.getClass();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass40);
//        int int42 = year34.compareTo((java.lang.Object) timeSeries41);
//        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) year34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int47 = fixedMillisecond45.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass48 = fixedMillisecond45.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond50.getMiddleMillisecond(calendar51);
//        java.util.Date date53 = fixedMillisecond50.getEnd();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date53, timeZone54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
//        java.util.Date date60 = fixedMillisecond57.getTime();
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date60, timeZone62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date60);
//        java.lang.Class class68 = null;
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class68);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int73 = fixedMillisecond71.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar74 = null;
//        fixedMillisecond71.peg(calendar74);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries69.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = timeSeries69.getNextTimePeriod();
//        boolean boolean79 = timeSeries69.isEmpty();
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day80.previous();
//        long long82 = day80.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries69.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day80, (double) (byte) 1);
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
//        long long86 = day85.getSerialIndex();
//        long long87 = day85.getSerialIndex();
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = day88.previous();
//        boolean boolean90 = day85.equals((java.lang.Object) regularTimePeriod89);
//        long long91 = day85.getLastMillisecond();
//        boolean boolean92 = day80.equals((java.lang.Object) long91);
//        long long93 = day80.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (org.jfree.data.time.RegularTimePeriod) day80);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day80, (double) 23640L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 43626L + "'", long82 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem84);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 43626L + "'", long86 == 43626L);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 43626L + "'", long87 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1560236399999L + "'", long91 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 1560150000000L + "'", long93 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries94);
//    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1.0f);
        timeSeries2.setMaximumItemCount(9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass20 = fixedMillisecond17.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getEnd();
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date25, timeZone26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        java.util.Date date32 = fixedMillisecond29.getTime();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date32, timeZone34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(0L);
        int int40 = fixedMillisecond38.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass41 = fixedMillisecond38.getClass();
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
        java.util.Date date47 = fixedMillisecond44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone49);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date32, timeZone49);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month51, (double) 4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        timeSeries4.setNotify(false);
        try {
            timeSeries4.removeAgedItems(0L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond5.getTime();
//        long long9 = fixedMillisecond5.getMiddleMillisecond();
//        boolean boolean10 = day0.equals((java.lang.Object) fixedMillisecond5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        java.lang.String str5 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        timeSeries21.setDomainDescription("Value");
//        timeSeries21.setDomainDescription("Last");
//        timeSeries21.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        long long31 = month30.getFirstMillisecond();
//        java.lang.String str32 = month30.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month30.next();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int38 = spreadsheetDate37.toSerial();
//        boolean boolean39 = spreadsheetDate35.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int43 = fixedMillisecond41.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass44 = fixedMillisecond41.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
//        java.util.Date date49 = fixedMillisecond46.getEnd();
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date49, timeZone50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond53.getMiddleMillisecond(calendar54);
//        java.util.Date date56 = fixedMillisecond53.getTime();
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date56, timeZone58);
//        boolean boolean60 = spreadsheetDate37.equals((java.lang.Object) wildcardClass44);
//        boolean boolean61 = month30.equals((java.lang.Object) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month30.previous();
//        try {
//            timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month30, 0.0d, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getFirstMillisecond();
        java.text.DateFormatSymbols dateFormatSymbols4 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int5 = year0.compareTo((java.lang.Object) dateFormatSymbols4);
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(dateFormatSymbols4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        timeSeries4.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener17);
        timeSeries4.setMaximumItemAge(0L);
        java.lang.String str21 = timeSeries4.getDescription();
        timeSeries4.setMaximumItemAge((long) ' ');
        boolean boolean24 = timeSeries4.getNotify();
        try {
            timeSeries4.setMaximumItemAge((long) (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = fixedMillisecond2.equals(obj6);
//        java.util.Date date8 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        int int11 = day9.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = day9.getSerialDate();
//        java.util.Date date13 = day9.getStart();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date13, timeZone16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date8, timeZone16);
//        long long20 = year19.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(6, year19);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1969L + "'", long20 == 1969L);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(0L);
        int int6 = fixedMillisecond4.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond4.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass7);
        int int9 = year1.compareTo((java.lang.Object) timeSeries8);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        int int21 = fixedMillisecond19.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar22 = null;
        fixedMillisecond19.peg(calendar22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries17.getNextTimePeriod();
        timeSeries17.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries17.addChangeListener(seriesChangeListener28);
        java.lang.String str30 = timeSeries17.getDomainDescription();
        java.lang.Class<?> wildcardClass31 = timeSeries17.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "10-June-2019", "31-December-1969", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, (java.lang.Class) wildcardClass31);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        boolean boolean16 = timeSeries4.isEmpty();
        java.lang.Comparable comparable17 = timeSeries4.getKey();
        java.util.Collection collection18 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (-1) + "'", comparable17.equals((-1)));
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries4.addChangeListener(seriesChangeListener15);
        java.lang.Comparable comparable17 = timeSeries4.getKey();
        int int18 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            timeSeries4.add(regularTimePeriod19, (java.lang.Number) 10.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (-1) + "'", comparable17.equals((-1)));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        java.lang.Number number20 = timeSeriesDataItem19.getValue();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getFirstMillisecond();
//        java.lang.String str23 = month21.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int29 = spreadsheetDate28.toSerial();
//        boolean boolean30 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass35 = fixedMillisecond32.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
//        java.util.Date date40 = fixedMillisecond37.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
//        java.util.Date date47 = fixedMillisecond44.getTime();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date47, timeZone49);
//        boolean boolean51 = spreadsheetDate28.equals((java.lang.Object) wildcardClass35);
//        boolean boolean52 = month21.equals((java.lang.Object) spreadsheetDate28);
//        boolean boolean53 = timeSeriesDataItem19.equals((java.lang.Object) spreadsheetDate28);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(2019);
//        boolean boolean56 = spreadsheetDate28.isOnOrBefore(serialDate55);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2.0d + "'", number20.equals(2.0d));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-447), 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -447");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        int int4 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        serialDate8.setDescription("");
//        java.lang.String str11 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate14);
//        boolean boolean17 = spreadsheetDate2.isInRange(serialDate8, serialDate14, (int) (short) 10);
//        int int18 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        java.util.Date date20 = spreadsheetDate2.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int24 = fixedMillisecond22.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass25 = fixedMillisecond22.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond27.getEnd();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
//        java.util.Date date37 = fixedMillisecond34.getTime();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date37, timeZone39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date20, timeZone39);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        java.lang.String str5 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getMonth();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, class6);
        boolean boolean8 = timeSeries7.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        boolean boolean14 = timeSeries4.isEmpty();
        timeSeries4.setDescription("ERROR : Relative To String");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener17);
        java.lang.Class class19 = timeSeries4.getTimePeriodClass();
        try {
            timeSeries4.update((-459), (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(class19);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond6.getLastMillisecond(calendar13);
        long long15 = fixedMillisecond6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        java.lang.String str8 = day6.toString();
        java.lang.String str9 = day6.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        int int15 = fixedMillisecond13.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date28, timeZone30);
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str9, "June 2019", "Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(class32);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        int int8 = day7.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int11 = spreadsheetDate10.toSerial();
        int int12 = spreadsheetDate10.getMonth();
        boolean boolean13 = day7.equals((java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
        int int21 = day20.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int24 = spreadsheetDate23.toSerial();
        int int25 = spreadsheetDate23.getMonth();
        boolean boolean26 = day20.equals((java.lang.Object) spreadsheetDate23);
        java.util.Date date27 = spreadsheetDate23.toDate();
        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int33 = spreadsheetDate32.toSerial();
        boolean boolean34 = spreadsheetDate30.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        spreadsheetDate30.setDescription("");
        boolean boolean37 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        try {
            org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9999, (org.jfree.data.time.SerialDate) spreadsheetDate23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("10-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getYear();
//        int int4 = day0.getYear();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1.0f);
        long long14 = year8.getLastMillisecond();
        long long15 = year8.getFirstMillisecond();
        int int16 = year8.getYear();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int4 = spreadsheetDate3.toSerial();
//        int int5 = spreadsheetDate3.getMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        serialDate9.setDescription("");
//        java.lang.String str12 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate15);
//        boolean boolean18 = spreadsheetDate3.isInRange(serialDate9, serialDate15, (int) (short) 10);
//        int int19 = spreadsheetDate3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getYear();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int31 = spreadsheetDate30.toSerial();
//        int int32 = spreadsheetDate30.getMonth();
//        boolean boolean33 = day27.equals((java.lang.Object) spreadsheetDate30);
//        java.util.Date date34 = spreadsheetDate30.toDate();
//        boolean boolean35 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths(9999, (org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(serialDate36);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) (short) 10);
        long long15 = fixedMillisecond6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        try {
            timeSeries2.delete(1964, (-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeries21.isEmpty();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) timeSeries21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year25 = month24.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int30 = fixedMillisecond28.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass31);
//        int int33 = year25.compareTo((java.lang.Object) timeSeries32);
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) year25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass39 = fixedMillisecond36.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getEnd();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date44, timeZone45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
//        java.util.Date date51 = fixedMillisecond48.getTime();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date51, timeZone53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date51);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int64 = fixedMillisecond62.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar65 = null;
//        fixedMillisecond62.peg(calendar65);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries60.getNextTimePeriod();
//        boolean boolean70 = timeSeries60.isEmpty();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.previous();
//        long long73 = day71.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day71, (double) (byte) 1);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        long long77 = day76.getSerialIndex();
//        long long78 = day76.getSerialIndex();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day79.previous();
//        boolean boolean81 = day76.equals((java.lang.Object) regularTimePeriod80);
//        long long82 = day76.getLastMillisecond();
//        boolean boolean83 = day71.equals((java.lang.Object) long82);
//        long long84 = day71.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (org.jfree.data.time.RegularTimePeriod) day71);
//        long long86 = fixedMillisecond55.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (double) 28799999L);
//        long long89 = fixedMillisecond55.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 43626L + "'", long73 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 43626L + "'", long77 == 43626L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 43626L + "'", long78 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560236399999L + "'", long82 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560150000000L + "'", long84 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries85);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 0L + "'", long86 == 0L);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate20 = day15.getSerialDate();
//        long long21 = day15.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        long long10 = year8.getMiddleMillisecond();
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1.0f);
        long long14 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 1969, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int4 = spreadsheetDate3.toSerial();
//        boolean boolean5 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int6 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int9 = spreadsheetDate8.toSerial();
//        int int10 = spreadsheetDate8.getMonth();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        int int13 = day11.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
//        serialDate14.setDescription("");
//        java.lang.String str17 = serialDate14.toString();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate20);
//        boolean boolean23 = spreadsheetDate8.isInRange(serialDate14, serialDate20, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int26 = spreadsheetDate25.toSerial();
//        int int27 = spreadsheetDate25.getMonth();
//        boolean boolean28 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        boolean boolean29 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int30 = spreadsheetDate8.toSerial();
//        try {
//            org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate8.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Jan");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "31-December-1969", "Last", (java.lang.Class) wildcardClass8);
        java.util.List list11 = timeSeries10.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            java.lang.Number number13 = timeSeries10.getValue(regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int12 = spreadsheetDate11.toSerial();
        boolean boolean13 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass18 = fixedMillisecond15.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getEnd();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date23, timeZone24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date30, timeZone32);
        boolean boolean34 = spreadsheetDate11.equals((java.lang.Object) wildcardClass18);
        boolean boolean35 = fixedMillisecond1.equals((java.lang.Object) boolean34);
        long long36 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond1.getMiddleMillisecond(calendar37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Date date4 = day0.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date4, timeZone7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
//        java.lang.Class<?> wildcardClass11 = month9.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', 4, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        boolean boolean4 = timeSeries2.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond6.equals(obj10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        boolean boolean14 = fixedMillisecond6.equals((java.lang.Object) year12);
        java.lang.Number number15 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        long long16 = fixedMillisecond6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond6.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate9.toSerial();
        int int11 = spreadsheetDate9.getMonth();
        boolean boolean12 = day6.equals((java.lang.Object) spreadsheetDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int23 = spreadsheetDate22.toSerial();
        int int24 = spreadsheetDate22.getMonth();
        boolean boolean25 = day19.equals((java.lang.Object) spreadsheetDate22);
        java.util.Date date26 = spreadsheetDate22.toDate();
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int28 = spreadsheetDate9.getYYYY();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries4.addChangeListener(seriesChangeListener15);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class18);
        java.lang.String str20 = timeSeries19.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener21);
        java.util.Collection collection23 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries4.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(collection23);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        timeSeries4.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener17);
        timeSeries4.setMaximumItemAge(0L);
        java.lang.String str21 = timeSeries4.getDescription();
        timeSeries4.setMaximumItemAge((long) ' ');
        boolean boolean24 = timeSeries4.getNotify();
        timeSeries4.update(0, (java.lang.Number) 31);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int24 = spreadsheetDate23.toSerial();
//        int int25 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        serialDate29.setDescription("");
//        java.lang.String str32 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate35);
//        boolean boolean38 = spreadsheetDate23.isInRange(serialDate29, serialDate35, (int) (short) 10);
//        int int39 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate44);
//        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int49 = spreadsheetDate48.toSerial();
//        int int50 = spreadsheetDate48.getMonth();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        long long52 = day51.getSerialIndex();
//        int int53 = day51.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate54 = day51.getSerialDate();
//        serialDate54.setDescription("");
//        java.lang.String str57 = serialDate54.toString();
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate60);
//        boolean boolean63 = spreadsheetDate48.isInRange(serialDate54, serialDate60, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int66 = spreadsheetDate65.toSerial();
//        int int67 = spreadsheetDate65.getMonth();
//        boolean boolean68 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
//        int int69 = spreadsheetDate65.getYYYY();
//        boolean boolean70 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int73 = spreadsheetDate72.toSerial();
//        int int74 = spreadsheetDate72.getMonth();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        long long76 = day75.getSerialIndex();
//        int int77 = day75.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate78 = day75.getSerialDate();
//        serialDate78.setDescription("");
//        java.lang.String str81 = serialDate78.toString();
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate84);
//        boolean boolean87 = spreadsheetDate72.isInRange(serialDate78, serialDate84, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate89 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int90 = spreadsheetDate89.toSerial();
//        int int91 = spreadsheetDate89.getMonth();
//        boolean boolean92 = spreadsheetDate72.isOn((org.jfree.data.time.SerialDate) spreadsheetDate89);
//        int int93 = spreadsheetDate72.getDayOfWeek();
//        try {
//            int int94 = spreadsheetDate65.compareTo((java.lang.Object) int93);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 43626L + "'", long52 == 43626L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "10-June-2019" + "'", str57.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 10 + "'", int66 == 10);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1900 + "'", int69 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 43626L + "'", long76 == 43626L);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 10 + "'", int77 == 10);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "10-June-2019" + "'", str81.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 10 + "'", int90 == 10);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 3 + "'", int93 == 3);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        long long8 = day6.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getEnd();
        java.lang.Object obj7 = null;
        boolean boolean8 = fixedMillisecond3.equals(obj7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        boolean boolean11 = fixedMillisecond3.equals((java.lang.Object) year9);
        long long12 = year9.getFirstMillisecond();
        int int13 = month0.compareTo((java.lang.Object) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month0.next();
        long long15 = month0.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int20 = spreadsheetDate19.toSerial();
        boolean boolean21 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int22 = spreadsheetDate17.getMonth();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str24 = day23.toString();
        int int25 = month0.compareTo((java.lang.Object) day23);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-January-1900" + "'", str24.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate9.toSerial();
        int int11 = spreadsheetDate9.getMonth();
        boolean boolean12 = day6.equals((java.lang.Object) spreadsheetDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int23 = spreadsheetDate22.toSerial();
        int int24 = spreadsheetDate22.getMonth();
        boolean boolean25 = day19.equals((java.lang.Object) spreadsheetDate22);
        java.util.Date date26 = spreadsheetDate22.toDate();
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        java.util.Date date32 = fixedMillisecond29.getTime();
        java.util.Calendar calendar33 = null;
        fixedMillisecond29.peg(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond29.next();
        long long36 = fixedMillisecond29.getMiddleMillisecond();
        try {
            int int37 = spreadsheetDate22.compareTo((java.lang.Object) long36);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1969 + "'", int20 == 1969);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        try {
            java.lang.Number number7 = timeSeries2.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        java.lang.Number number20 = timeSeriesDataItem19.getValue();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getFirstMillisecond();
//        java.lang.String str23 = month21.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int29 = spreadsheetDate28.toSerial();
//        boolean boolean30 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass35 = fixedMillisecond32.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
//        java.util.Date date40 = fixedMillisecond37.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
//        java.util.Date date47 = fixedMillisecond44.getTime();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date47, timeZone49);
//        boolean boolean51 = spreadsheetDate28.equals((java.lang.Object) wildcardClass35);
//        boolean boolean52 = month21.equals((java.lang.Object) spreadsheetDate28);
//        boolean boolean53 = timeSeriesDataItem19.equals((java.lang.Object) spreadsheetDate28);
//        java.lang.Number number54 = timeSeriesDataItem19.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeriesDataItem19.getPeriod();
//        java.lang.Number number56 = timeSeriesDataItem19.getValue();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2.0d + "'", number20.equals(2.0d));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 2.0d + "'", number54.equals(2.0d));
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 2.0d + "'", number56.equals(2.0d));
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar9 = null;
        fixedMillisecond6.peg(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        int int15 = timeSeries4.getItemCount();
        timeSeries4.setDescription("");
        timeSeries4.clear();
        timeSeries4.removeAgedItems(true);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate4.toSerial();
        boolean boolean6 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        spreadsheetDate2.setDescription("");
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        serialDate9.setDescription("January");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        java.lang.Number number20 = timeSeriesDataItem19.getValue();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getFirstMillisecond();
//        java.lang.String str23 = month21.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int29 = spreadsheetDate28.toSerial();
//        boolean boolean30 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int34 = fixedMillisecond32.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass35 = fixedMillisecond32.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
//        java.util.Date date40 = fixedMillisecond37.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
//        java.util.Date date47 = fixedMillisecond44.getTime();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date47, timeZone49);
//        boolean boolean51 = spreadsheetDate28.equals((java.lang.Object) wildcardClass35);
//        boolean boolean52 = month21.equals((java.lang.Object) spreadsheetDate28);
//        boolean boolean53 = timeSeriesDataItem19.equals((java.lang.Object) spreadsheetDate28);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class57);
//        java.util.List list59 = timeSeries58.getItems();
//        boolean boolean60 = timeSeries58.getNotify();
//        timeSeries58.setMaximumItemCount(6);
//        boolean boolean63 = timeSeriesDataItem19.equals((java.lang.Object) timeSeries58);
//        java.lang.Number number64 = timeSeriesDataItem19.getValue();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2.0d + "'", number20.equals(2.0d));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(list59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 2.0d + "'", number64.equals(2.0d));
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        long long6 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass9 = fixedMillisecond6.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date21, timeZone23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date21);
        int int27 = fixedMillisecond1.compareTo((java.lang.Object) date21);
        long long28 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date29 = fixedMillisecond1.getTime();
        long long30 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getSerialIndex();
        long long8 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int3 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int6 = spreadsheetDate5.toSerial();
//        int int7 = spreadsheetDate5.getMonth();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        int int10 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
//        serialDate11.setDescription("");
//        java.lang.String str14 = serialDate11.toString();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate17);
//        boolean boolean20 = spreadsheetDate5.isInRange(serialDate11, serialDate17, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int23 = spreadsheetDate22.toSerial();
//        int int24 = spreadsheetDate22.getMonth();
//        boolean boolean25 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int28 = spreadsheetDate27.toSerial();
//        int int29 = spreadsheetDate27.getMonth();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getSerialIndex();
//        int int32 = day30.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
//        serialDate33.setDescription("");
//        java.lang.String str36 = serialDate33.toString();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate39);
//        boolean boolean42 = spreadsheetDate27.isInRange(serialDate33, serialDate39, (int) (short) 10);
//        int int43 = spreadsheetDate27.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate48);
//        boolean boolean50 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, serialDate48);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int55 = spreadsheetDate54.toSerial();
//        boolean boolean56 = spreadsheetDate52.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int61 = spreadsheetDate60.toSerial();
//        boolean boolean62 = spreadsheetDate58.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        int int63 = spreadsheetDate58.getDayOfWeek();
//        boolean boolean65 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, (org.jfree.data.time.SerialDate) spreadsheetDate58, 6);
//        int int66 = spreadsheetDate27.getDayOfMonth();
//        int int67 = spreadsheetDate27.toSerial();
//        int int68 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        try {
//            org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addYears((-435), (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 3 + "'", int63 == 3);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 9 + "'", int66 == 9);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 10 + "'", int67 == 10);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Sunday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries4.addChangeListener(seriesChangeListener15);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class18);
//        java.lang.String str20 = timeSeries19.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries19.addPropertyChangeListener(propertyChangeListener21);
//        java.util.Collection collection23 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        boolean boolean24 = timeSeries4.isEmpty();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int33 = fixedMillisecond31.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar34 = null;
//        fixedMillisecond31.peg(calendar34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeries29.getNextTimePeriod();
//        boolean boolean39 = timeSeries29.isEmpty();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
//        long long42 = day40.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day40, (double) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day40.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.TimeSeries timeSeries47 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries48 = timeSeries4.addAndOrUpdate(timeSeries47);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43626L + "'", long42 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        long long6 = fixedMillisecond5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedMillisecond1.equals(obj5);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond2.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1559372400000L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getEnd();
        java.lang.Number number18 = null;
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond14.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener6);
        timeSeries2.setNotify(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class1);
//        java.lang.String str3 = timeSeries2.getDomainDescription();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class5);
//        java.lang.String str7 = timeSeries6.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries6);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class14);
//        boolean boolean16 = timeSeries15.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
//        java.lang.String str19 = timeSeries15.getRangeDescription();
//        java.lang.Class class20 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection21 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getSerialIndex();
//        long long25 = day23.getSerialIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        boolean boolean28 = day23.equals((java.lang.Object) regularTimePeriod27);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.createCopy(regularTimePeriod22, regularTimePeriod27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ERROR : Relative To String" + "'", str19.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNull(class20);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int12 = spreadsheetDate11.toSerial();
        boolean boolean13 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass18 = fixedMillisecond15.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getEnd();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date23, timeZone24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date30, timeZone32);
        boolean boolean34 = spreadsheetDate11.equals((java.lang.Object) wildcardClass18);
        boolean boolean35 = fixedMillisecond1.equals((java.lang.Object) boolean34);
        long long36 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond1.getMiddleMillisecond(calendar37);
        long long39 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate4.toSerial();
        boolean boolean6 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.Year year21 = month20.getYear();
        int int22 = month20.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        int int9 = day7.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        java.util.Date date11 = day7.getStart();
//        timeSeries4.setKey((java.lang.Comparable) date11);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class14);
//        java.lang.String str16 = timeSeries15.getDomainDescription();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 0, class18);
//        java.lang.String str20 = timeSeries19.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries19.addPropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries19);
//        java.util.Collection collection24 = timeSeries23.getTimePeriods();
//        java.util.Collection collection25 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod27, 0.0d);
//        try {
//            timeSeries23.add(timeSeriesDataItem29, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.next();
//        java.lang.String str21 = day15.toString();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), "hi!", "ERROR : Relative To String", class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) 2);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//        boolean boolean14 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        long long17 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        long long22 = day20.getSerialIndex();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        boolean boolean25 = day20.equals((java.lang.Object) regularTimePeriod24);
//        long long26 = day20.getLastMillisecond();
//        boolean boolean27 = day15.equals((java.lang.Object) long26);
//        long long28 = day15.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day15.previous();
//        java.util.Calendar calendar30 = null;
//        try {
//            day15.peg(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560150000000L + "'", long28 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int2 = spreadsheetDate1.toSerial();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        int int6 = day4.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        serialDate7.setDescription("");
//        java.lang.String str10 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate13);
//        boolean boolean16 = spreadsheetDate1.isInRange(serialDate7, serialDate13, (int) (short) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        int int19 = spreadsheetDate18.toSerial();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int27 = fixedMillisecond25.compareTo((java.lang.Object) 2);
//        java.lang.Class<?> wildcardClass28 = fixedMillisecond25.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, "7-January-1900", "org.jfree.data.general.SeriesException: Time", class29);
//        boolean boolean31 = timeSeries30.isEmpty();
//        java.lang.String str32 = timeSeries30.getDescription();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries35 = timeSeries30.createCopy(10, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNull(str32);
//    }
//}

