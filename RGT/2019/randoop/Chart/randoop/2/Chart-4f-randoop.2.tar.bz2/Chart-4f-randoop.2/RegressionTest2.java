import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color3);
        combinedRangeXYPlot0.setRangeTickBandPaint((java.awt.Paint) color3);
        java.awt.Shape shape10 = null;
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape10, (java.awt.Paint) color11);
        combinedRangeXYPlot0.setBackgroundPaint((java.awt.Paint) color11);
        java.lang.Object obj14 = combinedRangeXYPlot0.clone();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getLinePaint();
        legendItem17.setShapeVisible(false);
        java.awt.Stroke stroke21 = legendItem17.getOutlineStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator23, xYURLGenerator24);
        java.awt.Font font27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font27);
        xYAreaRenderer25.setBaseItemLabelFont(font27);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint32 = combinedRangeXYPlot31.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke33 = combinedRangeXYPlot31.getDomainCrosshairStroke();
        xYAreaRenderer25.setSeriesStroke((int) (byte) 1, stroke33, true);
        legendItem17.setOutlineStroke(stroke33);
        combinedRangeXYPlot0.setRangeZeroBaselineStroke(stroke33);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset9 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem14 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number15 = null;
        xYDataItem14.setY(number15);
        double double17 = xYDataItem14.getXValue();
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity(shape7, (org.jfree.data.general.PieDataset) defaultPieDataset9, 4, 8, (java.lang.Comparable) double17, "[12.0, NaN]", "DateTickMarkPosition.MIDDLE");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint23 = numberAxis22.getTickMarkPaint();
        numberAxis22.configure();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = numberAxis22.java2DToValue(4.0d, rectangle2D26, rectangleEdge27);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator29 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer31 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator29, xYURLGenerator30);
        xYStepRenderer31.setDrawSeriesLineAsPath(true);
        java.lang.Object obj34 = xYStepRenderer31.clone();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer31.setLegendLine(shape36);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint41 = combinedRangeXYPlot40.getDomainZeroBaselinePaint();
        textTitle39.setBackgroundPaint(paint41);
        org.jfree.chart.entity.TitleEntity titleEntity44 = new org.jfree.chart.entity.TitleEntity(shape36, (org.jfree.chart.title.Title) textTitle39, "PlotOrientation.HORIZONTAL");
        numberAxis22.setLeftArrow(shape36);
        boolean boolean46 = org.jfree.chart.util.ShapeUtilities.equal(shape7, shape36);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 12.0d + "'", double17 == 12.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.05d, true);
        xYSeries2.add((double) 9, 0.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        float float5 = dateAxis2.getMinorTickMarkOutsideLength();
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis2.setTimeline(timeline6);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType8 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType8, 100);
        int int11 = dateTickUnit10.getCalendarField();
        double double12 = dateTickUnit10.getSize();
        int int13 = dateTickUnit10.getRollMultiple();
        java.util.Date date14 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit10);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNotNull(dateTickUnitType8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.6E8d + "'", double12 == 3.6E8d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator1, xYURLGenerator2);
        xYStepAreaRenderer3.setPlotArea(false);
        xYStepAreaRenderer3.setRangeBase((double) ' ');
        java.awt.Paint paint9 = xYStepAreaRenderer3.getSeriesOutlinePaint(7);
        java.awt.Font font11 = xYStepAreaRenderer3.lookupLegendTextFont(5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(font11);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Stroke stroke9 = categoryPlot0.getRangeZeroBaselineStroke();
        java.awt.Paint paint10 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedRangeXYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedRangeXYPlot7.zoomRangeAxes((double) 1, plotRenderingInfo12, point2D13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        combinedRangeXYPlot0.remove((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7);
        boolean boolean18 = combinedRangeXYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis3D3.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        double double9 = categoryAxis3D3.getLowerMargin();
        java.awt.Font font10 = categoryAxis3D3.getLabelFont();
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 12, (-16646144), textMeasurer14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis3D17.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D20, rectangleEdge21);
        double double23 = categoryAxis3D17.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = categoryAxis3D17.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator27, xYURLGenerator28);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font31);
        xYAreaRenderer29.setBaseItemLabelFont(font31);
        categoryAxis3D17.setTickLabelFont((java.lang.Comparable) 10.0d, font31);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock15.addLine("hi!", font31, paint35);
        standardChartTheme1.setSmallFont(font31);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint40 = numberAxis39.getTickMarkPaint();
        java.awt.Paint paint41 = numberAxis39.getAxisLinePaint();
        standardChartTheme1.setLegendBackgroundPaint(paint41);
        java.awt.Paint paint43 = standardChartTheme1.getSubtitlePaint();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = null;
        xYStepRenderer2.setBaseItemLabelGenerator(xYItemLabelGenerator4);
        boolean boolean8 = xYStepRenderer2.getItemShapeVisible(100, (int) '#');
        java.awt.Paint paint10 = xYStepRenderer2.getLegendTextPaint((int) (short) 10);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        int int3 = numberAxis1.getMinorTickCount();
        numberAxis1.setRange(0.0d, (double) 1L);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        numberFormat0.setGroupingUsed(false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        org.jfree.data.general.DatasetGroup datasetGroup7 = timeSeriesCollection4.getGroup();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate9 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection4, true);
        boolean boolean10 = intervalXYDelegate9.isAutoWidth();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot11.setLegendItemShape(shape13);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot11.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator15);
        java.awt.Color color17 = java.awt.Color.pink;
        boolean boolean18 = ringPlot11.equals((java.lang.Object) color17);
        boolean boolean19 = intervalXYDelegate9.equals((java.lang.Object) color17);
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator20 = numberFormat0.formatToCharacterIterator((java.lang.Object) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(datasetGroup7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Stroke stroke9 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.clearRangeMarkers((-16646144));
        categoryPlot0.setCrosshairDatasetIndex(2);
        double double14 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        java.awt.Graphics2D graphics2D16 = null;
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone18);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double23 = dateRange22.getCentralValue();
        dateAxis19.setRange((org.jfree.data.Range) dateRange22);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double28 = dateRange27.getCentralValue();
        org.jfree.data.Range range29 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange22, (org.jfree.data.Range) dateRange27);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange27, (double) 2);
        java.util.TimeZone timeZone33 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone33);
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double38 = dateRange37.getCentralValue();
        dateAxis34.setRange((org.jfree.data.Range) dateRange37);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint31.toRangeWidth((org.jfree.data.Range) dateRange37);
        try {
            org.jfree.chart.util.Size2D size2D41 = textTitle10.arrange(graphics2D16, rectangleConstraint40);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.5d + "'", double28 == 0.5d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.5d + "'", double38 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        boolean boolean7 = xYStepRenderer2.getItemShapeFilled(0, (-16646144));
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint10 = numberAxis9.getTickMarkPaint();
        numberAxis9.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint14 = combinedRangeXYPlot13.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = null;
        combinedRangeXYPlot13.setDrawingSupplier(drawingSupplier15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        combinedRangeXYPlot13.setFixedDomainAxisSpace(axisSpace17);
        boolean boolean19 = numberAxis9.hasListener((java.util.EventListener) combinedRangeXYPlot13);
        combinedRangeXYPlot13.setRangePannable(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        combinedRangeXYPlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        java.awt.Stroke stroke24 = defaultDrawingSupplier22.getNextStroke();
        xYStepRenderer2.setBaseOutlineStroke(stroke24);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator28 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) 'a', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator28, xYURLGenerator29);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot32.setFixedDomainAxisSpace(axisSpace33, false);
        int int36 = categoryPlot32.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint39 = combinedRangeXYPlot38.getDomainZeroBaselinePaint();
        int int40 = combinedRangeXYPlot38.getDomainAxisCount();
        boolean boolean41 = combinedRangeXYPlot38.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        combinedRangeXYPlot38.setFixedDomainAxisSpace(axisSpace42);
        org.jfree.chart.entity.EntityCollection entityCollection46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo(entityCollection46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo47);
        combinedRangeXYPlot38.handleClick(64, (int) (byte) 10, plotRenderingInfo48);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot50 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint51 = combinedRangeXYPlot50.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier52 = null;
        combinedRangeXYPlot50.setDrawingSupplier(drawingSupplier52);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        java.awt.geom.Point2D point2D56 = null;
        combinedRangeXYPlot50.zoomRangeAxes((double) 1, plotRenderingInfo55, point2D56);
        org.jfree.chart.JFreeChart jFreeChart58 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType59 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent60 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot50, jFreeChart58, chartChangeEventType59);
        java.awt.geom.Point2D point2D61 = combinedRangeXYPlot50.getQuadrantOrigin();
        categoryPlot32.zoomDomainAxes(10.0d, plotRenderingInfo48, point2D61);
        org.jfree.data.category.CategoryDataset categoryDataset63 = categoryPlot32.getDataset();
        java.awt.Paint paint64 = categoryPlot32.getRangeMinorGridlinePaint();
        java.awt.Stroke stroke65 = categoryPlot32.getDomainGridlineStroke();
        xYStepAreaRenderer30.setSeriesOutlineStroke(13, stroke65, false);
        try {
            xYStepRenderer2.setSeriesOutlineStroke((int) (byte) -1, stroke65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator28);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(point2D61);
        org.junit.Assert.assertNull(categoryDataset63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D33 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        int int34 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder35);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.util.List list40 = null;
        combinedRangeXYPlot37.drawDomainTickBands(graphics2D38, rectangle2D39, list40);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot37);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.data.Range range44 = combinedRangeXYPlot37.getDataRange(valueAxis43);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot0.getDomainAxis((-1));
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        double double6 = axisSpace4.getRight();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number3 = null;
        xYDataItem2.setY(number3);
        java.lang.Number number5 = xYDataItem2.getY();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj9 = timeSeriesCollection8.clone();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        int int11 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray14 = null;
        try {
            combinedRangeXYPlot0.setRenderers(xYItemRendererArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Stroke stroke9 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.clearRangeMarkers((-16646144));
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        double double13 = axisSpace12.getTop();
        axisSpace12.setBottom((-16.0d));
        categoryPlot0.setFixedRangeAxisSpace(axisSpace12, true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        boolean boolean7 = xYStepRenderer2.getItemShapeFilled(0, (-16646144));
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint10 = numberAxis9.getTickMarkPaint();
        numberAxis9.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint14 = combinedRangeXYPlot13.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = null;
        combinedRangeXYPlot13.setDrawingSupplier(drawingSupplier15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        combinedRangeXYPlot13.setFixedDomainAxisSpace(axisSpace17);
        boolean boolean19 = numberAxis9.hasListener((java.util.EventListener) combinedRangeXYPlot13);
        combinedRangeXYPlot13.setRangePannable(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        combinedRangeXYPlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        java.awt.Stroke stroke24 = defaultDrawingSupplier22.getNextStroke();
        xYStepRenderer2.setBaseOutlineStroke(stroke24);
        xYStepRenderer2.setBaseLinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str1.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection3.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection3);
        boolean boolean8 = barRenderer3D2.equals((java.lang.Object) timeSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            int int10 = timeSeriesCollection3.indexOf(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint3 = combinedRangeXYPlot2.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke4 = combinedRangeXYPlot2.getDomainCrosshairStroke();
        java.util.List list5 = combinedRangeXYPlot2.getSubplots();
        projectInfo0.setContributors(list5);
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone7);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.util.TimeZone timeZone11 = periodAxis10.getTimeZone();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double15 = dateRange14.getCentralValue();
        periodAxis10.setRange((org.jfree.data.Range) dateRange14, true, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = periodAxis10.getLast();
        java.util.Locale locale20 = periodAxis10.getLocale();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("Size2D[width=0.0, height=0.0]", (org.jfree.data.time.RegularTimePeriod) year1, (org.jfree.data.time.RegularTimePeriod) day5, timeZone7, locale20);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(locale20);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot0.getRangeAxisForDataset(11);
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot33.setLegendItemShape(shape35);
        java.awt.Color color37 = java.awt.Color.BLUE;
        java.awt.Color color38 = color37.brighter();
        ringPlot33.setLabelOutlinePaint((java.awt.Paint) color37);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color37);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        categoryPlot41.setFixedDomainAxisSpace(axisSpace42, false);
        java.awt.Paint paint45 = categoryPlot41.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor46 = categoryPlot41.getDomainGridlinePosition();
        boolean boolean47 = categoryPlot41.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace48 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot41.setFixedRangeAxisSpace(axisSpace48, false);
        java.lang.String str51 = axisSpace48.toString();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace48, false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(categoryAnchor46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        java.lang.Comparable comparable3 = xYSeries2.getKey();
        try {
            java.lang.Number number5 = xYSeries2.getY((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        java.awt.Color color4 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color4);
        double double6 = combinedRangeXYPlot0.getGap();
        java.awt.Stroke stroke7 = combinedRangeXYPlot0.getRangeGridlineStroke();
        java.awt.geom.Point2D point2D8 = combinedRangeXYPlot0.getQuadrantOrigin();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(point2D8);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color9.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintContext16);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        java.util.List list2 = axisState0.getTicks();
        double double3 = axisState0.getCursor();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        ringPlot27.setShadowYOffset(4.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot27.getLabelGenerator();
        ringPlot27.setLabelLinksVisible(false);
        java.awt.Stroke stroke53 = ringPlot27.getLabelOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator54 = ringPlot27.getLabelGenerator();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator54);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        int int3 = numberAxis1.getMinorTickCount();
        numberAxis1.setAutoRangeIncludesZero(false);
        numberAxis1.setRangeAboutValue((double) (byte) -1, (double) (short) 100);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor9 = org.jfree.data.time.TimePeriodAnchor.START;
        boolean boolean10 = numberAxis1.equals((java.lang.Object) timePeriodAnchor9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(timePeriodAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double11 = dateRange10.getCentralValue();
        org.jfree.data.Range range12 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange10, (double) 2);
        org.jfree.chart.util.Size2D size2D15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = rectangleConstraint14.calculateConstrainedSize(size2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent3);
        java.lang.String str5 = waferMapPlot1.getPlotType();
        java.lang.String str6 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertNull(waferMapDataset2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "WMAP_Plot" + "'", str5.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "WMAP_Plot" + "'", str6.equals("WMAP_Plot"));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.lang.Class class2 = periodAxis1.getAutoRangeTimePeriodClass();
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot3.setFixedDomainAxisSpace(axisSpace4, false);
        int int7 = categoryPlot3.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainZeroBaselinePaint();
        int int11 = combinedRangeXYPlot9.getDomainAxisCount();
        boolean boolean12 = combinedRangeXYPlot9.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        combinedRangeXYPlot9.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.entity.EntityCollection entityCollection17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo(entityCollection17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        combinedRangeXYPlot9.handleClick(64, (int) (byte) 10, plotRenderingInfo19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint22 = combinedRangeXYPlot21.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = null;
        combinedRangeXYPlot21.setDrawingSupplier(drawingSupplier23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        combinedRangeXYPlot21.zoomRangeAxes((double) 1, plotRenderingInfo26, point2D27);
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot21, jFreeChart29, chartChangeEventType30);
        java.awt.geom.Point2D point2D32 = combinedRangeXYPlot21.getQuadrantOrigin();
        categoryPlot3.zoomDomainAxes(10.0d, plotRenderingInfo19, point2D32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot3.getRangeAxisForDataset(11);
        java.awt.Color color38 = java.awt.Color.BLUE;
        java.awt.Color color39 = color38.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color39);
        java.awt.Shape shape45 = null;
        java.awt.Color color46 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape45, (java.awt.Paint) color46);
        int int48 = color46.getRGB();
        intervalMarker40.setOutlinePaint((java.awt.Paint) color46);
        org.jfree.chart.util.Layer layer50 = null;
        boolean boolean51 = categoryPlot3.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker40, layer50);
        java.awt.Stroke stroke52 = categoryPlot3.getRangeGridlineStroke();
        java.awt.Stroke stroke53 = categoryPlot3.getRangeGridlineStroke();
        combinedRangeXYPlot0.setRangeGridlineStroke(stroke53);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-16776961) + "'", int48 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
    }
}

