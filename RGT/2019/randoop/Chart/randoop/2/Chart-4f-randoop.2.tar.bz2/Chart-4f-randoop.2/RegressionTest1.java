import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis2.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
        boolean boolean9 = dateAxis2.isNegativeArrowVisible();
        dateAxis2.setNegativeArrowVisible(true);
        double double12 = dateAxis2.getLowerMargin();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        java.lang.String str5 = legendItem2.getLabel();
        boolean boolean6 = legendItem2.isShapeVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str5.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        ringPlot27.setShadowYOffset(4.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot27.getLabelGenerator();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor52 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        ringPlot27.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor52);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator54 = null;
        ringPlot27.setLegendLabelURLGenerator(pieURLGenerator54);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color3);
        java.awt.Shape shape9 = null;
        java.awt.Color color10 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape9, (java.awt.Paint) color10);
        int int12 = color10.getRGB();
        intervalMarker4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        intervalMarker4.notifyListeners(markerChangeEvent14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = intervalMarker4.getLabelAnchor();
        try {
            intervalMarker4.setAlpha((float) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16776961) + "'", int12 == (-16776961));
        org.junit.Assert.assertNotNull(rectangleAnchor17);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        boolean boolean6 = xYStepRenderer2.isSeriesVisible((int) '4');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = xYStepRenderer2.getToolTipGenerator((int) ' ', 0, false);
        java.awt.Paint paint12 = xYStepRenderer2.lookupSeriesOutlinePaint(3);
        java.awt.Color color14 = java.awt.Color.GRAY;
        xYStepRenderer2.setSeriesOutlinePaint(100, (java.awt.Paint) color14, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(xYToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        org.jfree.data.general.PieDataset pieDataset8 = ringPlot0.getDataset();
        boolean boolean9 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        ringPlot0.setAutoPopulateSectionPaint(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYStepAreaRenderer3.isShapesFilled();
        java.awt.Shape shape6 = xYStepAreaRenderer3.lookupSeriesShape(64);
        xYStepAreaRenderer3.setShapesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ThreadContext", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke5 = combinedRangeXYPlot3.getDomainCrosshairStroke();
        xYStepRenderer2.setBaseOutlineStroke(stroke5, true);
        xYStepRenderer2.setSeriesShapesFilled(100, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer2.getLegendItem((int) ' ', 7);
        xYStepRenderer2.setSeriesLinesVisible((int) (byte) 10, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(legendItem13);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection0.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection0);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent4.getSummary();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(timeSeries3);
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = null;
        try {
            ringPlot0.setSimpleLabelOffset(rectangleInsets48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.lang.Number number3 = defaultPieDataset0.getValue(12);
        defaultPieDataset0.setValue((java.lang.Comparable) 45.0d, 1.0d);
        java.lang.Object obj7 = defaultPieDataset0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        double double7 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit8);
        java.util.TimeZone timeZone10 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone10;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9, timeZone10);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj9 = timeSeriesCollection8.clone();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        int int11 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier12);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color16);
        java.awt.Paint paint18 = legendItem17.getLinePaint();
        legendItem17.setShapeVisible(false);
        java.lang.Object obj21 = legendItem17.clone();
        java.awt.Color color22 = java.awt.Color.PINK;
        legendItem17.setLinePaint((java.awt.Paint) color22);
        try {
            combinedRangeXYPlot0.setQuadrantPaint((int) '4', (java.awt.Paint) color22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (52) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        boolean boolean6 = intervalXYDelegate5.isAutoWidth();
        double double8 = intervalXYDelegate5.getDomainLowerBound(false);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(255);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font10 = textFragment9.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot11.setDrawingSupplier(drawingSupplier13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, false);
        boolean boolean17 = dateAxis2.hasListener((java.util.EventListener) combinedRangeXYPlot11);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getFirstMillisecond();
        java.util.Date date20 = year18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, 0.2d);
        java.util.TimeZone timeZone26 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone26);
        dateAxis27.setInverted(false);
        dateAxis27.setLowerBound((double) 0);
        double double32 = dateAxis27.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date34 = dateAxis27.calculateHighestVisibleTickValue(dateTickUnit33);
        boolean boolean35 = timeSeriesDataItem24.equals((java.lang.Object) date34);
        try {
            dateAxis2.setRange(date20, date34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint3 = combinedRangeXYPlot2.getDomainZeroBaselinePaint();
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setExpandToFitSpace(true);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle1.setVerticalAlignment(verticalAlignment7);
        textTitle1.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(verticalAlignment7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2);
        timeSeriesDataItem2.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem2.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font3 = textFragment2.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot4, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            jFreeChart9.setPadding(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.lang.String str11 = chartChangeEvent10.toString();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font3 = textFragment2.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot4, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart9.getXYPlot();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart9.setBorderStroke(stroke11);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(xYPlot10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setToolTipText("hi!");
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        java.lang.String str2 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str2.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number6 = null;
        xYDataItem5.setY(number6);
        double double8 = xYDataItem5.getXValue();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        combinedRangeXYPlot9.setDrawingSupplier(drawingSupplier11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        combinedRangeXYPlot9.zoomRangeAxes((double) 1, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = combinedRangeXYPlot9.getDomainAxis(1);
        boolean boolean21 = xYDataItem5.equals((java.lang.Object) 1);
        xYSeries2.add(xYDataItem5, false);
        double double24 = xYSeries2.getMinY();
        xYSeries2.add((-1.0d), (java.lang.Number) 64);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 12.0d + "'", double8 == 12.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeriesCollection2.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.Class<?> wildcardClass7 = timeSeriesCollection2.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("12/31/69", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(timeSeries5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNull(inputStream9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.lang.Boolean boolean9 = xYAreaRenderer3.getSeriesVisible(0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer3.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        java.lang.Object obj12 = standardGradientPaintTransformer10.clone();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer15 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator13, xYURLGenerator14);
        xYStepRenderer15.setDrawSeriesLineAsPath(true);
        java.lang.Object obj18 = xYStepRenderer15.clone();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer15.setLegendLine(shape20);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint25 = combinedRangeXYPlot24.getDomainZeroBaselinePaint();
        textTitle23.setBackgroundPaint(paint25);
        org.jfree.chart.entity.TitleEntity titleEntity28 = new org.jfree.chart.entity.TitleEntity(shape20, (org.jfree.chart.title.Title) textTitle23, "PlotOrientation.HORIZONTAL");
        boolean boolean30 = titleEntity28.equals((java.lang.Object) (byte) 10);
        java.lang.String str31 = titleEntity28.toString();
        org.jfree.chart.title.Title title32 = titleEntity28.getTitle();
        boolean boolean33 = standardGradientPaintTransformer10.equals((java.lang.Object) titleEntity28);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "TitleEntity: tooltip = PlotOrientation.HORIZONTAL" + "'", str31.equals("TitleEntity: tooltip = PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(title32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.lang.Boolean boolean9 = xYAreaRenderer3.getSeriesVisible(0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer3.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        java.awt.GradientPaint gradientPaint12 = null;
        java.awt.Shape shape13 = null;
        try {
            java.awt.GradientPaint gradientPaint14 = standardGradientPaintTransformer10.transform(gradientPaint12, shape13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (-16.0d), 4.0d, (double) 1546329600000L);
        double double6 = rectangleInsets4.calculateLeftOutset(4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-16.0d) + "'", double6 == (-16.0d));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (byte) 0, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ChartChangeEventType.DATASET_UPDATED", "12/31/69", "12/31/69", "12/31/69", "[12.0, NaN]");
        basicProjectInfo5.setInfo("org.jfree.data.UnknownKeyException: {0}: ({1}, {2})");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo1.getOptionalLibraries();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke5 = combinedRangeXYPlot3.getDomainCrosshairStroke();
        java.util.List list6 = combinedRangeXYPlot3.getSubplots();
        projectInfo1.setContributors(list6);
        segmentedTimeline0.addExceptions(list6);
        try {
            java.util.Collection collection9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        java.awt.Paint paint4 = ringPlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        ringPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier5);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, false);
        org.jfree.data.Range range6 = intervalXYDelegate4.getDomainBounds(false);
        org.jfree.data.Range range8 = intervalXYDelegate4.getDomainBounds(false);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint6 = null;
        try {
            standardChartTheme1.setWallPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        combinedRangeXYPlot5.setRangePannable(true);
        combinedRangeXYPlot5.setDomainMinorGridlinesVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis2.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
        dateAxis2.setMinorTickMarksVisible(true);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        double double2 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset1);
        try {
            java.lang.String str4 = standardPieToolTipGenerator0.generateToolTip((org.jfree.data.general.PieDataset) defaultPieDataset1, (java.lang.Comparable) 13);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 13");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        combinedRangeXYPlot5.setRangePannable(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        combinedRangeXYPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier14);
        java.awt.Stroke stroke16 = defaultDrawingSupplier14.getNextStroke();
        java.awt.Paint paint17 = defaultDrawingSupplier14.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        java.util.List list3 = combinedRangeXYPlot0.getSubplots();
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        combinedRangeXYPlot0.zoomDomainAxes((double) ' ', plotRenderingInfo8, point2D11);
        int int13 = plotRenderingInfo8.getSubplotCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = barRenderer3D2.getDrawingSupplier();
        double double4 = barRenderer3D2.getShadowYOffset();
        org.junit.Assert.assertNull(drawingSupplier3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        ringPlot27.setShadowYOffset(4.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot27.getLabelGenerator();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor52 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        ringPlot27.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor52);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord55 = pieLabelDistributor52.getPieLabelRecord((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -460");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (-460));
        categoryPlot0.configureRangeAxes();
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        boolean boolean10 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator2, xYURLGenerator3);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font6);
        xYAreaRenderer4.setBaseItemLabelFont(font6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYAreaRenderer4);
        boolean boolean10 = textLine0.equals((java.lang.Object) xYAreaRenderer4);
        org.jfree.chart.text.TextFragment textFragment11 = textLine0.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment12 = textLine0.getLastTextFragment();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(textFragment11);
        org.junit.Assert.assertNull(textFragment12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainPannable();
        categoryPlot0.setRangeZeroBaselineVisible(false);
        categoryPlot0.setWeight(5);
        java.awt.Color color9 = java.awt.Color.BLUE;
        java.awt.Color color10 = color9.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color10);
        java.awt.Shape shape16 = null;
        java.awt.Color color17 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape16, (java.awt.Paint) color17);
        int int19 = color17.getRGB();
        intervalMarker11.setOutlinePaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot0.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker11, layer21, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = intervalMarker11.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-16776961) + "'", int19 == (-16776961));
        org.junit.Assert.assertNull(gradientPaintTransformer24);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        categoryAxis3D16.configure();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        xYAreaRenderer3.setUseFillPaint(false);
        boolean boolean10 = xYAreaRenderer3.isSeriesItemLabelsVisible(0);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYAreaRenderer3.getURLGenerator((-16646144), (int) (short) 1, true);
        java.awt.Paint paint15 = xYAreaRenderer3.getBaseFillPaint();
        xYAreaRenderer3.setItemLabelAnchorOffset((double) (-460));
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYURLGenerator14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot0.getRangeAxisForDataset(11);
        java.awt.Color color35 = java.awt.Color.BLUE;
        java.awt.Color color36 = color35.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color36);
        java.awt.Shape shape42 = null;
        java.awt.Color color43 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape42, (java.awt.Paint) color43);
        int int45 = color43.getRGB();
        intervalMarker37.setOutlinePaint((java.awt.Paint) color43);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker37, layer47);
        java.awt.Stroke stroke49 = categoryPlot0.getRangeGridlineStroke();
        java.lang.Comparable comparable50 = null;
        categoryPlot0.setDomainCrosshairRowKey(comparable50);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-16776961) + "'", int45 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        java.awt.Color color4 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color4);
        double double6 = combinedRangeXYPlot0.getGap();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedRangeXYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedRangeXYPlot7.zoomRangeAxes((double) 1, plotRenderingInfo12, point2D13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = combinedRangeXYPlot7.getDomainAxis(1);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        combinedRangeXYPlot3.setDrawingSupplier(drawingSupplier5);
        int int7 = combinedRangeXYPlot3.getSeriesCount();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color9);
        legendItem10.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset13 = null;
        legendItem10.setDataset(dataset13);
        java.lang.String str15 = legendItem10.getLabel();
        java.awt.Shape shape16 = legendItem10.getShape();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint20 = combinedRangeXYPlot19.getDomainZeroBaselinePaint();
        textTitle18.setBackgroundPaint(paint20);
        textTitle18.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity25 = new org.jfree.chart.entity.TitleEntity(shape16, (org.jfree.chart.title.Title) textTitle18, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot28.setFixedDomainAxisSpace(axisSpace29, false);
        java.awt.Paint paint32 = categoryPlot28.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot28.getDomainGridlinePosition();
        boolean boolean34 = categoryPlot28.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace35 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot28.setFixedRangeAxisSpace(axisSpace35, false);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace38 = periodAxis1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot3, rectangle2D26, rectangleEdge27, axisSpace35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str15.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        org.jfree.data.time.Year year14 = month12.getYear();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        numberFormat0.setMinimumIntegerDigits((-16646144));
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font2 = textFragment1.getFont();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) (-16776961));
        try {
            float float7 = textFragment1.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator8, xYURLGenerator9);
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font12);
        xYAreaRenderer10.setBaseItemLabelFont(font12);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint17 = combinedRangeXYPlot16.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke18 = combinedRangeXYPlot16.getDomainCrosshairStroke();
        xYAreaRenderer10.setSeriesStroke((int) (byte) 1, stroke18, true);
        xYAreaRenderer3.setSeriesOutlineStroke((int) (byte) 1, stroke18);
        xYAreaRenderer3.setSeriesVisibleInLegend(1900, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        numberAxis1.resizeRange(45.0d, (double) 5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ClassContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection0.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection0);
        java.lang.Class<?> wildcardClass5 = timeSeriesCollection0.getClass();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(timeSeries3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator25 = null;
        ringPlot0.setURLGenerator(pieURLGenerator25);
        java.awt.Paint paint27 = ringPlot0.getLabelLinkPaint();
        boolean boolean28 = ringPlot0.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setCrosshairX((double) (-57600000L));
        crosshairState0.setAnchorX(16.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (-1));
        double double4 = rectangleInsets0.extendHeight((double) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 108.0d + "'", double4 == 108.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = periodAxis1.getLast();
        java.lang.Class class3 = periodAxis1.getAutoRangeTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getGPL();
        java.lang.String str3 = licences0.getLGPL();
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(64, layer6);
        java.awt.Stroke stroke8 = categoryPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = xYStepRenderer2.getDrawingSupplier();
        org.junit.Assert.assertNull(drawingSupplier3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        java.awt.Paint paint2 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo0.addOptionalLibrary("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo6.getOptionalLibraries();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo6.getLibraries();
        java.lang.String str10 = projectInfo6.getLicenceName();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        try {
            java.lang.Number number3 = defaultPieDataset0.getValue((java.lang.Comparable) "[12.0, NaN]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: [12.0, NaN]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo0.addOptionalLibrary("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo6.getOptionalLibraries();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
        java.util.List list9 = projectInfo6.getContributors();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        segmentedTimeline0.addBaseTimelineException((long) 5);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        java.util.Date date16 = year14.getEnd();
        java.util.Date date17 = year14.getStart();
        segmentedTimeline0.addBaseTimelineException(date17);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint3 = combinedRangeXYPlot2.getDomainZeroBaselinePaint();
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.setExpandToFitSpace(true);
        textTitle1.setNotify(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean10 = categoryPlot9.isDomainPannable();
        categoryPlot9.setRangeZeroBaselineVisible(false);
        categoryPlot9.setWeight(5);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryPlot9.setRangeMinorGridlinePaint((java.awt.Paint) color15);
        boolean boolean17 = textTitle1.equals((java.lang.Object) categoryPlot9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 1, 7, (int) (byte) 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.lang.String[] strArray12 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.lang.String str15 = symbolAxis13.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis13);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot17.setLegendItemShape(shape19);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot17.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator21);
        java.awt.Color color23 = java.awt.Color.pink;
        boolean boolean24 = ringPlot17.equals((java.lang.Object) color23);
        symbolAxis13.setGridBandAlternatePaint((java.awt.Paint) color23);
        java.awt.Paint paint26 = symbolAxis13.getGridBandPaint();
        symbolAxis13.setUpperBound((double) (byte) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        try {
            double double6 = timeSeriesCollection0.getStartYValue((-9999), 64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        combinedRangeXYPlot0.notifyListeners(plotChangeEvent5);
        combinedRangeXYPlot0.configureRangeAxes();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator8, xYURLGenerator9);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke13 = combinedRangeXYPlot11.getDomainCrosshairStroke();
        xYStepRenderer10.setBaseOutlineStroke(stroke13, true);
        combinedRangeXYPlot0.setDomainMinorGridlineStroke(stroke13);
        java.awt.Color color17 = java.awt.Color.darkGray;
        combinedRangeXYPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        int int19 = color17.getGreen();
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 64 + "'", int19 == 64);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        boolean boolean7 = xYStepRenderer2.getItemShapeFilled(0, (-16646144));
        xYStepRenderer2.setBaseCreateEntities(true);
        java.lang.Object obj10 = xYStepRenderer2.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape4, (java.awt.Paint) color5);
        boolean boolean7 = legendItem6.isLineVisible();
        legendItem6.setSeriesIndex(1);
        boolean boolean10 = legendItem6.isShapeVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.util.TimeZone timeZone2 = periodAxis1.getTimeZone();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        periodAxis1.setRange((org.jfree.data.Range) dateRange5, true, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeriesCollection11.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection11);
        java.lang.Class<?> wildcardClass16 = timeSeriesCollection11.getClass();
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", (java.lang.Class) wildcardClass16);
        periodAxis1.setMajorTickTimePeriodClass((java.lang.Class) wildcardClass16);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(timeSeries14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(inputStream17);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) (-16776961));
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Color color11 = color10.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot13.setFixedDomainAxisSpace(axisSpace14, false);
        categoryPlot13.setDomainCrosshairColumnKey((java.lang.Comparable) (-460));
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace20, false);
        int int23 = categoryPlot19.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint26 = combinedRangeXYPlot25.getDomainZeroBaselinePaint();
        int int27 = combinedRangeXYPlot25.getDomainAxisCount();
        boolean boolean28 = combinedRangeXYPlot25.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        combinedRangeXYPlot25.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.entity.EntityCollection entityCollection33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo(entityCollection33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        combinedRangeXYPlot25.handleClick(64, (int) (byte) 10, plotRenderingInfo35);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint38 = combinedRangeXYPlot37.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier39 = null;
        combinedRangeXYPlot37.setDrawingSupplier(drawingSupplier39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        combinedRangeXYPlot37.zoomRangeAxes((double) 1, plotRenderingInfo42, point2D43);
        org.jfree.chart.JFreeChart jFreeChart45 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot37, jFreeChart45, chartChangeEventType46);
        java.awt.geom.Point2D point2D48 = combinedRangeXYPlot37.getQuadrantOrigin();
        categoryPlot19.zoomDomainAxes(10.0d, plotRenderingInfo35, point2D48);
        org.jfree.chart.axis.ValueAxis valueAxis51 = categoryPlot19.getRangeAxisForDataset(11);
        java.awt.Color color54 = java.awt.Color.BLUE;
        java.awt.Color color55 = color54.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker56 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color55);
        java.awt.Shape shape61 = null;
        java.awt.Color color62 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape61, (java.awt.Paint) color62);
        int int64 = color62.getRGB();
        intervalMarker56.setOutlinePaint((java.awt.Paint) color62);
        org.jfree.chart.util.Layer layer66 = null;
        boolean boolean67 = categoryPlot19.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker56, layer66);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D68 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        double double73 = categoryAxis3D68.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D71, rectangleEdge72);
        double double74 = categoryAxis3D68.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions75 = categoryAxis3D68.getCategoryLabelPositions();
        categoryAxis3D68.setCategoryLabelPositionOffset((int) (byte) 1);
        java.awt.Font font79 = categoryAxis3D68.getTickLabelFont((java.lang.Comparable) 45.0d);
        int int80 = categoryPlot19.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D68);
        int int81 = categoryPlot13.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D68);
        intervalMarker12.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot13);
        org.jfree.chart.text.TextAnchor textAnchor83 = intervalMarker12.getLabelTextAnchor();
        try {
            java.awt.Shape shape84 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ItemLabelAnchor.INSIDE6", graphics2D1, (float) 255, (float) (short) 10, textAnchor4, (double) (byte) 100, textAnchor83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-16776961) + "'", int64 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.05d + "'", double74 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions75);
        org.junit.Assert.assertNotNull(font79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
        org.junit.Assert.assertNotNull(textAnchor83);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        categoryAxis3D0.setCategoryMargin((double) (byte) 0);
        int int8 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot10.setLegendItemShape(shape12);
        java.awt.Paint paint14 = ringPlot10.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = ringPlot10.getSimpleLabelOffset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        java.awt.Font font23 = categoryAxis3D16.getLabelFont();
        ringPlot10.setLabelFont(font23);
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 4.0d, font23);
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator31 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot27.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator31);
        java.awt.Color color33 = java.awt.Color.pink;
        boolean boolean34 = ringPlot27.equals((java.lang.Object) color33);
        ringPlot27.setLabelGap(0.0d);
        ringPlot27.setOuterSeparatorExtension((double) '4');
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color40);
        legendItem41.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset44 = null;
        legendItem41.setDataset(dataset44);
        java.lang.String str46 = legendItem41.getLabel();
        java.awt.Shape shape47 = legendItem41.getLine();
        java.awt.Font font48 = null;
        legendItem41.setLabelFont(font48);
        java.awt.Paint paint50 = legendItem41.getLinePaint();
        ringPlot27.setLabelBackgroundPaint(paint50);
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) "Combined_Domain_XYPlot", paint50);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str46.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(numberFormat3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        numberFormat0.setGroupingUsed(false);
        numberFormat0.setMaximumIntegerDigits((int) (short) -1);
        java.lang.String str7 = numberFormat0.format((long) 255);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        ringPlot27.setShadowYOffset(4.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot27.getLabelGenerator();
        ringPlot27.setLabelLinksVisible(false);
        ringPlot27.setIgnoreNullValues(true);
        org.jfree.chart.plot.RingPlot ringPlot55 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot55.setLegendItemShape(shape57);
        java.awt.Paint paint59 = ringPlot55.getBaseSectionOutlinePaint();
        ringPlot27.setBaseSectionOutlinePaint(paint59);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color3);
        java.awt.Shape shape9 = null;
        java.awt.Color color10 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape9, (java.awt.Paint) color10);
        int int12 = color10.getRGB();
        intervalMarker4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        intervalMarker4.notifyListeners(markerChangeEvent14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = intervalMarker4.getLabelAnchor();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = intervalMarker4.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16776961) + "'", int12 == (-16776961));
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNull(gradientPaintTransformer18);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        java.awt.Shape shape4 = ringPlot0.getLegendItemShape();
        ringPlot0.setOuterSeparatorExtension(5.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color3);
        java.awt.Shape shape9 = null;
        java.awt.Color color10 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape9, (java.awt.Paint) color10);
        int int12 = color10.getRGB();
        intervalMarker4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        intervalMarker4.notifyListeners(markerChangeEvent14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint19 = numberAxis18.getTickMarkPaint();
        numberAxis18.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = null;
        combinedRangeXYPlot22.setDrawingSupplier(drawingSupplier24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        combinedRangeXYPlot22.setFixedDomainAxisSpace(axisSpace26);
        boolean boolean28 = numberAxis18.hasListener((java.util.EventListener) combinedRangeXYPlot22);
        combinedRangeXYPlot22.setRangePannable(true);
        intervalMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) combinedRangeXYPlot22);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = intervalMarker4.getLabelOffset();
        java.awt.Font font33 = intervalMarker4.getLabelFont();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16776961) + "'", int12 == (-16776961));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        boolean boolean6 = xYStepRenderer2.isSeriesVisible((int) '4');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = xYStepRenderer2.getToolTipGenerator((int) ' ', 0, false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer11.setItemLabelAnchorOffset((double) 100);
        java.awt.Stroke stroke14 = xYAreaRenderer11.getBaseOutlineStroke();
        xYStepRenderer2.setBaseOutlineStroke(stroke14);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(xYToolTipGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) 45.0d);
        paintMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot2.setLegendItemShape(shape4);
        java.awt.Paint paint6 = ringPlot2.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot2.getSimpleLabelOffset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis3D8.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D11, rectangleEdge12);
        double double14 = categoryAxis3D8.getLowerMargin();
        java.awt.Font font15 = categoryAxis3D8.getLabelFont();
        ringPlot2.setLabelFont(font15);
        standardChartTheme1.setLargeFont(font15);
        java.awt.Color color18 = java.awt.Color.red;
        standardChartTheme1.setTitlePaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.configure();
        java.awt.Shape shape10 = numberAxis7.getLeftArrow();
        java.awt.Shape shape11 = numberAxis7.getUpArrow();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.lang.String str13 = categoryPlot0.getNoDataMessage();
        boolean boolean14 = categoryPlot0.isNotify();
        double double15 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Paint paint16 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        boolean boolean7 = xYStepRenderer2.isItemLabelVisible((-460), 5, false);
        java.awt.Shape shape12 = null;
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape12, (java.awt.Paint) color13);
        int int15 = color13.getRGB();
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color13.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        xYStepRenderer2.setBaseOutlinePaint((java.awt.Paint) color13, false);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16776961) + "'", int15 == (-16776961));
        org.junit.Assert.assertNotNull(paintContext21);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100L);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        java.lang.String str1 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.MILLISECOND" + "'", str1.equals("DateTickUnitType.MILLISECOND"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D33 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        int int34 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D33);
        java.awt.Paint paint35 = barRenderer3D33.getShadowPaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        java.awt.Color color4 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator6, xYURLGenerator7);
        xYStepRenderer8.setDrawSeriesLineAsPath(true);
        java.lang.Object obj11 = xYStepRenderer8.clone();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer8.setLegendLine(shape13);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj16 = timeSeriesCollection15.clone();
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        timeSeriesCollection15.removeAllSeries();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState19 = timeSeriesCollection15.getSelectionState();
        org.jfree.chart.entity.XYItemEntity xYItemEntity24 = new org.jfree.chart.entity.XYItemEntity(shape13, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, 0, 11, "{0}: ({1}, {2})", "AxisLocation.TOP_OR_RIGHT");
        int int25 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color9);
        java.awt.Paint paint11 = legendItem10.getLinePaint();
        java.awt.Shape shape12 = legendItem10.getLine();
        legendItem2.setLine(shape12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        legendItemEntity14.setSeriesKey((java.lang.Comparable) 5.0d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator8, xYURLGenerator9);
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font12);
        xYAreaRenderer10.setBaseItemLabelFont(font12);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint17 = combinedRangeXYPlot16.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke18 = combinedRangeXYPlot16.getDomainCrosshairStroke();
        xYAreaRenderer10.setSeriesStroke((int) (byte) 1, stroke18, true);
        boolean boolean21 = labelBlock6.equals((java.lang.Object) stroke18);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = labelBlock6.getContentAlignmentPoint();
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font25 = textFragment24.getFont();
        labelBlock6.setFont(font25);
        boolean boolean27 = datasetGroup3.equals((java.lang.Object) font25);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis3D3.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        double double9 = categoryAxis3D3.getLowerMargin();
        java.awt.Font font10 = categoryAxis3D3.getLabelFont();
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 12, (-16646144), textMeasurer14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis3D17.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D20, rectangleEdge21);
        double double23 = categoryAxis3D17.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = categoryAxis3D17.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator27, xYURLGenerator28);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font31);
        xYAreaRenderer29.setBaseItemLabelFont(font31);
        categoryAxis3D17.setTickLabelFont((java.lang.Comparable) 10.0d, font31);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock15.addLine("hi!", font31, paint35);
        standardChartTheme1.setSmallFont(font31);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint40 = numberAxis39.getTickMarkPaint();
        java.awt.Paint paint41 = numberAxis39.getAxisLinePaint();
        standardChartTheme1.setLegendBackgroundPaint(paint41);
        java.awt.Paint paint43 = standardChartTheme1.getChartBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeriesCollection4.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection4);
        boolean boolean9 = barRenderer3D3.equals((java.lang.Object) timeSeriesCollection4);
        boolean boolean10 = gradientXYBarPainter0.equals((java.lang.Object) timeSeriesCollection4);
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter0);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        combinedRangeXYPlot0.handleClick(64, (int) (byte) 10, plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate18 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection14, false);
        xYItemRendererState13.endSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection14, 0, (-16646144), 8, (-16776961), (-1));
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection14, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.awt.geom.Point2D point2D11 = combinedRangeXYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str14 = axisLocation13.toString();
        combinedRangeXYPlot0.setDomainAxisLocation(8, axisLocation13);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray16 = null;
        try {
            combinedRangeXYPlot0.setRenderers(xYItemRendererArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str14.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (-460));
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace7, false);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        int int14 = combinedRangeXYPlot12.getDomainAxisCount();
        boolean boolean15 = combinedRangeXYPlot12.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        combinedRangeXYPlot12.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.entity.EntityCollection entityCollection20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        combinedRangeXYPlot12.handleClick(64, (int) (byte) 10, plotRenderingInfo22);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint25 = combinedRangeXYPlot24.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        combinedRangeXYPlot24.setDrawingSupplier(drawingSupplier26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        combinedRangeXYPlot24.zoomRangeAxes((double) 1, plotRenderingInfo29, point2D30);
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot24, jFreeChart32, chartChangeEventType33);
        java.awt.geom.Point2D point2D35 = combinedRangeXYPlot24.getQuadrantOrigin();
        categoryPlot6.zoomDomainAxes(10.0d, plotRenderingInfo22, point2D35);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot6.getRangeAxisForDataset(11);
        java.awt.Color color41 = java.awt.Color.BLUE;
        java.awt.Color color42 = color41.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color42);
        java.awt.Shape shape48 = null;
        java.awt.Color color49 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape48, (java.awt.Paint) color49);
        int int51 = color49.getRGB();
        intervalMarker43.setOutlinePaint((java.awt.Paint) color49);
        org.jfree.chart.util.Layer layer53 = null;
        boolean boolean54 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker43, layer53);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis3D55.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D58, rectangleEdge59);
        double double61 = categoryAxis3D55.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions62 = categoryAxis3D55.getCategoryLabelPositions();
        categoryAxis3D55.setCategoryLabelPositionOffset((int) (byte) 1);
        java.awt.Font font66 = categoryAxis3D55.getTickLabelFont((java.lang.Comparable) 45.0d);
        int int67 = categoryPlot6.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D55);
        int int68 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D55);
        org.jfree.chart.plot.CategoryMarker categoryMarker69 = null;
        org.jfree.chart.util.Layer layer70 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker69, layer70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-16776961) + "'", int51 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions62);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYAreaRenderer3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(4.0d, (double) (byte) -1, (double) (-9999), (double) 23640L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font3);
        labelBlock4.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean8 = labelBlock4.equals((java.lang.Object) plotOrientation7);
        combinedRangeXYPlot0.setOrientation(plotOrientation7);
        java.lang.Object obj10 = combinedRangeXYPlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        boolean boolean6 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7, false);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.Object obj1 = null;
        boolean boolean2 = gradientPaintTransformType0.equals(obj1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("ItemLabelAnchor.OUTSIDE10");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) ' ', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator3);
        boolean boolean5 = xYStepAreaRenderer4.isShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 13, "ChartChangeEventType.DATASET_UPDATED", "0", true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot0.getRangeAxisForDataset(11);
        java.awt.Color color35 = java.awt.Color.BLUE;
        java.awt.Color color36 = color35.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color36);
        java.awt.Shape shape42 = null;
        java.awt.Color color43 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape42, (java.awt.Paint) color43);
        int int45 = color43.getRGB();
        intervalMarker37.setOutlinePaint((java.awt.Paint) color43);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker37, layer47);
        java.awt.Stroke stroke49 = categoryPlot0.getRangeGridlineStroke();
        float float50 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-16776961) + "'", int45 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 1.0f + "'", float50 == 1.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.awt.geom.Point2D point2D11 = combinedRangeXYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str14 = axisLocation13.toString();
        combinedRangeXYPlot0.setDomainAxisLocation(8, axisLocation13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint18 = combinedRangeXYPlot17.getDomainZeroBaselinePaint();
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color20);
        combinedRangeXYPlot17.setRangeTickBandPaint((java.awt.Paint) color20);
        try {
            combinedRangeXYPlot0.setQuadrantPaint(1900, (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (1900) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str14.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number3 = null;
        xYDataItem2.setY(number3);
        double double5 = xYDataItem2.getXValue();
        java.lang.String str6 = xYDataItem2.toString();
        boolean boolean7 = xYDataItem2.isSelected();
        java.lang.String str8 = xYDataItem2.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 12.0d + "'", double5 == 12.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[12.0, NaN]" + "'", str6.equals("[12.0, NaN]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[12.0, NaN]" + "'", str8.equals("[12.0, NaN]"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint9 = numberAxis8.getTickMarkPaint();
        int int10 = numberAxis8.getMinorTickCount();
        java.text.NumberFormat numberFormat11 = numberAxis8.getNumberFormatOverride();
        org.jfree.chart.entity.AxisEntity axisEntity12 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) numberAxis8);
        boolean boolean13 = pieLabelLinkStyle4.equals((java.lang.Object) shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint15 = combinedRangeXYPlot14.getDomainZeroBaselinePaint();
        int int16 = combinedRangeXYPlot14.getDomainAxisCount();
        combinedRangeXYPlot14.clearSelection();
        java.awt.Color color18 = java.awt.Color.GRAY;
        combinedRangeXYPlot14.setDomainMinorGridlinePaint((java.awt.Paint) color18);
        try {
            org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem(attributedString0, "97", "java.awt.Color[r=192,g=192,b=0]", "ChartChangeEventType.DATASET_UPDATED", shape6, (java.awt.Paint) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator25 = null;
        ringPlot0.setURLGenerator(pieURLGenerator25);
        double double27 = ringPlot0.getLabelLinkMargin();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = ringPlot0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.025d + "'", double27 == 0.025d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator28);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator7, xYURLGenerator8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYStepAreaRenderer9.setBaseOutlinePaint((java.awt.Paint) color10, false);
        standardChartTheme1.setLabelLinkPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint16 = combinedRangeXYPlot15.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        combinedRangeXYPlot15.setDrawingSupplier(drawingSupplier17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        combinedRangeXYPlot15.zoomRangeAxes((double) 1, plotRenderingInfo20, point2D21);
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot15, jFreeChart23, chartChangeEventType24);
        boolean boolean26 = combinedRangeXYPlot15.isDomainZeroBaselineVisible();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        java.awt.RenderingHints renderingHints28 = jFreeChart27.getRenderingHints();
        standardChartTheme1.apply(jFreeChart27);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(renderingHints28);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        pieLabelDistributor1.clear();
        pieLabelDistributor1.clear();
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYAreaRenderer3.setBaseURLGenerator(xYURLGenerator4, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator7, false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font3 = textFragment2.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot4, false);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint12 = numberAxis11.getTickMarkPaint();
        numberAxis11.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint16 = combinedRangeXYPlot15.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        combinedRangeXYPlot15.setDrawingSupplier(drawingSupplier17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        combinedRangeXYPlot15.setFixedDomainAxisSpace(axisSpace19);
        boolean boolean21 = numberAxis11.hasListener((java.util.EventListener) combinedRangeXYPlot15);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str23 = plotOrientation22.toString();
        combinedRangeXYPlot15.setOrientation(plotOrientation22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        jFreeChart9.plotChanged(plotChangeEvent25);
        org.jfree.chart.plot.Plot plot27 = plotChangeEvent25.getPlot();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str23.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(plot27);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 100L, Double.POSITIVE_INFINITY);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYAreaRenderer3.setBaseURLGenerator(xYURLGenerator4, true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        int int9 = combinedRangeXYPlot7.getDomainAxisCount();
        boolean boolean10 = combinedRangeXYPlot7.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke11 = combinedRangeXYPlot7.getRangeZeroBaselineStroke();
        xYAreaRenderer3.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot7);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = xYAreaRenderer3.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(xYToolTipGenerator13);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str13 = plotOrientation12.toString();
        combinedRangeXYPlot5.setOrientation(plotOrientation12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = combinedRangeXYPlot5.getDomainMarkers((int) (short) 10, layer17);
        combinedRangeXYPlot5.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        java.lang.Comparable comparable3 = xYSeries2.getKey();
        xYSeries2.setKey((java.lang.Comparable) 3.6E8d);
        xYSeries2.add((double) (-57600000L), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        textTitle4.setBackgroundPaint(paint6);
        textTitle4.setExpandToFitSpace(true);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle4.setVerticalAlignment(verticalAlignment10);
        org.jfree.chart.entity.TitleEntity titleEntity13 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) textTitle4, "blue");
        xYAreaRenderer0.setBaseShape(shape2, true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font1);
        labelBlock2.setWidth((double) (-1));
        labelBlock2.setMargin((double) 0.0f, (double) (byte) 10, 100.0d, 0.0d);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = labelBlock2.getContentAlignmentPoint();
        java.awt.Paint paint11 = labelBlock2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        int int3 = dateAxis2.getMinorTickCount();
        dateAxis2.setAutoRangeMinimumSize((double) 5);
        java.awt.Shape shape6 = dateAxis2.getLeftArrow();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number4 = null;
        xYDataItem3.setY(number4);
        double double6 = xYDataItem3.getXValue();
        java.lang.String str7 = xYDataItem3.toString();
        boolean boolean8 = xYDataItem3.isSelected();
        defaultPieDataset0.setValue((java.lang.Comparable) xYDataItem3, (double) 10L);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.0d + "'", double6 == 12.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[12.0, NaN]" + "'", str7.equals("[12.0, NaN]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color3);
        java.awt.Shape shape9 = null;
        java.awt.Color color10 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape9, (java.awt.Paint) color10);
        int int12 = color10.getRGB();
        intervalMarker4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint15 = combinedRangeXYPlot14.getDomainZeroBaselinePaint();
        int int16 = combinedRangeXYPlot14.getDomainAxisCount();
        boolean boolean17 = combinedRangeXYPlot14.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        combinedRangeXYPlot14.setFixedDomainAxisSpace(axisSpace18);
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        combinedRangeXYPlot14.handleClick(64, (int) (byte) 10, plotRenderingInfo24);
        intervalMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) combinedRangeXYPlot14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16776961) + "'", int12 == (-16776961));
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj9 = timeSeriesCollection8.clone();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        int int11 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.chart.ui.ProjectInfo projectInfo13 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray14 = projectInfo13.getOptionalLibraries();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint16 = combinedRangeXYPlot15.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke17 = combinedRangeXYPlot15.getDomainCrosshairStroke();
        java.util.List list18 = combinedRangeXYPlot15.getSubplots();
        projectInfo13.setContributors(list18);
        try {
            combinedRangeXYPlot0.mapDatasetToDomainAxes((int) (byte) 1, list18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(libraryArray14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        org.jfree.chart.axis.Axis axis27 = axisEntity26.getAxis();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection();
        boolean boolean29 = axisEntity26.equals((java.lang.Object) timeSeriesCollection28);
        org.jfree.data.time.TimeSeries timeSeries30 = null;
        try {
            int int31 = timeSeriesCollection28.indexOf(timeSeries30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(axis27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        ringPlot27.setShadowYOffset(4.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot27.getLabelGenerator();
        ringPlot27.setLabelLinksVisible(false);
        ringPlot27.setIgnoreNullValues(true);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor55 = ringPlot27.getLabelDistributor();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor55);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = barRenderer3D2.getDrawingSupplier();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        barRenderer3D2.setGradientPaintTransformer(gradientPaintTransformer4);
        org.junit.Assert.assertNull(drawingSupplier3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color3);
        java.awt.Shape shape9 = null;
        java.awt.Color color10 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape9, (java.awt.Paint) color10);
        int int12 = color10.getRGB();
        intervalMarker4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        intervalMarker4.notifyListeners(markerChangeEvent14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint19 = numberAxis18.getTickMarkPaint();
        numberAxis18.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = null;
        combinedRangeXYPlot22.setDrawingSupplier(drawingSupplier24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        combinedRangeXYPlot22.setFixedDomainAxisSpace(axisSpace26);
        boolean boolean28 = numberAxis18.hasListener((java.util.EventListener) combinedRangeXYPlot22);
        combinedRangeXYPlot22.setRangePannable(true);
        intervalMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) combinedRangeXYPlot22);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = combinedRangeXYPlot22.getRangeMarkers(5, layer33);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16776961) + "'", int12 == (-16776961));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(collection34);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = timeSeriesCollection2.getSelectionState();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, true);
        java.lang.String str9 = standardXYURLGenerator1.generateURL((org.jfree.data.xy.XYDataset) timeSeriesCollection2, 9, (int) (short) 1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "?series=9&amp;item=1" + "'", str9.equals("?series=9&amp;item=1"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot0.getRangeAxisForDataset(11);
        java.awt.Color color35 = java.awt.Color.BLUE;
        java.awt.Color color36 = color35.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color36);
        java.awt.Shape shape42 = null;
        java.awt.Color color43 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape42, (java.awt.Paint) color43);
        int int45 = color43.getRGB();
        intervalMarker37.setOutlinePaint((java.awt.Paint) color43);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker37, layer47);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis3D49.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D52, rectangleEdge53);
        double double55 = categoryAxis3D49.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions56 = categoryAxis3D49.getCategoryLabelPositions();
        categoryAxis3D49.setCategoryLabelPositionOffset((int) (byte) 1);
        java.awt.Font font60 = categoryAxis3D49.getTickLabelFont((java.lang.Comparable) 45.0d);
        int int61 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D49);
        categoryPlot0.clearRangeMarkers(5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent64 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent64);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation66 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-16776961) + "'", int45 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions56);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis3D8.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D11, rectangleEdge12);
        double double14 = categoryAxis3D8.getLowerMargin();
        java.awt.Font font15 = categoryAxis3D8.getLabelFont();
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color16, (float) 12, (-16646144), textMeasurer19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 1.0d, (double) 60000L, (double) (short) 100, (double) (byte) 1, font15);
        numberAxis1.setAutoRange(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock20);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis3D0.getLowerMargin();
        java.awt.Font font7 = categoryAxis3D0.getLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color11);
        legendItem12.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset15 = null;
        legendItem12.setDataset(dataset15);
        java.lang.String str17 = legendItem12.getLabel();
        java.awt.Shape shape18 = legendItem12.getShape();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint22 = combinedRangeXYPlot21.getDomainZeroBaselinePaint();
        textTitle20.setBackgroundPaint(paint22);
        textTitle20.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity27 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) textTitle20, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle20.getBounds();
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font31);
        labelBlock32.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean36 = labelBlock32.equals((java.lang.Object) plotOrientation35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation35);
        try {
            double double38 = categoryAxis3D0.getCategoryMiddle(100, 5, rectangle2D28, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str17.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        barRenderer3D2.setShadowXOffset((double) 10.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer3D2.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 100);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYAreaRenderer3.setBaseURLGenerator(xYURLGenerator4, true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        int int9 = combinedRangeXYPlot7.getDomainAxisCount();
        boolean boolean10 = combinedRangeXYPlot7.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke11 = combinedRangeXYPlot7.getRangeZeroBaselineStroke();
        xYAreaRenderer3.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = combinedRangeXYPlot7.getRenderer();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(xYItemRenderer13);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number3 = null;
        xYDataItem2.setY(number3);
        double double5 = xYDataItem2.getXValue();
        xYDataItem2.setY((java.lang.Number) 8.0d);
        java.lang.Number number8 = xYDataItem2.getX();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 12.0d + "'", double5 == 12.0d);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 12 + "'", number8.equals(12));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        categoryAxis3D0.setCategoryMargin((double) (byte) 0);
        double double8 = categoryAxis3D0.getLowerMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace10, false);
        boolean boolean13 = categoryPlot9.isOutlineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot14.setFixedDomainAxisSpace(axisSpace15, false);
        java.awt.Paint paint18 = categoryPlot14.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = categoryPlot14.getDomainGridlinePosition();
        categoryPlot9.setDomainGridlinePosition(categoryAnchor19);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color24);
        legendItem25.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset28 = null;
        legendItem25.setDataset(dataset28);
        java.lang.String str30 = legendItem25.getLabel();
        java.awt.Shape shape31 = legendItem25.getShape();
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint35 = combinedRangeXYPlot34.getDomainZeroBaselinePaint();
        textTitle33.setBackgroundPaint(paint35);
        textTitle33.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity40 = new org.jfree.chart.entity.TitleEntity(shape31, (org.jfree.chart.title.Title) textTitle33, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle33.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean43 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge42);
        try {
            double double44 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor19, 1, (int) (short) 10, rectangle2D41, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str30.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) intervalXYDelegate5, seriesChangeInfo6);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double[] doubleArray3 = new double[] { (-57600000L) };
        double[] doubleArray5 = new double[] { (-57600000L) };
        double[] doubleArray7 = new double[] { (-57600000L) };
        double[] doubleArray9 = new double[] { (-57600000L) };
        double[] doubleArray11 = new double[] { (-57600000L) };
        double[][] doubleArray12 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SeriesRenderingOrder.REVERSE", "Combined Range XYPlot", doubleArray12);
        try {
            org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset13, (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.lang.String[] strArray12 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.lang.String str15 = symbolAxis13.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis13);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot17.setLegendItemShape(shape19);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot17.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator21);
        java.awt.Color color23 = java.awt.Color.pink;
        boolean boolean24 = ringPlot17.equals((java.lang.Object) color23);
        symbolAxis13.setGridBandAlternatePaint((java.awt.Paint) color23);
        java.awt.Paint paint26 = symbolAxis13.getGridBandPaint();
        java.awt.Shape shape27 = symbolAxis13.getLeftArrow();
        try {
            symbolAxis13.setRange(3.6E8d, (double) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (3.6E8) <= upper (1900.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        boolean boolean6 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7, false);
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        intervalMarker14.notifyListeners(markerChangeEvent24);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker14);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint29 = numberAxis28.getTickMarkPaint();
        numberAxis28.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint33 = combinedRangeXYPlot32.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = null;
        combinedRangeXYPlot32.setDrawingSupplier(drawingSupplier34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        combinedRangeXYPlot32.setFixedDomainAxisSpace(axisSpace36);
        boolean boolean38 = numberAxis28.hasListener((java.util.EventListener) combinedRangeXYPlot32);
        combinedRangeXYPlot32.setRangePannable(true);
        intervalMarker14.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) combinedRangeXYPlot32);
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker14, layer42);
        java.awt.Paint paint44 = null;
        try {
            intervalMarker14.setPaint(paint44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.util.TimeZone timeZone2 = periodAxis1.getTimeZone();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        periodAxis1.setLast((org.jfree.data.time.RegularTimePeriod) year3);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.setCrosshairY((double) (byte) 100);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYStepAreaRenderer3.isShapesFilled();
        java.awt.Shape shape6 = xYStepAreaRenderer3.lookupSeriesShape(64);
        boolean boolean7 = xYStepAreaRenderer3.isShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean9 = categoryPlot8.isDomainPannable();
        categoryPlot8.setRangeZeroBaselineVisible(false);
        categoryPlot8.setWeight(5);
        xYStepAreaRenderer3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint17 = combinedRangeXYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = null;
        combinedRangeXYPlot16.setDrawingSupplier(drawingSupplier18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        combinedRangeXYPlot16.drawBackgroundImage(graphics2D20, rectangle2D21);
        org.jfree.chart.util.PaintMap paintMap23 = new org.jfree.chart.util.PaintMap();
        java.awt.Paint paint25 = paintMap23.getPaint((java.lang.Comparable) 0.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis3D28.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D31, rectangleEdge32);
        double double34 = categoryAxis3D28.getLowerMargin();
        java.awt.Font font35 = categoryAxis3D28.getLabelFont();
        java.awt.Color color36 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer39 = null;
        org.jfree.chart.text.TextBlock textBlock40 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, (java.awt.Paint) color36, (float) 12, (-16646144), textMeasurer39);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator41 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator42 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer43 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator41, xYURLGenerator42);
        xYStepRenderer43.setDrawSeriesLineAsPath(true);
        java.lang.Object obj46 = xYStepRenderer43.clone();
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer43.setLegendLine(shape48);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint53 = combinedRangeXYPlot52.getDomainZeroBaselinePaint();
        textTitle51.setBackgroundPaint(paint53);
        org.jfree.chart.entity.TitleEntity titleEntity56 = new org.jfree.chart.entity.TitleEntity(shape48, (org.jfree.chart.title.Title) textTitle51, "PlotOrientation.HORIZONTAL");
        boolean boolean57 = color36.equals((java.lang.Object) textTitle51);
        paintMap23.put((java.lang.Comparable) 4.0d, (java.awt.Paint) color36);
        combinedRangeXYPlot16.setRangeMinorGridlinePaint((java.awt.Paint) color36);
        try {
            xYStepAreaRenderer3.setSeriesOutlinePaint((int) (byte) -1, (java.awt.Paint) color36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(textBlock40);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        categoryPlot0.setAnchorValue((double) 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection3.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection3);
        java.lang.Class<?> wildcardClass8 = timeSeriesCollection3.getClass();
        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", (java.lang.Class) wildcardClass8);
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2019", (java.lang.Class) wildcardClass8);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.UnknownKeyException: {0}: ({1}, {2})", (java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(inputStream9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(inputStream12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = numberAxis1.getAxisLinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis1);
        numberAxis1.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray13 = projectInfo12.getOptionalLibraries();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint15 = combinedRangeXYPlot14.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke16 = combinedRangeXYPlot14.getDomainCrosshairStroke();
        java.util.List list17 = combinedRangeXYPlot14.getSubplots();
        projectInfo12.setContributors(list17);
        segmentedTimeline0.addExceptions(list17);
        segmentedTimeline0.addException((long) (-1), (long) 5);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(libraryArray13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        double double2 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset1);
        java.lang.Number number4 = defaultPieDataset1.getValue(12);
        defaultPieDataset1.setValue((java.lang.Comparable) 45.0d, 1.0d);
        java.text.AttributedString attributedString9 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset1, (java.lang.Comparable) "97");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(attributedString9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        java.lang.Comparable comparable3 = xYSeries2.getKey();
        xYSeries2.setNotify(true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        java.util.List list3 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.axis.AxisSpace axisSpace4 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        boolean boolean6 = categoryPlot0.isRangeMinorGridlinesVisible();
        boolean boolean7 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot0.getRangeMarkers(layer8);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeriesCollection4.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection4);
        boolean boolean9 = barRenderer3D3.equals((java.lang.Object) timeSeriesCollection4);
        boolean boolean10 = gradientXYBarPainter0.equals((java.lang.Object) timeSeriesCollection4);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 100L);
        double double14 = xYBarRenderer13.getShadowXOffset();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color19);
        legendItem20.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset23 = null;
        legendItem20.setDataset(dataset23);
        java.lang.String str25 = legendItem20.getLabel();
        java.awt.Shape shape26 = legendItem20.getShape();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint30 = combinedRangeXYPlot29.getDomainZeroBaselinePaint();
        textTitle28.setBackgroundPaint(paint30);
        textTitle28.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity35 = new org.jfree.chart.entity.TitleEntity(shape26, (org.jfree.chart.title.Title) textTitle28, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D36 = textTitle28.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean38 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge37);
        try {
            gradientXYBarPainter0.paintBarShadow(graphics2D11, xYBarRenderer13, 0, 1900, false, (java.awt.geom.RectangularShape) rectangle2D36, rectangleEdge37, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str25.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        java.lang.String str8 = standardPieSectionLabelGenerator4.generateSectionLabel(pieDataset6, (java.lang.Comparable) "Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(5.0d, (double) 0.0f, 108.0d, (double) (byte) -1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint9 = numberAxis8.getTickMarkPaint();
        numberAxis8.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = null;
        combinedRangeXYPlot12.setDrawingSupplier(drawingSupplier14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        combinedRangeXYPlot12.setFixedDomainAxisSpace(axisSpace16);
        boolean boolean18 = numberAxis8.hasListener((java.util.EventListener) combinedRangeXYPlot12);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str20 = plotOrientation19.toString();
        combinedRangeXYPlot12.setOrientation(plotOrientation19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation6, plotOrientation19);
        combinedRangeXYPlot4.setDomainAxisLocation((int) ' ', axisLocation6, false);
        java.util.List list25 = combinedRangeXYPlot4.getSubplots();
        projectInfo0.setContributors(list25);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str20.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendItem2.getLinePaint();
        legendItem2.setShapeVisible(false);
        java.lang.Object obj6 = legendItem2.clone();
        legendItem2.setSeriesIndex((-16646144));
        java.lang.Object obj9 = legendItem2.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        segmentedTimeline0.addBaseTimelineException((long) 5);
        boolean boolean16 = segmentedTimeline0.containsDomainRange(0L, (long) (byte) 100);
        java.lang.Object obj17 = segmentedTimeline0.clone();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint3 = combinedRangeXYPlot2.getDomainZeroBaselinePaint();
        int int4 = combinedRangeXYPlot2.getDomainAxisCount();
        boolean boolean5 = combinedRangeXYPlot2.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        combinedRangeXYPlot2.setFixedDomainAxisSpace(axisSpace6);
        combinedRangeXYPlot2.clearDomainAxes();
        boolean boolean9 = size2D0.equals((java.lang.Object) combinedRangeXYPlot2);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
        java.awt.Stroke stroke12 = defaultDrawingSupplier10.getNextStroke();
        combinedRangeXYPlot2.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10, false);
        java.awt.Stroke stroke15 = defaultDrawingSupplier10.getNextOutlineStroke();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String[] strArray4 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.lang.String str7 = symbolAxis5.valueToString(Double.POSITIVE_INFINITY);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        java.awt.Paint paint11 = barRenderer3D10.getWallPaint();
        symbolAxis5.setAxisLinePaint(paint11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            year3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYStepAreaRenderer3.isShapesFilled();
        java.awt.Shape shape6 = xYStepAreaRenderer3.lookupSeriesShape(64);
        xYStepAreaRenderer3.setOutline(false);
        boolean boolean10 = xYStepAreaRenderer3.isSeriesVisible((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint9 = combinedRangeXYPlot8.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        combinedRangeXYPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot8.setFixedDomainAxisSpace(axisSpace12);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        int int15 = combinedRangeXYPlot8.getSeriesCount();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = combinedRangeXYPlot8.removeDomainMarker(5, marker17, layer18);
        org.jfree.data.xy.XYDataset xYDataset21 = combinedRangeXYPlot8.getDataset((-16776961));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(xYDataset21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double11 = dateRange10.getCentralValue();
        org.jfree.data.Range range12 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange10);
        double double13 = range12.getLowerBound();
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range12, 10.0d, true);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        try {
            boolean boolean14 = segmentedTimeline0.containsDomainRange(23640L, (long) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (13) < domainValueStart (23640)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font2);
        java.awt.Font font4 = labelBlock3.getFont();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("TitleEntity: tooltip = PlotOrientation.HORIZONTAL", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("");
        textLine6.removeFragment(textFragment8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine6.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textFragment10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        int int6 = combinedRangeXYPlot4.getDomainAxisCount();
        combinedRangeXYPlot4.clearSelection();
        combinedRangeXYPlot4.setRangeZeroBaselineVisible(false);
        java.lang.Object obj10 = combinedRangeXYPlot4.clone();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        java.lang.String[] strArray16 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis17 = new org.jfree.chart.axis.SymbolAxis("", strArray16);
        java.lang.String str19 = symbolAxis17.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis17);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot21.setLegendItemShape(shape23);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator25 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot21.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        java.awt.Color color27 = java.awt.Color.pink;
        boolean boolean28 = ringPlot21.equals((java.lang.Object) color27);
        symbolAxis17.setGridBandAlternatePaint((java.awt.Paint) color27);
        java.awt.Paint paint30 = symbolAxis17.getGridBandPaint();
        combinedRangeXYPlot0.setNoDataMessagePaint(paint30);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation32 = null;
        try {
            boolean boolean33 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 9, "", false);
        java.text.NumberFormat numberFormat4 = logFormat3.getExponentFormat();
        org.jfree.data.xy.XYSeries xYSeries7 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        org.jfree.data.xy.XYDataItem xYDataItem10 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number11 = null;
        xYDataItem10.setY(number11);
        double double13 = xYDataItem10.getXValue();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint15 = combinedRangeXYPlot14.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        combinedRangeXYPlot14.setDrawingSupplier(drawingSupplier16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        combinedRangeXYPlot14.zoomRangeAxes((double) 1, plotRenderingInfo19, point2D20);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot14.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = combinedRangeXYPlot14.getDomainAxis(1);
        boolean boolean26 = xYDataItem10.equals((java.lang.Object) 1);
        xYSeries7.add(xYDataItem10, false);
        boolean boolean29 = logFormat3.equals((java.lang.Object) xYDataItem10);
        java.lang.StringBuffer stringBuffer31 = null;
        java.text.FieldPosition fieldPosition32 = null;
        java.lang.StringBuffer stringBuffer33 = logFormat3.format(1.0d, stringBuffer31, fieldPosition32);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 12.0d + "'", double13 == 12.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stringBuffer33);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (-1));
        double double4 = rectangleInsets0.extendWidth(0.0d);
        double double6 = rectangleInsets0.extendHeight(3.6E8d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.0d + "'", double4 == 16.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.60000008E8d + "'", double6 == 3.60000008E8d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedRangeXYPlot4.zoomRangeAxes((double) 1, plotRenderingInfo9, point2D10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot4, jFreeChart12, chartChangeEventType13);
        java.awt.geom.Point2D point2D15 = combinedRangeXYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str18 = axisLocation17.toString();
        combinedRangeXYPlot4.setDomainAxisLocation(8, axisLocation17);
        categoryPlot0.setRangeAxisLocation(axisLocation17, true);
        boolean boolean22 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str18.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer3D2.getNegativeItemLabelPositionFallback();
        double double5 = barRenderer3D2.getItemMargin();
        double double6 = barRenderer3D2.getBase();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Shape shape8 = legendItem2.getLine();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace10, false);
        java.awt.Paint paint13 = categoryPlot9.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot9.getDomainGridlinePosition();
        boolean boolean15 = categoryPlot9.isRangeMinorGridlinesVisible();
        boolean boolean16 = categoryPlot9.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str18 = axisLocation17.toString();
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation17.getOpposite();
        categoryPlot9.setRangeAxisLocation(axisLocation17);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "?series=9&amp;item=1", "0");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str18.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = 0.05d;
        java.lang.Object obj3 = size2D0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Combined_Domain_XYPlot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.awt.Paint paint2 = paintMap0.getPaint((java.lang.Comparable) 0.0f);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        int int9 = combinedRangeXYPlot7.getDomainAxisCount();
        combinedRangeXYPlot7.clearSelection();
        java.awt.Color color11 = java.awt.Color.GRAY;
        combinedRangeXYPlot7.setDomainMinorGridlinePaint((java.awt.Paint) color11);
        paintMap0.put((java.lang.Comparable) timeSeriesDataItem5, (java.awt.Paint) color11);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.FIXED" + "'", str1.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setCrosshairX((double) (-57600000L));
        crosshairState0.setDatasetIndex((-1));
        java.awt.geom.Point2D point2D5 = crosshairState0.getAnchor();
        org.junit.Assert.assertNull(point2D5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        int int3 = numberAxis1.getMinorTickCount();
        numberAxis1.setAutoRangeIncludesZero(false);
        numberAxis1.setRangeAboutValue((double) (byte) -1, (double) (short) 100);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit9, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        double double48 = ringPlot0.getShadowYOffset();
        boolean boolean49 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        double double50 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 4.0d + "'", double48 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.2d + "'", double50 == 0.2d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 100);
        int int3 = dateTickUnit2.getCalendarField();
        double double4 = dateTickUnit2.getSize();
        java.lang.String str5 = dateTickUnit2.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.6E8d + "'", double4 == 3.6E8d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTickUnit[DateTickUnitType.HOUR, 100]" + "'", str5.equals("DateTickUnit[DateTickUnitType.HOUR, 100]"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot1.setFixedDomainAxisSpace(axisSpace2, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot1.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYStepRenderer9.getLegendItems();
        categoryPlot1.setFixedLegendItems(legendItemCollection10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot1.getRangeMarkers(7, layer13);
        boolean boolean15 = xYAreaRenderer0.hasListener((java.util.EventListener) categoryPlot1);
        java.awt.Stroke stroke17 = xYAreaRenderer0.getSeriesOutlineStroke((int) '4');
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(stroke17);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        xYStepRenderer2.setUseFillPaint(false);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator7 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYStepRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        boolean boolean8 = combinedRangeXYPlot0.canSelectByPoint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font2 = textFragment1.getFont();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            float float5 = textFragment1.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj1 = timeSeriesCollection0.clone();
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        timeSeriesCollection0.removeAllSeries();
        java.util.List list4 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double11 = dateRange10.getCentralValue();
        dateAxis7.setRange((org.jfree.data.Range) dateRange10);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double16 = dateRange15.getCentralValue();
        org.jfree.data.Range range17 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange10, (org.jfree.data.Range) dateRange15);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange10);
        org.jfree.data.Range range20 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange18, (double) (byte) 100);
        try {
            org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, list4, range20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = barRenderer3D2.getDrawingSupplier();
        int int4 = barRenderer3D2.getPassCount();
        org.junit.Assert.assertNull(drawingSupplier3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font3 = textFragment2.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot4, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart9.getXYPlot();
        jFreeChart9.setBackgroundImageAlignment(12);
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        boolean boolean16 = jFreeChart9.equals((java.lang.Object) waferMapRenderer14);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(xYPlot10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font1);
        labelBlock2.setWidth((double) (-1));
        double double5 = labelBlock2.getHeight();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = null;
        try {
            labelBlock2.setContentAlignmentPoint(textBlockAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        boolean boolean4 = barRenderer3D2.isDrawBarOutline();
        double double5 = barRenderer3D2.getBase();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator6);
        org.jfree.chart.renderer.category.BarPainter barPainter8 = barRenderer3D2.getBarPainter();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(barPainter8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, (double) (short) 10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis3D0.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 1);
        java.awt.Font font11 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 45.0d);
        java.lang.String str12 = categoryAxis3D0.getLabelURL();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Shape shape8 = legendItem2.getShape();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        textTitle10.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity17 = new org.jfree.chart.entity.TitleEntity(shape8, (org.jfree.chart.title.Title) textTitle10, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle10.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        textTitle10.setPadding(rectangleInsets19);
        double double22 = rectangleInsets19.calculateBottomInset((double) (short) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        combinedRangeXYPlot5.setRangePannable(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator16, xYURLGenerator17);
        java.lang.Boolean boolean20 = xYAreaRenderer18.getSeriesVisible(2);
        boolean boolean21 = xYAreaRenderer18.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        xYAreaRenderer18.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator23);
        combinedRangeXYPlot5.setRenderer(64, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer18);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int49 = color48.getTransparency();
        ringPlot27.setLabelShadowPaint((java.awt.Paint) color48);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        xYLineAndShapeRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint9 = numberAxis8.getTickMarkPaint();
        java.awt.Paint paint10 = numberAxis8.getAxisLinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        int int14 = combinedRangeXYPlot12.getDomainAxisCount();
        combinedRangeXYPlot12.clearSelection();
        combinedRangeXYPlot12.setRangeZeroBaselineVisible(false);
        java.lang.Object obj18 = combinedRangeXYPlot12.clone();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.lang.String[] strArray24 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis25 = new org.jfree.chart.axis.SymbolAxis("", strArray24);
        java.lang.String str27 = symbolAxis25.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis25);
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot29.setLegendItemShape(shape31);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator33 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot29.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator33);
        java.awt.Color color35 = java.awt.Color.pink;
        boolean boolean36 = ringPlot29.equals((java.lang.Object) color35);
        symbolAxis25.setGridBandAlternatePaint((java.awt.Paint) color35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis3D41.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D44, rectangleEdge45);
        double double47 = categoryAxis3D41.getLowerMargin();
        java.awt.Font font48 = categoryAxis3D41.getLabelFont();
        java.awt.Color color49 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer52 = null;
        org.jfree.chart.text.TextBlock textBlock53 = org.jfree.chart.text.TextUtilities.createTextBlock("", font48, (java.awt.Paint) color49, (float) 12, (-16646144), textMeasurer52);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis3D55.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D58, rectangleEdge59);
        double double61 = categoryAxis3D55.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions62 = categoryAxis3D55.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator65 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator66 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer67 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator65, xYURLGenerator66);
        java.awt.Font font69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock70 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font69);
        xYAreaRenderer67.setBaseItemLabelFont(font69);
        categoryAxis3D55.setTickLabelFont((java.lang.Comparable) 10.0d, font69);
        java.awt.Paint paint73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock53.addLine("hi!", font69, paint73);
        org.jfree.chart.plot.IntervalMarker intervalMarker75 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint73);
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        xYLineAndShapeRenderer0.drawDomainMarker(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot11, (org.jfree.chart.axis.ValueAxis) symbolAxis25, (org.jfree.chart.plot.Marker) intervalMarker75, rectangle2D76);
        double double78 = intervalMarker75.getEndValue();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(textBlock53);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions62);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        boolean boolean4 = barRenderer3D2.isDrawBarOutline();
        barRenderer3D2.setBase((double) (short) 1);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint10 = numberAxis9.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        java.awt.Font font23 = categoryAxis3D16.getLabelFont();
        java.awt.Color color24 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font23, (java.awt.Paint) color24, (float) 12, (-16646144), textMeasurer27);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis9, 1.0d, (double) 60000L, (double) (short) 100, (double) (byte) 1, font23);
        java.awt.Color color30 = java.awt.Color.BLUE;
        boolean boolean31 = markerAxisBand29.equals((java.lang.Object) color30);
        barRenderer3D2.setSeriesItemLabelPaint(11, (java.awt.Paint) color30);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        boolean boolean6 = intervalXYDelegate5.isAutoWidth();
        double double8 = intervalXYDelegate5.getDomainUpperBound(true);
        try {
            intervalXYDelegate5.setIntervalPositionFactor((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color3);
        combinedRangeXYPlot0.setRangeTickBandPaint((java.awt.Paint) color3);
        java.awt.Shape shape10 = null;
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape10, (java.awt.Paint) color11);
        combinedRangeXYPlot0.setBackgroundPaint((java.awt.Paint) color11);
        java.lang.String str14 = combinedRangeXYPlot0.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("{0}: ({1}, {2})");
        java.lang.String str2 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("{0}: ({1}, {2})");
        java.lang.String str5 = unknownKeyException4.toString();
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException4);
        java.lang.Throwable[] throwableArray7 = unknownKeyException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: {0}: ({1}, {2})" + "'", str2.equals("org.jfree.data.UnknownKeyException: {0}: ({1}, {2})"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: {0}: ({1}, {2})" + "'", str5.equals("org.jfree.data.UnknownKeyException: {0}: ({1}, {2})"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) '4', dateTickUnitType2, (-16776961), dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        java.awt.Paint paint6 = combinedRangeXYPlot0.getRangeMinorGridlinePaint();
        java.awt.Paint paint7 = combinedRangeXYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        boolean boolean6 = xYStepRenderer2.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        java.awt.Shape shape10 = xYStepRenderer2.getLegendShape((int) (byte) 0);
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepRenderer2.setSeriesItemLabelPaint(7, paint12);
        boolean boolean14 = xYStepRenderer2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        logAxis1.setBase(Double.POSITIVE_INFINITY);
        logAxis1.configure();
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke5 = combinedRangeXYPlot3.getDomainCrosshairStroke();
        xYStepRenderer2.setBaseOutlineStroke(stroke5, true);
        xYStepRenderer2.setSeriesShapesFilled(100, false);
        boolean boolean11 = xYStepRenderer2.getDrawOutlines();
        boolean boolean12 = xYStepRenderer2.getBaseShapesVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        boolean boolean7 = xYStepRenderer2.getItemShapeFilled(0, (-16646144));
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint10 = numberAxis9.getTickMarkPaint();
        numberAxis9.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint14 = combinedRangeXYPlot13.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = null;
        combinedRangeXYPlot13.setDrawingSupplier(drawingSupplier15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        combinedRangeXYPlot13.setFixedDomainAxisSpace(axisSpace17);
        boolean boolean19 = numberAxis9.hasListener((java.util.EventListener) combinedRangeXYPlot13);
        combinedRangeXYPlot13.setRangePannable(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        combinedRangeXYPlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        java.awt.Stroke stroke24 = defaultDrawingSupplier22.getNextStroke();
        xYStepRenderer2.setBaseOutlineStroke(stroke24);
        xYStepRenderer2.setSeriesShapesFilled(8, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.awt.Font font5 = xYStepRenderer2.getBaseLegendTextFont();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYStepRenderer2.getBaseURLGenerator();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(xYURLGenerator6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ItemLabelAnchor.INSIDE6", dateFormat1, dateFormat2);
        java.lang.String[] strArray9 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis10 = new org.jfree.chart.axis.SymbolAxis("", strArray9);
        java.awt.Paint paint11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        symbolAxis10.setGridBandAlternatePaint(paint11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint14 = combinedRangeXYPlot13.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke15 = combinedRangeXYPlot13.getDomainCrosshairStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.025d, paint11, stroke15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker16);
        boolean boolean18 = standardXYToolTipGenerator3.equals((java.lang.Object) valueMarker16);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape4, (java.awt.Paint) color5);
        boolean boolean7 = legendItem6.isLineVisible();
        legendItem6.setSeriesIndex(1);
        int int10 = legendItem6.getSeriesIndex();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 10);
        double double4 = rectangleInsets0.extendWidth(3.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 19.0d + "'", double4 == 19.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator1, xYURLGenerator2);
        xYStepAreaRenderer3.setPlotArea(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        int int9 = combinedRangeXYPlot7.getDomainAxisCount();
        boolean boolean10 = combinedRangeXYPlot7.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        combinedRangeXYPlot7.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        combinedRangeXYPlot7.handleClick(64, (int) (byte) 10, plotRenderingInfo17);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo17);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color21);
        legendItem22.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset25 = null;
        legendItem22.setDataset(dataset25);
        java.lang.String str27 = legendItem22.getLabel();
        java.awt.Shape shape28 = legendItem22.getShape();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint32 = combinedRangeXYPlot31.getDomainZeroBaselinePaint();
        textTitle30.setBackgroundPaint(paint32);
        textTitle30.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity37 = new org.jfree.chart.entity.TitleEntity(shape28, (org.jfree.chart.title.Title) textTitle30, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle30.getBounds();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean40 = combinedRangeXYPlot39.isDomainZeroBaselineVisible();
        combinedRangeXYPlot39.setDomainCrosshairValue((double) '#', true);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.RenderingSource renderingSource47 = null;
        combinedRangeXYPlot39.select(1.0d, (double) (-1), rectangle2D46, renderingSource47);
        java.util.TimeZone timeZone50 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone50);
        dateAxis51.setInverted(false);
        float float54 = dateAxis51.getMinorTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint57 = numberAxis56.getTickMarkPaint();
        numberAxis56.configure();
        double double59 = numberAxis56.getLowerBound();
        java.awt.Shape shape60 = numberAxis56.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot61 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint62 = combinedRangeXYPlot61.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke63 = combinedRangeXYPlot61.getDomainCrosshairStroke();
        numberAxis56.setAxisLineStroke(stroke63);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection65 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range66 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection65);
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeriesCollection65.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.Range range69 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection65);
        try {
            xYStepAreaRenderer3.drawItem(graphics2D6, xYItemRendererState19, rectangle2D38, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot39, (org.jfree.chart.axis.ValueAxis) dateAxis51, (org.jfree.chart.axis.ValueAxis) numberAxis56, (org.jfree.data.xy.XYDataset) timeSeriesCollection65, 255, 0, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (255).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str27.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 2.0f + "'", float54 == 2.0f);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertNull(timeSeries68);
        org.junit.Assert.assertNull(range69);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        java.lang.String str4 = datasetGroup3.getID();
        java.lang.String str5 = datasetGroup3.getID();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NOID" + "'", str4.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NOID" + "'", str5.equals("NOID"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setLabelGap(0.0d);
        ringPlot0.setOuterSeparatorExtension((double) '4');
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color13);
        legendItem14.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset17 = null;
        legendItem14.setDataset(dataset17);
        java.lang.String str19 = legendItem14.getLabel();
        java.awt.Shape shape20 = legendItem14.getLine();
        java.awt.Font font21 = null;
        legendItem14.setLabelFont(font21);
        java.awt.Paint paint23 = legendItem14.getLinePaint();
        ringPlot0.setLabelBackgroundPaint(paint23);
        java.awt.Paint paint25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot0.setLabelPaint(paint25);
        ringPlot0.setInnerSeparatorExtension(0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str19.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font3 = textFragment2.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot4, false);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color12);
        legendItem13.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset16 = null;
        legendItem13.setDataset(dataset16);
        java.lang.String str18 = legendItem13.getLabel();
        java.awt.Shape shape19 = legendItem13.getShape();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        textTitle21.setBackgroundPaint(paint23);
        textTitle21.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity28 = new org.jfree.chart.entity.TitleEntity(shape19, (org.jfree.chart.title.Title) textTitle21, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle21.getBounds();
        try {
            jFreeChart9.draw(graphics2D10, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str18.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        org.jfree.chart.axis.Axis axis27 = axisEntity26.getAxis();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection();
        boolean boolean29 = axisEntity26.equals((java.lang.Object) timeSeriesCollection28);
        java.lang.String str30 = axisEntity26.toString();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(axis27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AxisEntity: tooltip = ClassContext" + "'", str30.equals("AxisEntity: tooltip = ClassContext"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator2, xYURLGenerator3);
        java.lang.Boolean boolean6 = xYAreaRenderer4.getSeriesVisible(2);
        java.awt.Paint paint7 = xYAreaRenderer4.getBaseItemLabelPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator9, xYURLGenerator10);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font13);
        xYAreaRenderer11.setBaseItemLabelFont(font13);
        xYAreaRenderer4.setBaseItemLabelFont(font13, true);
        java.awt.Color color18 = java.awt.Color.yellow;
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font21);
        labelBlock22.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean26 = labelBlock22.equals((java.lang.Object) plotOrientation25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation25);
        boolean boolean28 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=192,g=192,b=0]", font13, (java.awt.Paint) color18, rectangleEdge27, horizontalAlignment29, verticalAlignment30, rectangleInsets31);
        boolean boolean33 = textTitle32.visible;
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis3D3.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        double double9 = categoryAxis3D3.getLowerMargin();
        java.awt.Font font10 = categoryAxis3D3.getLabelFont();
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, (java.awt.Paint) color11, (float) 12, (-16646144), textMeasurer14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis3D17.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D20, rectangleEdge21);
        double double23 = categoryAxis3D17.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = categoryAxis3D17.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator27, xYURLGenerator28);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font31);
        xYAreaRenderer29.setBaseItemLabelFont(font31);
        categoryAxis3D17.setTickLabelFont((java.lang.Comparable) 10.0d, font31);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock15.addLine("hi!", font31, paint35);
        standardChartTheme1.setSmallFont(font31);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint40 = numberAxis39.getTickMarkPaint();
        java.awt.Paint paint41 = numberAxis39.getAxisLinePaint();
        standardChartTheme1.setLegendBackgroundPaint(paint41);
        java.awt.Paint paint43 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        standardChartTheme1.setLabelLinkPaint(paint43);
        org.jfree.chart.renderer.category.BarPainter barPainter45 = standardChartTheme1.getBarPainter();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(barPainter45);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number4 = null;
        xYDataItem3.setY(number4);
        double double6 = xYDataItem3.getXValue();
        java.lang.String str7 = xYDataItem3.toString();
        boolean boolean8 = xYDataItem3.isSelected();
        defaultPieDataset0.setValue((java.lang.Comparable) xYDataItem3, (double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isDomainPannable();
        categoryPlot11.setRangeZeroBaselineVisible(false);
        boolean boolean15 = defaultPieDataset0.hasListener((java.util.EventListener) categoryPlot11);
        java.awt.Paint paint16 = categoryPlot11.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.0d + "'", double6 == 12.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[12.0, NaN]" + "'", str7.equals("[12.0, NaN]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getCrosshairX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot0.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot0.getDataset();
        categoryPlot0.setAnchorValue((double) 4, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = null;
        categoryPlot0.axisChanged(axisChangeEvent36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertNull(categoryAxis38);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        java.awt.Paint paint8 = xYAreaRenderer3.lookupSeriesPaint(0);
        java.awt.Stroke stroke9 = xYAreaRenderer3.getBaseStroke();
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendItem2.getLinePaint();
        legendItem2.setShapeVisible(false);
        legendItem2.setDatasetIndex((int) (short) 100);
        org.jfree.chart.StandardChartTheme standardChartTheme9 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis3D11.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D14, rectangleEdge15);
        double double17 = categoryAxis3D11.getLowerMargin();
        java.awt.Font font18 = categoryAxis3D11.getLabelFont();
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, (java.awt.Paint) color19, (float) 12, (-16646144), textMeasurer22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis3D25.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D28, rectangleEdge29);
        double double31 = categoryAxis3D25.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions32 = categoryAxis3D25.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator35 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator36 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer37 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator35, xYURLGenerator36);
        java.awt.Font font39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font39);
        xYAreaRenderer37.setBaseItemLabelFont(font39);
        categoryAxis3D25.setTickLabelFont((java.lang.Comparable) 10.0d, font39);
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock23.addLine("hi!", font39, paint43);
        standardChartTheme9.setSmallFont(font39);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint48 = numberAxis47.getTickMarkPaint();
        java.awt.Paint paint49 = numberAxis47.getAxisLinePaint();
        standardChartTheme9.setLegendBackgroundPaint(paint49);
        legendItem2.setFillPaint(paint49);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions32);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 15;
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getGridBandPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis3D7.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D10, rectangleEdge11);
        double double13 = categoryAxis3D7.getLowerMargin();
        java.awt.Font font14 = categoryAxis3D7.getLabelFont();
        java.awt.Color color15 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, (java.awt.Paint) color15, (float) 12, (-16646144), textMeasurer18);
        standardChartTheme1.setSmallFont(font14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock19);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color3);
        combinedRangeXYPlot0.setRangeTickBandPaint((java.awt.Paint) color3);
        boolean boolean6 = combinedRangeXYPlot0.isNotify();
        boolean boolean7 = combinedRangeXYPlot0.canSelectByPoint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray3 = new float[] { '4', 1 };
        try {
            float[] floatArray4 = color0.getRGBColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeriesCollection3.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection3);
        boolean boolean8 = barRenderer3D2.equals((java.lang.Object) timeSeriesCollection3);
        try {
            java.lang.Number number11 = timeSeriesCollection3.getX((int) 'a', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 100);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType3 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType3, 100);
        int int6 = dateTickUnit5.getCalendarField();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone8);
        dateAxis9.setInverted(false);
        dateAxis9.setLowerBound((double) 0);
        double double14 = dateAxis9.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date16 = dateAxis9.calculateHighestVisibleTickValue(dateTickUnit15);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone17;
        java.util.Date date19 = dateTickUnit5.rollDate(date16, timeZone17);
        java.util.Date date20 = dateTickUnit2.rollDate(date16);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        categoryAxis3D16.setLowerMargin((double) 1900);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis13 = combinedRangeXYPlot5.getRangeAxis(100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        logAxis1.setFixedAutoRange((double) 3);
        logAxis1.pan((double) 64);
        logAxis1.setAutoRangeMinimumSize(0.025d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis3D1.getLowerMargin();
        java.awt.Font font8 = categoryAxis3D1.getLabelFont();
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, (java.awt.Paint) color9, (float) 12, (-16646144), textMeasurer12);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator14, xYURLGenerator15);
        xYStepRenderer16.setDrawSeriesLineAsPath(true);
        java.lang.Object obj19 = xYStepRenderer16.clone();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer16.setLegendLine(shape21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint26 = combinedRangeXYPlot25.getDomainZeroBaselinePaint();
        textTitle24.setBackgroundPaint(paint26);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape21, (org.jfree.chart.title.Title) textTitle24, "PlotOrientation.HORIZONTAL");
        boolean boolean30 = color9.equals((java.lang.Object) textTitle24);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double33 = rectangleInsets31.calculateTopOutset((double) 10);
        double double35 = rectangleInsets31.calculateBottomOutset(0.0d);
        textTitle24.setMargin(rectangleInsets31);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        textTitle24.setMargin(rectangleInsets37);
        textTitle24.setExpandToFitSpace(false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedRangeXYPlot0.getDomainAxis((int) (short) 1);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = new org.jfree.chart.plot.CrosshairState();
        boolean boolean14 = combinedRangeXYPlot0.render(graphics2D9, rectangle2D10, 3, plotRenderingInfo12, crosshairState13);
        crosshairState13.setAnchorX((double) 100.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Color color1 = java.awt.Color.getColor("NOID");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        int int3 = numberAxis1.getMinorTickCount();
        numberAxis1.pan((double) (-1L));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        xYStepRenderer2.setDrawOutlines(true);
        double double7 = xYStepRenderer2.getStepPoint();
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint4 = numberAxis3.getTickMarkPaint();
        int int5 = numberAxis3.getMinorTickCount();
        java.text.NumberFormat numberFormat6 = numberAxis3.getNumberFormatOverride();
        org.jfree.chart.entity.AxisEntity axisEntity7 = new org.jfree.chart.entity.AxisEntity(shape1, (org.jfree.chart.axis.Axis) numberAxis3);
        java.lang.String str8 = axisEntity7.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AxisEntity: tooltip = null" + "'", str8.equals("AxisEntity: tooltip = null"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str13 = plotOrientation12.toString();
        combinedRangeXYPlot5.setOrientation(plotOrientation12);
        combinedRangeXYPlot5.setWeight((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace17 = combinedRangeXYPlot5.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNull(axisSpace17);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint2 = combinedRangeXYPlot1.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        combinedRangeXYPlot1.setDrawingSupplier(drawingSupplier3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot1.zoomRangeAxes((double) 1, plotRenderingInfo6, point2D7);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot1, jFreeChart9, chartChangeEventType10);
        boolean boolean12 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        org.jfree.chart.event.ChartProgressListener chartProgressListener15 = null;
        jFreeChart13.removeProgressListener(chartProgressListener15);
        try {
            org.jfree.chart.title.Title title18 = jFreeChart13.getSubtitle((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(renderingHints14);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setLabelGap(0.0d);
        java.awt.Stroke stroke10 = ringPlot0.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        boolean boolean7 = xYStepRenderer2.removeAnnotation(xYAnnotation6);
        java.lang.Boolean boolean9 = xYStepRenderer2.getSeriesShapesVisible(0);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        textTitle11.setBackgroundPaint(paint13);
        textTitle11.setExpandToFitSpace(true);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle11.setVerticalAlignment(verticalAlignment17);
        org.jfree.chart.event.TitleChangeListener titleChangeListener19 = null;
        textTitle11.addChangeListener(titleChangeListener19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace22, false);
        int int25 = categoryPlot21.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint29 = numberAxis28.getTickMarkPaint();
        numberAxis28.configure();
        java.awt.Shape shape31 = numberAxis28.getLeftArrow();
        java.awt.Shape shape32 = numberAxis28.getUpArrow();
        categoryPlot21.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis28);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double36 = rectangleInsets34.calculateTopOutset((double) (-1));
        double double38 = rectangleInsets34.extendWidth(0.0d);
        double double40 = rectangleInsets34.trimWidth((double) (byte) 0);
        numberAxis28.setLabelInsets(rectangleInsets34, false);
        textTitle11.setPadding(rectangleInsets34);
        boolean boolean44 = xYStepRenderer2.equals((java.lang.Object) rectangleInsets34);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 16.0d + "'", double38 == 16.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-16.0d) + "'", double40 == (-16.0d));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        xYStepRenderer2.setUseFillPaint(false);
        java.lang.Boolean boolean8 = xYStepRenderer2.getSeriesLinesVisible((-9999));
        xYStepRenderer2.setSeriesLinesVisible((int) (byte) 0, false);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        categoryAxis3D16.clearCategoryLabelToolTips();
        java.lang.String str29 = categoryAxis3D16.getCategoryLabelToolTip((java.lang.Comparable) 5.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        boolean boolean6 = barRenderer3D2.getItemVisible((int) (byte) 10, 5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        intervalXYDelegate2.datasetChanged(datasetChangeEvent3);
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedRangeXYPlot0.getDomainAxis((int) (short) 1);
        combinedRangeXYPlot0.mapDatasetToDomainAxis(12, 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        double double3 = barRenderer3D2.getMaximumBarWidth();
        barRenderer3D2.setMaximumBarWidth(0.0d);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = combinedRangeXYPlot8.getDatasetGroup();
        boolean boolean11 = combinedRangeXYPlot8.isNotify();
        java.awt.Stroke stroke12 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator14, xYURLGenerator15);
        xYAreaRenderer16.setBaseItemLabelsVisible(true, false);
        boolean boolean20 = combinedRangeXYPlot8.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone4);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone4);
        boolean boolean8 = year0.equals((java.lang.Object) timeSeriesCollection7);
        try {
            double double11 = timeSeriesCollection7.getStartYValue(100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        java.util.List list3 = combinedRangeXYPlot0.getSubplots();
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        combinedRangeXYPlot0.zoomDomainAxes((double) ' ', plotRenderingInfo8, point2D11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint14 = combinedRangeXYPlot13.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke15 = combinedRangeXYPlot13.getDomainCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint17 = combinedRangeXYPlot16.getDomainZeroBaselinePaint();
        int int18 = combinedRangeXYPlot16.getDomainAxisCount();
        combinedRangeXYPlot16.clearSelection();
        combinedRangeXYPlot16.setRangeZeroBaselineVisible(false);
        java.lang.Object obj22 = combinedRangeXYPlot16.clone();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart23.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo27);
        combinedRangeXYPlot13.setBackgroundImage((java.awt.Image) bufferedImage28);
        combinedRangeXYPlot0.setBackgroundImage((java.awt.Image) bufferedImage28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis3D33.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D36, rectangleEdge37);
        double double39 = categoryAxis3D33.getLowerMargin();
        java.awt.Font font40 = categoryAxis3D33.getLabelFont();
        java.awt.Color color41 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer44 = null;
        org.jfree.chart.text.TextBlock textBlock45 = org.jfree.chart.text.TextUtilities.createTextBlock("", font40, (java.awt.Paint) color41, (float) 12, (-16646144), textMeasurer44);
        org.jfree.chart.text.TextLine textLine46 = textBlock45.getLastLine();
        java.util.List list47 = textBlock45.getLines();
        try {
            combinedRangeXYPlot0.mapDatasetToRangeAxes(15, list47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(bufferedImage28);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(textBlock45);
        org.junit.Assert.assertNull(textLine46);
        org.junit.Assert.assertNotNull(list47);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator25 = null;
        ringPlot0.setURLGenerator(pieURLGenerator25);
        java.awt.Paint paint27 = ringPlot0.getShadowPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis2.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
        boolean boolean9 = dateAxis2.isNegativeArrowVisible();
        dateAxis2.setNegativeArrowVisible(true);
        org.jfree.chart.plot.Plot plot12 = dateAxis2.getPlot();
        java.util.TimeZone timeZone13 = dateAxis2.getTimeZone();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo2.setCopyright("ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        logAxis1.setBase(Double.POSITIVE_INFINITY);
        boolean boolean4 = logAxis1.isTickMarksVisible();
        org.jfree.data.Range range5 = logAxis1.getRange();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        numberFormat0.setGroupingUsed(false);
        numberFormat0.setMaximumIntegerDigits((int) (short) -1);
        boolean boolean6 = numberFormat0.isParseIntegerOnly();
        java.text.ParsePosition parsePosition8 = null;
        try {
            java.lang.Object obj9 = numberFormat0.parseObject("hi!", parsePosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.configure();
        java.awt.Shape shape10 = numberAxis7.getLeftArrow();
        java.awt.Shape shape11 = numberAxis7.getUpArrow();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets13.calculateTopOutset((double) (-1));
        double double17 = rectangleInsets13.extendWidth(0.0d);
        double double19 = rectangleInsets13.trimWidth((double) (byte) 0);
        numberAxis7.setLabelInsets(rectangleInsets13, false);
        java.text.NumberFormat numberFormat22 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str24 = numberFormat22.format((long) 11);
        java.text.NumberFormat numberFormat25 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency26 = numberFormat25.getCurrency();
        numberFormat22.setCurrency(currency26);
        numberAxis7.setNumberFormatOverride(numberFormat22);
        numberFormat22.setGroupingUsed(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 16.0d + "'", double17 == 16.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-16.0d) + "'", double19 == (-16.0d));
        org.junit.Assert.assertNotNull(numberFormat22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "11" + "'", str24.equals("11"));
        org.junit.Assert.assertNotNull(numberFormat25);
        org.junit.Assert.assertNotNull(currency26);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        piePlot3D0.setDarkerSides(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 100L);
        double double2 = xYBarRenderer1.getShadowXOffset();
        xYBarRenderer1.setBase((double) 13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(itemLabelPosition5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint3 = standardChartTheme2.getShadowPaint();
        categoryAxis3D0.setTickLabelPaint(paint3);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        java.lang.Object obj8 = dateAxis2.clone();
        dateAxis2.pan(Double.NaN);
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis2.setLabelPaint(paint11);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        java.awt.Paint paint8 = xYAreaRenderer3.getSeriesFillPaint(0);
        double double9 = xYAreaRenderer3.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        java.awt.Paint paint2 = dateAxis0.getLabelPaint();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis3.java2DToValue(0.0d, rectangle2D7, rectangleEdge8);
        boolean boolean10 = dateAxis3.isNegativeArrowVisible();
        dateAxis3.setNegativeArrowVisible(true);
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend13 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) dateAxis3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean2 = textTitle1.isVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        textTitle1.setBackgroundPaint(paint4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, number13);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = null;
        try {
            combinedRangeXYPlot0.setRangeAxes(valueAxisArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Stroke stroke9 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double12 = rectangleInsets10.calculateTopOutset((double) 10);
        double double14 = rectangleInsets10.calculateBottomOutset(0.0d);
        categoryPlot0.setAxisOffset(rectangleInsets10);
        double[] doubleArray19 = new double[] { (-57600000L) };
        double[] doubleArray21 = new double[] { (-57600000L) };
        double[] doubleArray23 = new double[] { (-57600000L) };
        double[] doubleArray25 = new double[] { (-57600000L) };
        double[] doubleArray27 = new double[] { (-57600000L) };
        double[][] doubleArray28 = new double[][] { doubleArray19, doubleArray21, doubleArray23, doubleArray25, doubleArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SeriesRenderingOrder.REVERSE", "Combined Range XYPlot", doubleArray28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset29, true);
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset29);
        categoryPlot0.setDataset(categoryDataset29);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-2.88E8d) + "'", number32.equals((-2.88E8d)));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer5 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYStepRenderer5.getLegendItems();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYStepRenderer5.setBaseItemLabelGenerator(xYItemLabelGenerator7);
        objectList0.set(100, (java.lang.Object) xYItemLabelGenerator7);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        segmentedTimeline0.addBaseTimelineException((long) 5);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint15 = combinedRangeXYPlot14.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke16 = combinedRangeXYPlot14.getDomainCrosshairStroke();
        java.util.List list17 = combinedRangeXYPlot14.getSubplots();
        segmentedTimeline0.setExceptionSegments(list17);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = combinedRangeXYPlot8.getDatasetGroup();
        boolean boolean11 = combinedRangeXYPlot8.isNotify();
        java.awt.Stroke stroke12 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        combinedRangeXYPlot8.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        try {
            java.awt.Color color1 = java.awt.Color.decode("{0}: ({1}, {2})");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"{0}: ({1}, {2})\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke5 = combinedRangeXYPlot3.getDomainCrosshairStroke();
        xYStepRenderer2.setBaseOutlineStroke(stroke5, true);
        xYStepRenderer2.setSeriesShapesFilled(100, false);
        org.jfree.chart.LegendItem legendItem13 = xYStepRenderer2.getLegendItem((int) ' ', 7);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYStepRenderer2.setSeriesOutlinePaint(64, (java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-9999));
        boolean boolean2 = xYSeries1.getAllowDuplicateXValues();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setAutoPopulateSectionOutlineStroke(false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        pieLabelDistributor1.distributeLabels(0.0d, 3.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        java.awt.Shape shape4 = numberAxis1.getLeftArrow();
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        java.lang.String str8 = numberAxis1.getLabel();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(axisSpace31);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        xYLineAndShapeRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint9 = numberAxis8.getTickMarkPaint();
        java.awt.Paint paint10 = numberAxis8.getAxisLinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        int int14 = combinedRangeXYPlot12.getDomainAxisCount();
        combinedRangeXYPlot12.clearSelection();
        combinedRangeXYPlot12.setRangeZeroBaselineVisible(false);
        java.lang.Object obj18 = combinedRangeXYPlot12.clone();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.lang.String[] strArray24 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis25 = new org.jfree.chart.axis.SymbolAxis("", strArray24);
        java.lang.String str27 = symbolAxis25.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis25);
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot29.setLegendItemShape(shape31);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator33 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot29.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator33);
        java.awt.Color color35 = java.awt.Color.pink;
        boolean boolean36 = ringPlot29.equals((java.lang.Object) color35);
        symbolAxis25.setGridBandAlternatePaint((java.awt.Paint) color35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis3D41.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D44, rectangleEdge45);
        double double47 = categoryAxis3D41.getLowerMargin();
        java.awt.Font font48 = categoryAxis3D41.getLabelFont();
        java.awt.Color color49 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer52 = null;
        org.jfree.chart.text.TextBlock textBlock53 = org.jfree.chart.text.TextUtilities.createTextBlock("", font48, (java.awt.Paint) color49, (float) 12, (-16646144), textMeasurer52);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis3D55.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D58, rectangleEdge59);
        double double61 = categoryAxis3D55.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions62 = categoryAxis3D55.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator65 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator66 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer67 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator65, xYURLGenerator66);
        java.awt.Font font69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock70 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font69);
        xYAreaRenderer67.setBaseItemLabelFont(font69);
        categoryAxis3D55.setTickLabelFont((java.lang.Comparable) 10.0d, font69);
        java.awt.Paint paint73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock53.addLine("hi!", font69, paint73);
        org.jfree.chart.plot.IntervalMarker intervalMarker75 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint73);
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        xYLineAndShapeRenderer0.drawDomainMarker(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot11, (org.jfree.chart.axis.ValueAxis) symbolAxis25, (org.jfree.chart.plot.Marker) intervalMarker75, rectangle2D76);
        java.awt.Color color80 = java.awt.Color.BLUE;
        java.awt.Color color81 = color80.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker82 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color81);
        java.awt.Shape shape87 = null;
        java.awt.Color color88 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem89 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape87, (java.awt.Paint) color88);
        int int90 = color88.getRGB();
        intervalMarker82.setOutlinePaint((java.awt.Paint) color88);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent92 = null;
        intervalMarker82.notifyListeners(markerChangeEvent92);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent94 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker82);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor95 = intervalMarker82.getLabelAnchor();
        intervalMarker75.setLabelAnchor(rectangleAnchor95);
        java.awt.Paint paint97 = intervalMarker75.getLabelPaint();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(textBlock53);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions62);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-16776961) + "'", int90 == (-16776961));
        org.junit.Assert.assertNotNull(rectangleAnchor95);
        org.junit.Assert.assertNotNull(paint97);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        boolean boolean3 = xYDataItem2.isSelected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font3 = textFragment2.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot4, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart9.getXYPlot();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart9.createBufferedImage(12, 5, chartRenderingInfo14);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(xYPlot10);
        org.junit.Assert.assertNotNull(bufferedImage16);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        java.lang.String str1 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.START" + "'", str1.equals("TimePeriodAnchor.START"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Color color5 = color4.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color5);
        boolean boolean7 = year0.equals((java.lang.Object) Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.zoomRange(0.025d, Double.POSITIVE_INFINITY);
        dateAxis2.configure();
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedRangeXYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedRangeXYPlot7.zoomRangeAxes((double) 1, plotRenderingInfo12, point2D13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        combinedRangeXYPlot0.remove((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeriesCollection2.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.Class<?> wildcardClass7 = timeSeriesCollection2.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", (java.lang.Class) wildcardClass7);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2019", (java.lang.Class) wildcardClass7);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(timeSeries5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue(4.0d, rectangle2D5, rectangleEdge6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer10 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator8, xYURLGenerator9);
        xYStepRenderer10.setDrawSeriesLineAsPath(true);
        java.lang.Object obj13 = xYStepRenderer10.clone();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer10.setLegendLine(shape15);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint20 = combinedRangeXYPlot19.getDomainZeroBaselinePaint();
        textTitle18.setBackgroundPaint(paint20);
        org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape15, (org.jfree.chart.title.Title) textTitle18, "PlotOrientation.HORIZONTAL");
        numberAxis1.setLeftArrow(shape15);
        java.util.TimeZone timeZone26 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone26);
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double31 = dateRange30.getCentralValue();
        dateAxis27.setRange((org.jfree.data.Range) dateRange30);
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double36 = dateRange35.getCentralValue();
        org.jfree.data.Range range37 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange30, (org.jfree.data.Range) dateRange35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange35, (double) 2);
        double double40 = dateRange35.getUpperBound();
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange35);
        numberAxis1.pan(19.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.5d + "'", double31 == 0.5d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.5d + "'", double36 == 0.5d);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace7, false);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        int int14 = combinedRangeXYPlot12.getDomainAxisCount();
        boolean boolean15 = combinedRangeXYPlot12.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        combinedRangeXYPlot12.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.entity.EntityCollection entityCollection20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        combinedRangeXYPlot12.handleClick(64, (int) (byte) 10, plotRenderingInfo22);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint25 = combinedRangeXYPlot24.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        combinedRangeXYPlot24.setDrawingSupplier(drawingSupplier26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        combinedRangeXYPlot24.zoomRangeAxes((double) 1, plotRenderingInfo29, point2D30);
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot24, jFreeChart32, chartChangeEventType33);
        java.awt.geom.Point2D point2D35 = combinedRangeXYPlot24.getQuadrantOrigin();
        categoryPlot6.zoomDomainAxes(10.0d, plotRenderingInfo22, point2D35);
        java.awt.geom.Point2D point2D37 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot38 = combinedRangeXYPlot0.findSubplot(plotRenderingInfo22, point2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(point2D35);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        combinedRangeXYPlot0.handleClick(64, (int) (byte) 10, plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        boolean boolean14 = xYItemRendererState13.getProcessVisibleItemsOnly();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset9 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem14 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number15 = null;
        xYDataItem14.setY(number15);
        double double17 = xYDataItem14.getXValue();
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity(shape7, (org.jfree.data.general.PieDataset) defaultPieDataset9, 4, 8, (java.lang.Comparable) double17, "[12.0, NaN]", "DateTickMarkPosition.MIDDLE");
        org.jfree.data.general.PieDataset pieDataset21 = pieSectionEntity20.getDataset();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 12.0d + "'", double17 == 12.0d);
        org.junit.Assert.assertNotNull(pieDataset21);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.util.TimeZone timeZone2 = periodAxis1.getTimeZone();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        periodAxis1.setRange((org.jfree.data.Range) dateRange5, true, false);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange5, 0.0d, false);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double[] doubleArray3 = new double[] { (-57600000L) };
        double[] doubleArray5 = new double[] { (-57600000L) };
        double[] doubleArray7 = new double[] { (-57600000L) };
        double[] doubleArray9 = new double[] { (-57600000L) };
        double[] doubleArray11 = new double[] { (-57600000L) };
        double[][] doubleArray12 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SeriesRenderingOrder.REVERSE", "Combined Range XYPlot", doubleArray12);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset13);
        try {
            org.jfree.data.general.PieDataset pieDataset16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset13, (java.lang.Comparable) "blue");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainPannable();
        categoryPlot0.setRangeZeroBaselineVisible(false);
        categoryPlot0.setWeight(5);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = null;
        xYStepRenderer2.setBaseItemLabelGenerator(xYItemLabelGenerator4);
        xYStepRenderer2.setSeriesShapesVisible(1900, (java.lang.Boolean) true);
        double double9 = xYStepRenderer2.getStepPoint();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        java.awt.Shape shape2 = logAxis1.getRightArrow();
        logAxis1.setFixedDimension((double) 9);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        java.awt.Stroke stroke7 = null;
        try {
            categoryPlot0.setRangeGridlineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType2, 100);
        int int5 = dateTickUnit4.getCalendarField();
        double double6 = dateTickUnit4.getSize();
        int int7 = dateTickUnit4.getRollMultiple();
        java.lang.String str9 = dateTickUnit4.valueToString((double) 0.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, 0.2d);
        java.util.TimeZone timeZone15 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone15);
        dateAxis16.setInverted(false);
        dateAxis16.setLowerBound((double) 0);
        double double21 = dateAxis16.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date23 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit22);
        boolean boolean24 = timeSeriesDataItem13.equals((java.lang.Object) date23);
        java.lang.String str25 = dateTickUnit4.dateToString(date23);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone28 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone28);
        dateAxis29.setInverted(false);
        dateAxis29.setLowerBound((double) 0);
        double double34 = dateAxis29.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date36 = dateAxis29.calculateHighestVisibleTickValue(dateTickUnit35);
        long long37 = segmentedTimeline26.getTime(date36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36);
        org.jfree.data.time.DateRange dateRange39 = new org.jfree.data.time.DateRange(date23, date36);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint43 = combinedRangeXYPlot42.getDomainZeroBaselinePaint();
        textTitle41.setBackgroundPaint(paint43);
        textTitle41.setExpandToFitSpace(true);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle41.setVerticalAlignment(verticalAlignment47);
        java.awt.geom.Rectangle2D rectangle2D49 = textTitle41.getBounds();
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint53 = numberAxis52.getTickMarkPaint();
        numberAxis52.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint57 = combinedRangeXYPlot56.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier58 = null;
        combinedRangeXYPlot56.setDrawingSupplier(drawingSupplier58);
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        combinedRangeXYPlot56.setFixedDomainAxisSpace(axisSpace60);
        boolean boolean62 = numberAxis52.hasListener((java.util.EventListener) combinedRangeXYPlot56);
        org.jfree.chart.plot.PlotOrientation plotOrientation63 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str64 = plotOrientation63.toString();
        combinedRangeXYPlot56.setOrientation(plotOrientation63);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation50, plotOrientation63);
        double double67 = dateAxis0.dateToJava2D(date36, rectangle2D49, rectangleEdge66);
        org.jfree.chart.axis.AxisLocation axisLocation68 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.awt.Font font70 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock71 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font70);
        labelBlock71.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation74 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean75 = labelBlock71.equals((java.lang.Object) plotOrientation74);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation68, plotOrientation74);
        double double77 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D49, rectangleEdge76);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.6E8d + "'", double6 == 3.6E8d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "12/31/69" + "'", str9.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "12/31/69" + "'", str25.equals("12/31/69"));
        org.junit.Assert.assertNotNull(segmentedTimeline26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-57600000L) + "'", long37 == (-57600000L));
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(plotOrientation63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str64.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertNotNull(plotOrientation74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(tableOrder1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        float float5 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number4 = null;
        xYDataItem3.setY(number4);
        double double6 = xYDataItem3.getXValue();
        java.lang.String str7 = xYDataItem3.toString();
        boolean boolean8 = xYDataItem3.isSelected();
        defaultPieDataset0.setValue((java.lang.Comparable) xYDataItem3, (double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isDomainPannable();
        categoryPlot11.setRangeZeroBaselineVisible(false);
        boolean boolean15 = defaultPieDataset0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        ringPlot16.setShadowYOffset((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.0d + "'", double6 == 12.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[12.0, NaN]" + "'", str7.equals("[12.0, NaN]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font10 = textFragment9.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot11.setDrawingSupplier(drawingSupplier13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, false);
        boolean boolean17 = dateAxis2.hasListener((java.util.EventListener) combinedRangeXYPlot11);
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double21 = dateRange20.getCentralValue();
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        org.jfree.data.Range range25 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange20, (org.jfree.data.Range) dateRange24);
        java.util.TimeZone timeZone27 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone27);
        dateAxis28.setInverted(false);
        dateAxis28.setLowerBound((double) 0);
        double double33 = dateAxis28.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date35 = dateAxis28.calculateHighestVisibleTickValue(dateTickUnit34);
        java.util.TimeZone timeZone37 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone37);
        org.jfree.data.time.DateRange dateRange41 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double42 = dateRange41.getCentralValue();
        dateAxis38.setRange((org.jfree.data.Range) dateRange41);
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double47 = dateRange46.getCentralValue();
        org.jfree.data.Range range48 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange41, (org.jfree.data.Range) dateRange46);
        dateAxis28.setRangeWithMargins((org.jfree.data.Range) dateRange41);
        org.jfree.data.Range range51 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange41, (double) '#');
        org.jfree.data.Range range52 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange20, (org.jfree.data.Range) dateRange41);
        dateAxis2.setRange((org.jfree.data.Range) dateRange20, false, true);
        dateAxis2.resizeRange((double) (byte) 10, 0.0d);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5d + "'", double21 == 0.5d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.5d + "'", double42 == 0.5d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.5d + "'", double47 == 0.5d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(range52);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator7, xYURLGenerator8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYStepAreaRenderer9.setBaseOutlinePaint((java.awt.Paint) color10, false);
        standardChartTheme1.setSubtitlePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 100L);
        double double2 = xYBarRenderer1.getShadowXOffset();
        double double3 = xYBarRenderer1.getMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone14 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone14);
        dateAxis15.setInverted(false);
        dateAxis15.setLowerBound((double) 0);
        double double20 = dateAxis15.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date22 = dateAxis15.calculateHighestVisibleTickValue(dateTickUnit21);
        long long23 = segmentedTimeline12.getTime(date22);
        long long24 = segmentedTimeline0.toTimelineValue(date22);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-57600000L) + "'", long23 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 644263200000L + "'", long24 == 644263200000L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) 'a', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo4.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo6);
        projectInfo4.addOptionalLibrary("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo10.getOptionalLibraries();
        projectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo10);
        projectInfo10.setCopyright("");
        boolean boolean15 = standardXYToolTipGenerator1.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace6, false);
        java.awt.Paint paint9 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean11 = categoryPlot5.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint14 = numberAxis13.getTickMarkPaint();
        numberAxis13.configure();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis13.java2DToValue(4.0d, rectangle2D17, rectangleEdge18);
        java.awt.Color color22 = java.awt.Color.BLUE;
        java.awt.Color color23 = color22.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color23);
        java.awt.Shape shape29 = null;
        java.awt.Color color30 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape29, (java.awt.Paint) color30);
        int int32 = color30.getRGB();
        intervalMarker24.setOutlinePaint((java.awt.Paint) color30);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        intervalMarker24.notifyListeners(markerChangeEvent34);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker24);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color38);
        legendItem39.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset42 = null;
        legendItem39.setDataset(dataset42);
        java.lang.String str44 = legendItem39.getLabel();
        java.awt.Shape shape45 = legendItem39.getShape();
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint49 = combinedRangeXYPlot48.getDomainZeroBaselinePaint();
        textTitle47.setBackgroundPaint(paint49);
        textTitle47.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity54 = new org.jfree.chart.entity.TitleEntity(shape45, (org.jfree.chart.title.Title) textTitle47, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle47.getBounds();
        barRenderer3D2.drawRangeMarker(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.plot.Marker) intervalMarker24, rectangle2D55);
        barRenderer3D2.setDefaultEntityRadius(0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-16776961) + "'", int32 == (-16776961));
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str44.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis3D5.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D8, rectangleEdge9);
        double double11 = categoryAxis3D5.getLowerMargin();
        java.awt.Font font12 = categoryAxis3D5.getLabelFont();
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer16 = null;
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, (java.awt.Paint) color13, (float) 12, (-16646144), textMeasurer16);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator19 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer20 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator18, xYURLGenerator19);
        xYStepRenderer20.setDrawSeriesLineAsPath(true);
        java.lang.Object obj23 = xYStepRenderer20.clone();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer20.setLegendLine(shape25);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint30 = combinedRangeXYPlot29.getDomainZeroBaselinePaint();
        textTitle28.setBackgroundPaint(paint30);
        org.jfree.chart.entity.TitleEntity titleEntity33 = new org.jfree.chart.entity.TitleEntity(shape25, (org.jfree.chart.title.Title) textTitle28, "PlotOrientation.HORIZONTAL");
        boolean boolean34 = color13.equals((java.lang.Object) textTitle28);
        barRenderer3D2.setBaseItemLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = null;
        barRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator36, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = null;
        barRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition39);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        boolean boolean4 = barRenderer3D2.isDrawBarOutline();
        barRenderer3D2.setBase((double) (short) 1);
        barRenderer3D2.setMaximumBarWidth((double) (-16776961));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        boolean boolean6 = xYStepRenderer2.isSeriesVisible((int) '4');
        boolean boolean7 = xYStepRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.util.PaintMap paintMap9 = new org.jfree.chart.util.PaintMap();
        java.lang.String[] strArray15 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis16 = new org.jfree.chart.axis.SymbolAxis("", strArray15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint18 = combinedRangeXYPlot17.getDomainZeroBaselinePaint();
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color20);
        combinedRangeXYPlot17.setRangeTickBandPaint((java.awt.Paint) color20);
        symbolAxis16.setTickMarkPaint((java.awt.Paint) color20);
        paintMap9.put((java.lang.Comparable) '#', (java.awt.Paint) color20);
        xYStepRenderer2.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color20);
        xYStepRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        java.awt.Paint paint4 = ringPlot0.getBaseSectionOutlinePaint();
        boolean boolean5 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2);
        ringPlot0.setLegendItemShape(shape7);
        float float9 = ringPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.configure();
        java.awt.Shape shape10 = numberAxis7.getLeftArrow();
        java.awt.Shape shape11 = numberAxis7.getUpArrow();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.lang.String str13 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(0, axisLocation15);
        double[] doubleArray20 = new double[] { (-57600000L) };
        double[] doubleArray22 = new double[] { (-57600000L) };
        double[] doubleArray24 = new double[] { (-57600000L) };
        double[] doubleArray26 = new double[] { (-57600000L) };
        double[] doubleArray28 = new double[] { (-57600000L) };
        double[][] doubleArray29 = new double[][] { doubleArray20, doubleArray22, doubleArray24, doubleArray26, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SeriesRenderingOrder.REVERSE", "Combined Range XYPlot", doubleArray29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset30, true);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset30);
        categoryPlot0.setDataset(categoryDataset30);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-2.88E8d) + "'", number33.equals((-2.88E8d)));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        ringPlot27.setShadowYOffset(4.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot27.getLabelGenerator();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor52 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        ringPlot27.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor52);
        ringPlot27.setStartAngle((double) (-1L));
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator57 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator58 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer59 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator57, xYURLGenerator58);
        java.lang.Boolean boolean61 = xYAreaRenderer59.getSeriesVisible(2);
        java.awt.Paint paint62 = xYAreaRenderer59.getBaseItemLabelPaint();
        xYAreaRenderer59.setUseFillPaint(false);
        java.awt.Stroke stroke65 = xYAreaRenderer59.getBaseOutlineStroke();
        ringPlot27.setLabelOutlineStroke(stroke65);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
        org.junit.Assert.assertNull(boolean61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        pieLabelDistributor1.distributeLabels((double) (short) 1, Double.NaN);
        java.lang.String str5 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke2 = xYAreaRenderer0.lookupSeriesOutlineStroke((int) 'a');
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = barRenderer3D6.getDrawingSupplier();
        java.awt.Font font8 = barRenderer3D6.getBaseItemLabelFont();
        xYAreaRenderer0.setSeriesItemLabelFont((int) (short) 0, font8, true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.awt.geom.Point2D point2D11 = combinedRangeXYPlot0.getQuadrantOrigin();
        combinedRangeXYPlot0.setDomainCrosshairVisible(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment14, verticalAlignment15, (double) 0.0f, 0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment19, verticalAlignment20, (double) 1546329600000L, (double) (byte) 1);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0, (org.jfree.chart.block.Arrangement) columnArrangement18, (org.jfree.chart.block.Arrangement) columnArrangement23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment20);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = combinedRangeXYPlot8.getDatasetGroup();
        boolean boolean11 = combinedRangeXYPlot8.isNotify();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot12.setFixedDomainAxisSpace(axisSpace13, false);
        java.awt.Paint paint16 = categoryPlot12.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot12.getDomainGridlinePosition();
        boolean boolean18 = categoryPlot12.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot12.setFixedRangeAxisSpace(axisSpace19, false);
        combinedRangeXYPlot8.setFixedRangeAxisSpace(axisSpace19, false);
        axisSpace19.setBottom(19.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisSpace19.ensureAtLeast(0.5d, rectangleEdge27);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Font font5 = xYLineAndShapeRenderer0.getLegendTextFont(8);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = xYLineAndShapeRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(drawingSupplier6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis3D8.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D11, rectangleEdge12);
        double double14 = categoryAxis3D8.getLowerMargin();
        java.awt.Font font15 = categoryAxis3D8.getLabelFont();
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color16, (float) 12, (-16646144), textMeasurer19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 1.0d, (double) 60000L, (double) (short) 100, (double) (byte) 1, font15);
        java.awt.Color color22 = java.awt.Color.BLUE;
        boolean boolean23 = markerAxisBand21.equals((java.lang.Object) color22);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot24.setLegendItemShape(shape26);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot24.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator28);
        java.awt.Color color30 = java.awt.Color.pink;
        boolean boolean31 = ringPlot24.equals((java.lang.Object) color30);
        ringPlot24.setLabelGap(0.0d);
        ringPlot24.setOuterSeparatorExtension((double) '4');
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color37);
        legendItem38.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset41 = null;
        legendItem38.setDataset(dataset41);
        java.lang.String str43 = legendItem38.getLabel();
        java.awt.Shape shape44 = legendItem38.getLine();
        java.awt.Font font45 = null;
        legendItem38.setLabelFont(font45);
        java.awt.Paint paint47 = legendItem38.getLinePaint();
        ringPlot24.setLabelBackgroundPaint(paint47);
        java.awt.Paint paint49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot24.setLabelPaint(paint49);
        boolean boolean51 = markerAxisBand21.equals((java.lang.Object) ringPlot24);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str43.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        combinedRangeXYPlot0.handleClick(64, (int) (byte) 10, plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState13 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo10.getPlotArea();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(rectangle2D14);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot0.getDataset();
        java.awt.Paint paint32 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean37 = categoryPlot0.removeDomainMarker((int) (short) 1, marker34, layer35, true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        xYStepRenderer2.setAutoPopulateSeriesShape(true);
        java.awt.Paint paint11 = null;
        try {
            xYStepRenderer2.setBaseFillPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        double double6 = intervalXYDelegate5.getIntervalPositionFactor();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.previous();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month12.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        categoryAxis3D1.setTickLabelFont(font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator6, xYURLGenerator7);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font10);
        xYAreaRenderer8.setBaseItemLabelFont(font10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYAreaRenderer8);
        boolean boolean14 = textLine4.equals((java.lang.Object) xYAreaRenderer8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font18 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        categoryAxis3D17.setTickLabelFont(font18);
        xYAreaRenderer8.setSeriesItemLabelFont(255, font18);
        categoryAxis3D1.setLabelFont(font18);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        java.util.List list4 = axisState3.getTicks();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 2);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double11 = dateRange10.getCentralValue();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        org.jfree.data.Range range15 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange10, (org.jfree.data.Range) dateRange14);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone17);
        dateAxis18.setInverted(false);
        dateAxis18.setLowerBound((double) 0);
        double double23 = dateAxis18.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date25 = dateAxis18.calculateHighestVisibleTickValue(dateTickUnit24);
        java.util.TimeZone timeZone27 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone27);
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double32 = dateRange31.getCentralValue();
        dateAxis28.setRange((org.jfree.data.Range) dateRange31);
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double37 = dateRange36.getCentralValue();
        org.jfree.data.Range range38 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange31, (org.jfree.data.Range) dateRange36);
        dateAxis18.setRangeWithMargins((org.jfree.data.Range) dateRange31);
        org.jfree.data.Range range41 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange31, (double) '#');
        org.jfree.data.Range range42 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange10, (org.jfree.data.Range) dateRange31);
        int int43 = year5.compareTo((java.lang.Object) range42);
        org.jfree.data.Range range45 = timeSeriesCollection0.getRangeBounds(list4, range42, false);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.5d + "'", double32 == 0.5d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.5d + "'", double37 == 0.5d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertEquals((double) number46, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape4, (java.awt.Paint) color5);
        int int7 = color5.getRGB();
        int int8 = color5.getBlue();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16776961) + "'", int7 == (-16776961));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.configure();
        java.awt.Shape shape10 = numberAxis7.getLeftArrow();
        java.awt.Shape shape11 = numberAxis7.getUpArrow();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.lang.String[] strArray17 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis18 = new org.jfree.chart.axis.SymbolAxis("", strArray17);
        java.lang.String str20 = symbolAxis18.valueToString(Double.POSITIVE_INFINITY);
        double double21 = symbolAxis18.getUpperMargin();
        int int22 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) symbolAxis18);
        double double23 = symbolAxis18.getLowerBound();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color9);
        java.awt.Paint paint11 = legendItem10.getLinePaint();
        java.awt.Shape shape12 = legendItem10.getLine();
        legendItem2.setLine(shape12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot15.setFixedDomainAxisSpace(axisSpace16, false);
        java.awt.Paint paint19 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot15.getDomainGridlinePosition();
        boolean boolean21 = categoryPlot15.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke24 = combinedRangeXYPlot22.getDomainCrosshairStroke();
        java.util.List list25 = combinedRangeXYPlot22.getSubplots();
        java.util.List list26 = combinedRangeXYPlot22.getSubplots();
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot22);
        boolean boolean28 = legendItemEntity14.equals((java.lang.Object) combinedRangeXYPlot22);
        java.awt.Stroke stroke29 = combinedRangeXYPlot22.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        java.util.List list3 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.Marker marker4 = null;
        boolean boolean5 = combinedRangeXYPlot0.removeDomainMarker(marker4);
        combinedRangeXYPlot0.clearDomainMarkers();
        boolean boolean7 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator6, xYURLGenerator7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYStepRenderer8.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection9);
        int int11 = legendItemCollection9.getItemCount();
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        int int3 = plotRenderingInfo2.getSubplotCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font3);
        labelBlock4.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean8 = labelBlock4.equals((java.lang.Object) plotOrientation7);
        combinedRangeXYPlot0.setOrientation(plotOrientation7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        int int13 = combinedRangeXYPlot11.getDomainAxisCount();
        boolean boolean14 = combinedRangeXYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace15);
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        combinedRangeXYPlot11.handleClick(64, (int) (byte) 10, plotRenderingInfo21);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo21);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint25 = combinedRangeXYPlot24.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        combinedRangeXYPlot24.setDrawingSupplier(drawingSupplier26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        combinedRangeXYPlot24.zoomRangeAxes((double) 1, plotRenderingInfo29, point2D30);
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot24, jFreeChart32, chartChangeEventType33);
        java.awt.geom.Point2D point2D35 = combinedRangeXYPlot24.getQuadrantOrigin();
        combinedRangeXYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo21, point2D35, true);
        boolean boolean38 = combinedRangeXYPlot0.isRangeCrosshairLockedOnData();
        boolean boolean39 = combinedRangeXYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace6, false);
        java.awt.Paint paint9 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean11 = categoryPlot5.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint14 = numberAxis13.getTickMarkPaint();
        numberAxis13.configure();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis13.java2DToValue(4.0d, rectangle2D17, rectangleEdge18);
        java.awt.Color color22 = java.awt.Color.BLUE;
        java.awt.Color color23 = color22.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color23);
        java.awt.Shape shape29 = null;
        java.awt.Color color30 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape29, (java.awt.Paint) color30);
        int int32 = color30.getRGB();
        intervalMarker24.setOutlinePaint((java.awt.Paint) color30);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        intervalMarker24.notifyListeners(markerChangeEvent34);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker24);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color38);
        legendItem39.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset42 = null;
        legendItem39.setDataset(dataset42);
        java.lang.String str44 = legendItem39.getLabel();
        java.awt.Shape shape45 = legendItem39.getShape();
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint49 = combinedRangeXYPlot48.getDomainZeroBaselinePaint();
        textTitle47.setBackgroundPaint(paint49);
        textTitle47.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity54 = new org.jfree.chart.entity.TitleEntity(shape45, (org.jfree.chart.title.Title) textTitle47, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle47.getBounds();
        barRenderer3D2.drawRangeMarker(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.plot.Marker) intervalMarker24, rectangle2D55);
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        intervalMarker24.setOutlinePaint((java.awt.Paint) color57);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-16776961) + "'", int32 == (-16776961));
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str44.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        int int3 = dateAxis2.getMinorTickCount();
        dateAxis2.setAutoRangeMinimumSize((double) 5);
        dateAxis2.pan(12.0d);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        ringPlot27.setShadowYOffset(4.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot27.getLabelGenerator();
        ringPlot27.setLabelLinksVisible(false);
        ringPlot27.setIgnoreNullValues(true);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle55 = ringPlot27.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle55);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart7.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo11.getPlotInfo();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean15 = categoryPlot14.isDomainPannable();
        categoryPlot14.setRangeZeroBaselineVisible(false);
        categoryPlot14.setWeight(5);
        java.awt.Color color23 = java.awt.Color.BLUE;
        java.awt.Color color24 = color23.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color24);
        java.awt.Shape shape30 = null;
        java.awt.Color color31 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape30, (java.awt.Paint) color31);
        int int33 = color31.getRGB();
        intervalMarker25.setOutlinePaint((java.awt.Paint) color31);
        org.jfree.chart.util.Layer layer35 = null;
        categoryPlot14.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker25, layer35, false);
        boolean boolean38 = plotRenderingInfo13.equals((java.lang.Object) categoryPlot14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(bufferedImage12);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-16776961) + "'", int33 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number6 = null;
        xYDataItem5.setY(number6);
        double double8 = xYDataItem5.getXValue();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        combinedRangeXYPlot9.setDrawingSupplier(drawingSupplier11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        combinedRangeXYPlot9.zoomRangeAxes((double) 1, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = combinedRangeXYPlot9.getDomainAxis(1);
        boolean boolean21 = xYDataItem5.equals((java.lang.Object) 1);
        xYSeries2.add(xYDataItem5, false);
        double double24 = xYSeries2.getMinY();
        xYSeries2.update((java.lang.Number) 12, (java.lang.Number) 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 12.0d + "'", double8 == 12.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getEndOfCurrentMonth(serialDate3);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double3 = dateRange2.getCentralValue();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        org.jfree.data.Range range7 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange6);
        java.util.TimeZone timeZone9 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone9);
        dateAxis10.setInverted(false);
        dateAxis10.setLowerBound((double) 0);
        double double15 = dateAxis10.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date17 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit16);
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone19);
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double24 = dateRange23.getCentralValue();
        dateAxis20.setRange((org.jfree.data.Range) dateRange23);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double29 = dateRange28.getCentralValue();
        org.jfree.data.Range range30 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange23, (org.jfree.data.Range) dateRange28);
        dateAxis10.setRangeWithMargins((org.jfree.data.Range) dateRange23);
        org.jfree.data.Range range33 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange23, (double) '#');
        org.jfree.data.Range range34 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange23);
        boolean boolean37 = range34.intersects((double) 12, 0.0d);
        double double38 = range34.getUpperBound();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.5d + "'", double24 == 0.5d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.5d + "'", double29 == 0.5d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        segmentedTimeline0.addBaseTimelineException((long) 5);
        boolean boolean16 = segmentedTimeline0.containsDomainRange(0L, (long) (byte) 100);
        segmentedTimeline0.addBaseTimelineException((long) 12);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot0.getDataset();
        java.awt.Paint paint32 = categoryPlot0.getRangeMinorGridlinePaint();
        java.awt.Stroke stroke33 = categoryPlot0.getDomainGridlineStroke();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        int int9 = combinedRangeXYPlot7.getDomainAxisCount();
        boolean boolean10 = combinedRangeXYPlot7.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        combinedRangeXYPlot7.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        combinedRangeXYPlot7.handleClick(64, (int) (byte) 10, plotRenderingInfo17);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint21 = combinedRangeXYPlot20.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        combinedRangeXYPlot20.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        combinedRangeXYPlot20.zoomRangeAxes((double) 1, plotRenderingInfo25, point2D26);
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot20, jFreeChart28, chartChangeEventType29);
        java.awt.geom.Point2D point2D31 = combinedRangeXYPlot20.getQuadrantOrigin();
        categoryPlot0.panRangeAxes((double) 8, plotRenderingInfo17, point2D31);
        double[] doubleArray37 = new double[] { (-57600000L) };
        double[] doubleArray39 = new double[] { (-57600000L) };
        double[] doubleArray41 = new double[] { (-57600000L) };
        double[] doubleArray43 = new double[] { (-57600000L) };
        double[] doubleArray45 = new double[] { (-57600000L) };
        double[][] doubleArray46 = new double[][] { doubleArray37, doubleArray39, doubleArray41, doubleArray43, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SeriesRenderingOrder.REVERSE", "Combined Range XYPlot", doubleArray46);
        categoryPlot0.setDataset(0, categoryDataset47);
        java.lang.Number number49 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset47);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 0.0d + "'", number49.equals(0.0d));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX(3.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font10);
        labelBlock11.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean15 = labelBlock11.equals((java.lang.Object) plotOrientation14);
        combinedRangeXYPlot7.setOrientation(plotOrientation14);
        crosshairState0.updateCrosshairPoint(0.0d, (double) 8, (-1.0d), 0.025d, plotOrientation14);
        int int18 = crosshairState0.getDatasetIndex();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number4 = null;
        xYDataItem3.setY(number4);
        double double6 = xYDataItem3.getXValue();
        java.lang.String str7 = xYDataItem3.toString();
        boolean boolean8 = xYDataItem3.isSelected();
        defaultPieDataset0.setValue((java.lang.Comparable) xYDataItem3, (double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isDomainPannable();
        categoryPlot11.setRangeZeroBaselineVisible(false);
        boolean boolean15 = defaultPieDataset0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        ringPlot16.setExplodePercent((java.lang.Comparable) "", (double) 'a');
        ringPlot16.setSimpleLabels(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.0d + "'", double6 == 12.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[12.0, NaN]" + "'", str7.equals("[12.0, NaN]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 100L);
        double double2 = xYBarRenderer1.getShadowXOffset();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj4 = timeSeriesCollection3.clone();
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        timeSeriesCollection3.removeAllSeries();
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer1.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(itemLabelPosition9);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis3D0.getLowerMargin();
        java.awt.Font font7 = categoryAxis3D0.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D0.getCategorySeriesMiddle(100, (int) (byte) 10, 100, (-460), (double) '#', rectangle2D13, rectangleEdge14);
        int int16 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str13 = plotOrientation12.toString();
        combinedRangeXYPlot5.setOrientation(plotOrientation12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        java.lang.Object obj16 = plotChangeEvent15.getSource();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRendererCount();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 100);
        int int3 = dateTickUnit2.getCalendarField();
        double double4 = dateTickUnit2.getSize();
        int int5 = dateTickUnit2.getRollMultiple();
        int int6 = dateTickUnit2.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.6E8d + "'", double4 == 3.6E8d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot0.getDataset();
        java.awt.Paint paint32 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot0.getRangeAxis(15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(valueAxis34);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator1, true);
        java.awt.Font font5 = xYAreaRenderer0.getLegendTextFont((int) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo16);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo16);
        boolean boolean20 = xYAreaRenderer0.equals((java.lang.Object) plotRenderingInfo16);
        java.lang.Object obj21 = plotRenderingInfo16.clone();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        java.lang.Object obj8 = dateAxis2.clone();
        boolean boolean9 = dateAxis2.isAutoRange();
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone11);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double16 = dateRange15.getCentralValue();
        dateAxis12.setRange((org.jfree.data.Range) dateRange15);
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double21 = dateRange20.getCentralValue();
        org.jfree.data.Range range22 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange20);
        double double23 = range22.getLowerBound();
        dateAxis2.setRange(range22);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5d + "'", double21 == 0.5d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.configure();
        java.awt.Shape shape10 = numberAxis7.getLeftArrow();
        java.awt.Shape shape11 = numberAxis7.getUpArrow();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.lang.String str13 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(0, axisLocation15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot0.setDomainAxis(1, categoryAxis18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator1, true);
        java.awt.Shape shape7 = xYAreaRenderer0.getItemShape((int) (short) -1, (int) (byte) 100, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator9, xYURLGenerator10);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font13);
        xYAreaRenderer11.setBaseItemLabelFont(font13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint18 = combinedRangeXYPlot17.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke19 = combinedRangeXYPlot17.getDomainCrosshairStroke();
        xYAreaRenderer11.setSeriesStroke((int) (byte) 1, stroke19, true);
        xYAreaRenderer11.setUseFillPaint(true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator26 = new org.jfree.chart.urls.StandardXYURLGenerator("");
        xYAreaRenderer11.setSeriesURLGenerator(12, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator26, true);
        xYAreaRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator26, false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        boolean boolean6 = categoryPlot0.isRangeMinorGridlinesVisible();
        boolean boolean7 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str9 = axisLocation8.toString();
        org.jfree.chart.axis.AxisLocation axisLocation10 = axisLocation8.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation8);
        boolean boolean12 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Color color15 = java.awt.Color.BLUE;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color16);
        java.awt.Shape shape22 = null;
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape22, (java.awt.Paint) color23);
        int int25 = color23.getRGB();
        intervalMarker17.setOutlinePaint((java.awt.Paint) color23);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = null;
        intervalMarker17.notifyListeners(markerChangeEvent27);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = intervalMarker17.getLabelAnchor();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        categoryPlot0.setRangePannable(false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str9.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-16776961) + "'", int25 == (-16776961));
        org.junit.Assert.assertNotNull(rectangleAnchor30);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        int int6 = combinedRangeXYPlot4.getDomainAxisCount();
        combinedRangeXYPlot4.clearSelection();
        combinedRangeXYPlot4.setRangeZeroBaselineVisible(false);
        java.lang.Object obj10 = combinedRangeXYPlot4.clone();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        java.lang.String[] strArray16 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis17 = new org.jfree.chart.axis.SymbolAxis("", strArray16);
        java.lang.String str19 = symbolAxis17.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis17);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot21.setLegendItemShape(shape23);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator25 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot21.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        java.awt.Color color27 = java.awt.Color.pink;
        boolean boolean28 = ringPlot21.equals((java.lang.Object) color27);
        symbolAxis17.setGridBandAlternatePaint((java.awt.Paint) color27);
        java.awt.Paint paint30 = symbolAxis17.getGridBandPaint();
        java.awt.Shape shape31 = symbolAxis17.getLeftArrow();
        java.awt.Paint paint32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.StandardChartTheme standardChartTheme35 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint36 = standardChartTheme35.getShadowPaint();
        java.awt.Paint paint37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme35.setRangeGridlinePaint(paint37);
        java.awt.Paint paint39 = standardChartTheme35.getWallPaint();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", "12/31/69", "12/31/69", "PlotOrientation.HORIZONTAL", shape31, paint32, stroke33, paint39);
        java.awt.Shape shape41 = null;
        try {
            legendItem40.setLine(shape41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        ringPlot0.clearSectionOutlineStrokes(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getGridBandPaint();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot11.setDrawingSupplier(drawingSupplier13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace15);
        boolean boolean17 = numberAxis7.hasListener((java.util.EventListener) combinedRangeXYPlot11);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str19 = plotOrientation18.toString();
        combinedRangeXYPlot11.setOrientation(plotOrientation18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        java.awt.Paint paint22 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        standardChartTheme1.setGridBandAlternatePaint(paint22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis3D25.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D28, rectangleEdge29);
        double double31 = categoryAxis3D25.getLowerMargin();
        java.awt.Font font32 = categoryAxis3D25.getLabelFont();
        java.awt.Color color33 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer36 = null;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, (java.awt.Paint) color33, (float) 12, (-16646144), textMeasurer36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis3D39.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D42, rectangleEdge43);
        double double45 = categoryAxis3D39.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions46 = categoryAxis3D39.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator49 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer51 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator49, xYURLGenerator50);
        java.awt.Font font53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock54 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font53);
        xYAreaRenderer51.setBaseItemLabelFont(font53);
        categoryAxis3D39.setTickLabelFont((java.lang.Comparable) 10.0d, font53);
        java.awt.Paint paint57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock37.addLine("hi!", font53, paint57);
        standardChartTheme1.setWallPaint(paint57);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer61 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 100L);
        double double62 = xYBarRenderer61.getShadowXOffset();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection63 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj64 = timeSeriesCollection63.clone();
        boolean boolean65 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection63);
        timeSeriesCollection63.removeAllSeries();
        java.lang.Number number67 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection63);
        org.jfree.data.Range range68 = xYBarRenderer61.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection63);
        java.awt.Shape shape74 = null;
        java.awt.Color color75 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem76 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape74, (java.awt.Paint) color75);
        int int77 = color75.getRGB();
        xYBarRenderer61.setSeriesOutlinePaint(2, (java.awt.Paint) color75, true);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color75);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str19.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions46);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 4.0d + "'", double62 == 4.0d);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNull(number67);
        org.junit.Assert.assertNull(range68);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-16776961) + "'", int77 == (-16776961));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier8, true);
        boolean boolean11 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint16 = numberAxis15.getTickMarkPaint();
        numberAxis15.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint20 = combinedRangeXYPlot19.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        combinedRangeXYPlot19.setDrawingSupplier(drawingSupplier21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        combinedRangeXYPlot19.setFixedDomainAxisSpace(axisSpace23);
        boolean boolean25 = numberAxis15.hasListener((java.util.EventListener) combinedRangeXYPlot19);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str27 = plotOrientation26.toString();
        combinedRangeXYPlot19.setOrientation(plotOrientation26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation26);
        combinedRangeXYPlot0.setRangeAxisLocation(8, axisLocation13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str27.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getGridBandPaint();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot11.setDrawingSupplier(drawingSupplier13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace15);
        boolean boolean17 = numberAxis7.hasListener((java.util.EventListener) combinedRangeXYPlot11);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str19 = plotOrientation18.toString();
        combinedRangeXYPlot11.setOrientation(plotOrientation18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        java.awt.Paint paint22 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        standardChartTheme1.setGridBandAlternatePaint(paint22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis3D25.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D28, rectangleEdge29);
        double double31 = categoryAxis3D25.getLowerMargin();
        java.awt.Font font32 = categoryAxis3D25.getLabelFont();
        java.awt.Color color33 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer36 = null;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, (java.awt.Paint) color33, (float) 12, (-16646144), textMeasurer36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis3D39.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D42, rectangleEdge43);
        double double45 = categoryAxis3D39.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions46 = categoryAxis3D39.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator49 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer51 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator49, xYURLGenerator50);
        java.awt.Font font53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock54 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font53);
        xYAreaRenderer51.setBaseItemLabelFont(font53);
        categoryAxis3D39.setTickLabelFont((java.lang.Comparable) 10.0d, font53);
        java.awt.Paint paint57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock37.addLine("hi!", font53, paint57);
        standardChartTheme1.setWallPaint(paint57);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D61 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Font font62 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        categoryAxis3D61.setTickLabelFont(font62);
        standardChartTheme1.setExtraLargeFont(font62);
        java.awt.Font font65 = standardChartTheme1.getRegularFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str19.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions46);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(font65);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset9 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem14 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number15 = null;
        xYDataItem14.setY(number15);
        double double17 = xYDataItem14.getXValue();
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity(shape7, (org.jfree.data.general.PieDataset) defaultPieDataset9, 4, 8, (java.lang.Comparable) double17, "[12.0, NaN]", "DateTickMarkPosition.MIDDLE");
        defaultPieDataset9.clear();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 12.0d + "'", double17 == 12.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (-1));
        double double4 = rectangleInsets0.extendWidth(0.0d);
        double double6 = rectangleInsets0.trimWidth((double) (byte) 0);
        double double8 = rectangleInsets0.extendWidth((double) 9);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.0d + "'", double4 == 16.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-16.0d) + "'", double6 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 25.0d + "'", double8 == 25.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection0.getSelectionState();
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            int int4 = timeSeriesCollection0.indexOf(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer3D6.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace10, false);
        java.awt.Paint paint13 = categoryPlot9.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot9.getDomainGridlinePosition();
        boolean boolean15 = categoryPlot9.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint18 = numberAxis17.getTickMarkPaint();
        numberAxis17.configure();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis17.java2DToValue(4.0d, rectangle2D21, rectangleEdge22);
        java.awt.Color color26 = java.awt.Color.BLUE;
        java.awt.Color color27 = color26.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color27);
        java.awt.Shape shape33 = null;
        java.awt.Color color34 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape33, (java.awt.Paint) color34);
        int int36 = color34.getRGB();
        intervalMarker28.setOutlinePaint((java.awt.Paint) color34);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        intervalMarker28.notifyListeners(markerChangeEvent38);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker28);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color42);
        legendItem43.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset46 = null;
        legendItem43.setDataset(dataset46);
        java.lang.String str48 = legendItem43.getLabel();
        java.awt.Shape shape49 = legendItem43.getShape();
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint53 = combinedRangeXYPlot52.getDomainZeroBaselinePaint();
        textTitle51.setBackgroundPaint(paint53);
        textTitle51.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity58 = new org.jfree.chart.entity.TitleEntity(shape49, (org.jfree.chart.title.Title) textTitle51, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D59 = textTitle51.getBounds();
        barRenderer3D6.drawRangeMarker(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.plot.Marker) intervalMarker28, rectangle2D59);
        java.awt.geom.AffineTransform affineTransform61 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot63 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint64 = combinedRangeXYPlot63.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier65 = null;
        combinedRangeXYPlot63.setDrawingSupplier(drawingSupplier65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Point2D point2D69 = null;
        combinedRangeXYPlot63.zoomRangeAxes((double) 1, plotRenderingInfo68, point2D69);
        org.jfree.chart.JFreeChart jFreeChart71 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType72 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent73 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot63, jFreeChart71, chartChangeEventType72);
        boolean boolean74 = combinedRangeXYPlot63.isDomainZeroBaselineVisible();
        org.jfree.chart.JFreeChart jFreeChart75 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) combinedRangeXYPlot63);
        java.awt.RenderingHints renderingHints76 = jFreeChart75.getRenderingHints();
        java.awt.PaintContext paintContext77 = color1.createContext(colorModel2, rectangle3, rectangle2D59, affineTransform61, renderingHints76);
        multiplePiePlot0.setLegendItemShape((java.awt.Shape) rectangle2D59);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-16776961) + "'", int36 == (-16776961));
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str48.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(renderingHints76);
        org.junit.Assert.assertNotNull(paintContext77);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint9 = combinedRangeXYPlot8.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        combinedRangeXYPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot8.setFixedDomainAxisSpace(axisSpace12);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation16 = combinedRangeXYPlot0.getRangeAxisLocation(9999);
        org.jfree.data.xy.XYDataset xYDataset17 = combinedRangeXYPlot0.getDataset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(xYDataset17);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator1, true);
        java.awt.Font font5 = xYAreaRenderer0.getLegendTextFont((int) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo16);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo16);
        boolean boolean20 = xYAreaRenderer0.equals((java.lang.Object) plotRenderingInfo16);
        org.jfree.chart.renderer.RendererState rendererState21 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo16);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str4 = projectInfo2.getInfo();
        java.lang.String str5 = projectInfo2.getVersion();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        org.jfree.data.general.PieDataset pieDataset8 = ringPlot0.getDataset();
        boolean boolean9 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        java.awt.Paint paint10 = ringPlot0.getLabelBackgroundPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot0.getLabelGenerator();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        int int5 = combinedRangeXYPlot3.getDomainAxisCount();
        combinedRangeXYPlot3.clearSelection();
        combinedRangeXYPlot3.setRangeZeroBaselineVisible(false);
        java.lang.Object obj9 = combinedRangeXYPlot3.clone();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        java.awt.image.BufferedImage bufferedImage15 = jFreeChart10.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo14);
        combinedRangeXYPlot0.setBackgroundImage((java.awt.Image) bufferedImage15);
        java.awt.Paint paint17 = combinedRangeXYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(bufferedImage15);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = numberAxis1.getAxisLinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            combinedDomainXYPlot4.addAnnotation(xYAnnotation5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        boolean boolean4 = barRenderer3D2.isDrawBarOutline();
        barRenderer3D2.setBase((double) (short) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            barRenderer3D2.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        combinedRangeXYPlot0.handleClick(64, (int) (byte) 10, plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo10);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState14 = state13.getCrosshairState();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYCrosshairState14);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) dateTickUnit4);
        org.junit.Assert.assertNotNull(dateTickUnit4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        xYLineAndShapeRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint9 = numberAxis8.getTickMarkPaint();
        java.awt.Paint paint10 = numberAxis8.getAxisLinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        int int14 = combinedRangeXYPlot12.getDomainAxisCount();
        combinedRangeXYPlot12.clearSelection();
        combinedRangeXYPlot12.setRangeZeroBaselineVisible(false);
        java.lang.Object obj18 = combinedRangeXYPlot12.clone();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.lang.String[] strArray24 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis25 = new org.jfree.chart.axis.SymbolAxis("", strArray24);
        java.lang.String str27 = symbolAxis25.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis25);
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot29.setLegendItemShape(shape31);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator33 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot29.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator33);
        java.awt.Color color35 = java.awt.Color.pink;
        boolean boolean36 = ringPlot29.equals((java.lang.Object) color35);
        symbolAxis25.setGridBandAlternatePaint((java.awt.Paint) color35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis3D41.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D44, rectangleEdge45);
        double double47 = categoryAxis3D41.getLowerMargin();
        java.awt.Font font48 = categoryAxis3D41.getLabelFont();
        java.awt.Color color49 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer52 = null;
        org.jfree.chart.text.TextBlock textBlock53 = org.jfree.chart.text.TextUtilities.createTextBlock("", font48, (java.awt.Paint) color49, (float) 12, (-16646144), textMeasurer52);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis3D55.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D58, rectangleEdge59);
        double double61 = categoryAxis3D55.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions62 = categoryAxis3D55.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator65 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator66 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer67 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator65, xYURLGenerator66);
        java.awt.Font font69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock70 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font69);
        xYAreaRenderer67.setBaseItemLabelFont(font69);
        categoryAxis3D55.setTickLabelFont((java.lang.Comparable) 10.0d, font69);
        java.awt.Paint paint73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock53.addLine("hi!", font69, paint73);
        org.jfree.chart.plot.IntervalMarker intervalMarker75 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint73);
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        xYLineAndShapeRenderer0.drawDomainMarker(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot11, (org.jfree.chart.axis.ValueAxis) symbolAxis25, (org.jfree.chart.plot.Marker) intervalMarker75, rectangle2D76);
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = intervalMarker75.getLabelOffset();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(textBlock53);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions62);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(rectangleInsets78);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str4 = projectInfo2.getName();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace6, false);
        java.awt.Paint paint9 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        boolean boolean11 = categoryPlot5.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint14 = numberAxis13.getTickMarkPaint();
        numberAxis13.configure();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis13.java2DToValue(4.0d, rectangle2D17, rectangleEdge18);
        java.awt.Color color22 = java.awt.Color.BLUE;
        java.awt.Color color23 = color22.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color23);
        java.awt.Shape shape29 = null;
        java.awt.Color color30 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape29, (java.awt.Paint) color30);
        int int32 = color30.getRGB();
        intervalMarker24.setOutlinePaint((java.awt.Paint) color30);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        intervalMarker24.notifyListeners(markerChangeEvent34);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker24);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color38);
        legendItem39.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset42 = null;
        legendItem39.setDataset(dataset42);
        java.lang.String str44 = legendItem39.getLabel();
        java.awt.Shape shape45 = legendItem39.getShape();
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint49 = combinedRangeXYPlot48.getDomainZeroBaselinePaint();
        textTitle47.setBackgroundPaint(paint49);
        textTitle47.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity54 = new org.jfree.chart.entity.TitleEntity(shape45, (org.jfree.chart.title.Title) textTitle47, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle47.getBounds();
        barRenderer3D2.drawRangeMarker(graphics2D4, categoryPlot5, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.plot.Marker) intervalMarker24, rectangle2D55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint59 = numberAxis58.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D65 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        double double70 = categoryAxis3D65.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D68, rectangleEdge69);
        double double71 = categoryAxis3D65.getLowerMargin();
        java.awt.Font font72 = categoryAxis3D65.getLabelFont();
        java.awt.Color color73 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer76 = null;
        org.jfree.chart.text.TextBlock textBlock77 = org.jfree.chart.text.TextUtilities.createTextBlock("", font72, (java.awt.Paint) color73, (float) 12, (-16646144), textMeasurer76);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand78 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis58, 1.0d, (double) 60000L, (double) (short) 100, (double) (byte) 1, font72);
        numberAxis13.setMarkerBand(markerAxisBand78);
        org.jfree.chart.util.LogFormat logFormat83 = new org.jfree.chart.util.LogFormat((double) 9, "", false);
        java.text.NumberFormat numberFormat84 = logFormat83.getExponentFormat();
        java.text.NumberFormat numberFormat85 = logFormat83.getExponentFormat();
        numberAxis13.setNumberFormatOverride((java.text.NumberFormat) logFormat83);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-16776961) + "'", int32 == (-16776961));
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str44.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.05d + "'", double71 == 0.05d);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(textBlock77);
        org.junit.Assert.assertNotNull(numberFormat84);
        org.junit.Assert.assertNotNull(numberFormat85);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 1L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = barRenderer3D2.getDrawingSupplier();
        double double4 = barRenderer3D2.getLowerClip();
        org.junit.Assert.assertNull(drawingSupplier3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection1.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection1);
        java.lang.Class<?> wildcardClass6 = timeSeriesCollection1.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("12/31/69", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(timeSeries4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        java.awt.Shape shape4 = numberAxis1.getLeftArrow();
        java.awt.Shape shape5 = numberAxis1.getUpArrow();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(markerAxisBand6);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.util.TimeZone timeZone2 = periodAxis1.getTimeZone();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        periodAxis1.setRange((org.jfree.data.Range) dateRange5, true, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = periodAxis1.getLast();
        java.util.Locale locale11 = periodAxis1.getLocale();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale11);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(locale11);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        double double4 = numberAxis1.getLowerBound();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        combinedRangeXYPlot5.zoomRangeAxes((double) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot5, jFreeChart13, chartChangeEventType14);
        combinedRangeXYPlot5.clearAnnotations();
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = combinedRangeXYPlot5.getRangeAxis((-16646144));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(valueAxis19);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer3D2.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator5, true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(itemLabelPosition4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        boolean boolean4 = barRenderer3D2.isDrawBarOutline();
        double double5 = barRenderer3D2.getBase();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer3D2.findRangeBounds(categoryDataset6);
        java.awt.Paint paint9 = null;
        barRenderer3D2.setLegendTextPaint(64, paint9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot11.setFixedDomainAxisSpace(axisSpace12, false);
        barRenderer3D2.setPlot(categoryPlot11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        java.lang.Number number4 = null;
        xYDataItem3.setY(number4);
        double double6 = xYDataItem3.getXValue();
        java.lang.String str7 = xYDataItem3.toString();
        boolean boolean8 = xYDataItem3.isSelected();
        defaultPieDataset0.setValue((java.lang.Comparable) xYDataItem3, (double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isDomainPannable();
        categoryPlot11.setRangeZeroBaselineVisible(false);
        boolean boolean15 = defaultPieDataset0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.awt.Color color19 = java.awt.Color.yellow;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator20 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator21 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer22 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator20, xYURLGenerator21);
        java.awt.Stroke stroke23 = xYStepRenderer22.getBaseOutlineStroke();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot25.setLegendItemShape(shape27);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator29 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot25.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator29);
        java.awt.Color color31 = java.awt.Color.pink;
        boolean boolean32 = ringPlot25.equals((java.lang.Object) color31);
        ringPlot25.setLabelGap(0.0d);
        ringPlot25.setOuterSeparatorExtension((double) '4');
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color38);
        legendItem39.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset42 = null;
        legendItem39.setDataset(dataset42);
        java.lang.String str44 = legendItem39.getLabel();
        java.awt.Shape shape45 = legendItem39.getLine();
        java.awt.Font font46 = null;
        legendItem39.setLabelFont(font46);
        java.awt.Paint paint48 = legendItem39.getLinePaint();
        ringPlot25.setLabelBackgroundPaint(paint48);
        java.awt.Stroke stroke50 = ringPlot25.getOutlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker((double) ' ', 0.025d, (java.awt.Paint) color19, stroke23, (java.awt.Paint) color24, stroke50, (float) 0);
        ringPlot16.setSeparatorStroke(stroke23);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.0d + "'", double6 == 12.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[12.0, NaN]" + "'", str7.equals("[12.0, NaN]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str44.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str4 = projectInfo2.getInfo();
        projectInfo2.setLicenceText("hi!");
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String[] strArray4 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.lang.Object obj6 = symbolAxis5.clone();
        java.awt.Paint paint7 = symbolAxis5.getGridBandPaint();
        boolean boolean8 = symbolAxis5.isGridBandsVisible();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = combinedRangeXYPlot0.isSubplot();
        org.jfree.chart.plot.Plot plot3 = combinedRangeXYPlot0.getRootPlot();
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        java.awt.Color color5 = color4.darker();
        combinedRangeXYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plot3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        combinedRangeXYPlot6.setDrawingSupplier(drawingSupplier8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        combinedRangeXYPlot6.zoomRangeAxes((double) 1, plotRenderingInfo11, point2D12);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot6, jFreeChart14, chartChangeEventType15);
        int int17 = combinedRangeXYPlot6.getRangeAxisCount();
        java.awt.Stroke stroke18 = combinedRangeXYPlot6.getDomainMinorGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot19.setLegendItemShape(shape21);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot19.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator23);
        java.awt.Color color25 = java.awt.Color.pink;
        boolean boolean26 = ringPlot19.equals((java.lang.Object) color25);
        ringPlot19.setLabelGap(0.0d);
        ringPlot19.setOuterSeparatorExtension((double) '4');
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color32);
        legendItem33.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset36 = null;
        legendItem33.setDataset(dataset36);
        java.lang.String str38 = legendItem33.getLabel();
        java.awt.Shape shape39 = legendItem33.getLine();
        java.awt.Font font40 = null;
        legendItem33.setLabelFont(font40);
        java.awt.Paint paint42 = legendItem33.getLinePaint();
        ringPlot19.setLabelBackgroundPaint(paint42);
        try {
            org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem(attributedString0, "11", "ChartChangeEventType.DATASET_UPDATED", "Combined_Domain_XYPlot", shape4, paint5, stroke18, paint42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str38.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        java.lang.String str5 = legendItem2.getLabel();
        java.lang.String str6 = legendItem2.getLabel();
        org.jfree.data.general.Dataset dataset7 = legendItem2.getDataset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str5.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str6.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNull(dataset7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRenderer(12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D5.setUpperMargin((double) 9);
        int int8 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getGridBandPaint();
        java.awt.Paint paint6 = standardChartTheme1.getThermometerPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font10 = textFragment9.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot11.setDrawingSupplier(drawingSupplier13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, false);
        boolean boolean17 = dateAxis2.hasListener((java.util.EventListener) combinedRangeXYPlot11);
        boolean boolean18 = combinedRangeXYPlot11.isRangePannable();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color3);
        combinedRangeXYPlot0.setRangeTickBandPaint((java.awt.Paint) color3);
        combinedRangeXYPlot0.setNoDataMessage("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        pieLabelDistributor1.distributeLabels((double) (short) 1, Double.NaN);
        pieLabelDistributor1.clear();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord6 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator1, true);
        java.awt.Font font5 = xYAreaRenderer0.getLegendTextFont((int) ' ');
        java.lang.Object obj6 = xYAreaRenderer0.clone();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = numberAxis1.getAxisLinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis1);
        combinedDomainXYPlot4.setGap((double) '4');
        double double7 = combinedDomainXYPlot4.getRangeCrosshairValue();
        double double8 = combinedDomainXYPlot4.getGap();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.0d + "'", double8 == 52.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0d, (-57600000L), 100L, 0, (byte) 100, (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d, (-57600000L), 100L, 0, (byte) 100, (-1.0f) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0d, (-57600000L), 100L, 0, (byte) 100, (-1.0f) };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 1.0d, (-57600000L), 100L, 0, (byte) 100, (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 1.0d, (-57600000L), 100L, 0, (byte) 100, (-1.0f) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 1.0d, (-57600000L), 100L, 0, (byte) 100, (-1.0f) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ItemLabelAnchor.INSIDE6", "11", numberArray44);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        org.jfree.data.general.PieDataset pieDataset8 = ringPlot0.getDataset();
        boolean boolean9 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getCurrencyInstance();
        java.text.NumberFormat numberFormat12 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator13 = new org.jfree.chart.labels.StandardPieToolTipGenerator("ERROR : Relative To String", numberFormat11, numberFormat12);
        ringPlot0.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator13);
        boolean boolean15 = ringPlot0.getAutoPopulateSectionPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberFormat12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        boolean boolean6 = xYAreaRenderer3.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator8);
        xYAreaRenderer3.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        try {
            xYAreaRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.lang.String str8 = legendItem2.getDescription();
        java.awt.Shape shape9 = legendItem2.getLine();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str8.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        int int9 = combinedRangeXYPlot7.getDomainAxisCount();
        boolean boolean10 = combinedRangeXYPlot7.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        combinedRangeXYPlot7.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        combinedRangeXYPlot7.handleClick(64, (int) (byte) 10, plotRenderingInfo17);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState19 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint21 = combinedRangeXYPlot20.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        combinedRangeXYPlot20.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        combinedRangeXYPlot20.zoomRangeAxes((double) 1, plotRenderingInfo25, point2D26);
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot20, jFreeChart28, chartChangeEventType29);
        java.awt.geom.Point2D point2D31 = combinedRangeXYPlot20.getQuadrantOrigin();
        categoryPlot0.panRangeAxes((double) 8, plotRenderingInfo17, point2D31);
        double[] doubleArray37 = new double[] { (-57600000L) };
        double[] doubleArray39 = new double[] { (-57600000L) };
        double[] doubleArray41 = new double[] { (-57600000L) };
        double[] doubleArray43 = new double[] { (-57600000L) };
        double[] doubleArray45 = new double[] { (-57600000L) };
        double[][] doubleArray46 = new double[][] { doubleArray37, doubleArray39, doubleArray41, doubleArray43, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SeriesRenderingOrder.REVERSE", "Combined Range XYPlot", doubleArray46);
        categoryPlot0.setDataset(0, categoryDataset47);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, true);
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset47, false);
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset47);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNotNull(range53);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getThermometerPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator7, xYURLGenerator8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYStepAreaRenderer9.setBaseOutlinePaint((java.awt.Paint) color10, false);
        standardChartTheme1.setLabelLinkPaint((java.awt.Paint) color10);
        java.lang.String str14 = org.jfree.chart.util.PaintUtilities.colorToString(color10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#800080" + "'", str14.equals("#800080"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.LEFT" + "'", str1.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 100L);
        double double2 = xYBarRenderer1.getShadowXOffset();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj4 = timeSeriesCollection3.clone();
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        timeSeriesCollection3.removeAllSeries();
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.Range range8 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        java.awt.Shape shape14 = null;
        java.awt.Color color15 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape14, (java.awt.Paint) color15);
        int int17 = color15.getRGB();
        xYBarRenderer1.setSeriesOutlinePaint(2, (java.awt.Paint) color15, true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYBarRenderer1.getURLGenerator(3, 4, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16776961) + "'", int17 == (-16776961));
        org.junit.Assert.assertNull(xYURLGenerator23);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        org.jfree.chart.axis.Axis axis27 = axisEntity26.getAxis();
        boolean boolean28 = axis27.isVisible();
        java.awt.Stroke stroke29 = axis27.getTickMarkStroke();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(axis27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator4, xYURLGenerator5);
        xYStepRenderer6.setDrawSeriesLineAsPath(true);
        java.lang.Object obj9 = xYStepRenderer6.clone();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer6.setLegendLine(shape11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint16 = combinedRangeXYPlot15.getDomainZeroBaselinePaint();
        textTitle14.setBackgroundPaint(paint16);
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape11, (org.jfree.chart.title.Title) textTitle14, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis3D20.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D23, rectangleEdge24);
        double double26 = categoryAxis3D20.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = categoryAxis3D20.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis3D20, "ClassContext", "");
        java.awt.Color color31 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("", "12/31/69", "Combined_Domain_XYPlot", "0", shape11, (java.awt.Paint) color31);
        legendItem32.setShapeVisible(false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        org.jfree.data.general.PieDataset pieDataset8 = ringPlot0.getDataset();
        boolean boolean9 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        java.awt.Paint paint10 = ringPlot0.getLabelBackgroundPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator14, xYURLGenerator15);
        java.lang.Boolean boolean18 = xYAreaRenderer16.getSeriesVisible(2);
        java.awt.Paint paint19 = xYAreaRenderer16.getBaseItemLabelPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator21 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator21, xYURLGenerator22);
        java.awt.Font font25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font25);
        xYAreaRenderer23.setBaseItemLabelFont(font25);
        xYAreaRenderer16.setBaseItemLabelFont(font25, true);
        java.awt.Color color30 = java.awt.Color.yellow;
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.awt.Font font33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font33);
        labelBlock34.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean38 = labelBlock34.equals((java.lang.Object) plotOrientation37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation37);
        boolean boolean40 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge39);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=192,g=192,b=0]", font25, (java.awt.Paint) color30, rectangleEdge39, horizontalAlignment41, verticalAlignment42, rectangleInsets43);
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 45.0d, (java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = combinedRangeXYPlot0.isSubplot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) combinedRangeXYPlot0, true);
        java.lang.Object obj5 = rendererChangeEvent4.getRenderer();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.lang.String[] strArray4 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        symbolAxis5.setGridBandPaint(paint6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.util.TimeZone timeZone3 = periodAxis2.getTimeZone();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double7 = dateRange6.getCentralValue();
        periodAxis2.setRange((org.jfree.data.Range) dateRange6, true, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis2.getLast();
        java.util.Locale locale12 = periodAxis2.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale12);
        java.util.ResourceBundle.Control control14 = null;
        try {
            java.util.ResourceBundle resourceBundle15 = java.util.ResourceBundle.getBundle("AxisLocation.TOP_OR_RIGHT", locale12, control14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertNotNull(tickUnitSource13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 60000L, "ItemLabelAnchor.INSIDE6", "LengthConstraintType.FIXED", true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.util.TimeZone timeZone2 = periodAxis1.getTimeZone();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        periodAxis1.setRange((org.jfree.data.Range) dateRange5, true, false);
        java.lang.Object obj10 = periodAxis1.clone();
        periodAxis1.setMinorTickMarkOutsideLength(0.0f);
        java.util.TimeZone timeZone13 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        try {
            periodAxis1.setTimeZone(timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(timeZone13);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        double double4 = numberAxis1.getLowerBound();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        combinedRangeXYPlot5.zoomRangeAxes((double) 1, plotRenderingInfo10, point2D11);
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot5, jFreeChart13, chartChangeEventType14);
        combinedRangeXYPlot5.clearAnnotations();
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot5);
        combinedRangeXYPlot5.setDomainCrosshairValue((double) (short) 0, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean2 = textTitle1.isVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str5 = rectangleConstraint4.toString();
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle1.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        logAxis1.setFixedAutoRange((double) 3);
        double double5 = logAxis1.calculateLog((double) 10.0f);
        double double7 = logAxis1.calculateLog((double) 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = combinedRangeXYPlot0.isSubplot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) combinedRangeXYPlot0, true);
        boolean boolean5 = rendererChangeEvent4.getSeriesVisibilityChanged();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        double double7 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit8);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType10 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType10, 100);
        dateAxis2.setTickUnit(dateTickUnit12, false, false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTickUnitType10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint11 = combinedRangeXYPlot10.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = null;
        combinedRangeXYPlot10.setDrawingSupplier(drawingSupplier12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        combinedRangeXYPlot10.zoomRangeAxes((double) 1, plotRenderingInfo15, point2D16);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj19 = timeSeriesCollection18.clone();
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        int int21 = combinedRangeXYPlot10.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        boolean boolean22 = categoryPlot0.equals((java.lang.Object) int21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean24 = categoryPlot23.isDomainPannable();
        categoryPlot23.setRangeZeroBaselineVisible(false);
        categoryPlot23.setWeight(5);
        java.awt.Color color32 = java.awt.Color.BLUE;
        java.awt.Color color33 = color32.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color33);
        java.awt.Shape shape39 = null;
        java.awt.Color color40 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape39, (java.awt.Paint) color40);
        int int42 = color40.getRGB();
        intervalMarker34.setOutlinePaint((java.awt.Paint) color40);
        org.jfree.chart.util.Layer layer44 = null;
        categoryPlot23.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker34, layer44, false);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker34);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-16776961) + "'", int42 == (-16776961));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        boolean boolean2 = segmentedTimeline0.containsDomainValue((long) 255);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone5 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone5);
        dateAxis6.setInverted(false);
        dateAxis6.setLowerBound((double) 0);
        double double11 = dateAxis6.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date13 = dateAxis6.calculateHighestVisibleTickValue(dateTickUnit12);
        long long14 = segmentedTimeline3.getTime(date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        segmentedTimeline0.addException(date13);
        int int17 = segmentedTimeline0.getSegmentsExcluded();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-57600000L) + "'", long14 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 68 + "'", int17 == 68);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        int int6 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(pieURLGenerator7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone4);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone4);
        boolean boolean8 = year0.equals((java.lang.Object) timeSeriesCollection7);
        int int9 = year0.getYear();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("ERROR : Relative To String", numberFormat1, numberFormat2);
        numberFormat1.setGroupingUsed(true);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getShadowPaint();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        standardChartTheme1.setRangeGridlinePaint(paint3);
        java.awt.Paint paint5 = standardChartTheme1.getWallPaint();
        java.awt.Paint paint6 = standardChartTheme1.getWallPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis3D8.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D11, rectangleEdge12);
        double double14 = categoryAxis3D8.getLowerMargin();
        java.awt.Font font15 = categoryAxis3D8.getLabelFont();
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color16, (float) 12, (-16646144), textMeasurer19);
        standardChartTheme1.setRegularFont(font15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock20);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Shape shape8 = legendItem2.getShape();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        textTitle10.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity17 = new org.jfree.chart.entity.TitleEntity(shape8, (org.jfree.chart.title.Title) textTitle10, "ThreadContext");
        java.awt.Font font18 = textTitle10.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = textTitle10.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String[] strArray4 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        symbolAxis5.setGridBandAlternatePaint(paint6);
        symbolAxis5.setTickMarkInsideLength((float) (-16646144));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str8 = seriesRenderingOrder7.toString();
        combinedRangeXYPlot0.setSeriesRenderingOrder(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str8.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        ringPlot0.setOuterSeparatorExtension((-2.88E8d));
        java.awt.Stroke stroke6 = null;
        try {
            ringPlot0.setLabelLinkStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }
}

