import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.Arrangement arrangement2 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, arrangement1, arrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) (short) 0, (float) 1, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) (byte) 1, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj1 = timeSeriesCollection0.clone();
        java.util.List list2 = null;
        try {
            org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, list2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = null;
        try {
            numberAxis1.setUpArrow(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "PlotOrientation.HORIZONTAL", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        java.awt.Shape shape3 = null;
        try {
            numberAxis1.setUpArrow(shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        try {
            dateAxis2.setRange(0.0d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.Marker marker2 = null;
        org.jfree.chart.util.Layer layer3 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(0, marker2, layer3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int3 = java.awt.Color.HSBtoRGB(10.0f, (float) (short) 1, (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16646144) + "'", int3 == (-16646144));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        java.util.List list7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        try {
            double double10 = categoryAxis3D0.getCategoryMiddle((java.lang.Comparable) 12, list7, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 12, (double) 0, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        java.util.Locale locale3 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone1, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = java.awt.Color.yellow;
        java.awt.Color color9 = java.awt.Color.orange;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Color color14 = java.awt.Color.orange;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", false, shape5, false, (java.awt.Paint) color7, true, (java.awt.Paint) color9, stroke10, false, shape12, stroke13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (-460), plotRenderingInfo7, point2D8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str2 = plotOrientation1.toString();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str2.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = combinedRangeXYPlot0.render(graphics2D4, rectangle2D5, (int) '#', plotRenderingInfo7, crosshairState8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, 0.0d, (float) (-16646144), (float) (-1));
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        try {
            xYAreaRenderer3.setSeriesToolTipGenerator((int) (byte) -1, xYToolTipGenerator5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        waferMapPlot1.setDataset(waferMapDataset2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 100);
        java.util.Date date3 = null;
        java.util.TimeZone timeZone5 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone5);
        try {
            java.util.Date date7 = dateTickUnit2.addToDate(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = xYAreaRenderer3.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Shape shape0 = null;
        org.jfree.chart.title.Title title1 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity2 = new org.jfree.chart.entity.TitleEntity(shape0, title1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        boolean boolean2 = domainOrder0.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date0, timeZone2, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        java.awt.Paint paint4 = null;
        try {
            combinedRangeXYPlot0.setRangeZeroBaselinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        try {
            numberAxis1.setRangeWithMargins((double) 5, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (5.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setCursor(0.0d);
        axisState0.cursorLeft((double) (byte) -1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        float float5 = dateAxis2.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color2);
        legendItem3.setDescription("PlotOrientation.HORIZONTAL");
        java.lang.StringBuffer stringBuffer6 = null;
        java.text.FieldPosition fieldPosition7 = null;
        try {
            java.lang.StringBuffer stringBuffer8 = numberFormat0.format((java.lang.Object) legendItem3, stringBuffer6, fieldPosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker((int) '4', marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            boolean boolean7 = combinedRangeXYPlot0.removeRangeMarker(100, marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        combinedRangeXYPlot0.notifyListeners(plotChangeEvent5);
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            boolean boolean11 = combinedRangeXYPlot0.removeRangeMarker((int) ' ', marker8, layer9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        org.jfree.chart.LegendItem legendItem10 = xYAreaRenderer3.getLegendItem((int) (short) 0, 9);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(legendItem10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator2, xYURLGenerator3);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font6);
        xYAreaRenderer4.setBaseItemLabelFont(font6);
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double15 = rectangleInsets13.calculateTopOutset((double) (-1));
        try {
            org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("", font6, paint9, rectangleEdge10, horizontalAlignment11, verticalAlignment12, rectangleInsets13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.awt.Paint paint8 = null;
        xYAreaRenderer3.setBaseLegendTextPaint(paint8);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        try {
            double double6 = timeSeriesCollection0.getStartXValue((int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke11 = combinedRangeXYPlot9.getDomainCrosshairStroke();
        xYAreaRenderer3.setSeriesStroke((int) (byte) 1, stroke11, true);
        java.io.ObjectOutputStream objectOutputStream14 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke11, objectOutputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean4 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        try {
            combinedRangeXYPlot0.setOrientation(plotOrientation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = null;
        try {
            numberAxis1.setTickMarkPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 10.0f, 100.0d, 2, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedRangeXYPlot0.getDomainAxis((int) (short) 1);
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo10.getOptionalLibraries();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke14 = combinedRangeXYPlot12.getDomainCrosshairStroke();
        java.util.List list15 = combinedRangeXYPlot12.getSubplots();
        projectInfo10.setContributors(list15);
        try {
            combinedRangeXYPlot0.mapDatasetToDomainAxes(100, list15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(libraryArray11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        int int4 = combinedRangeXYPlot0.getSeriesCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("AxisLocation.TOP_OR_RIGHT", "AxisLocation.TOP_OR_RIGHT", "", "PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        int int1 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis2.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
        java.util.Date date9 = null;
        java.util.Date date10 = null;
        try {
            dateAxis2.setRange(date9, date10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            boolean boolean7 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis3D0.getLowerMargin();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.axis.AxisState axisState13 = categoryAxis3D0.draw(graphics2D7, (double) (-1), rectangle2D9, rectangle2D10, rectangleEdge11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        combinedRangeXYPlot3.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot3.zoomRangeAxes((double) 1, plotRenderingInfo8, point2D9);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot3, jFreeChart11, chartChangeEventType12);
        java.awt.geom.Point2D point2D14 = combinedRangeXYPlot3.getQuadrantOrigin();
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (byte) 1, plotRenderingInfo2, point2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(point2D14);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo1.getOptionalLibraries();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke5 = combinedRangeXYPlot3.getDomainCrosshairStroke();
        java.util.List list6 = combinedRangeXYPlot3.getSubplots();
        projectInfo1.setContributors(list6);
        try {
            org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis3D11.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D14, rectangleEdge15);
        double double17 = categoryAxis3D11.getLowerMargin();
        java.awt.Font font18 = categoryAxis3D11.getLabelFont();
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, (java.awt.Paint) color19, (float) 12, (-16646144), textMeasurer22);
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint27 = combinedRangeXYPlot26.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = null;
        combinedRangeXYPlot26.setDrawingSupplier(drawingSupplier28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        combinedRangeXYPlot26.zoomRangeAxes((double) 1, plotRenderingInfo31, point2D32);
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot26, jFreeChart34, chartChangeEventType35);
        java.awt.geom.Point2D point2D37 = combinedRangeXYPlot26.getQuadrantOrigin();
        try {
            org.jfree.chart.plot.XYPlot xYPlot38 = combinedRangeXYPlot0.findSubplot(plotRenderingInfo25, point2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(point2D37);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        boolean boolean10 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (-1), 0.0f, (double) 100L, 0.0f, 0.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.0f, 0.0d);
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            java.lang.Number number5 = intervalXYDelegate2.getStartX((int) (short) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        try {
            double double31 = categoryAxis3D16.getCategoryMiddle((int) (short) 100, 3, rectangle2D29, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.lang.String str2 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        java.lang.Boolean boolean4 = xYStepRenderer2.getSeriesLinesVisible((int) (byte) 10);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("11", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(markerAxisBand4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            int int4 = timeSeriesCollection0.getItemCount(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (12).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str2 = numberFormat0.format((long) 11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator4 = numberFormat0.formatToCharacterIterator((java.lang.Object) categoryAxis3D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11" + "'", str2.equals("11"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency3 = numberFormat2.getCurrency();
        numberFormat0.setCurrency(currency3);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(currency3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint6 = numberAxis5.getTickMarkPaint();
        numberAxis5.configure();
        java.awt.Shape shape8 = numberAxis5.getLeftArrow();
        java.awt.Shape shape9 = numberAxis5.getUpArrow();
        java.awt.Stroke stroke10 = null;
        java.awt.Color color11 = java.awt.Color.BLUE;
        java.awt.Color color12 = color11.brighter();
        try {
            org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem(attributedString0, "ChartChangeEventType.DATASET_UPDATED", "PlotOrientation.HORIZONTAL", "{0}: ({1}, {2})", shape9, stroke10, (java.awt.Paint) color12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo1.getOptionalLibraries();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke5 = combinedRangeXYPlot3.getDomainCrosshairStroke();
        java.util.List list6 = combinedRangeXYPlot3.getSubplots();
        projectInfo1.setContributors(list6);
        try {
            org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, list6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2);
        timeSeriesDataItem2.setSelected(true);
        java.text.NumberFormat numberFormat5 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency6 = numberFormat5.getCurrency();
        int int7 = timeSeriesDataItem2.compareTo((java.lang.Object) currency6);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(currency6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.awt.geom.Point2D point2D11 = combinedRangeXYPlot0.getQuadrantOrigin();
        combinedRangeXYPlot0.setDomainCrosshairVisible(false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint17 = combinedRangeXYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = null;
        combinedRangeXYPlot16.setDrawingSupplier(drawingSupplier18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        combinedRangeXYPlot16.zoomRangeAxes((double) 1, plotRenderingInfo21, point2D22);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot16, jFreeChart24, chartChangeEventType25);
        java.awt.geom.Point2D point2D27 = combinedRangeXYPlot16.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState28 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            combinedRangeXYPlot0.draw(graphics2D14, rectangle2D15, point2D27, plotState28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2);
        timeSeriesDataItem2.setValue((java.lang.Number) (byte) 10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection7, false);
        try {
            combinedRangeXYPlot0.setDataset((-1), (org.jfree.data.xy.XYDataset) timeSeriesCollection7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        boolean boolean4 = xYStepRenderer2.getDrawSeriesLineAsPath();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 64, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (64.0) <= upper (32.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint3 = combinedRangeXYPlot2.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = null;
        combinedRangeXYPlot2.setDrawingSupplier(drawingSupplier4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) 1, plotRenderingInfo7, point2D8);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj11 = timeSeriesCollection10.clone();
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        int int13 = combinedRangeXYPlot2.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        timeSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection10);
        double double16 = timeSeriesCollection0.getDomainLowerBound(false);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        try {
            java.util.Date date2 = dateTickUnit0.rollDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.lang.Boolean boolean9 = xYAreaRenderer3.getSeriesVisible(0);
        java.lang.Boolean boolean11 = xYAreaRenderer3.getSeriesVisible(10);
        boolean boolean12 = xYAreaRenderer3.getPlotArea();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        combinedRangeXYPlot0.notifyListeners(plotChangeEvent5);
        combinedRangeXYPlot0.clearDomainMarkers();
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace4, true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedRangeXYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedRangeXYPlot7.zoomRangeAxes((double) 1, plotRenderingInfo12, point2D13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        combinedRangeXYPlot0.remove((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint21 = combinedRangeXYPlot20.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = null;
        combinedRangeXYPlot20.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        combinedRangeXYPlot20.zoomRangeAxes((double) 1, plotRenderingInfo25, point2D26);
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot20, jFreeChart28, chartChangeEventType29);
        java.awt.geom.Point2D point2D31 = combinedRangeXYPlot20.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState32 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            combinedRangeXYPlot7.draw(graphics2D18, rectangle2D19, point2D31, plotState32, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D31);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        java.lang.Object obj16 = titleEntity15.clone();
        java.lang.String str17 = titleEntity15.toString();
        org.jfree.chart.title.Title title18 = titleEntity15.getTitle();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TitleEntity: tooltip = PlotOrientation.HORIZONTAL" + "'", str17.equals("TitleEntity: tooltip = PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(title18);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double3 = dateRange2.getCentralValue();
        boolean boolean6 = dateRange2.intersects((double) (-16776961), (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5d + "'", double3 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockBorder0.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemShapeFilled((int) (short) 100, 12);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        combinedRangeXYPlot0.axisChanged(axisChangeEvent7);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE6" + "'", str1.equals("ItemLabelAnchor.INSIDE6"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator1, true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        int int7 = combinedRangeXYPlot5.getDomainAxisCount();
        boolean boolean8 = combinedRangeXYPlot5.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        logAxis12.setBase(Double.POSITIVE_INFINITY);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            xYAreaRenderer0.fillRangeGridBand(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.chart.axis.ValueAxis) logAxis12, rectangle2D15, (double) (byte) 10, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis3D0.getLowerMargin();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean9 = combinedRangeXYPlot8.isDomainZeroBaselineVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot11.setDrawingSupplier(drawingSupplier13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        combinedRangeXYPlot11.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = combinedRangeXYPlot11.getDomainAxis((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = combinedRangeXYPlot11.getRangeAxisEdge((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace23 = categoryAxis3D0.reserveSpace(graphics2D7, (org.jfree.chart.plot.Plot) combinedRangeXYPlot8, rectangle2D10, rectangleEdge21, axisSpace22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent3);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent5);
        org.junit.Assert.assertNull(waferMapDataset2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = null;
        try {
            jFreeChart7.titleChanged(titleChangeEvent8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = numberAxis1.getAxisLinePaint();
        numberAxis1.setLowerBound((double) (byte) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        try {
            numberAxis1.setRange(0.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, false);
        org.jfree.data.Range range6 = intervalXYDelegate4.getDomainBounds(false);
        double double7 = intervalXYDelegate4.getFixedIntervalWidth();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = color1.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ItemLabelAnchor.INSIDE6", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis3D0.getLowerMargin();
        int int7 = categoryAxis3D0.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot11.setDrawingSupplier(drawingSupplier13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        combinedRangeXYPlot11.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = combinedRangeXYPlot11.getDomainAxis((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = combinedRangeXYPlot11.getRangeAxisEdge((int) ' ');
        boolean boolean22 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge21);
        try {
            double double23 = categoryAxis3D0.getCategoryEnd(100, (int) (byte) 1, rectangle2D10, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 100);
        int int3 = dateTickUnit2.getCalendarField();
        java.lang.String str5 = dateTickUnit2.valueToString((double) 1);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69" + "'", str5.equals("12/31/69"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setUpperMargin((double) 9);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double5 = rectangleInsets3.calculateTopOutset((double) (-1));
        double double7 = rectangleInsets3.extendWidth(0.0d);
        categoryAxis3D0.setLabelInsets(rectangleInsets3, false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint16 = combinedRangeXYPlot15.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = null;
        combinedRangeXYPlot15.setDrawingSupplier(drawingSupplier17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        combinedRangeXYPlot15.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = combinedRangeXYPlot15.getDomainAxis((int) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = combinedRangeXYPlot15.getRangeAxisEdge((int) ' ');
        try {
            double double26 = categoryAxis3D0.getCategorySeriesMiddle((java.lang.Comparable) (short) 1, (java.lang.Comparable) 10.0f, categoryDataset12, (double) (-1), rectangle2D14, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 16.0d + "'", double7 == 16.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.String str6 = combinedRangeXYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        try {
            defaultPieDataset0.insertValue((int) 'a', (java.lang.Comparable) "12/31/69", (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj9 = timeSeriesCollection8.clone();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        int int11 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (-1));
        double double4 = rectangleInsets0.extendWidth(0.0d);
        double double6 = rectangleInsets0.calculateLeftOutset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.0d + "'", double4 == 16.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot0.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.plot.PlotState plotState14 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        try {
            combinedRangeXYPlot0.draw(graphics2D11, rectangle2D12, point2D13, plotState14, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale5 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("ItemLabelAnchor.INSIDE6", (org.jfree.data.time.RegularTimePeriod) year1, regularTimePeriod3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        xYStepRenderer2.setDrawOutlines(true);
        double double7 = xYStepRenderer2.getStepPoint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        try {
            xYStepRenderer2.addAnnotation(xYAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.awt.Paint paint2 = paintMap0.getPaint((java.lang.Comparable) 0.0f);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) 4);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        java.awt.Paint paint8 = xYAreaRenderer3.lookupSeriesPaint(0);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        try {
            xYAreaRenderer3.setSeriesURLGenerator((-16776961), xYURLGenerator10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        try {
            java.lang.Comparable comparable3 = defaultPieDataset0.getKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-16646144), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator4 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator4, xYURLGenerator5);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font8);
        xYAreaRenderer6.setBaseItemLabelFont(font8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke14 = combinedRangeXYPlot12.getDomainCrosshairStroke();
        xYAreaRenderer6.setSeriesStroke((int) (byte) 1, stroke14, true);
        boolean boolean17 = labelBlock2.equals((java.lang.Object) stroke14);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = labelBlock2.getContentAlignmentPoint();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        try {
            org.jfree.chart.util.Size2D size2D21 = labelBlock2.arrange(graphics2D19, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        xYAreaRenderer3.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean11 = xYAreaRenderer3.getPlotLines();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color3);
        combinedRangeXYPlot0.setRangeTickBandPaint((java.awt.Paint) color3);
        java.awt.Shape shape10 = null;
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape10, (java.awt.Paint) color11);
        combinedRangeXYPlot0.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint17 = combinedRangeXYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = null;
        combinedRangeXYPlot16.setDrawingSupplier(drawingSupplier18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        combinedRangeXYPlot16.zoomRangeAxes((double) 1, plotRenderingInfo21, point2D22);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot16, jFreeChart24, chartChangeEventType25);
        java.awt.geom.Point2D point2D27 = combinedRangeXYPlot16.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState28 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.entity.EntityCollection entityCollection29 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo(entityCollection29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        try {
            combinedRangeXYPlot0.draw(graphics2D14, rectangle2D15, point2D27, plotState28, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double4 = dateRange3.getCentralValue();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double10 = dateRange9.getCentralValue();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(1.0d, (org.jfree.data.Range) dateRange3, lengthConstraintType5, 8.0d, (org.jfree.data.Range) dateRange9, lengthConstraintType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.INSIDE6", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        java.lang.String str3 = legendItem2.getURLText();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double4 = dateRange3.getCentralValue();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        org.jfree.data.Range range8 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange3, (org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = null;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double14 = dateRange13.getCentralValue();
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        org.jfree.data.Range range18 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange13, (org.jfree.data.Range) dateRange17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) '4', range8, lengthConstraintType9, (double) 10.0f, range18, lengthConstraintType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5d + "'", double14 == 0.5d);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str13 = plotOrientation12.toString();
        combinedRangeXYPlot5.setOrientation(plotOrientation12);
        combinedRangeXYPlot5.clearDomainMarkers();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setCursor(0.0d);
        axisState0.cursorUp((double) (short) 0);
        double double5 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color9);
        legendItem10.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset13 = null;
        legendItem10.setDataset(dataset13);
        java.lang.String str15 = legendItem10.getLabel();
        java.awt.Shape shape16 = legendItem10.getLine();
        try {
            jFreeChart7.setTextAntiAlias((java.lang.Object) shape16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.geom.Line2D$Float@38cf728d incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str15.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double11 = dateRange10.getCentralValue();
        org.jfree.data.Range range12 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange10);
        double double14 = range12.constrain(Double.NaN);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        try {
            intervalMarker4.setLabelAnchor(rectangleAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone4);
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date0, timeZone4, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection0.getSeries((java.lang.Comparable) (-1.0d));
        try {
            java.lang.Number number6 = timeSeriesCollection0.getEndY(64, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 64, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(timeSeries3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.Class class1 = null;
        java.util.Date date2 = null;
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date2, timeZone4);
        java.util.Locale locale7 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("ItemLabelAnchor.INSIDE6", timeZone4, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = combinedRangeXYPlot0.isSubplot();
        org.jfree.chart.plot.Plot plot3 = combinedRangeXYPlot0.getRootPlot();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer7 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator5, xYURLGenerator6);
        xYStepRenderer7.setDrawSeriesLineAsPath(true);
        java.lang.Object obj10 = xYStepRenderer7.clone();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer7.setLegendLine(shape12);
        combinedRangeXYPlot0.setRenderer(8, (org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer7, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plot3);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis3D1.getLowerMargin();
        java.awt.Font font8 = categoryAxis3D1.getLabelFont();
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, (java.awt.Paint) color9, (float) 12, (-16646144), textMeasurer12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis3D15.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D18, rectangleEdge19);
        double double21 = categoryAxis3D15.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = categoryAxis3D15.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator25, xYURLGenerator26);
        java.awt.Font font29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font29);
        xYAreaRenderer27.setBaseItemLabelFont(font29);
        categoryAxis3D15.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock13.addLine("hi!", font29, paint33);
        java.awt.Graphics2D graphics2D35 = null;
        try {
            org.jfree.chart.util.Size2D size2D36 = textBlock13.calculateDimensions(graphics2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        java.lang.String str28 = categoryAxis3D16.getCategoryLabelToolTip((java.lang.Comparable) 3.0d);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot33.setFixedDomainAxisSpace(axisSpace34, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot33.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.entity.EntityCollection entityCollection39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo(entityCollection39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        try {
            org.jfree.chart.axis.AxisState axisState42 = categoryAxis3D16.draw(graphics2D29, (double) (-16646144), rectangle2D31, rectangle2D32, rectangleEdge38, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        xYLineAndShapeRenderer0.setUseFillPaint(false);
        boolean boolean6 = xYLineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        combinedRangeXYPlot6.setDrawingSupplier(drawingSupplier8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        combinedRangeXYPlot6.zoomRangeAxes((double) 1, plotRenderingInfo11, point2D12);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj15 = timeSeriesCollection14.clone();
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        int int17 = combinedRangeXYPlot6.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        timeSeriesCollection4.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection14);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        org.jfree.data.Range range21 = timeSeriesCollection4.getDomainBounds(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint3 = combinedRangeXYPlot2.getDomainZeroBaselinePaint();
        textTitle1.setBackgroundPaint(paint3);
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle1.getMargin();
        textTitle1.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font3 = textFragment2.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot4, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart9.getXYPlot();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.entity.EntityCollection entityCollection15 = chartRenderingInfo14.getEntityCollection();
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart9.createBufferedImage((int) (byte) 0, 0, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(xYPlot10);
        org.junit.Assert.assertNull(entityCollection15);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem4 = xYSeries2.remove((java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        combinedRangeXYPlot0.handleClick(64, (int) (byte) 10, plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        org.jfree.chart.entity.EntityCollection entityCollection13 = xYItemRendererState12.getEntityCollection();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(entityCollection13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        double double7 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit8);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = dateAxis2.getStandardTickUnits();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            double double5 = timeSeriesCollection0.getEndYValue(5, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            boolean boolean11 = combinedRangeXYPlot8.removeAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font1);
        labelBlock2.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean6 = labelBlock2.equals((java.lang.Object) plotOrientation5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = labelBlock2.getContentAlignmentPoint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint2 = combinedRangeXYPlot1.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        combinedRangeXYPlot1.setDrawingSupplier(drawingSupplier3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot1.zoomRangeAxes((double) 1, plotRenderingInfo6, point2D7);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot1, jFreeChart9, chartChangeEventType10);
        boolean boolean12 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.title.LegendTitle legendTitle14 = null;
        try {
            jFreeChart13.addLegend(legendTitle14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis3D8.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D11, rectangleEdge12);
        double double14 = categoryAxis3D8.getLowerMargin();
        java.awt.Font font15 = categoryAxis3D8.getLabelFont();
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color16, (float) 12, (-16646144), textMeasurer19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 1.0d, (double) 60000L, (double) (short) 100, (double) (byte) 1, font15);
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock20);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(10.0d, (double) (short) 1, (double) 1L, (double) (byte) 0, paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendItem2.getLinePaint();
        java.awt.Shape shape4 = legendItem2.getLine();
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        java.awt.Shape shape4 = numberAxis1.getLeftArrow();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str13 = plotOrientation12.toString();
        combinedRangeXYPlot5.setOrientation(plotOrientation12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint19 = numberAxis18.getTickMarkPaint();
        numberAxis18.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = null;
        combinedRangeXYPlot22.setDrawingSupplier(drawingSupplier24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        combinedRangeXYPlot22.setFixedDomainAxisSpace(axisSpace26);
        boolean boolean28 = numberAxis18.hasListener((java.util.EventListener) combinedRangeXYPlot22);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str30 = plotOrientation29.toString();
        combinedRangeXYPlot22.setOrientation(plotOrientation29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation29);
        combinedRangeXYPlot5.setDomainAxisLocation(axisLocation16, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str30.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        xYAreaRenderer3.setUseFillPaint(false);
        boolean boolean10 = xYAreaRenderer3.isSeriesItemLabelsVisible(0);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYAreaRenderer3.getURLGenerator((-16646144), (int) (short) 1, true);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint18 = numberAxis17.getTickMarkPaint();
        java.awt.Paint paint19 = numberAxis17.getAxisLinePaint();
        try {
            xYAreaRenderer3.setSeriesOutlinePaint((int) (byte) -1, paint19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYURLGenerator14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        boolean boolean4 = combinedRangeXYPlot0.isDomainPannable();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        int int9 = numberAxis7.getMinorTickCount();
        try {
            combinedRangeXYPlot0.setRangeAxis((-460), (org.jfree.chart.axis.ValueAxis) numberAxis7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis2.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
        boolean boolean9 = dateAxis2.isNegativeArrowVisible();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType10 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType10, 100);
        int int13 = dateTickUnit12.getCalendarField();
        java.util.TimeZone timeZone15 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone15);
        dateAxis16.setInverted(false);
        dateAxis16.setLowerBound((double) 0);
        double double21 = dateAxis16.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date23 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit22);
        java.util.TimeZone timeZone24 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone24;
        java.util.Date date26 = dateTickUnit12.rollDate(date23, timeZone24);
        dateAxis2.setMinimumDate(date23);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTickUnitType10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Shape shape8 = legendItem2.getShape();
        legendItem2.setSeriesKey((java.lang.Comparable) false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.util.Date date2 = year0.getEnd();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint2 = combinedRangeXYPlot1.getDomainZeroBaselinePaint();
        int int3 = combinedRangeXYPlot1.getDomainAxisCount();
        combinedRangeXYPlot1.clearSelection();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint8 = combinedRangeXYPlot7.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        combinedRangeXYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        combinedRangeXYPlot7.zoomRangeAxes((double) 1, plotRenderingInfo12, point2D13);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj16 = timeSeriesCollection15.clone();
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        int int18 = combinedRangeXYPlot7.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        timeSeriesCollection5.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection15);
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        try {
            java.lang.String str22 = standardXYSeriesLabelGenerator0.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.String[] strArray4 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.lang.Object obj6 = symbolAxis5.clone();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot12.setFixedDomainAxisSpace(axisSpace13, false);
        int int16 = categoryPlot12.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        int int20 = combinedRangeXYPlot18.getDomainAxisCount();
        boolean boolean21 = combinedRangeXYPlot18.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        combinedRangeXYPlot18.setFixedDomainAxisSpace(axisSpace22);
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        combinedRangeXYPlot18.handleClick(64, (int) (byte) 10, plotRenderingInfo28);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint31 = combinedRangeXYPlot30.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = null;
        combinedRangeXYPlot30.setDrawingSupplier(drawingSupplier32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        combinedRangeXYPlot30.zoomRangeAxes((double) 1, plotRenderingInfo35, point2D36);
        org.jfree.chart.JFreeChart jFreeChart38 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType39 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot30, jFreeChart38, chartChangeEventType39);
        java.awt.geom.Point2D point2D41 = combinedRangeXYPlot30.getQuadrantOrigin();
        categoryPlot12.zoomDomainAxes(10.0d, plotRenderingInfo28, point2D41);
        try {
            org.jfree.chart.axis.AxisState axisState43 = symbolAxis5.draw(graphics2D7, (double) (-1.0f), rectangle2D9, rectangle2D10, rectangleEdge11, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(point2D41);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        int int11 = combinedRangeXYPlot0.getRangeAxisCount();
        boolean boolean12 = combinedRangeXYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 100, (float) 10);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            timeSeriesCollection0.addSeries(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        java.awt.Shape shape7 = xYAreaRenderer3.getLegendArea();
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font1);
        labelBlock2.setWidth((double) (-1));
        labelBlock2.setMargin((double) 0.0f, (double) (byte) 10, 100.0d, 0.0d);
        labelBlock2.setHeight((double) (-57600000L));
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font1);
        java.awt.Font font3 = labelBlock2.getFont();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = labelBlock2.getContentAlignmentPoint();
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = labelBlock2.arrange(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = null;
        try {
            dateAxis2.setTickMarkPosition(dateTickMarkPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("java.awt.Color[r=192,g=192,b=0]", "11", "", "ClassContext");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        combinedRangeXYPlot0.handleClick(64, (int) (byte) 10, plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState12 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo10);
        boolean boolean14 = state13.isLastPointGood();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.lang.Number number3 = defaultPieDataset0.getValue(12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone6);
        dateAxis7.setInverted(false);
        dateAxis7.setLowerBound((double) 0);
        double double12 = dateAxis7.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date14 = dateAxis7.calculateHighestVisibleTickValue(dateTickUnit13);
        long long15 = segmentedTimeline4.getTime(date14);
        try {
            java.lang.Number number16 = defaultPieDataset0.getValue((java.lang.Comparable) date14);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: Wed Dec 31 00:00:00 PST 1969");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-57600000L) + "'", long15 == (-57600000L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        xYAreaRenderer3.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Font font12 = xYAreaRenderer3.getSeriesItemLabelFont((int) 'a');
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = combinedRangeXYPlot0.getDomainAxis((int) (short) 1);
        java.util.TimeZone timeZone10 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone10);
        dateAxis11.setInverted(false);
        org.jfree.data.Range range14 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        java.lang.String str5 = legendItem2.getLabel();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem2.getFillPaintTransformer();
        java.awt.Font font7 = legendItem2.getLabelFont();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str5.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        boolean boolean2 = combinedRangeXYPlot0.isSubplot();
        org.jfree.chart.plot.Plot plot3 = combinedRangeXYPlot0.getRootPlot();
        org.jfree.chart.plot.XYPlot xYPlot4 = null;
        try {
            combinedRangeXYPlot0.add(xYPlot4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plot3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        double double7 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit8);
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone11);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double16 = dateRange15.getCentralValue();
        dateAxis12.setRange((org.jfree.data.Range) dateRange15);
        org.jfree.data.time.DateRange dateRange20 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double21 = dateRange20.getCentralValue();
        org.jfree.data.Range range22 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange20);
        dateAxis2.setRangeWithMargins((org.jfree.data.Range) dateRange15);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.awt.Font font30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font30);
        labelBlock31.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean35 = labelBlock31.equals((java.lang.Object) plotOrientation34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation28, plotOrientation34);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint38 = combinedRangeXYPlot37.getDomainZeroBaselinePaint();
        int int39 = combinedRangeXYPlot37.getDomainAxisCount();
        boolean boolean40 = combinedRangeXYPlot37.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        combinedRangeXYPlot37.setFixedDomainAxisSpace(axisSpace41);
        org.jfree.chart.entity.EntityCollection entityCollection45 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo(entityCollection45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        combinedRangeXYPlot37.handleClick(64, (int) (byte) 10, plotRenderingInfo47);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState49 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo47);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState50 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo47);
        try {
            org.jfree.chart.axis.AxisState axisState51 = dateAxis2.draw(graphics2D24, (double) 11, rectangle2D26, rectangle2D27, rectangleEdge36, plotRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5d + "'", double21 == 0.5d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator3, xYURLGenerator4);
        java.lang.Boolean boolean7 = xYAreaRenderer5.getSeriesVisible(2);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator10, xYURLGenerator11);
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font14);
        xYAreaRenderer12.setBaseItemLabelFont(font14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke20 = combinedRangeXYPlot18.getDomainCrosshairStroke();
        xYAreaRenderer12.setSeriesStroke((int) (byte) 1, stroke20, true);
        xYAreaRenderer5.setSeriesOutlineStroke((int) (byte) 1, stroke20);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color25);
        java.awt.Paint paint27 = legendItem26.getLinePaint();
        java.awt.Stroke stroke28 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke20, paint27, stroke28, (float) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Shape shape4 = xYLineAndShapeRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer0.lookupSeriesOutlineStroke(2);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer0.getSeriesURLGenerator(10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        try {
            xYLineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator25 = null;
        ringPlot0.setURLGenerator(pieURLGenerator25);
        double double27 = ringPlot0.getLabelLinkMargin();
        int int28 = ringPlot0.getPieIndex();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.025d + "'", double27 == 0.025d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        java.lang.Comparable comparable3 = xYSeries2.getKey();
        try {
            java.lang.Number number5 = xYSeries2.getY(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape4, (java.awt.Paint) color5);
        java.lang.String str7 = org.jfree.chart.util.PaintUtilities.colorToString(color5);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "blue" + "'", str7.equals("blue"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.05d, (double) (-16776961), rectangleAnchor3);
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font2 = textFragment1.getFont();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            float float5 = textFragment1.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        boolean boolean3 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint9 = combinedRangeXYPlot8.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke10 = combinedRangeXYPlot8.getDomainCrosshairStroke();
        java.util.List list11 = combinedRangeXYPlot8.getSubplots();
        java.util.List list12 = combinedRangeXYPlot8.getSubplots();
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        combinedRangeXYPlot8.zoomDomainAxes((double) ' ', plotRenderingInfo16, point2D19);
        org.jfree.chart.plot.PlotState plotState21 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        int int24 = combinedRangeXYPlot22.getDomainAxisCount();
        boolean boolean25 = combinedRangeXYPlot22.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        combinedRangeXYPlot22.setFixedDomainAxisSpace(axisSpace26);
        org.jfree.chart.entity.EntityCollection entityCollection30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo(entityCollection30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        combinedRangeXYPlot22.handleClick(64, (int) (byte) 10, plotRenderingInfo32);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState34 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo32);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState35 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo32);
        try {
            combinedRangeXYPlot0.draw(graphics2D6, rectangle2D7, point2D19, plotState21, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorX(3.0d);
        crosshairState0.setDatasetIndex(11);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator25 = null;
        ringPlot0.setURLGenerator(pieURLGenerator25);
        double double27 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setStartAngle(0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.025d + "'", double27 == 0.025d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        java.util.List list3 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedRangeXYPlot0.getDomainAxisEdge((int) (short) 1);
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        logAxis1.setBase(Double.POSITIVE_INFINITY);
        boolean boolean4 = logAxis1.isTickMarksVisible();
        logAxis1.setBase((double) 3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYAreaRenderer3.setSeriesPaint(0, paint9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color13);
        legendItem14.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset17 = null;
        legendItem14.setDataset(dataset17);
        java.lang.String str19 = legendItem14.getLabel();
        java.awt.Shape shape20 = legendItem14.getShape();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint24 = combinedRangeXYPlot23.getDomainZeroBaselinePaint();
        textTitle22.setBackgroundPaint(paint24);
        textTitle22.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape20, (org.jfree.chart.title.Title) textTitle22, "ThreadContext");
        java.awt.Font font30 = textTitle22.getFont();
        xYAreaRenderer3.setBaseLegendTextFont(font30);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str19.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font30);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot7.setFixedDomainAxisSpace(axisSpace8, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot7.getDomainAxisEdge((int) (short) 1);
        try {
            gradientXYBarPainter0.paintBarShadow(graphics2D1, xYBarRenderer2, 100, 11, true, rectangularShape6, rectangleEdge12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        logAxis1.setFixedAutoRange((double) 3);
        logAxis1.setAutoTickUnitSelection(true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.util.Currency currency1 = numberFormat0.getCurrency();
        numberFormat0.setGroupingUsed(false);
        numberFormat0.setMaximumIntegerDigits((int) (short) -1);
        java.math.RoundingMode roundingMode6 = null;
        try {
            numberFormat0.setRoundingMode(roundingMode6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.awt.geom.Point2D point2D11 = combinedRangeXYPlot0.getQuadrantOrigin();
        combinedRangeXYPlot0.setDomainCrosshairVisible(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator15, xYURLGenerator16);
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font19);
        xYAreaRenderer17.setBaseItemLabelFont(font19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint24 = combinedRangeXYPlot23.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke25 = combinedRangeXYPlot23.getDomainCrosshairStroke();
        xYAreaRenderer17.setSeriesStroke((int) (byte) 1, stroke25, true);
        combinedRangeXYPlot0.setRangeMinorGridlineStroke(stroke25);
        org.jfree.chart.axis.ValueAxis valueAxis29 = combinedRangeXYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        java.awt.Paint paint3 = legendItem2.getLinePaint();
        boolean boolean4 = legendItem2.isLineVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        boolean boolean6 = xYStepRenderer2.isSeriesVisible((int) '4');
        boolean boolean7 = xYStepRenderer2.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        combinedRangeXYPlot9.setDrawingSupplier(drawingSupplier11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        combinedRangeXYPlot9.drawBackgroundImage(graphics2D13, rectangle2D14);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone17);
        dateAxis18.setInverted(false);
        java.awt.Color color23 = java.awt.Color.BLUE;
        java.awt.Color color24 = color23.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color24);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYStepRenderer2.drawDomainMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.plot.Marker) intervalMarker25, rectangle2D26);
        xYStepRenderer2.setBaseSeriesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeriesCollection2.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection2);
        java.lang.Class<?> wildcardClass7 = timeSeriesCollection2.getClass();
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("11", (java.lang.Class) wildcardClass7);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Size2D[width=0.0, height=0.0]", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(timeSeries5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(uRL8);
        org.junit.Assert.assertNull(uRL9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) '4', (double) '4', (double) (-16646144));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainPannable();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.lang.Number number3 = defaultPieDataset0.getValue(12);
        try {
            java.lang.Comparable comparable5 = defaultPieDataset0.getKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Shape shape8 = legendItem2.getLine();
        java.awt.Font font9 = null;
        legendItem2.setLabelFont(font9);
        boolean boolean11 = legendItem2.isShapeFilled();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        try {
            org.jfree.chart.title.Title title9 = jFreeChart7.getSubtitle(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator25 = null;
        ringPlot0.setURLGenerator(pieURLGenerator25);
        java.awt.Font font27 = ringPlot0.getLabelFont();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        double double7 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit8);
        int int10 = dateTickUnit8.getCalendarField();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        xYAreaRenderer3.setBaseSeriesVisibleInLegend(true, true);
        xYAreaRenderer3.setOutline(false);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone2);
        dateAxis3.setInverted(false);
        dateAxis3.setLowerBound((double) 0);
        double double8 = dateAxis3.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date10 = dateAxis3.calculateHighestVisibleTickValue(dateTickUnit9);
        long long11 = segmentedTimeline0.getTime(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        long long14 = month12.getSerialIndex();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 23640L + "'", long14 == 23640L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint2 = xYStepRenderer0.lookupSeriesPaint(9);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj1 = timeSeriesCollection0.clone();
        try {
            timeSeriesCollection0.removeSeries((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        combinedRangeXYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setUpperMargin((double) 9);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double5 = rectangleInsets3.calculateTopOutset((double) (-1));
        double double7 = rectangleInsets3.extendWidth(0.0d);
        categoryAxis3D0.setLabelInsets(rectangleInsets3, false);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            rectangleInsets3.trim(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 16.0d + "'", double7 == 16.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        double double3 = barRenderer3D2.getMaximumBarWidth();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace7, false);
        int int10 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint13 = combinedRangeXYPlot12.getDomainZeroBaselinePaint();
        int int14 = combinedRangeXYPlot12.getDomainAxisCount();
        boolean boolean15 = combinedRangeXYPlot12.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        combinedRangeXYPlot12.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.entity.EntityCollection entityCollection20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        combinedRangeXYPlot12.handleClick(64, (int) (byte) 10, plotRenderingInfo22);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint25 = combinedRangeXYPlot24.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        combinedRangeXYPlot24.setDrawingSupplier(drawingSupplier26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        combinedRangeXYPlot24.zoomRangeAxes((double) 1, plotRenderingInfo29, point2D30);
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot24, jFreeChart32, chartChangeEventType33);
        java.awt.geom.Point2D point2D35 = combinedRangeXYPlot24.getQuadrantOrigin();
        categoryPlot6.zoomDomainAxes(10.0d, plotRenderingInfo22, point2D35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = categoryPlot6.getDataset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint40 = combinedRangeXYPlot39.getDomainZeroBaselinePaint();
        int int41 = combinedRangeXYPlot39.getDomainAxisCount();
        boolean boolean42 = combinedRangeXYPlot39.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        combinedRangeXYPlot39.setFixedDomainAxisSpace(axisSpace43);
        org.jfree.chart.entity.EntityCollection entityCollection47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = new org.jfree.chart.ChartRenderingInfo(entityCollection47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        combinedRangeXYPlot39.handleClick(64, (int) (byte) 10, plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo49);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state52 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo49);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState53 = barRenderer3D2.initialise(graphics2D4, rectangle2D5, categoryPlot6, 9, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNull(categoryDataset37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font1);
        java.awt.Font font3 = labelBlock2.getFont();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            labelBlock2.draw(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-16646144));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        xYAreaRenderer3.setUseFillPaint(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = xYAreaRenderer3.getLegendItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        xYAreaRenderer3.setSeriesPositiveItemLabelPosition(3, itemLabelPosition11, true);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        combinedRangeXYPlot8.setFixedLegendItems(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = timeSeriesCollection0.getGroup();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        double double6 = intervalXYDelegate5.getFixedIntervalWidth();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        intervalXYDelegate5.datasetChanged(datasetChangeEvent7);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Color color5 = color4.brighter();
        ringPlot0.setLabelOutlinePaint((java.awt.Paint) color4);
        try {
            ringPlot0.setInteriorGap((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo0.addOptionalLibrary("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo6.getOptionalLibraries();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
        java.lang.String str9 = projectInfo6.toString();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(libraryArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str9.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        boolean boolean6 = xYStepRenderer2.isSeriesVisible((int) '4');
        boolean boolean7 = xYStepRenderer2.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        combinedRangeXYPlot9.setDrawingSupplier(drawingSupplier11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        combinedRangeXYPlot9.drawBackgroundImage(graphics2D13, rectangle2D14);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone17);
        dateAxis18.setInverted(false);
        java.awt.Color color23 = java.awt.Color.BLUE;
        java.awt.Color color24 = color23.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color24);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYStepRenderer2.drawDomainMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.plot.Marker) intervalMarker25, rectangle2D26);
        boolean boolean29 = dateAxis18.isHiddenValue((long) ' ');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("DateTickMarkPosition.MIDDLE", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.lang.Object obj2 = standardPieToolTipGenerator1.clone();
        boolean boolean3 = domainOrder0.equals(obj2);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Font font7 = xYStepRenderer2.getLegendTextFont((int) (byte) -1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(11, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieToolTipGenerator.DEFAULT_TOOLTIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj10 = timeSeriesCollection9.clone();
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeriesCollection9.removeAllSeries();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState13 = timeSeriesCollection9.getSelectionState();
        org.jfree.chart.entity.XYItemEntity xYItemEntity18 = new org.jfree.chart.entity.XYItemEntity(shape7, (org.jfree.data.xy.XYDataset) timeSeriesCollection9, 0, 11, "{0}: ({1}, {2})", "AxisLocation.TOP_OR_RIGHT");
        org.jfree.data.xy.XYDataset xYDataset19 = xYItemEntity18.getDataset();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator20 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator21 = null;
        try {
            java.lang.String str22 = xYItemEntity18.getImageMapAreaTag(toolTipTagFragmentGenerator20, uRLTagFragmentGenerator21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState13);
        org.junit.Assert.assertNotNull(xYDataset19);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis3D0.getLowerMargin();
        java.awt.Font font7 = categoryAxis3D0.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis3D0.getCategorySeriesMiddle(100, (int) (byte) 10, 100, (-460), (double) '#', rectangle2D13, rectangleEdge14);
        java.lang.Object obj16 = categoryAxis3D0.clone();
        categoryAxis3D0.setUpperMargin(0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        boolean boolean2 = standardPieSectionLabelGenerator0.equals((java.lang.Object) projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 12, (java.lang.Number) (short) 10);
        double double3 = xYDataItem2.getYValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation((int) ' ', axisLocation2, true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        java.lang.Comparable comparable3 = xYSeries2.getKey();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.remove((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(0.0d, (double) (byte) 1);
        double double6 = dateRange5.getCentralValue();
        dateAxis2.setRange((org.jfree.data.Range) dateRange5);
        java.lang.Object obj8 = dateAxis2.clone();
        java.util.TimeZone timeZone10 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone10);
        dateAxis11.setInverted(false);
        dateAxis11.setLowerBound((double) 0);
        double double16 = dateAxis11.getUpperBound();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date18 = dateAxis11.calculateHighestVisibleTickValue(dateTickUnit17);
        dateAxis2.setTickUnit(dateTickUnit17, false, true);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.lang.String[] strArray12 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis13 = new org.jfree.chart.axis.SymbolAxis("", strArray12);
        java.lang.String str15 = symbolAxis13.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis13);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot17.setLegendItemShape(shape19);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot17.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator21);
        java.awt.Color color23 = java.awt.Color.pink;
        boolean boolean24 = ringPlot17.equals((java.lang.Object) color23);
        symbolAxis13.setGridBandAlternatePaint((java.awt.Paint) color23);
        symbolAxis13.setGridBandsVisible(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        java.awt.Paint paint8 = xYAreaRenderer3.lookupSeriesPaint(0);
        java.awt.Paint paint9 = null;
        xYAreaRenderer3.setBasePaint(paint9);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        float[] floatArray5 = new float[] { (byte) -1, 1546329600000L };
        try {
            float[] floatArray6 = java.awt.Color.RGBtoHSB(1900, (int) (byte) -1, 5, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        plotRenderingInfo2.setDataArea(rectangle2D3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis3D1.getLowerMargin();
        java.awt.Font font8 = categoryAxis3D1.getLabelFont();
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, (java.awt.Paint) color9, (float) 12, (-16646144), textMeasurer12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis3D15.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D18, rectangleEdge19);
        double double21 = categoryAxis3D15.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = categoryAxis3D15.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator25 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator25, xYURLGenerator26);
        java.awt.Font font29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font29);
        xYAreaRenderer27.setBaseItemLabelFont(font29);
        categoryAxis3D15.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textBlock13.addLine("hi!", font29, paint33);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textBlock13.getLineAlignment();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        java.awt.Shape shape4 = numberAxis1.getLeftArrow();
        java.awt.Shape shape5 = numberAxis1.getUpArrow();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.util.List list10 = numberAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setHeight(0.0d);
        size2D0.width = 1.0E-5d;
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint4 = combinedRangeXYPlot3.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        combinedRangeXYPlot3.setDrawingSupplier(drawingSupplier5);
        boolean boolean7 = combinedRangeXYPlot0.equals((java.lang.Object) combinedRangeXYPlot3);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis9 = combinedRangeXYPlot3.getRangeAxisForDataset((-16646144));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -16646144 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.String[] strArray4 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.awt.Shape shape6 = symbolAxis5.getRightArrow();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        java.lang.Comparable comparable3 = xYSeries2.getKey();
        xYSeries2.add((double) (byte) -1, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        boolean boolean17 = titleEntity15.equals((java.lang.Object) (byte) 10);
        java.lang.String str18 = titleEntity15.toString();
        org.jfree.chart.title.Title title19 = titleEntity15.getTitle();
        titleEntity15.setToolTipText("[12.0, NaN]");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TitleEntity: tooltip = PlotOrientation.HORIZONTAL" + "'", str18.equals("TitleEntity: tooltip = PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(title19);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = xYAreaRenderer3.getURLGenerator((int) 'a', (int) (short) -1, false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(xYURLGenerator11);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint3 = combinedRangeXYPlot2.getDomainZeroBaselinePaint();
        textTitle1.setBackgroundPaint(paint3);
        textTitle1.visible = true;
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYStepAreaRenderer3.isShapesFilled();
        xYStepAreaRenderer3.setPlotArea(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Paint paint1 = xYLineAndShapeRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYStepAreaRenderer3.setBaseOutlinePaint((java.awt.Paint) color4, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        try {
            xYStepAreaRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.lang.Boolean boolean9 = xYAreaRenderer3.getSeriesVisible(0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        xYAreaRenderer3.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer10);
        boolean boolean13 = xYAreaRenderer3.isSeriesVisible(2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint9 = combinedRangeXYPlot8.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        combinedRangeXYPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot8.setFixedDomainAxisSpace(axisSpace12);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        int int15 = combinedRangeXYPlot8.getSeriesCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        try {
            boolean boolean17 = combinedRangeXYPlot8.removeAnnotation(xYAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis2.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
        boolean boolean9 = dateAxis2.isNegativeArrowVisible();
        dateAxis2.setNegativeArrowVisible(true);
        double double12 = dateAxis2.getLabelAngle();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemToolTipGenerator();
        boolean boolean4 = barRenderer3D2.isDrawBarOutline();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot7.setFixedDomainAxisSpace(axisSpace8, false);
        int int11 = categoryPlot7.getRendererCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint14 = combinedRangeXYPlot13.getDomainZeroBaselinePaint();
        int int15 = combinedRangeXYPlot13.getDomainAxisCount();
        boolean boolean16 = combinedRangeXYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        combinedRangeXYPlot13.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo(entityCollection21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        combinedRangeXYPlot13.handleClick(64, (int) (byte) 10, plotRenderingInfo23);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = barRenderer3D2.initialise(graphics2D5, rectangle2D6, categoryPlot7, (int) '4', plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        boolean boolean6 = xYStepRenderer2.isSeriesVisible((int) '4');
        boolean boolean7 = xYStepRenderer2.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        combinedRangeXYPlot9.setDrawingSupplier(drawingSupplier11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        combinedRangeXYPlot9.drawBackgroundImage(graphics2D13, rectangle2D14);
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone17);
        dateAxis18.setInverted(false);
        java.awt.Color color23 = java.awt.Color.BLUE;
        java.awt.Color color24 = color23.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color24);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYStepRenderer2.drawDomainMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.plot.Marker) intervalMarker25, rectangle2D26);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener28 = null;
        try {
            xYStepRenderer2.removeChangeListener(rendererChangeListener28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint5 = numberAxis4.getTickMarkPaint();
        numberAxis4.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint9 = combinedRangeXYPlot8.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        combinedRangeXYPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot8.setFixedDomainAxisSpace(axisSpace12);
        boolean boolean14 = numberAxis4.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str16 = plotOrientation15.toString();
        combinedRangeXYPlot8.setOrientation(plotOrientation15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation2, plotOrientation15);
        combinedRangeXYPlot0.setDomainAxisLocation((int) ' ', axisLocation2, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        combinedRangeXYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21, true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str16.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.awt.geom.Point2D point2D11 = combinedRangeXYPlot0.getQuadrantOrigin();
        combinedRangeXYPlot0.setDomainCrosshairVisible(false);
        boolean boolean14 = combinedRangeXYPlot0.canSelectByPoint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.lang.Boolean boolean9 = xYAreaRenderer3.getSeriesVisible(0);
        java.lang.Boolean boolean11 = xYAreaRenderer3.getSeriesVisible(10);
        java.awt.Paint paint15 = xYAreaRenderer3.getItemFillPaint((-9999), 12, false);
        java.awt.Shape shape17 = xYAreaRenderer3.lookupSeriesShape((-16776961));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 10);
        double double4 = rectangleInsets0.calculateBottomOutset(0.0d);
        double double6 = rectangleInsets0.trimHeight(2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6.0d) + "'", double6 == (-6.0d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setBaseSeriesVisible(false, false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYAreaRenderer3.setSeriesPaint(0, paint9, false);
        java.lang.Object obj12 = xYAreaRenderer3.clone();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE10" + "'", str1.equals("ItemLabelAnchor.OUTSIDE10"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        boolean boolean2 = domainOrder0.equals((java.lang.Object) 100);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint5 = numberAxis4.getTickMarkPaint();
        numberAxis4.configure();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis4.java2DToValue(4.0d, rectangle2D8, rectangleEdge9);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator11, xYURLGenerator12);
        xYStepRenderer13.setDrawSeriesLineAsPath(true);
        java.lang.Object obj16 = xYStepRenderer13.clone();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer13.setLegendLine(shape18);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        textTitle21.setBackgroundPaint(paint23);
        org.jfree.chart.entity.TitleEntity titleEntity26 = new org.jfree.chart.entity.TitleEntity(shape18, (org.jfree.chart.title.Title) textTitle21, "PlotOrientation.HORIZONTAL");
        numberAxis4.setLeftArrow(shape18);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = numberAxis4.valueToJava2D(0.025d, rectangle2D29, rectangleEdge30);
        boolean boolean32 = domainOrder0.equals((java.lang.Object) rectangle2D29);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.POSITIVE_INFINITY + "'", double10 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("{0}: ({1}, {2})", graphics2D1, (float) 0L, 0.0f, textAnchor4, (double) 10.0f, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("DateTickMarkPosition.MIDDLE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 0.05d, true);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem4 = xYSeries2.remove((java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font3);
        labelBlock4.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean8 = labelBlock4.equals((java.lang.Object) plotOrientation7);
        combinedRangeXYPlot0.setOrientation(plotOrientation7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        int int13 = combinedRangeXYPlot11.getDomainAxisCount();
        boolean boolean14 = combinedRangeXYPlot11.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace15);
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        combinedRangeXYPlot11.handleClick(64, (int) (byte) 10, plotRenderingInfo21);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo21);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint25 = combinedRangeXYPlot24.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = null;
        combinedRangeXYPlot24.setDrawingSupplier(drawingSupplier26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        combinedRangeXYPlot24.zoomRangeAxes((double) 1, plotRenderingInfo29, point2D30);
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot24, jFreeChart32, chartChangeEventType33);
        java.awt.geom.Point2D point2D35 = combinedRangeXYPlot24.getQuadrantOrigin();
        combinedRangeXYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo21, point2D35, true);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection38 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range39 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection38);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeriesCollection38.getSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection38);
        int int43 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection38);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNull(timeSeries41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj10 = timeSeriesCollection9.clone();
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeriesCollection9.removeAllSeries();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState13 = timeSeriesCollection9.getSelectionState();
        org.jfree.chart.entity.XYItemEntity xYItemEntity18 = new org.jfree.chart.entity.XYItemEntity(shape7, (org.jfree.data.xy.XYDataset) timeSeriesCollection9, 0, 11, "{0}: ({1}, {2})", "AxisLocation.TOP_OR_RIGHT");
        org.jfree.chart.axis.Axis axis19 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity22 = new org.jfree.chart.entity.AxisEntity(shape7, axis19, "", "ItemLabelAnchor.INSIDE6");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState13);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, 45.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis3D11.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D14, rectangleEdge15);
        double double17 = categoryAxis3D11.getLowerMargin();
        java.awt.Font font18 = categoryAxis3D11.getLabelFont();
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, (java.awt.Paint) color19, (float) 12, (-16646144), textMeasurer22);
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator27, xYURLGenerator28);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font31);
        xYAreaRenderer29.setBaseItemLabelFont(font31);
        java.lang.Boolean boolean35 = xYAreaRenderer29.getSeriesVisible(0);
        combinedRangeXYPlot0.setRenderer(12, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer29);
        combinedRangeXYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(boolean35);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font10 = textFragment9.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot11.setDrawingSupplier(drawingSupplier13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, false);
        boolean boolean17 = dateAxis2.hasListener((java.util.EventListener) combinedRangeXYPlot11);
        boolean boolean18 = dateAxis2.isInverted();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        pieLabelDistributor1.clear();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        java.lang.Comparable comparable3 = xYSeries2.getKey();
        double double4 = xYSeries2.getMinY();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        xYSeries2.removePropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("ItemLabelAnchor.INSIDE6", graphics2D1, (float) 0L, (float) (-1), textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis3D11.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D14, rectangleEdge15);
        double double17 = categoryAxis3D11.getLowerMargin();
        java.awt.Font font18 = categoryAxis3D11.getLabelFont();
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, (java.awt.Paint) color19, (float) 12, (-16646144), textMeasurer22);
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator27 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator27, xYURLGenerator28);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font31);
        xYAreaRenderer29.setBaseItemLabelFont(font31);
        java.lang.Boolean boolean35 = xYAreaRenderer29.getSeriesVisible(0);
        combinedRangeXYPlot0.setRenderer(12, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer29);
        boolean boolean37 = combinedRangeXYPlot0.isRangeZoomable();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot40.setFixedDomainAxisSpace(axisSpace41, false);
        int int44 = categoryPlot40.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot46 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint47 = combinedRangeXYPlot46.getDomainZeroBaselinePaint();
        int int48 = combinedRangeXYPlot46.getDomainAxisCount();
        boolean boolean49 = combinedRangeXYPlot46.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        combinedRangeXYPlot46.setFixedDomainAxisSpace(axisSpace50);
        org.jfree.chart.entity.EntityCollection entityCollection54 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = new org.jfree.chart.ChartRenderingInfo(entityCollection54);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo55);
        combinedRangeXYPlot46.handleClick(64, (int) (byte) 10, plotRenderingInfo56);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot58 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint59 = combinedRangeXYPlot58.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier60 = null;
        combinedRangeXYPlot58.setDrawingSupplier(drawingSupplier60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        java.awt.geom.Point2D point2D64 = null;
        combinedRangeXYPlot58.zoomRangeAxes((double) 1, plotRenderingInfo63, point2D64);
        org.jfree.chart.JFreeChart jFreeChart66 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType67 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent68 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot58, jFreeChart66, chartChangeEventType67);
        java.awt.geom.Point2D point2D69 = combinedRangeXYPlot58.getQuadrantOrigin();
        categoryPlot40.zoomDomainAxes(10.0d, plotRenderingInfo56, point2D69);
        org.jfree.chart.plot.PlotState plotState71 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot72 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Graphics2D graphics2D73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        java.util.List list75 = null;
        combinedRangeXYPlot72.drawDomainTickBands(graphics2D73, rectangle2D74, list75);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent77 = null;
        combinedRangeXYPlot72.notifyListeners(plotChangeEvent77);
        java.awt.Graphics2D graphics2D79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot82 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint83 = combinedRangeXYPlot82.getDomainZeroBaselinePaint();
        int int84 = combinedRangeXYPlot82.getDomainAxisCount();
        boolean boolean85 = combinedRangeXYPlot82.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace86 = null;
        combinedRangeXYPlot82.setFixedDomainAxisSpace(axisSpace86);
        org.jfree.chart.entity.EntityCollection entityCollection90 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo91 = new org.jfree.chart.ChartRenderingInfo(entityCollection90);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo92 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo91);
        combinedRangeXYPlot82.handleClick(64, (int) (byte) 10, plotRenderingInfo92);
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState94 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo92);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState95 = new org.jfree.chart.plot.XYCrosshairState();
        boolean boolean96 = combinedRangeXYPlot72.render(graphics2D79, rectangle2D80, 10, plotRenderingInfo92, (org.jfree.chart.plot.CrosshairState) xYCrosshairState95);
        try {
            combinedRangeXYPlot0.draw(graphics2D38, rectangle2D39, point2D69, plotState71, plotRenderingInfo92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(boolean35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(point2D69);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        int int1 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        textTitle3.setBackgroundPaint(paint5);
        numberAxis1.setAxisLinePaint(paint5);
        float float8 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot1.setFixedDomainAxisSpace(axisSpace2, false);
        java.awt.Paint paint5 = categoryPlot1.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot1.getDomainGridlinePosition();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge10);
        try {
            double double12 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor6, (int) 'a', 0, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint6 = combinedRangeXYPlot5.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        combinedRangeXYPlot5.setDrawingSupplier(drawingSupplier7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace9);
        boolean boolean11 = numberAxis1.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str13 = plotOrientation12.toString();
        combinedRangeXYPlot5.setOrientation(plotOrientation12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = plotChangeEvent15.getType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(chartChangeEventType16);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color9);
        java.awt.Paint paint11 = legendItem10.getLinePaint();
        java.awt.Shape shape12 = legendItem10.getLine();
        legendItem2.setLine(shape12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        try {
            java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, rectangleAnchor14, (double) 255, 16.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        java.lang.String str16 = titleEntity15.toString();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TitleEntity: tooltip = PlotOrientation.HORIZONTAL" + "'", str16.equals("TitleEntity: tooltip = PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = categoryAxis3D0.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D3, rectangleEdge4);
        double double6 = categoryAxis3D0.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3D0.getCategoryLabelPositions();
        categoryAxis3D0.setCategoryLabelPositionOffset((int) (byte) 1);
        java.awt.Font font11 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 45.0d);
        double double12 = categoryAxis3D0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart8, chartChangeEventType9);
        java.awt.geom.Point2D point2D11 = combinedRangeXYPlot0.getQuadrantOrigin();
        java.lang.Object obj12 = null;
        boolean boolean13 = combinedRangeXYPlot0.equals(obj12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainPannable();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.configure();
        java.awt.Shape shape10 = numberAxis7.getLeftArrow();
        java.awt.Shape shape11 = numberAxis7.getUpArrow();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis3D13.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D16, rectangleEdge17);
        double double19 = categoryAxis3D13.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis3D13.getCategoryLabelPositions();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator23 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator23, xYURLGenerator24);
        java.awt.Font font27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font27);
        xYAreaRenderer25.setBaseItemLabelFont(font27);
        categoryAxis3D13.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D13);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        org.jfree.chart.util.Layer layer33 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker32, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        int int1 = numberFormat0.getMinimumFractionDigits();
        int int2 = numberFormat0.getMaximumFractionDigits();
        java.lang.String str4 = numberFormat0.format((double) 'a');
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97" + "'", str4.equals("97"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis3D1.getLowerMargin();
        java.awt.Font font8 = categoryAxis3D1.getLabelFont();
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, (java.awt.Paint) color9, (float) 12, (-16646144), textMeasurer12);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator14, xYURLGenerator15);
        xYStepRenderer16.setDrawSeriesLineAsPath(true);
        java.lang.Object obj19 = xYStepRenderer16.clone();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer16.setLegendLine(shape21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint26 = combinedRangeXYPlot25.getDomainZeroBaselinePaint();
        textTitle24.setBackgroundPaint(paint26);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape21, (org.jfree.chart.title.Title) textTitle24, "PlotOrientation.HORIZONTAL");
        boolean boolean30 = color9.equals((java.lang.Object) textTitle24);
        java.awt.Paint paint31 = textTitle24.getPaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint9 = combinedRangeXYPlot8.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        combinedRangeXYPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot8.setFixedDomainAxisSpace(axisSpace12);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState();
        java.util.List list17 = axisState16.getTicks();
        try {
            combinedRangeXYPlot0.mapDatasetToDomainAxes((-460), list17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        barRenderer3D2.setShadowXOffset((double) 10.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        try {
            barRenderer3D2.setSeriesToolTipGenerator((int) (short) -1, categoryToolTipGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        xYStepRenderer2.setUseFillPaint(false);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        ringPlot0.setExplodePercent((java.lang.Comparable) 2, 3.0d);
        boolean boolean28 = ringPlot0.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint10 = combinedRangeXYPlot9.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke11 = combinedRangeXYPlot9.getDomainCrosshairStroke();
        xYAreaRenderer3.setSeriesStroke((int) (byte) 1, stroke11, true);
        xYAreaRenderer3.setUseFillPaint(true);
        boolean boolean16 = xYAreaRenderer3.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        barRenderer3D2.setShadowXOffset((double) 10.0f);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        try {
            barRenderer3D2.setSeriesItemLabelFont((-16776961), font6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj10 = timeSeriesCollection9.clone();
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeriesCollection9.removeAllSeries();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState13 = timeSeriesCollection9.getSelectionState();
        org.jfree.chart.entity.XYItemEntity xYItemEntity18 = new org.jfree.chart.entity.XYItemEntity(shape7, (org.jfree.data.xy.XYDataset) timeSeriesCollection9, 0, 11, "{0}: ({1}, {2})", "AxisLocation.TOP_OR_RIGHT");
        org.jfree.data.xy.XYDataset xYDataset19 = xYItemEntity18.getDataset();
        xYItemEntity18.setItem(12);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState13);
        org.junit.Assert.assertNotNull(xYDataset19);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        combinedRangeXYPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        java.awt.Paint paint4 = ringPlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getSimpleLabelOffset();
        org.jfree.chart.util.Rotation rotation6 = null;
        try {
            ringPlot0.setDirection(rotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color3);
        java.awt.Shape shape9 = null;
        java.awt.Color color10 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape9, (java.awt.Paint) color10);
        int int12 = color10.getRGB();
        intervalMarker4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        intervalMarker4.notifyListeners(markerChangeEvent14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint19 = numberAxis18.getTickMarkPaint();
        numberAxis18.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = null;
        combinedRangeXYPlot22.setDrawingSupplier(drawingSupplier24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        combinedRangeXYPlot22.setFixedDomainAxisSpace(axisSpace26);
        boolean boolean28 = numberAxis18.hasListener((java.util.EventListener) combinedRangeXYPlot22);
        combinedRangeXYPlot22.setRangePannable(true);
        intervalMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) combinedRangeXYPlot22);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str33 = axisLocation32.toString();
        combinedRangeXYPlot22.setRangeAxisLocation(axisLocation32);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-16776961) + "'", int12 == (-16776961));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str33.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint3 = numberAxis2.getTickMarkPaint();
        numberAxis2.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        combinedRangeXYPlot6.setDrawingSupplier(drawingSupplier8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        boolean boolean12 = numberAxis2.hasListener((java.util.EventListener) combinedRangeXYPlot6);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str14 = plotOrientation13.toString();
        combinedRangeXYPlot6.setOrientation(plotOrientation13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation13);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str14.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape4, (java.awt.Paint) color5);
        int int7 = legendItem6.getSeriesIndex();
        org.jfree.data.general.Dataset dataset8 = legendItem6.getDataset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(dataset8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("AxisLocation.TOP_OR_RIGHT");
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend3 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) numberAxis2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = xYStepRenderer2.getLegendItems();
        java.lang.Object obj4 = legendItemCollection3.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace6, false);
        java.awt.Paint paint9 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot5.getLegendItems();
        legendItemCollection3.addAll(legendItemCollection11);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (-1));
        double double4 = rectangleInsets0.extendWidth(0.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.0d + "'", double4 == 16.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})");
        java.awt.Font font3 = textFragment2.getFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint5 = combinedRangeXYPlot4.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedRangeXYPlot4.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot4, false);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot10 = jFreeChart9.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CombinedRangeXYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        logAxis1.setStandardTickUnits(tickUnitSource2);
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        java.awt.Paint paint4 = ringPlot0.getBaseSectionOutlinePaint();
        ringPlot0.setLabelLinkMargin(10.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        java.lang.Comparable comparable3 = xYSeries2.getKey();
        double double4 = xYSeries2.getMinY();
        xYSeries2.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + false + "'", comparable3.equals(false));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = barRenderer3D2.getDrawingSupplier();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color5);
        barRenderer3D2.setWallPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Number number0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick(number0, "AxisLocation.TOP_OR_RIGHT", textAnchor2, textAnchor3, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false, false);
        int int3 = xYSeries2.getItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(12, xYToolTipGenerator1, xYURLGenerator2);
        xYStepAreaRenderer3.setPlotArea(false);
        xYStepAreaRenderer3.setShapesFilled(true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis3D1.getLowerMargin();
        java.awt.Font font8 = categoryAxis3D1.getLabelFont();
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, (java.awt.Paint) color9, (float) 12, (-16646144), textMeasurer12);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator14, xYURLGenerator15);
        xYStepRenderer16.setDrawSeriesLineAsPath(true);
        java.lang.Object obj19 = xYStepRenderer16.clone();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer16.setLegendLine(shape21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint26 = combinedRangeXYPlot25.getDomainZeroBaselinePaint();
        textTitle24.setBackgroundPaint(paint26);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape21, (org.jfree.chart.title.Title) textTitle24, "PlotOrientation.HORIZONTAL");
        boolean boolean30 = color9.equals((java.lang.Object) textTitle24);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double33 = rectangleInsets31.calculateTopOutset((double) 10);
        double double35 = rectangleInsets31.calculateBottomOutset(0.0d);
        textTitle24.setMargin(rectangleInsets31);
        java.lang.String str37 = textTitle24.getText();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color9);
        java.awt.Paint paint11 = legendItem10.getLinePaint();
        java.awt.Shape shape12 = legendItem10.getLine();
        legendItem2.setLine(shape12);
        legendItem2.setShapeVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = numberAxis1.getAxisLinePaint();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis1);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color7);
        legendItem8.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset11 = null;
        legendItem8.setDataset(dataset11);
        java.lang.String str13 = legendItem8.getLabel();
        java.awt.Shape shape14 = legendItem8.getShape();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint18 = combinedRangeXYPlot17.getDomainZeroBaselinePaint();
        textTitle16.setBackgroundPaint(paint18);
        textTitle16.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape14, (org.jfree.chart.title.Title) textTitle16, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle16.getBounds();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint26 = combinedRangeXYPlot25.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke27 = combinedRangeXYPlot25.getDomainCrosshairStroke();
        java.util.List list28 = combinedRangeXYPlot25.getSubplots();
        java.util.List list29 = combinedRangeXYPlot25.getSubplots();
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = null;
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor35);
        combinedRangeXYPlot25.zoomDomainAxes((double) ' ', plotRenderingInfo33, point2D36);
        org.jfree.chart.plot.PlotState plotState38 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint40 = combinedRangeXYPlot39.getDomainZeroBaselinePaint();
        int int41 = combinedRangeXYPlot39.getDomainAxisCount();
        combinedRangeXYPlot39.clearSelection();
        combinedRangeXYPlot39.setRangeZeroBaselineVisible(false);
        java.lang.Object obj45 = combinedRangeXYPlot39.clone();
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot39);
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        java.awt.image.BufferedImage bufferedImage51 = jFreeChart46.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = chartRenderingInfo50.getPlotInfo();
        try {
            combinedDomainXYPlot4.draw(graphics2D5, rectangle2D24, point2D36, plotState38, plotRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str13.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(bufferedImage51);
        org.junit.Assert.assertNotNull(plotRenderingInfo52);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis3D8.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D11, rectangleEdge12);
        double double14 = categoryAxis3D8.getLowerMargin();
        java.awt.Font font15 = categoryAxis3D8.getLabelFont();
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, (java.awt.Paint) color16, (float) 12, (-16646144), textMeasurer19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 1.0d, (double) 60000L, (double) (short) 100, (double) (byte) 1, font15);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint24 = numberAxis23.getTickMarkPaint();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = categoryAxis3D30.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D33, rectangleEdge34);
        double double36 = categoryAxis3D30.getLowerMargin();
        java.awt.Font font37 = categoryAxis3D30.getLabelFont();
        java.awt.Color color38 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer41 = null;
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font37, (java.awt.Paint) color38, (float) 12, (-16646144), textMeasurer41);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand43 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis23, 1.0d, (double) 60000L, (double) (short) 100, (double) (byte) 1, font37);
        numberAxis1.setMarkerBand(markerAxisBand43);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(textBlock42);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint8 = numberAxis7.getTickMarkPaint();
        numberAxis7.configure();
        java.awt.Shape shape10 = numberAxis7.getLeftArrow();
        java.awt.Shape shape11 = numberAxis7.getUpArrow();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis7);
        java.lang.String str13 = categoryPlot0.getNoDataMessage();
        java.util.List list14 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(list14);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.DATASET_UPDATED");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        axisState3.setCursor(0.0d);
        axisState3.cursorUp((double) (short) 0);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color9);
        legendItem10.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset13 = null;
        legendItem10.setDataset(dataset13);
        java.lang.String str15 = legendItem10.getLabel();
        java.awt.Shape shape16 = legendItem10.getShape();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint20 = combinedRangeXYPlot19.getDomainZeroBaselinePaint();
        textTitle18.setBackgroundPaint(paint20);
        textTitle18.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity25 = new org.jfree.chart.entity.TitleEntity(shape16, (org.jfree.chart.title.Title) textTitle18, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle18.getBounds();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint30 = numberAxis29.getTickMarkPaint();
        numberAxis29.setUpperBound((double) 60000L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = null;
        combinedRangeXYPlot33.setDrawingSupplier(drawingSupplier35);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        combinedRangeXYPlot33.setFixedDomainAxisSpace(axisSpace37);
        boolean boolean39 = numberAxis29.hasListener((java.util.EventListener) combinedRangeXYPlot33);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str41 = plotOrientation40.toString();
        combinedRangeXYPlot33.setOrientation(plotOrientation40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation40);
        try {
            java.util.List list44 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D26, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str15.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str41.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color1);
        legendItem2.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.lang.String str7 = legendItem2.getLabel();
        java.awt.Shape shape8 = legendItem2.getShape();
        java.awt.Stroke stroke9 = legendItem2.getLineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str7.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis3D1.getLowerMargin();
        java.awt.Font font8 = categoryAxis3D1.getLabelFont();
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, (java.awt.Paint) color9, (float) 12, (-16646144), textMeasurer12);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator14, xYURLGenerator15);
        xYStepRenderer16.setDrawSeriesLineAsPath(true);
        java.lang.Object obj19 = xYStepRenderer16.clone();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer16.setLegendLine(shape21);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint26 = combinedRangeXYPlot25.getDomainZeroBaselinePaint();
        textTitle24.setBackgroundPaint(paint26);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity(shape21, (org.jfree.chart.title.Title) textTitle24, "PlotOrientation.HORIZONTAL");
        boolean boolean30 = color9.equals((java.lang.Object) textTitle24);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double33 = rectangleInsets31.calculateTopOutset((double) 10);
        double double35 = rectangleInsets31.calculateBottomOutset(0.0d);
        textTitle24.setMargin(rectangleInsets31);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = textTitle24.getHorizontalAlignment();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(false);
        boolean boolean7 = xYStepRenderer2.getItemShapeFilled(0, (-16646144));
        xYStepRenderer2.setBaseCreateEntities(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = xYStepRenderer2.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(drawingSupplier10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint2 = combinedRangeXYPlot1.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        combinedRangeXYPlot1.setDrawingSupplier(drawingSupplier3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot1.zoomRangeAxes((double) 1, plotRenderingInfo6, point2D7);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot1, jFreeChart9, chartChangeEventType10);
        boolean boolean12 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ThreadContext", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint18 = combinedRangeXYPlot17.getDomainZeroBaselinePaint();
        textTitle16.setBackgroundPaint(paint18);
        textTitle16.setExpandToFitSpace(true);
        jFreeChart13.setTitle(textTitle16);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Paint paint2 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue(4.0d, rectangle2D5, rectangleEdge6);
        double double8 = numberAxis1.getFixedDimension();
        float float9 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis3D1.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D4, rectangleEdge5);
        double double7 = categoryAxis3D1.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis3D1.getCategoryLabelPositions();
        categoryAxis3D1.setCategoryLabelPositionOffset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis3D11.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D14, rectangleEdge15);
        categoryAxis3D11.setCategoryMargin((double) (byte) 0);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis3D19.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis3D25.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D28, rectangleEdge29);
        double double31 = categoryAxis3D25.getLowerMargin();
        java.awt.Font font32 = categoryAxis3D25.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis3D25.getCategorySeriesMiddle(100, (int) (byte) 10, 100, (-460), (double) '#', rectangle2D38, rectangleEdge39);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray41 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis3D1, categoryAxis3D11, categoryAxis3D19, categoryAxis3D25 };
        categoryPlot0.setDomainAxes(categoryAxisArray41);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAxisArray41);
        org.junit.Assert.assertNull(valueAxis43);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.String[] strArray4 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis5 = new org.jfree.chart.axis.SymbolAxis("", strArray4);
        java.lang.Object obj6 = symbolAxis5.clone();
        boolean boolean7 = symbolAxis5.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot0.setLegendItemShape(shape2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = java.awt.Color.pink;
        boolean boolean7 = ringPlot0.equals((java.lang.Object) color6);
        ringPlot0.setMinimumArcAngleToDraw((double) (-57600000L));
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = color12.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color13);
        java.awt.Shape shape19 = null;
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape19, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        intervalMarker14.setOutlinePaint((java.awt.Paint) color20);
        ringPlot0.setLabelPaint((java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot27.setLegendItemShape(shape29);
        java.awt.Shape shape31 = ringPlot27.getLegendItemShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint34 = combinedRangeXYPlot33.getDomainZeroBaselinePaint();
        int int35 = combinedRangeXYPlot33.getDomainAxisCount();
        combinedRangeXYPlot33.clearSelection();
        combinedRangeXYPlot33.setRangeZeroBaselineVisible(false);
        java.lang.Object obj39 = combinedRangeXYPlot33.clone();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart40.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.plot.PiePlotState piePlotState47 = ringPlot0.initialise(graphics2D25, rectangle2D26, (org.jfree.chart.plot.PiePlot) ringPlot27, (java.lang.Integer) 64, plotRenderingInfo46);
        ringPlot27.setShadowYOffset(4.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot27.getLabelGenerator();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor52 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 0);
        ringPlot27.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor52);
        ringPlot27.setShadowYOffset((double) 0.0f);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16776961) + "'", int22 == (-16776961));
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(bufferedImage45);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
        org.junit.Assert.assertNotNull(piePlotState47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setCrosshairX((double) (-57600000L));
        crosshairState0.updateCrosshairX((double) 1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator0 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator1 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer2 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator0, xYURLGenerator1);
        xYStepRenderer2.setDrawSeriesLineAsPath(true);
        java.lang.Object obj5 = xYStepRenderer2.clone();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        xYStepRenderer2.setLegendLine(shape7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint12 = combinedRangeXYPlot11.getDomainZeroBaselinePaint();
        textTitle10.setBackgroundPaint(paint12);
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape7, (org.jfree.chart.title.Title) textTitle10, "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis3D16.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        double double22 = categoryAxis3D16.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis3D16.getCategoryLabelPositions();
        org.jfree.chart.entity.AxisEntity axisEntity26 = new org.jfree.chart.entity.AxisEntity(shape7, (org.jfree.chart.axis.Axis) categoryAxis3D16, "ClassContext", "");
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) '4', 3.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        java.awt.Paint paint8 = xYAreaRenderer3.lookupSeriesPaint(0);
        boolean boolean9 = xYAreaRenderer3.getAutoPopulateSeriesOutlinePaint();
        boolean boolean10 = xYAreaRenderer3.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint7 = combinedRangeXYPlot6.getDomainZeroBaselinePaint();
        int int8 = combinedRangeXYPlot6.getDomainAxisCount();
        boolean boolean9 = combinedRangeXYPlot6.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot6.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        combinedRangeXYPlot6.handleClick(64, (int) (byte) 10, plotRenderingInfo16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint19 = combinedRangeXYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = null;
        combinedRangeXYPlot18.setDrawingSupplier(drawingSupplier20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        combinedRangeXYPlot18.zoomRangeAxes((double) 1, plotRenderingInfo23, point2D24);
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot18, jFreeChart26, chartChangeEventType27);
        java.awt.geom.Point2D point2D29 = combinedRangeXYPlot18.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot0.getRangeAxisForDataset(11);
        java.awt.Color color35 = java.awt.Color.BLUE;
        java.awt.Color color36 = color35.brighter();
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker(Double.POSITIVE_INFINITY, (double) (byte) 0, (java.awt.Paint) color36);
        java.awt.Shape shape42 = null;
        java.awt.Color color43 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", "PlotOrientation.HORIZONTAL", "", "PlotOrientation.HORIZONTAL", shape42, (java.awt.Paint) color43);
        int int45 = color43.getRGB();
        intervalMarker37.setOutlinePaint((java.awt.Paint) color43);
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker37, layer47);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis3D49.getCategoryEnd((int) (short) 10, (int) (byte) 1, rectangle2D52, rectangleEdge53);
        double double55 = categoryAxis3D49.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions56 = categoryAxis3D49.getCategoryLabelPositions();
        categoryAxis3D49.setCategoryLabelPositionOffset((int) (byte) 1);
        java.awt.Font font60 = categoryAxis3D49.getTickLabelFont((java.lang.Comparable) 45.0d);
        int int61 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D49);
        categoryAxis3D49.clearCategoryLabelToolTips();
        java.awt.Font font63 = null;
        try {
            categoryAxis3D49.setLabelFont(font63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-16776961) + "'", int45 == (-16776961));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions56);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Paint paint5 = xYAreaRenderer3.getLegendTextPaint(64);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj1 = timeSeriesCollection0.clone();
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        timeSeriesCollection0.removeAllSeries();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = timeSeriesCollection0.getSelectionState();
        try {
            double double7 = timeSeriesCollection0.getXValue(9999, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        boolean boolean1 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation2, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj2 = timeSeriesCollection1.clone();
        boolean boolean3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            java.lang.String str6 = standardXYSeriesLabelGenerator0.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj9 = timeSeriesCollection8.clone();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        int int11 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font2);
        labelBlock3.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean7 = labelBlock3.equals((java.lang.Object) plotOrientation6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation6);
        java.lang.String str9 = plotOrientation6.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str9.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(12);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        java.awt.image.BufferedImage bufferedImage12 = jFreeChart7.createBufferedImage((int) (byte) 1, 2, chartRenderingInfo11);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = null;
        try {
            jFreeChart7.titleChanged(titleChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(bufferedImage12);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("TitleEntity: tooltip = PlotOrientation.HORIZONTAL");
        java.lang.Class class2 = null;
        try {
            periodAxis1.setMajorTickTimePeriodClass(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 64, (double) (short) 10);
        double double3 = barRenderer3D2.getMaximumBarWidth();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer3D2.getSeriesItemLabelGenerator((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesVisible(2);
        java.awt.Paint paint6 = xYAreaRenderer3.getBaseItemLabelPaint();
        xYAreaRenderer3.setUseFillPaint(false);
        boolean boolean10 = xYAreaRenderer3.isSeriesItemLabelsVisible(0);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYAreaRenderer3.getURLGenerator((-16646144), (int) (short) 1, true);
        java.awt.Paint paint15 = xYAreaRenderer3.getBaseFillPaint();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYAreaRenderer3.setSeriesToolTipGenerator((int) '4', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator17, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        try {
            xYAreaRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYURLGenerator14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator17);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1, false);
        int int4 = categoryPlot0.getRendererCount();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 100, false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) 'a', xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYStepAreaRenderer3.isOutline();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) 1, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint9 = combinedRangeXYPlot8.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = null;
        combinedRangeXYPlot8.setDrawingSupplier(drawingSupplier10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot8.setFixedDomainAxisSpace(axisSpace12);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = combinedRangeXYPlot0.getInsets();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj17 = timeSeriesCollection16.clone();
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        timeSeriesCollection16.removeAllSeries();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState20 = timeSeriesCollection16.getSelectionState();
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint23 = combinedRangeXYPlot22.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = null;
        combinedRangeXYPlot22.setDrawingSupplier(drawingSupplier24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        combinedRangeXYPlot22.setFixedDomainAxisSpace(axisSpace26);
        java.awt.Paint paint28 = combinedRangeXYPlot22.getBackgroundPaint();
        timeSeriesCollection16.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot22);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        combinedRangeXYPlot0.clearDomainMarkers((-16776961));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), xYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font5);
        xYAreaRenderer3.setBaseItemLabelFont(font5);
        java.lang.Boolean boolean9 = xYAreaRenderer3.getSeriesVisible(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer(xYToolTipGenerator11, xYURLGenerator12);
        xYStepRenderer13.setDrawSeriesLineAsPath(true);
        boolean boolean17 = xYStepRenderer13.isSeriesVisible((int) '4');
        boolean boolean18 = xYStepRenderer13.getBaseItemLabelsVisible();
        org.jfree.chart.util.PaintMap paintMap20 = new org.jfree.chart.util.PaintMap();
        java.lang.String[] strArray26 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis27 = new org.jfree.chart.axis.SymbolAxis("", strArray26);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint29 = combinedRangeXYPlot28.getDomainZeroBaselinePaint();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color31);
        combinedRangeXYPlot28.setRangeTickBandPaint((java.awt.Paint) color31);
        symbolAxis27.setTickMarkPaint((java.awt.Paint) color31);
        paintMap20.put((java.lang.Comparable) '#', (java.awt.Paint) color31);
        xYStepRenderer13.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color31);
        xYAreaRenderer3.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color31);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint40 = combinedRangeXYPlot39.getDomainZeroBaselinePaint();
        int int41 = combinedRangeXYPlot39.getDomainAxisCount();
        combinedRangeXYPlot39.clearSelection();
        combinedRangeXYPlot39.setRangeZeroBaselineVisible(false);
        java.lang.Object obj45 = combinedRangeXYPlot39.clone();
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot39);
        java.lang.String[] strArray51 = new java.lang.String[] { "{0}: ({1}, {2})", "{0}: ({1}, {2})", "hi!" };
        org.jfree.chart.axis.SymbolAxis symbolAxis52 = new org.jfree.chart.axis.SymbolAxis("", strArray51);
        java.lang.String str54 = symbolAxis52.valueToString(Double.POSITIVE_INFINITY);
        combinedRangeXYPlot39.setRangeAxis((org.jfree.chart.axis.ValueAxis) symbolAxis52);
        org.jfree.chart.plot.RingPlot ringPlot56 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        ringPlot56.setLegendItemShape(shape58);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator60 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot56.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator60);
        java.awt.Color color62 = java.awt.Color.pink;
        boolean boolean63 = ringPlot56.equals((java.lang.Object) color62);
        symbolAxis52.setGridBandAlternatePaint((java.awt.Paint) color62);
        xYAreaRenderer3.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color62);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        int int2 = combinedRangeXYPlot0.getDomainAxisCount();
        combinedRangeXYPlot0.clearSelection();
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(false);
        java.lang.Object obj6 = combinedRangeXYPlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        boolean boolean8 = combinedRangeXYPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone1);
        dateAxis2.setInverted(false);
        dateAxis2.setLowerBound((double) 0);
        double double7 = dateAxis2.getUpperBound();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace10, false);
        int int13 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint17 = combinedRangeXYPlot16.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke18 = combinedRangeXYPlot16.getDomainCrosshairStroke();
        java.util.List list19 = combinedRangeXYPlot16.getSubplots();
        java.util.List list20 = combinedRangeXYPlot16.getSubplots();
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        combinedRangeXYPlot16.zoomDomainAxes((double) ' ', plotRenderingInfo24, point2D27);
        categoryPlot9.handleClick((int) (short) 0, 8, plotRenderingInfo24);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("PlotOrientation.HORIZONTAL", (java.awt.Paint) color31);
        legendItem32.setDescription("PlotOrientation.HORIZONTAL");
        org.jfree.data.general.Dataset dataset35 = null;
        legendItem32.setDataset(dataset35);
        java.lang.String str37 = legendItem32.getLabel();
        java.awt.Shape shape38 = legendItem32.getShape();
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint42 = combinedRangeXYPlot41.getDomainZeroBaselinePaint();
        textTitle40.setBackgroundPaint(paint42);
        textTitle40.setExpandToFitSpace(true);
        org.jfree.chart.entity.TitleEntity titleEntity47 = new org.jfree.chart.entity.TitleEntity(shape38, (org.jfree.chart.title.Title) textTitle40, "ThreadContext");
        java.awt.geom.Rectangle2D rectangle2D48 = textTitle40.getBounds();
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.awt.Font font51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("PlotOrientation.HORIZONTAL", font51);
        labelBlock52.setWidth((double) (-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation55 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        boolean boolean56 = labelBlock52.equals((java.lang.Object) plotOrientation55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation49, plotOrientation55);
        boolean boolean58 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge57);
        org.jfree.chart.axis.AxisSpace axisSpace59 = new org.jfree.chart.axis.AxisSpace();
        double double60 = axisSpace59.getTop();
        axisSpace59.setBottom((-16.0d));
        try {
            org.jfree.chart.axis.AxisSpace axisSpace63 = dateAxis2.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) categoryPlot9, rectangle2D48, rectangleEdge57, axisSpace59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str37.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(plotOrientation55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }
}

