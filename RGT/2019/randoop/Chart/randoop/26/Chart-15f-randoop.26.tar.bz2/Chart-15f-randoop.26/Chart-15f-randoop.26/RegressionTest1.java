import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test1");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test2");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        float[] floatArray6 = new float[] { (byte) 0, (-1), 100L, ' ', 0L };
        float[] floatArray7 = color0.getComponents(floatArray6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { (byte) -1, 100, 100.0f, (short) 0, (-1.0d), (short) 100 };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray21, numberArray28, numberArray35, numberArray42, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "", numberArray50);
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=255,g=0,b=0]", numberArray50);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, (org.jfree.chart.axis.ValueAxis) dateAxis55, categoryItemRenderer56);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        dateAxis55.setAxisLineStroke(stroke60);
        org.jfree.chart.text.TextBlock textBlock62 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.RingPlot ringPlot64 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint66 = ringPlot64.getSectionOutlinePaint((java.lang.Comparable) false);
        java.awt.Font font67 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        ringPlot64.setNoDataMessageFont(font67);
        org.jfree.chart.plot.RingPlot ringPlot69 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = ringPlot69.getLabelPadding();
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint73 = categoryAxis72.getAxisLinePaint();
        ringPlot69.setLabelOutlinePaint(paint73);
        textBlock62.addLine("java.awt.Color[r=255,g=0,b=0]", font67, paint73);
        dateAxis55.setLabelFont(font67);
        org.jfree.data.general.PieDataset pieDataset77 = null;
        org.jfree.chart.plot.PiePlot piePlot78 = new org.jfree.chart.plot.PiePlot(pieDataset77);
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        categoryAxis80.configure();
        java.awt.Font font83 = categoryAxis80.getLabelFont();
        boolean boolean84 = piePlot78.equals((java.lang.Object) categoryAxis80);
        org.jfree.chart.util.Rotation rotation85 = piePlot78.getDirection();
        org.jfree.chart.JFreeChart jFreeChart87 = new org.jfree.chart.JFreeChart("", font67, (org.jfree.chart.plot.Plot) piePlot78, true);
        textTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart87);
        java.awt.Image image89 = jFreeChart87.getBackgroundImage();
        java.lang.Object obj90 = jFreeChart87.clone();
        boolean boolean91 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) floatArray6, obj90);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(font83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(rotation85);
        org.junit.Assert.assertNull(image89);
        org.junit.Assert.assertNotNull(obj90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }
}

