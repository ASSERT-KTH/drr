import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) (byte) 0, 100);
//        java.lang.String str8 = timePeriodValues1.getDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        int int10 = year9.getYear();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year9, (double) 8);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues14.addChangeListener(seriesChangeListener15);
//        timePeriodValues14.setDescription("hi!");
//        boolean boolean19 = timePeriodValues14.getNotify();
//        timePeriodValues14.setRangeDescription("");
//        boolean boolean22 = timePeriodValues14.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timePeriodValues24.addChangeListener(seriesChangeListener25);
//        timePeriodValues24.fireSeriesChanged();
//        timePeriodValues24.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, (java.lang.Number) 1.0f);
//        long long34 = day30.getMiddleMillisecond();
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) day30, (double) 100L);
//        java.util.Date date37 = day30.getEnd();
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day30, (double) 0);
//        int int40 = timePeriodValues14.getItemCount();
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = timePeriodValues14.createCopy(11, (int) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
//        timePeriodValues45.addChangeListener(seriesChangeListener46);
//        timePeriodValues45.fireSeriesChanged();
//        timePeriodValues45.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day51, (java.lang.Number) 1.0f);
//        long long55 = day51.getMiddleMillisecond();
//        timePeriodValues45.add((org.jfree.data.time.TimePeriod) day51, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue59 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day51, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate60 = day51.getSerialDate();
//        int int61 = day51.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day51.previous();
//        timePeriodValues43.add((org.jfree.data.time.TimePeriod) regularTimePeriod62, (double) 43629L);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod62, (java.lang.Number) 6);
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560452399999L + "'", long34 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(timePeriodValues43);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560452399999L + "'", long55 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        java.lang.Object obj7 = timePeriodValues1.clone();
        try {
            timePeriodValues1.update(0, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues7.addChangeListener(seriesChangeListener8);
//        timePeriodValues7.fireSeriesChanged();
//        timePeriodValues7.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 1.0f);
//        long long17 = day13.getMiddleMillisecond();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day13, (double) 100L);
//        java.util.Date date20 = day13.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20, timeZone23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date20, timeZone25);
//        int int27 = day0.compareTo((java.lang.Object) date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues29.addChangeListener(seriesChangeListener30);
//        timePeriodValues29.fireSeriesChanged();
//        timePeriodValues29.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0f);
//        long long39 = day35.getMiddleMillisecond();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day35, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day35.previous();
//        org.jfree.data.time.SerialDate serialDate43 = day35.getSerialDate();
//        long long44 = day35.getLastMillisecond();
//        int int45 = day0.compareTo((java.lang.Object) day35);
//        org.jfree.data.time.SerialDate serialDate46 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560452399999L + "'", long17 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560452399999L + "'", long39 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560495599999L + "'", long44 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(serialDate46);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
//        int int16 = day7.getDayOfMonth();
//        java.lang.String str17 = day7.toString();
//        int int18 = day7.getMonth();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        boolean boolean18 = year15.equals((java.lang.Object) 0.0f);
//        int int19 = day7.compareTo((java.lang.Object) year15);
//        long long20 = year15.getFirstMillisecond();
//        long long21 = year15.getSerialIndex();
//        int int22 = year15.getYear();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy((int) (short) -1, (int) '4');
        java.lang.String str10 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, 1560495599999L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timePeriodValues4.addChangeListener(seriesChangeListener5);
//        timePeriodValues4.fireSeriesChanged();
//        timePeriodValues4.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        long long14 = day10.getMiddleMillisecond();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day10, (double) 100L);
//        java.util.Date date17 = day10.getEnd();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17, timeZone20);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timePeriodValues24.addChangeListener(seriesChangeListener25);
//        timePeriodValues24.fireSeriesChanged();
//        timePeriodValues24.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, (java.lang.Number) 1.0f);
//        long long34 = day30.getMiddleMillisecond();
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) day30, (double) 100L);
//        java.util.Date date37 = day30.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date37, timeZone38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date17, date37);
//        long long42 = simpleTimePeriod41.getStartMillis();
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
//        timePeriodValues45.addChangeListener(seriesChangeListener46);
//        timePeriodValues45.fireSeriesChanged();
//        timePeriodValues45.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day51, (java.lang.Number) 1.0f);
//        long long55 = day51.getMiddleMillisecond();
//        timePeriodValues45.add((org.jfree.data.time.TimePeriod) day51, (double) 100L);
//        java.util.Date date58 = day51.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date58, timeZone59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.next();
//        boolean boolean63 = simpleTimePeriod41.equals((java.lang.Object) regularTimePeriod62);
//        java.lang.Class<?> wildcardClass64 = regularTimePeriod62.getClass();
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class65);
//        boolean boolean67 = simpleTimePeriod2.equals((java.lang.Object) class66);
//        java.util.Date date68 = simpleTimePeriod2.getEnd();
//        java.util.Date date69 = simpleTimePeriod2.getEnd();
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560452399999L + "'", long34 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560495599999L + "'", long42 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560452399999L + "'", long55 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(date69);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        java.lang.String str5 = seriesException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        java.lang.String str9 = seriesException8.toString();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        java.lang.String str12 = seriesException11.toString();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.Throwable[] throwableArray14 = seriesException11.getSuppressed();
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException11.addSuppressed((java.lang.Throwable) seriesException16);
        seriesException4.addSuppressed((java.lang.Throwable) seriesException16);
        java.lang.Throwable throwable19 = null;
        try {
            seriesException16.addSuppressed(throwable19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str9.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str12.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setRangeDescription("");
//        boolean boolean9 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) 0);
//        int int27 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues1.createCopy(11, (int) (byte) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timePeriodValues32.addChangeListener(seriesChangeListener33);
//        timePeriodValues32.fireSeriesChanged();
//        timePeriodValues32.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        int int39 = day38.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) 1.0f);
//        long long42 = day38.getMiddleMillisecond();
//        timePeriodValues32.add((org.jfree.data.time.TimePeriod) day38, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate47 = day38.getSerialDate();
//        int int48 = day38.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day38.previous();
//        timePeriodValues30.add((org.jfree.data.time.TimePeriod) regularTimePeriod49, (double) 43629L);
//        timePeriodValues30.setRangeDescription("TimePeriodValue[13-June-2019,1.0]");
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(timePeriodValues30);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560452399999L + "'", long42 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Class<?> wildcardClass4 = seriesException1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        long long39 = simpleTimePeriod38.getStartMillis();
//        long long40 = simpleTimePeriod38.getEndMillis();
//        java.util.Date date41 = simpleTimePeriod38.getStart();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560495599999L + "'", long40 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date41);
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        int int15 = day7.getYear();
//        long long16 = day7.getSerialIndex();
//        long long17 = day7.getLastMillisecond();
//        long long18 = day7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) 1560409200000L);
        java.lang.Object obj7 = timePeriodValue6.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(obj7);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        java.lang.String str5 = timePeriodValues1.getDomainDescription();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues8.addChangeListener(seriesChangeListener9);
//        timePeriodValues8.fireSeriesChanged();
//        timePeriodValues8.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 1.0f);
//        long long18 = day14.getMiddleMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day14, (double) 100L);
//        java.util.Date date21 = day14.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        java.lang.Class class25 = null;
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timePeriodValues28.addChangeListener(seriesChangeListener29);
//        timePeriodValues28.fireSeriesChanged();
//        timePeriodValues28.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 1.0f);
//        long long38 = day34.getMiddleMillisecond();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day34, (double) 100L);
//        java.util.Date date41 = day34.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date41, timeZone42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date41, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date21, timeZone44);
//        long long47 = day46.getLastMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day46, (double) 8);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        java.lang.String str51 = year50.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
//        timePeriodValues53.addChangeListener(seriesChangeListener54);
//        timePeriodValues53.fireSeriesChanged();
//        timePeriodValues53.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        int int60 = day59.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day59, (java.lang.Number) 1.0f);
//        long long63 = day59.getMiddleMillisecond();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) day59, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day59, (java.lang.Number) 1);
//        java.lang.Object obj68 = timePeriodValue67.clone();
//        int int69 = year50.compareTo((java.lang.Object) timePeriodValue67);
//        int int70 = day46.compareTo((java.lang.Object) year50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year50.next();
//        long long72 = year50.getMiddleMillisecond();
//        java.util.Date date73 = year50.getEnd();
//        org.jfree.data.time.TimePeriodValue timePeriodValue75 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year50, (double) 9);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560452399999L + "'", long38 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560495599999L + "'", long47 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019" + "'", str51.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560452399999L + "'", long63 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1562097599999L + "'", long72 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date73);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getSerialIndex();
        java.util.Date date4 = year0.getStart();
        java.util.Date date5 = year0.getEnd();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        java.lang.String str17 = day7.toString();
//        int int18 = day7.getMonth();
//        java.util.Date date19 = day7.getEnd();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        int int7 = timePeriodValues1.getItemCount();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        int int17 = day7.getMonth();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues20.addChangeListener(seriesChangeListener21);
//        timePeriodValues20.fireSeriesChanged();
//        timePeriodValues20.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 1.0f);
//        long long30 = day26.getMiddleMillisecond();
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day26, (double) 100L);
//        java.util.Date date33 = day26.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date33, timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33);
//        java.lang.Class class37 = null;
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timePeriodValues40.addChangeListener(seriesChangeListener41);
//        timePeriodValues40.fireSeriesChanged();
//        timePeriodValues40.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 1.0f);
//        long long50 = day46.getMiddleMillisecond();
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) day46, (double) 100L);
//        java.util.Date date53 = day46.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date53, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date33, timeZone56);
//        int int59 = day7.compareTo((java.lang.Object) date33);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date33);
//        long long61 = day60.getLastMillisecond();
//        int int62 = day60.getMonth();
//        int int63 = day60.getMonth();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560452399999L + "'", long30 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560452399999L + "'", long50 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        long long39 = simpleTimePeriod38.getStartMillis();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timePeriodValues42.addChangeListener(seriesChangeListener43);
//        timePeriodValues42.fireSeriesChanged();
//        timePeriodValues42.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 1.0f);
//        long long52 = day48.getMiddleMillisecond();
//        timePeriodValues42.add((org.jfree.data.time.TimePeriod) day48, (double) 100L);
//        java.util.Date date55 = day48.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date55, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.next();
//        boolean boolean60 = simpleTimePeriod38.equals((java.lang.Object) regularTimePeriod59);
//        java.lang.Class<?> wildcardClass61 = regularTimePeriod59.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        int int64 = day63.getYear();
//        long long65 = day63.getFirstMillisecond();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass67 = timeZone66.getClass();
//        java.lang.Class class68 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass67);
//        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener71 = null;
//        timePeriodValues70.addChangeListener(seriesChangeListener71);
//        timePeriodValues70.fireSeriesChanged();
//        timePeriodValues70.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        int int77 = day76.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue79 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day76, (java.lang.Number) 1.0f);
//        long long80 = day76.getMiddleMillisecond();
//        timePeriodValues70.add((org.jfree.data.time.TimePeriod) day76, (double) 100L);
//        java.util.Date date83 = day76.getEnd();
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date83);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date83);
//        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date83, timeZone86);
//        java.util.TimeZone timeZone88 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date83, timeZone88);
//        int int90 = day63.compareTo((java.lang.Object) date83);
//        java.util.TimeZone timeZone91 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date83, timeZone91);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560452399999L + "'", long52 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560409200000L + "'", long65 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(class68);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560452399999L + "'", long80 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone86);
//        org.junit.Assert.assertNull(regularTimePeriod89);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod92);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        int int15 = day7.getYear();
//        int int16 = day7.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        boolean boolean18 = year15.equals((java.lang.Object) 0.0f);
//        int int19 = day7.compareTo((java.lang.Object) year15);
//        java.util.Date date20 = year15.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getYear();
//        long long24 = day22.getFirstMillisecond();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass26 = timeZone25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues29.addChangeListener(seriesChangeListener30);
//        timePeriodValues29.fireSeriesChanged();
//        timePeriodValues29.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0f);
//        long long39 = day35.getMiddleMillisecond();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day35, (double) 100L);
//        java.util.Date date42 = day35.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date42, timeZone45);
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date42, timeZone47);
//        int int49 = day22.compareTo((java.lang.Object) date42);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date42);
//        long long52 = year51.getFirstMillisecond();
//        java.util.Calendar calendar53 = null;
//        try {
//            long long54 = year51.getLastMillisecond(calendar53);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560452399999L + "'", long39 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1546329600000L + "'", long52 == 1546329600000L);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', 1560409200000L);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        long long5 = simpleTimePeriod2.getStartMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues7.addChangeListener(seriesChangeListener8);
//        timePeriodValues7.setDescription("hi!");
//        boolean boolean12 = timePeriodValues7.getNotify();
//        timePeriodValues7.setKey((java.lang.Comparable) 100);
//        timePeriodValues7.setRangeDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timePeriodValues18.addChangeListener(seriesChangeListener19);
//        timePeriodValues18.fireSeriesChanged();
//        timePeriodValues18.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        int int25 = day24.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 1.0f);
//        long long28 = day24.getMiddleMillisecond();
//        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day24, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) 1);
//        java.lang.Object obj33 = timePeriodValue32.clone();
//        timePeriodValues7.add(timePeriodValue32);
//        boolean boolean35 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560452399999L + "'", long28 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinEndIndex();
//        int int5 = timePeriodValues1.getMinEndIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
//        int int7 = timePeriodValues1.getMinMiddleIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        java.lang.Object obj9 = timePeriodValues1.clone();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.lang.String str11 = year10.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timePeriodValues13.addChangeListener(seriesChangeListener14);
//        timePeriodValues13.fireSeriesChanged();
//        timePeriodValues13.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 1.0f);
//        long long23 = day19.getMiddleMillisecond();
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day19, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 1);
//        java.lang.Object obj28 = timePeriodValue27.clone();
//        int int29 = year10.compareTo((java.lang.Object) timePeriodValue27);
//        long long30 = year10.getSerialIndex();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (short) -1);
//        java.util.Calendar calendar33 = null;
//        try {
//            year10.peg(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560452399999L + "'", long23 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
        try {
            java.lang.Number number9 = timePeriodValues1.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Object obj12 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        int int14 = timePeriodValues1.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues1.getDataItem(0);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues1.getDataItem(3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timePeriodValue16);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 6);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getFirstMillisecond();
        int int3 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        long long2 = year0.getLastMillisecond();
//        long long3 = year0.getSerialIndex();
//        long long4 = year0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        long long6 = year0.getSerialIndex();
//        java.lang.Class class7 = null;
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        timePeriodValues10.fireSeriesChanged();
//        timePeriodValues10.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 1.0f);
//        long long20 = day16.getMiddleMillisecond();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day16, (double) 100L);
//        java.util.Date date23 = day16.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date23, timeZone24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date23, timeZone26);
//        int int28 = year0.compareTo((java.lang.Object) timeZone26);
//        long long29 = year0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560452399999L + "'", long20 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setRangeDescription("");
//        boolean boolean9 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) 0);
//        int int27 = timePeriodValues1.getItemCount();
//        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
//        boolean boolean5 = day0.equals((java.lang.Object) "");
//        java.util.Date date6 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinEndIndex();
//        timePeriodValues1.setRangeDescription("hi!");
//        java.lang.String str7 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues9.addChangeListener(seriesChangeListener10);
//        timePeriodValues9.setDescription("hi!");
//        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str16 = seriesException15.toString();
//        boolean boolean17 = timePeriodValues9.equals((java.lang.Object) str16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) 1.0f);
//        java.lang.Number number22 = timePeriodValue21.getValue();
//        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue21.getPeriod();
//        timePeriodValues9.add(timePeriodValue21);
//        boolean boolean25 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timePeriodValues28.addChangeListener(seriesChangeListener29);
//        timePeriodValues28.fireSeriesChanged();
//        timePeriodValues28.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 1.0f);
//        long long38 = day34.getMiddleMillisecond();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day34, (double) 100L);
//        java.util.Date date41 = day34.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date41, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date41);
//        java.lang.Class class45 = null;
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
//        timePeriodValues48.addChangeListener(seriesChangeListener49);
//        timePeriodValues48.fireSeriesChanged();
//        timePeriodValues48.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        int int55 = day54.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (java.lang.Number) 1.0f);
//        long long58 = day54.getMiddleMillisecond();
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) day54, (double) 100L);
//        java.util.Date date61 = day54.getEnd();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date61, timeZone62);
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date61, timeZone64);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date41, timeZone64);
//        long long67 = day66.getLastMillisecond();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day66, (double) 1);
//        long long70 = day66.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str16.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1.0f + "'", number22.equals(1.0f));
//        org.junit.Assert.assertNotNull(timePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560452399999L + "'", long38 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560452399999L + "'", long58 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560495599999L + "'", long67 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 43629L + "'", long70 == 43629L);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) (byte) 0, 100);
//        java.lang.String str8 = timePeriodValues1.getDescription();
//        java.lang.String str9 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date24, timeZone27);
//        java.lang.String str29 = year28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.next();
//        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod30);
//        boolean boolean32 = timePeriodValues1.isEmpty();
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setRangeDescription("");
//        boolean boolean9 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) 0);
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = timePeriodValues1.getDataItem(0);
//        int int29 = timePeriodValues1.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener30);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timePeriodValue28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        java.util.Date date39 = simpleTimePeriod38.getStart();
//        java.util.Date date40 = simpleTimePeriod38.getEnd();
//        long long41 = simpleTimePeriod38.getEndMillis();
//        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod38, (-1.0d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560495599999L + "'", long41 == 1560495599999L);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        java.lang.String str17 = day7.toString();
//        int int18 = day7.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day7.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        java.lang.Class class36 = null;
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timePeriodValues39.addChangeListener(seriesChangeListener40);
//        timePeriodValues39.fireSeriesChanged();
//        timePeriodValues39.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        int int46 = day45.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day45, (java.lang.Number) 1.0f);
//        long long49 = day45.getMiddleMillisecond();
//        timePeriodValues39.add((org.jfree.data.time.TimePeriod) day45, (double) 100L);
//        java.util.Date date52 = day45.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date52, timeZone53);
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date52, timeZone55);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date34, timeZone55);
//        int int58 = day7.compareTo((java.lang.Object) year57);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560452399999L + "'", long49 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        boolean boolean18 = year15.equals((java.lang.Object) 0.0f);
//        int int19 = day7.compareTo((java.lang.Object) year15);
//        java.util.Date date20 = year15.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getYear();
//        long long24 = day22.getFirstMillisecond();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass26 = timeZone25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues29.addChangeListener(seriesChangeListener30);
//        timePeriodValues29.fireSeriesChanged();
//        timePeriodValues29.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0f);
//        long long39 = day35.getMiddleMillisecond();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day35, (double) 100L);
//        java.util.Date date42 = day35.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date42, timeZone45);
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date42, timeZone47);
//        int int49 = day22.compareTo((java.lang.Object) date42);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        long long51 = simpleTimePeriod50.getStartMillis();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560452399999L + "'", long39 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        boolean boolean9 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) -1, (int) (byte) 1);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 1.0f);
        timePeriodValues1.add(timePeriodValue16);
        java.lang.Object obj18 = timePeriodValue16.clone();
        boolean boolean20 = timePeriodValue16.equals((java.lang.Object) 7);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        int int23 = timePeriodValues22.getMaxEndIndex();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day24, (java.lang.Number) (-1L));
        boolean boolean27 = timePeriodValue16.equals((java.lang.Object) (-1L));
        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue16.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod28, "org.jfree.data.general.SeriesException: 13-June-2019", "org.jfree.data.time.TimePeriodFormatException: 2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues31.addChangeListener(seriesChangeListener32);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timePeriod28);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        java.lang.String str17 = day7.toString();
//        int int18 = day7.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues20.addChangeListener(seriesChangeListener21);
//        timePeriodValues20.fireSeriesChanged();
//        timePeriodValues20.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 1.0f);
//        long long30 = day26.getMiddleMillisecond();
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day26, (double) 100L);
//        java.util.Date date33 = day26.getEnd();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date33, timeZone36);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timePeriodValues40.addChangeListener(seriesChangeListener41);
//        timePeriodValues40.fireSeriesChanged();
//        timePeriodValues40.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 1.0f);
//        long long50 = day46.getMiddleMillisecond();
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) day46, (double) 100L);
//        java.util.Date date53 = day46.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date53, timeZone54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date53);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date33, date53);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass59 = timeZone58.getClass();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date53, timeZone58);
//        int int61 = day7.compareTo((java.lang.Object) day60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day7.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "TimePeriodValue[13-June-2019,1.0]", "org.jfree.data.general.SeriesException: 13-June-2019");
//        java.lang.String str66 = timePeriodValues65.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560452399999L + "'", long30 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560452399999L + "'", long50 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str66.equals("TimePeriodValue[13-June-2019,1.0]"));
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day3);
//        java.lang.Object obj5 = seriesChangeEvent4.getSource();
//        java.lang.String str6 = seriesChangeEvent4.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) (byte) 10);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) (byte) 10);
//        java.util.Date date9 = simpleTimePeriod8.getEnd();
//        java.util.Date date10 = simpleTimePeriod8.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass12 = timeZone11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timePeriodValues15.addChangeListener(seriesChangeListener16);
//        timePeriodValues15.fireSeriesChanged();
//        timePeriodValues15.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        int int22 = day21.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) 1.0f);
//        long long25 = day21.getMiddleMillisecond();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day21, (double) 100L);
//        java.util.Date date28 = day21.getEnd();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date28, timeZone31);
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date28, timeZone33);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timePeriodValues37.addChangeListener(seriesChangeListener38);
//        timePeriodValues37.fireSeriesChanged();
//        timePeriodValues37.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        int int44 = day43.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, (java.lang.Number) 1.0f);
//        long long47 = day43.getMiddleMillisecond();
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day43, (double) 100L);
//        java.util.Date date50 = day43.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date28, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone51);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date3, date10);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date10);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560452399999L + "'", long25 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560452399999L + "'", long47 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        int int6 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        timePeriodValues1.setNotify(true);
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues1.createCopy((int) 'a', (int) '4');
        timePeriodValues1.fireSeriesChanged();
        int int16 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues1.getDomainDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getYear();
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setRangeDescription("");
//        boolean boolean9 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) 0);
//        long long27 = day17.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 97L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560452399999L + "'", long27 == 1560452399999L);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.addChangeListener(seriesChangeListener6);
//        timePeriodValues5.fireSeriesChanged();
//        timePeriodValues5.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 1.0f);
//        long long15 = day11.getMiddleMillisecond();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (double) 100L);
//        java.util.Date date18 = day11.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date18, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timePeriodValues25.addChangeListener(seriesChangeListener26);
//        timePeriodValues25.fireSeriesChanged();
//        timePeriodValues25.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 1.0f);
//        long long35 = day31.getMiddleMillisecond();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day31, (double) 100L);
//        java.util.Date date38 = day31.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date38, timeZone39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date18, date38);
//        java.util.Date date43 = simpleTimePeriod42.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
//        timePeriodValues45.addChangeListener(seriesChangeListener46);
//        timePeriodValues45.fireSeriesChanged();
//        timePeriodValues45.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day51, (java.lang.Number) 1.0f);
//        long long55 = day51.getMiddleMillisecond();
//        timePeriodValues45.add((org.jfree.data.time.TimePeriod) day51, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day51.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod58);
//        boolean boolean60 = simpleTimePeriod42.equals((java.lang.Object) timePeriodValues59);
//        long long61 = simpleTimePeriod42.getStartMillis();
//        java.util.Date date62 = simpleTimePeriod42.getEnd();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
//        boolean boolean64 = timePeriodValue3.equals((java.lang.Object) date62);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560452399999L + "'", long35 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560452399999L + "'", long55 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date14, timeZone19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timePeriodValues22.addChangeListener(seriesChangeListener23);
//        timePeriodValues22.fireSeriesChanged();
//        timePeriodValues22.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 1.0f);
//        long long32 = day28.getMiddleMillisecond();
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day28, (double) 100L);
//        java.util.Date date35 = day28.getEnd();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        int int37 = year36.getYear();
//        boolean boolean39 = year36.equals((java.lang.Object) 0.0f);
//        int int40 = day28.compareTo((java.lang.Object) year36);
//        java.util.Date date41 = year36.getStart();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timePeriodValues44.addChangeListener(seriesChangeListener45);
//        timePeriodValues44.fireSeriesChanged();
//        timePeriodValues44.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        int int51 = day50.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue53 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day50, (java.lang.Number) 1.0f);
//        long long54 = day50.getMiddleMillisecond();
//        timePeriodValues44.add((org.jfree.data.time.TimePeriod) day50, (double) 100L);
//        java.util.Date date57 = day50.getEnd();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date57);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date57, timeZone60);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
//        timePeriodValues64.addChangeListener(seriesChangeListener65);
//        timePeriodValues64.fireSeriesChanged();
//        timePeriodValues64.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        int int71 = day70.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day70, (java.lang.Number) 1.0f);
//        long long74 = day70.getMiddleMillisecond();
//        timePeriodValues64.add((org.jfree.data.time.TimePeriod) day70, (double) 100L);
//        java.util.Date date77 = day70.getEnd();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date77, timeZone78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date77);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod81 = new org.jfree.data.time.SimpleTimePeriod(date57, date77);
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass83 = timeZone82.getClass();
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date77, timeZone82);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date41, timeZone82);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date14, timeZone82);
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day();
//        int int88 = day87.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue90 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day87, (java.lang.Number) 1.0f);
//        java.lang.Number number91 = timePeriodValue90.getValue();
//        org.jfree.data.time.TimePeriod timePeriod92 = timePeriodValue90.getPeriod();
//        org.jfree.data.time.TimePeriodValue timePeriodValue94 = new org.jfree.data.time.TimePeriodValue(timePeriod92, (java.lang.Number) 1560452399999L);
//        boolean boolean95 = day86.equals((java.lang.Object) timePeriod92);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560452399999L + "'", long32 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560452399999L + "'", long54 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2019 + "'", int71 == 2019);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560452399999L + "'", long74 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNotNull(wildcardClass83);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2019 + "'", int88 == 2019);
//        org.junit.Assert.assertTrue("'" + number91 + "' != '" + 1.0f + "'", number91.equals(1.0f));
//        org.junit.Assert.assertNotNull(timePeriod92);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        boolean boolean9 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) -1, (int) (byte) 1);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 1.0f);
        timePeriodValues1.add(timePeriodValue16);
        java.lang.Object obj18 = timePeriodValue16.clone();
        java.lang.Object obj19 = timePeriodValue16.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj19);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        java.lang.String str17 = day7.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues19.addChangeListener(seriesChangeListener20);
//        int int22 = timePeriodValues19.getMinEndIndex();
//        int int23 = timePeriodValues19.getMinEndIndex();
//        java.lang.String str24 = timePeriodValues19.getRangeDescription();
//        int int25 = day7.compareTo((java.lang.Object) str24);
//        java.util.Date date26 = day7.getEnd();
//        long long27 = day7.getSerialIndex();
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = day7.getMiddleMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43629L + "'", long27 == 43629L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) (byte) 0, 100);
        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues10.addChangeListener(seriesChangeListener11);
        timePeriodValues10.fireSeriesChanged();
        java.lang.String str14 = timePeriodValues10.getDomainDescription();
        int int15 = timePeriodValues10.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener16);
        timePeriodValues10.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues10.addChangeListener(seriesChangeListener20);
        timePeriodValues10.setNotify(false);
        boolean boolean24 = timePeriodValues7.equals((java.lang.Object) timePeriodValues10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean24);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str8 = seriesException7.toString();
//        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) str8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        java.lang.Number number14 = timePeriodValue13.getValue();
//        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue13.getPeriod();
//        timePeriodValues1.add(timePeriodValue13);
//        int int17 = timePeriodValues1.getItemCount();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues20.addChangeListener(seriesChangeListener21);
//        timePeriodValues20.fireSeriesChanged();
//        timePeriodValues20.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) 1.0f);
//        long long30 = day26.getMiddleMillisecond();
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day26, (double) 100L);
//        java.util.Date date33 = day26.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date33, timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33);
//        java.lang.Class class37 = null;
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timePeriodValues40.addChangeListener(seriesChangeListener41);
//        timePeriodValues40.fireSeriesChanged();
//        timePeriodValues40.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 1.0f);
//        long long50 = day46.getMiddleMillisecond();
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) day46, (double) 100L);
//        java.util.Date date53 = day46.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date53, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date33, timeZone56);
//        long long59 = day58.getFirstMillisecond();
//        java.lang.String str60 = day58.toString();
//        boolean boolean61 = timePeriodValues1.equals((java.lang.Object) str60);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0f + "'", number14.equals(1.0f));
//        org.junit.Assert.assertNotNull(timePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560452399999L + "'", long30 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560452399999L + "'", long50 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560409200000L + "'", long59 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "13-June-2019" + "'", str60.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timePeriodValues2.addChangeListener(seriesChangeListener3);
//        timePeriodValues2.fireSeriesChanged();
//        timePeriodValues2.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 1.0f);
//        long long12 = day8.getMiddleMillisecond();
//        timePeriodValues2.add((org.jfree.data.time.TimePeriod) day8, (double) 100L);
//        java.util.Date date15 = day8.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        java.lang.Class class19 = null;
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timePeriodValues22.addChangeListener(seriesChangeListener23);
//        timePeriodValues22.fireSeriesChanged();
//        timePeriodValues22.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 1.0f);
//        long long32 = day28.getMiddleMillisecond();
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day28, (double) 100L);
//        java.util.Date date35 = day28.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date35, timeZone36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date35, timeZone38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date15, timeZone38);
//        long long41 = day40.getMiddleMillisecond();
//        java.lang.String str42 = day40.toString();
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560452399999L + "'", long32 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560452399999L + "'", long41 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener10);
        try {
            java.lang.Number number13 = timePeriodValues1.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        java.util.Date date39 = simpleTimePeriod38.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
//        timePeriodValues41.addChangeListener(seriesChangeListener42);
//        timePeriodValues41.fireSeriesChanged();
//        timePeriodValues41.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        int int48 = day47.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue50 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day47, (java.lang.Number) 1.0f);
//        long long51 = day47.getMiddleMillisecond();
//        timePeriodValues41.add((org.jfree.data.time.TimePeriod) day47, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day47.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod54);
//        boolean boolean56 = simpleTimePeriod38.equals((java.lang.Object) timePeriodValues55);
//        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean56);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560452399999L + "'", long51 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 10, 1560495599999L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timePeriodValues4.addChangeListener(seriesChangeListener5);
//        timePeriodValues4.fireSeriesChanged();
//        timePeriodValues4.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        long long14 = day10.getMiddleMillisecond();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day10, (double) 100L);
//        java.util.Date date17 = day10.getEnd();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17, timeZone20);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timePeriodValues24.addChangeListener(seriesChangeListener25);
//        timePeriodValues24.fireSeriesChanged();
//        timePeriodValues24.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int31 = day30.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, (java.lang.Number) 1.0f);
//        long long34 = day30.getMiddleMillisecond();
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) day30, (double) 100L);
//        java.util.Date date37 = day30.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date37, timeZone38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date17, date37);
//        long long42 = simpleTimePeriod41.getStartMillis();
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
//        timePeriodValues45.addChangeListener(seriesChangeListener46);
//        timePeriodValues45.fireSeriesChanged();
//        timePeriodValues45.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        int int52 = day51.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day51, (java.lang.Number) 1.0f);
//        long long55 = day51.getMiddleMillisecond();
//        timePeriodValues45.add((org.jfree.data.time.TimePeriod) day51, (double) 100L);
//        java.util.Date date58 = day51.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date58, timeZone59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.next();
//        boolean boolean63 = simpleTimePeriod41.equals((java.lang.Object) regularTimePeriod62);
//        java.lang.Class<?> wildcardClass64 = regularTimePeriod62.getClass();
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize(class65);
//        boolean boolean67 = simpleTimePeriod2.equals((java.lang.Object) class66);
//        java.util.Date date68 = simpleTimePeriod2.getStart();
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560452399999L + "'", long34 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560495599999L + "'", long42 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560452399999L + "'", long55 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(date68);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1L));
        int int2 = timePeriodValues1.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue4 = timePeriodValues1.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        java.lang.String str5 = timePeriodValues1.getDomainDescription();
//        int int6 = timePeriodValues1.getMinMiddleIndex();
//        int int7 = timePeriodValues1.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date24, timeZone27);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timePeriodValues31.addChangeListener(seriesChangeListener32);
//        timePeriodValues31.fireSeriesChanged();
//        timePeriodValues31.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) 1.0f);
//        long long41 = day37.getMiddleMillisecond();
//        timePeriodValues31.add((org.jfree.data.time.TimePeriod) day37, (double) 100L);
//        java.util.Date date44 = day37.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date44, timeZone45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date24, date44);
//        java.util.Date date49 = simpleTimePeriod48.getStart();
//        java.util.Date date50 = simpleTimePeriod48.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timePeriodValues52.addChangeListener(seriesChangeListener53);
//        timePeriodValues52.fireSeriesChanged();
//        timePeriodValues52.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        int int59 = day58.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue61 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day58, (java.lang.Number) 1.0f);
//        long long62 = day58.getMiddleMillisecond();
//        timePeriodValues52.add((org.jfree.data.time.TimePeriod) day58, (double) 100L);
//        java.util.Date date65 = day58.getEnd();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date65);
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date65, timeZone68);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date50, date65);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, (java.lang.Number) 8);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, (java.lang.Number) (-1));
//        timePeriodValues1.setNotify(false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560452399999L + "'", long41 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560452399999L + "'", long62 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone68);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        int int6 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener11);
        java.lang.String str13 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj14 = timePeriodValues1.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues1.createCopy((int) (byte) 10, 0);
        int int18 = timePeriodValues17.getMaxEndIndex();
        try {
            java.lang.Number number20 = timePeriodValues17.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        int int15 = day7.getYear();
//        int int16 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate17 = day7.getSerialDate();
//        int int18 = day7.getYear();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        boolean boolean7 = timePeriodValues1.isEmpty();
        try {
            java.lang.Number number9 = timePeriodValues1.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        boolean boolean7 = timePeriodValues1.isEmpty();
        timePeriodValues1.setNotify(true);
        java.lang.Object obj10 = null;
        boolean boolean11 = timePeriodValues1.equals(obj10);
        boolean boolean12 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues1.createCopy((int) (short) 0, 13);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,3]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        java.lang.Object obj7 = timePeriodValues1.clone();
        timePeriodValues1.setDomainDescription("hi!");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) (byte) 0, 100);
        java.lang.String str8 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year9, (double) 8);
        java.lang.Object obj13 = null;
        boolean boolean14 = year9.equals(obj13);
        boolean boolean16 = year9.equals((java.lang.Object) false);
        java.lang.String str17 = year9.toString();
        long long18 = year9.getLastMillisecond();
        long long19 = year9.getSerialIndex();
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1.0f);
//        long long13 = day9.getMiddleMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) 100L);
//        java.util.Date date16 = day9.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date16, timeZone17);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date16, timeZone19);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timePeriodValues25.addChangeListener(seriesChangeListener26);
//        timePeriodValues25.fireSeriesChanged();
//        timePeriodValues25.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 1.0f);
//        long long35 = day31.getMiddleMillisecond();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day31, (double) 100L);
//        java.util.Date date38 = day31.getEnd();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date38, timeZone41);
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date38, timeZone43);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
//        timePeriodValues47.addChangeListener(seriesChangeListener48);
//        timePeriodValues47.fireSeriesChanged();
//        timePeriodValues47.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) 1.0f);
//        long long57 = day53.getMiddleMillisecond();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) day53, (double) 100L);
//        java.util.Date date60 = day53.getEnd();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date60, timeZone61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date38, timeZone61);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date16, timeZone61);
//        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (double) 5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560452399999L + "'", long35 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560452399999L + "'", long57 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(0, (int) (short) 0);
        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + '#' + "'", comparable5.equals('#'));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + '#' + "'", comparable9.equals('#'));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        long long39 = simpleTimePeriod38.getStartMillis();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        int int41 = year40.getYear();
//        long long42 = year40.getLastMillisecond();
//        long long43 = year40.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year40.previous();
//        int int45 = simpleTimePeriod38.compareTo((java.lang.Object) regularTimePeriod44);
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
//        timePeriodValues48.addChangeListener(seriesChangeListener49);
//        timePeriodValues48.fireSeriesChanged();
//        timePeriodValues48.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        int int55 = day54.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (java.lang.Number) 1.0f);
//        long long58 = day54.getMiddleMillisecond();
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) day54, (double) 100L);
//        java.util.Date date61 = day54.getEnd();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date61);
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date61, timeZone64);
//        java.lang.Class class66 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener69 = null;
//        timePeriodValues68.addChangeListener(seriesChangeListener69);
//        timePeriodValues68.fireSeriesChanged();
//        timePeriodValues68.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        int int75 = day74.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue77 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day74, (java.lang.Number) 1.0f);
//        long long78 = day74.getMiddleMillisecond();
//        timePeriodValues68.add((org.jfree.data.time.TimePeriod) day74, (double) 100L);
//        java.util.Date date81 = day74.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date81, timeZone82);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date81);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(date61, date81);
//        long long86 = simpleTimePeriod85.getStartMillis();
//        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year();
//        int int88 = year87.getYear();
//        long long89 = year87.getLastMillisecond();
//        long long90 = year87.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = year87.previous();
//        int int92 = simpleTimePeriod85.compareTo((java.lang.Object) regularTimePeriod91);
//        org.jfree.data.time.TimePeriodValues timePeriodValues93 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod85);
//        timePeriodValues46.setKey((java.lang.Comparable) simpleTimePeriod85);
//        java.util.Date date95 = simpleTimePeriod85.getEnd();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1562097599999L + "'", long43 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560452399999L + "'", long58 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560452399999L + "'", long78 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1560495599999L + "'", long86 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2019 + "'", int88 == 2019);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1577865599999L + "'", long89 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1562097599999L + "'", long90 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//        org.junit.Assert.assertNotNull(date95);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        int int1 = year0.getYear();
//        long long2 = year0.getLastMillisecond();
//        long long3 = year0.getSerialIndex();
//        long long4 = year0.getSerialIndex();
//        java.util.Date date5 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues7.addChangeListener(seriesChangeListener8);
//        timePeriodValues7.fireSeriesChanged();
//        timePeriodValues7.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 1.0f);
//        long long17 = day13.getMiddleMillisecond();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day13, (double) 100L);
//        java.util.Date date20 = day13.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20, timeZone23);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timePeriodValues27.addChangeListener(seriesChangeListener28);
//        timePeriodValues27.fireSeriesChanged();
//        timePeriodValues27.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (java.lang.Number) 1.0f);
//        long long37 = day33.getMiddleMillisecond();
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) day33, (double) 100L);
//        java.util.Date date40 = day33.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date40, timeZone41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date40);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date20, date40);
//        java.util.Date date45 = simpleTimePeriod44.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
//        timePeriodValues47.addChangeListener(seriesChangeListener48);
//        timePeriodValues47.fireSeriesChanged();
//        timePeriodValues47.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) 1.0f);
//        long long57 = day53.getMiddleMillisecond();
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) day53, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day53.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod60);
//        boolean boolean62 = simpleTimePeriod44.equals((java.lang.Object) timePeriodValues61);
//        long long63 = simpleTimePeriod44.getStartMillis();
//        java.util.Date date64 = simpleTimePeriod44.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod(date5, date64);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560452399999L + "'", long17 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560452399999L + "'", long37 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560452399999L + "'", long57 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560495599999L + "'", long63 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date64);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        java.lang.String str17 = day7.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues19.addChangeListener(seriesChangeListener20);
//        int int22 = timePeriodValues19.getMinEndIndex();
//        int int23 = timePeriodValues19.getMinEndIndex();
//        java.lang.String str24 = timePeriodValues19.getRangeDescription();
//        int int25 = day7.compareTo((java.lang.Object) str24);
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, number26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues29.addChangeListener(seriesChangeListener30);
//        int int32 = timePeriodValues29.getMinEndIndex();
//        int int33 = timePeriodValues29.getMinEndIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues29);
//        int int35 = timePeriodValues29.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues29.removePropertyChangeListener(propertyChangeListener36);
//        boolean boolean38 = day7.equals((java.lang.Object) timePeriodValues29);
//        int int39 = timePeriodValues29.getItemCount();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1.0f);
//        long long4 = day0.getMiddleMillisecond();
//        boolean boolean6 = day0.equals((java.lang.Object) (byte) 10);
//        int int7 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        java.lang.String str5 = timePeriodValues1.getDomainDescription();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues8.addChangeListener(seriesChangeListener9);
//        timePeriodValues8.fireSeriesChanged();
//        timePeriodValues8.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 1.0f);
//        long long18 = day14.getMiddleMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day14, (double) 100L);
//        java.util.Date date21 = day14.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        java.lang.Class class25 = null;
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timePeriodValues28.addChangeListener(seriesChangeListener29);
//        timePeriodValues28.fireSeriesChanged();
//        timePeriodValues28.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 1.0f);
//        long long38 = day34.getMiddleMillisecond();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day34, (double) 100L);
//        java.util.Date date41 = day34.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date41, timeZone42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date41, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date21, timeZone44);
//        long long47 = day46.getLastMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day46, (double) 8);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        java.lang.String str51 = year50.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
//        timePeriodValues53.addChangeListener(seriesChangeListener54);
//        timePeriodValues53.fireSeriesChanged();
//        timePeriodValues53.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        int int60 = day59.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day59, (java.lang.Number) 1.0f);
//        long long63 = day59.getMiddleMillisecond();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) day59, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day59, (java.lang.Number) 1);
//        java.lang.Object obj68 = timePeriodValue67.clone();
//        int int69 = year50.compareTo((java.lang.Object) timePeriodValue67);
//        int int70 = day46.compareTo((java.lang.Object) year50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year50.next();
//        long long72 = year50.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560452399999L + "'", long38 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560495599999L + "'", long47 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019" + "'", str51.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560452399999L + "'", long63 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1577865599999L + "'", long72 == 1577865599999L);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), (long) 6);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues4.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener10);
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date14, timeZone19);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timePeriodValues23.addChangeListener(seriesChangeListener24);
//        timePeriodValues23.fireSeriesChanged();
//        timePeriodValues23.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 1.0f);
//        long long33 = day29.getMiddleMillisecond();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day29, (double) 100L);
//        java.util.Date date36 = day29.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date36, timeZone37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date14, timeZone37);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year39);
//        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str43 = seriesException42.toString();
//        boolean boolean44 = year39.equals((java.lang.Object) seriesException42);
//        java.lang.Throwable[] throwableArray45 = seriesException42.getSuppressed();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560452399999L + "'", long33 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(throwableArray45);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date14, timeZone19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        int int24 = year23.getYear();
//        long long25 = year23.getLastMillisecond();
//        long long26 = year23.getSerialIndex();
//        long long27 = year23.getSerialIndex();
//        java.util.Date date28 = year23.getStart();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date14, date28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertNotNull(date28);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = regularTimePeriod14.getMiddleMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setRangeDescription("");
//        boolean boolean9 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) 0);
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = timePeriodValues1.getDataItem(0);
//        int int29 = timePeriodValues1.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener30);
//        int int32 = timePeriodValues1.getMinMiddleIndex();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timePeriodValue28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        boolean boolean18 = year15.equals((java.lang.Object) 0.0f);
//        int int19 = day7.compareTo((java.lang.Object) year15);
//        java.util.Date date20 = year15.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getYear();
//        long long24 = day22.getFirstMillisecond();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass26 = timeZone25.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues29.addChangeListener(seriesChangeListener30);
//        timePeriodValues29.fireSeriesChanged();
//        timePeriodValues29.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0f);
//        long long39 = day35.getMiddleMillisecond();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day35, (double) 100L);
//        java.util.Date date42 = day35.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date42, timeZone45);
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date42, timeZone47);
//        int int49 = day22.compareTo((java.lang.Object) date42);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date20, date42);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
//        timePeriodValues54.addChangeListener(seriesChangeListener55);
//        timePeriodValues54.fireSeriesChanged();
//        timePeriodValues54.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        int int61 = day60.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day60, (java.lang.Number) 1.0f);
//        long long64 = day60.getMiddleMillisecond();
//        timePeriodValues54.add((org.jfree.data.time.TimePeriod) day60, (double) 100L);
//        java.util.Date date67 = day60.getEnd();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date67, timeZone68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = day70.previous();
//        int int72 = year51.compareTo((java.lang.Object) day70);
//        boolean boolean73 = simpleTimePeriod50.equals((java.lang.Object) year51);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560452399999L + "'", long39 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560452399999L + "'", long64 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        boolean boolean18 = year15.equals((java.lang.Object) 0.0f);
//        int int19 = day7.compareTo((java.lang.Object) year15);
//        long long20 = year15.getFirstMillisecond();
//        long long21 = year15.getSerialIndex();
//        long long22 = year15.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year15.previous();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setRangeDescription("");
//        boolean boolean9 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) 0);
//        int int27 = timePeriodValues1.getItemCount();
//        timePeriodValues1.setDomainDescription("Value");
//        timePeriodValues1.delete(10, 0);
//        java.lang.Object obj33 = null;
//        boolean boolean34 = timePeriodValues1.equals(obj33);
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.TimePeriod timePeriod38 = timePeriodValues1.getTimePeriod((int) (short) 0);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener39);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue42 = timePeriodValues1.getDataItem(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(timePeriod38);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        java.lang.String str5 = timePeriodValues1.getDomainDescription();
//        int int6 = timePeriodValues1.getMinMiddleIndex();
//        int int7 = timePeriodValues1.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date24, timeZone27);
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timePeriodValues31.addChangeListener(seriesChangeListener32);
//        timePeriodValues31.fireSeriesChanged();
//        timePeriodValues31.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int38 = day37.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) 1.0f);
//        long long41 = day37.getMiddleMillisecond();
//        timePeriodValues31.add((org.jfree.data.time.TimePeriod) day37, (double) 100L);
//        java.util.Date date44 = day37.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date44, timeZone45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date24, date44);
//        java.util.Date date49 = simpleTimePeriod48.getStart();
//        java.util.Date date50 = simpleTimePeriod48.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
//        timePeriodValues52.addChangeListener(seriesChangeListener53);
//        timePeriodValues52.fireSeriesChanged();
//        timePeriodValues52.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        int int59 = day58.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue61 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day58, (java.lang.Number) 1.0f);
//        long long62 = day58.getMiddleMillisecond();
//        timePeriodValues52.add((org.jfree.data.time.TimePeriod) day58, (double) 100L);
//        java.util.Date date65 = day58.getEnd();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date65);
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date65, timeZone68);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date50, date65);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, (java.lang.Number) 8);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, (java.lang.Number) (-1));
//        timePeriodValues1.setNotify(true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560452399999L + "'", long41 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560452399999L + "'", long62 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone68);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.String str19 = year18.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = regularTimePeriod20.getMiddleMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues7.addChangeListener(seriesChangeListener8);
//        timePeriodValues7.fireSeriesChanged();
//        timePeriodValues7.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 1.0f);
//        long long17 = day13.getMiddleMillisecond();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day13, (double) 100L);
//        java.util.Date date20 = day13.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20, timeZone23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date20, timeZone25);
//        int int27 = day0.compareTo((java.lang.Object) date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues29.addChangeListener(seriesChangeListener30);
//        timePeriodValues29.fireSeriesChanged();
//        timePeriodValues29.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        int int36 = day35.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0f);
//        long long39 = day35.getMiddleMillisecond();
//        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day35, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day35.previous();
//        org.jfree.data.time.SerialDate serialDate43 = day35.getSerialDate();
//        long long44 = day35.getLastMillisecond();
//        int int45 = day0.compareTo((java.lang.Object) day35);
//        org.jfree.data.time.SerialDate serialDate46 = day35.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560452399999L + "'", long17 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560452399999L + "'", long39 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560495599999L + "'", long44 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(serialDate46);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 31, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        int int7 = timePeriodValues1.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues1.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        java.lang.String str8 = seriesException7.toString();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) str8);
        timePeriodValues1.delete(0, (int) (short) -1);
        timePeriodValues1.setNotify(false);
        boolean boolean15 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str8 = seriesException7.toString();
//        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) str8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) 1.0f);
//        java.lang.Number number14 = timePeriodValue13.getValue();
//        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue13.getPeriod();
//        timePeriodValues1.add(timePeriodValue13);
//        java.lang.Object obj17 = null;
//        boolean boolean18 = timePeriodValue13.equals(obj17);
//        timePeriodValue13.setValue((java.lang.Number) 3);
//        java.lang.String str21 = timePeriodValue13.toString();
//        java.lang.Number number22 = timePeriodValue13.getValue();
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0f + "'", number14.equals(1.0f));
//        org.junit.Assert.assertNotNull(timePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TimePeriodValue[13-June-2019,3]" + "'", str21.equals("TimePeriodValue[13-June-2019,3]"));
//        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 3 + "'", number22.equals(3));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) (byte) 0, 100);
        timePeriodValues7.setRangeDescription("Time");
        int int10 = timePeriodValues7.getMaxStartIndex();
        timePeriodValues7.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.String str19 = year18.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        int int15 = day7.getYear();
//        long long16 = day7.getSerialIndex();
//        long long17 = day7.getLastMillisecond();
//        int int18 = day7.getYear();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        java.lang.String str5 = timePeriodValues1.getDomainDescription();
//        int int6 = timePeriodValues1.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
//        timePeriodValues1.setNotify(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getRangeDescription();
//        java.lang.Object obj14 = timePeriodValues1.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues1.createCopy((int) (byte) 10, 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues19.addChangeListener(seriesChangeListener20);
//        timePeriodValues19.fireSeriesChanged();
//        timePeriodValues19.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        int int26 = day25.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 1.0f);
//        long long29 = day25.getMiddleMillisecond();
//        timePeriodValues19.add((org.jfree.data.time.TimePeriod) day25, (double) 100L);
//        java.util.Date date32 = day25.getEnd();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        java.util.Date date34 = day33.getStart();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
//        long long37 = year35.getFirstMillisecond();
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timePeriodValues40.addChangeListener(seriesChangeListener41);
//        timePeriodValues40.fireSeriesChanged();
//        timePeriodValues40.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 1.0f);
//        long long50 = day46.getMiddleMillisecond();
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) day46, (double) 100L);
//        java.util.Date date53 = day46.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date53, timeZone54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date53);
//        int int57 = year35.compareTo((java.lang.Object) day56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.next();
//        boolean boolean59 = day33.equals((java.lang.Object) day56);
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day56, (double) 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day56.previous();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertNotNull(timePeriodValues17);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560452399999L + "'", long50 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        long long9 = year7.getFirstMillisecond();
        timePeriodValues1.setKey((java.lang.Comparable) long9);
        int int11 = timePeriodValues1.getMinEndIndex();
        java.lang.Comparable comparable12 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1546329600000L + "'", comparable12.equals(1546329600000L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        int int6 = timePeriodValues1.getMinMiddleIndex();
        int int7 = timePeriodValues1.getMaxEndIndex();
        int int8 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1.0f);
//        long long13 = day9.getMiddleMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1);
//        java.lang.Object obj18 = timePeriodValue17.clone();
//        int int19 = year0.compareTo((java.lang.Object) timePeriodValue17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getLastMillisecond();
//        boolean boolean22 = timePeriodValue17.equals((java.lang.Object) long21);
//        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue17.getPeriod();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue(timePeriod23, (double) 10.0f);
//        java.lang.Object obj26 = null;
//        boolean boolean27 = timePeriodValue25.equals(obj26);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        long long39 = simpleTimePeriod38.getEndMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
//        timePeriodValues41.addChangeListener(seriesChangeListener42);
//        timePeriodValues41.setDescription("hi!");
//        boolean boolean46 = timePeriodValues41.getNotify();
//        timePeriodValues41.setRangeDescription("");
//        boolean boolean49 = timePeriodValues41.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy((int) (short) -1, (int) (byte) 1);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) 1.0f);
//        timePeriodValues41.add(timePeriodValue56);
//        boolean boolean58 = simpleTimePeriod38.equals((java.lang.Object) timePeriodValue56);
//        java.util.Date date59 = simpleTimePeriod38.getEnd();
//        long long60 = simpleTimePeriod38.getEndMillis();
//        long long61 = simpleTimePeriod38.getStartMillis();
//        java.util.Date date62 = simpleTimePeriod38.getStart();
//        java.util.Date date63 = null;
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(date62, date63);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560495599999L + "'", long60 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date62);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) (byte) 0, 100);
        java.lang.Class<?> wildcardClass8 = timePeriodValues7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        long long39 = simpleTimePeriod38.getStartMillis();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timePeriodValues42.addChangeListener(seriesChangeListener43);
//        timePeriodValues42.fireSeriesChanged();
//        timePeriodValues42.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 1.0f);
//        long long52 = day48.getMiddleMillisecond();
//        timePeriodValues42.add((org.jfree.data.time.TimePeriod) day48, (double) 100L);
//        java.util.Date date55 = day48.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date55, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.next();
//        boolean boolean60 = simpleTimePeriod38.equals((java.lang.Object) regularTimePeriod59);
//        long long61 = simpleTimePeriod38.getStartMillis();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560452399999L + "'", long52 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setNotify(true);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        timePeriodValues10.fireSeriesChanged();
//        timePeriodValues10.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 1.0f);
//        long long20 = day16.getMiddleMillisecond();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day16, (double) 100L);
//        java.util.Date date23 = day16.getEnd();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date23, timeZone26);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 1.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = year27.getLastMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560452399999L + "'", long20 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        boolean boolean18 = year15.equals((java.lang.Object) 0.0f);
//        int int19 = day7.compareTo((java.lang.Object) year15);
//        java.util.Date date20 = year15.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        java.lang.Class class22 = null;
//        java.util.Date date23 = null;
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timePeriodValues26.addChangeListener(seriesChangeListener27);
//        timePeriodValues26.fireSeriesChanged();
//        timePeriodValues26.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day32, (java.lang.Number) 1.0f);
//        long long36 = day32.getMiddleMillisecond();
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) day32, (double) 100L);
//        java.util.Date date39 = day32.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone40);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date20, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.next();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560452399999L + "'", long36 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate15);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinEndIndex();
//        timePeriodValues1.setRangeDescription("hi!");
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getYear();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        int int11 = day8.getYear();
//        long long12 = day8.getFirstMillisecond();
//        int int13 = day8.getMonth();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day8, (double) (-1.0f));
//        java.lang.String str16 = day8.toString();
//        int int17 = day8.getDayOfMonth();
//        java.util.Date date18 = day8.getEnd();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertNotNull(date18);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getYear();
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        long long7 = day0.getSerialIndex();
//        int int8 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinEndIndex();
//        int int5 = timePeriodValues1.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues7.addChangeListener(seriesChangeListener8);
//        timePeriodValues7.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues7.createCopy((int) (byte) 0, 100);
//        java.lang.String str14 = timePeriodValues7.getDescription();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year15, (double) 8);
//        timePeriodValues1.setKey((java.lang.Comparable) 8);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 1.0f);
//        long long24 = day20.getMiddleMillisecond();
//        java.lang.String str25 = day20.toString();
//        org.jfree.data.time.SerialDate serialDate26 = day20.getSerialDate();
//        boolean boolean27 = timePeriodValues1.equals((java.lang.Object) day20);
//        timePeriodValues1.setRangeDescription("");
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560452399999L + "'", long24 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
        boolean boolean4 = year0.equals((java.lang.Object) "13-June-2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        int int17 = day7.getMonth();
//        java.util.Date date18 = day7.getStart();
//        long long19 = day7.getSerialIndex();
//        java.util.Date date20 = day7.getEnd();
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timePeriodValues25.addChangeListener(seriesChangeListener26);
//        timePeriodValues25.fireSeriesChanged();
//        timePeriodValues25.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 1.0f);
//        long long35 = day31.getMiddleMillisecond();
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) day31, (double) 100L);
//        java.util.Date date38 = day31.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone39);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date20, timeZone39);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560452399999L + "'", long35 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setRangeDescription("");
//        boolean boolean9 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) 0);
//        int int27 = timePeriodValues1.getItemCount();
//        int int28 = timePeriodValues1.getMaxMiddleIndex();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener6);
        timePeriodValues5.fireSeriesChanged();
        int int9 = year0.compareTo((java.lang.Object) timePeriodValues5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        int int17 = day7.getMonth();
//        int int18 = day7.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        long long15 = day7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day7.next();
//        long long17 = day7.getSerialIndex();
//        long long18 = day7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1.0f);
//        long long13 = day9.getMiddleMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1);
//        java.lang.Object obj18 = timePeriodValue17.clone();
//        int int19 = year0.compareTo((java.lang.Object) timePeriodValue17);
//        long long20 = year0.getSerialIndex();
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = year0.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        java.lang.String str17 = day7.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues19.addChangeListener(seriesChangeListener20);
//        int int22 = timePeriodValues19.getMinEndIndex();
//        int int23 = timePeriodValues19.getMinEndIndex();
//        java.lang.String str24 = timePeriodValues19.getRangeDescription();
//        int int25 = day7.compareTo((java.lang.Object) str24);
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, number26);
//        long long28 = day7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        boolean boolean18 = year15.equals((java.lang.Object) 0.0f);
//        int int19 = day7.compareTo((java.lang.Object) year15);
//        long long20 = year15.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timePeriodValues22.addChangeListener(seriesChangeListener23);
//        timePeriodValues22.setDescription("hi!");
//        boolean boolean27 = timePeriodValues22.getNotify();
//        timePeriodValues22.setRangeDescription("");
//        boolean boolean30 = timePeriodValues22.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues22.createCopy((int) (short) -1, (int) (byte) 1);
//        java.lang.Object obj34 = timePeriodValues33.clone();
//        boolean boolean35 = year15.equals(obj34);
//        java.lang.Object obj36 = null;
//        boolean boolean37 = year15.equals(obj36);
//        java.util.Calendar calendar38 = null;
//        try {
//            long long39 = year15.getLastMillisecond(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues33);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getSerialIndex();
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        int int14 = timePeriodValues1.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues1.getDataItem(0);
//        boolean boolean17 = timePeriodValues1.isEmpty();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(timePeriodValue16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setNotify(true);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        timePeriodValues10.fireSeriesChanged();
//        timePeriodValues10.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        int int17 = day16.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 1.0f);
//        long long20 = day16.getMiddleMillisecond();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day16, (double) 100L);
//        java.util.Date date23 = day16.getEnd();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date23, timeZone26);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 1.0d);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener30);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560452399999L + "'", long20 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timePeriodValues2.addChangeListener(seriesChangeListener3);
//        timePeriodValues2.fireSeriesChanged();
//        timePeriodValues2.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 1.0f);
//        long long12 = day8.getMiddleMillisecond();
//        timePeriodValues2.add((org.jfree.data.time.TimePeriod) day8, (double) 100L);
//        java.util.Date date15 = day8.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        java.lang.Class class19 = null;
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timePeriodValues22.addChangeListener(seriesChangeListener23);
//        timePeriodValues22.fireSeriesChanged();
//        timePeriodValues22.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 1.0f);
//        long long32 = day28.getMiddleMillisecond();
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day28, (double) 100L);
//        java.util.Date date35 = day28.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date35, timeZone36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date35, timeZone38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date15, timeZone38);
//        long long41 = day40.getFirstMillisecond();
//        java.lang.String str42 = day40.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timePeriodValues44.addChangeListener(seriesChangeListener45);
//        timePeriodValues44.fireSeriesChanged();
//        timePeriodValues44.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        int int51 = day50.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue53 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day50, (java.lang.Number) 1.0f);
//        long long54 = day50.getMiddleMillisecond();
//        timePeriodValues44.add((org.jfree.data.time.TimePeriod) day50, (double) 100L);
//        java.util.Date date57 = day50.getEnd();
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        int int59 = year58.getYear();
//        boolean boolean61 = year58.equals((java.lang.Object) 0.0f);
//        int int62 = day50.compareTo((java.lang.Object) year58);
//        java.util.Date date63 = year58.getStart();
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int66 = day65.getYear();
//        long long67 = day65.getFirstMillisecond();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass69 = timeZone68.getClass();
//        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
//        org.jfree.data.time.TimePeriodValues timePeriodValues72 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener73 = null;
//        timePeriodValues72.addChangeListener(seriesChangeListener73);
//        timePeriodValues72.fireSeriesChanged();
//        timePeriodValues72.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        int int79 = day78.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue81 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day78, (java.lang.Number) 1.0f);
//        long long82 = day78.getMiddleMillisecond();
//        timePeriodValues72.add((org.jfree.data.time.TimePeriod) day78, (double) 100L);
//        java.util.Date date85 = day78.getEnd();
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date85);
//        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date85);
//        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date85, timeZone88);
//        java.util.TimeZone timeZone90 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date85, timeZone90);
//        int int92 = day65.compareTo((java.lang.Object) date85);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod93 = new org.jfree.data.time.SimpleTimePeriod(date63, date85);
//        boolean boolean94 = day40.equals((java.lang.Object) date63);
//        org.jfree.data.time.TimePeriodValues timePeriodValues97 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean94, "org.jfree.data.time.TimePeriodFormatException: 2019", "TimePeriodValue[13-June-2019,3]");
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560452399999L + "'", long32 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560452399999L + "'", long54 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560409200000L + "'", long67 == 1560409200000L);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(class70);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2019 + "'", int79 == 2019);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560452399999L + "'", long82 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(timeZone88);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        boolean boolean9 = timePeriodValues1.isEmpty();
        int int10 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.setDescription("hi!");
//        boolean boolean6 = timePeriodValues1.getNotify();
//        timePeriodValues1.setRangeDescription("");
//        boolean boolean9 = timePeriodValues1.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.fireSeriesChanged();
//        timePeriodValues11.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (java.lang.Number) 1.0f);
//        long long21 = day17.getMiddleMillisecond();
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) day17, (double) 100L);
//        java.util.Date date24 = day17.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day17, (double) 0);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue28 = timePeriodValues1.getDataItem((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560452399999L + "'", long21 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date24);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        long long15 = day7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day7.next();
//        int int17 = day7.getMonth();
//        java.util.Date date18 = day7.getEnd();
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = day7.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        java.lang.String str5 = seriesException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException9);
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        java.lang.String str13 = seriesException12.toString();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        java.lang.String str16 = seriesException15.toString();
        seriesException12.addSuppressed((java.lang.Throwable) seriesException15);
        seriesException9.addSuppressed((java.lang.Throwable) seriesException12);
        java.lang.String str19 = seriesException9.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str13.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str16.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str19.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        int int9 = timePeriodValues1.getMinStartIndex();
        int int10 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues1.createCopy(31, 3);
        int int14 = timePeriodValues13.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinEndIndex();
//        timePeriodValues1.setRangeDescription("hi!");
//        timePeriodValues1.fireSeriesChanged();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getYear();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        int int11 = day8.getYear();
//        long long12 = day8.getFirstMillisecond();
//        int int13 = day8.getMonth();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day8, (double) (-1.0f));
//        java.lang.String str16 = day8.toString();
//        int int17 = day8.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day8);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        int int36 = year35.getYear();
//        boolean boolean38 = year35.equals((java.lang.Object) 0.0f);
//        int int39 = day27.compareTo((java.lang.Object) year35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day27.previous();
//        boolean boolean41 = day8.equals((java.lang.Object) day27);
//        long long42 = day8.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 13 + "'", int17 == 13);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43629L + "'", long42 == 43629L);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        boolean boolean3 = year0.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int5 = year4.getYear();
        long long6 = year4.getLastMillisecond();
        long long7 = year4.getSerialIndex();
        long long8 = year4.getSerialIndex();
        java.util.Date date9 = year4.getStart();
        boolean boolean10 = year0.equals((java.lang.Object) year4);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues12.addChangeListener(seriesChangeListener13);
        timePeriodValues12.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues12.createCopy((int) (byte) 0, 100);
        java.lang.String str19 = timePeriodValues12.getDescription();
        timePeriodValues12.setNotify(true);
        int int22 = timePeriodValues12.getMinMiddleIndex();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        int int24 = day23.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) 1.0f);
        java.lang.Number number27 = timePeriodValue26.getValue();
        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue26.getPeriod();
        timePeriodValues12.add(timePeriodValue26);
        boolean boolean30 = year4.equals((java.lang.Object) timePeriodValues12);
        long long31 = year4.getMiddleMillisecond();
        long long32 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 1.0f + "'", number27.equals(1.0f));
        org.junit.Assert.assertNotNull(timePeriod28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1562097599999L + "'", long31 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        int int5 = timePeriodValues1.getMaxEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        timePeriodValues3.fireSeriesChanged();
//        timePeriodValues3.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 1.0f);
//        long long13 = day9.getMiddleMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) 100L);
//        java.util.Date date16 = day9.getEnd();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date16, timeZone19);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timePeriodValues23.addChangeListener(seriesChangeListener24);
//        timePeriodValues23.fireSeriesChanged();
//        timePeriodValues23.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 1.0f);
//        long long33 = day29.getMiddleMillisecond();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day29, (double) 100L);
//        java.util.Date date36 = day29.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date36, timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date16, date36);
//        java.util.Date date41 = simpleTimePeriod40.getStart();
//        java.util.Date date42 = simpleTimePeriod40.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timePeriodValues44.addChangeListener(seriesChangeListener45);
//        timePeriodValues44.fireSeriesChanged();
//        timePeriodValues44.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        int int51 = day50.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue53 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day50, (java.lang.Number) 1.0f);
//        long long54 = day50.getMiddleMillisecond();
//        timePeriodValues44.add((org.jfree.data.time.TimePeriod) day50, (double) 100L);
//        java.util.Date date57 = day50.getEnd();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date57);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date57, timeZone60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(date42, date57);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod62, (java.lang.Number) 8);
//        int int65 = timePeriodValues1.getMinStartIndex();
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560452399999L + "'", long33 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560452399999L + "'", long54 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timePeriodValues2.addChangeListener(seriesChangeListener3);
//        timePeriodValues2.fireSeriesChanged();
//        timePeriodValues2.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 1.0f);
//        long long12 = day8.getMiddleMillisecond();
//        timePeriodValues2.add((org.jfree.data.time.TimePeriod) day8, (double) 100L);
//        java.util.Date date15 = day8.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) (byte) 100);
//        timePeriodValue21.setValue((java.lang.Number) 31);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
//        java.lang.String str18 = day17.toString();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        boolean boolean9 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) -1, (int) (byte) 1);
        timePeriodValues12.delete(12, 3);
        timePeriodValues12.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        int int2 = timePeriodValues1.getMaxEndIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) (-1L));
//        java.lang.Object obj6 = timePeriodValues1.clone();
//        java.lang.String str7 = timePeriodValues1.getRangeDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues9.addChangeListener(seriesChangeListener10);
//        timePeriodValues9.fireSeriesChanged();
//        timePeriodValues9.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 1.0f);
//        long long19 = day15.getMiddleMillisecond();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day15, (double) 100L);
//        int int22 = timePeriodValues9.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = timePeriodValues9.getDataItem(0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timePeriodValues26.addChangeListener(seriesChangeListener27);
//        timePeriodValues26.fireSeriesChanged();
//        timePeriodValues26.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day32, (java.lang.Number) 1.0f);
//        long long36 = day32.getMiddleMillisecond();
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) day32, (double) 100L);
//        java.util.Date date39 = day32.getEnd();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date39, timeZone42);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
//        timePeriodValues46.addChangeListener(seriesChangeListener47);
//        timePeriodValues46.fireSeriesChanged();
//        timePeriodValues46.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        int int53 = day52.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue55 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day52, (java.lang.Number) 1.0f);
//        long long56 = day52.getMiddleMillisecond();
//        timePeriodValues46.add((org.jfree.data.time.TimePeriod) day52, (double) 100L);
//        java.util.Date date59 = day52.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date59, timeZone60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date59);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod(date39, date59);
//        java.util.Date date64 = simpleTimePeriod63.getStart();
//        timePeriodValues9.setKey((java.lang.Comparable) simpleTimePeriod63);
//        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560452399999L + "'", long19 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(timePeriodValue24);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560452399999L + "'", long36 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560452399999L + "'", long56 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date64);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        long long39 = simpleTimePeriod38.getEndMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
//        timePeriodValues41.addChangeListener(seriesChangeListener42);
//        timePeriodValues41.setDescription("hi!");
//        boolean boolean46 = timePeriodValues41.getNotify();
//        timePeriodValues41.setRangeDescription("");
//        boolean boolean49 = timePeriodValues41.isEmpty();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy((int) (short) -1, (int) (byte) 1);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        int int54 = day53.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) 1.0f);
//        timePeriodValues41.add(timePeriodValue56);
//        boolean boolean58 = simpleTimePeriod38.equals((java.lang.Object) timePeriodValue56);
//        java.lang.Number number59 = timePeriodValue56.getValue();
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
//        java.lang.String str61 = year60.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
//        timePeriodValues63.addChangeListener(seriesChangeListener64);
//        timePeriodValues63.fireSeriesChanged();
//        timePeriodValues63.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        int int70 = day69.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue72 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day69, (java.lang.Number) 1.0f);
//        long long73 = day69.getMiddleMillisecond();
//        timePeriodValues63.add((org.jfree.data.time.TimePeriod) day69, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue77 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day69, (java.lang.Number) 1);
//        java.lang.Object obj78 = timePeriodValue77.clone();
//        int int79 = year60.compareTo((java.lang.Object) timePeriodValue77);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        long long81 = day80.getLastMillisecond();
//        boolean boolean82 = timePeriodValue77.equals((java.lang.Object) long81);
//        org.jfree.data.time.TimePeriod timePeriod83 = timePeriodValue77.getPeriod();
//        boolean boolean84 = timePeriodValue56.equals((java.lang.Object) timePeriod83);
//        java.lang.String str85 = timePeriodValue56.toString();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 1.0f + "'", number59.equals(1.0f));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560452399999L + "'", long73 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560495599999L + "'", long81 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(timePeriod83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str85.equals("TimePeriodValue[13-June-2019,1.0]"));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560409200000L);
        boolean boolean2 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        int int5 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        int int7 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 7);
        timePeriodValues1.add(timePeriodValue13);
        java.lang.String str15 = timePeriodValues1.getDomainDescription();
        int int16 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timePeriodValues2.addChangeListener(seriesChangeListener3);
//        timePeriodValues2.fireSeriesChanged();
//        timePeriodValues2.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, (java.lang.Number) 1.0f);
//        long long12 = day8.getMiddleMillisecond();
//        timePeriodValues2.add((org.jfree.data.time.TimePeriod) day8, (double) 100L);
//        java.util.Date date15 = day8.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        int int20 = day18.getYear();
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        boolean boolean3 = year0.equals((java.lang.Object) 0.0f);
        long long4 = year0.getSerialIndex();
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener9);
        timePeriodValues1.setRangeDescription("Time");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date14, timeZone19);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timePeriodValues23.addChangeListener(seriesChangeListener24);
//        timePeriodValues23.fireSeriesChanged();
//        timePeriodValues23.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 1.0f);
//        long long33 = day29.getMiddleMillisecond();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day29, (double) 100L);
//        java.util.Date date36 = day29.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date36, timeZone37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date14, timeZone37);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year39);
//        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str43 = seriesException42.toString();
//        boolean boolean44 = year39.equals((java.lang.Object) seriesException42);
//        java.util.Calendar calendar45 = null;
//        try {
//            year39.peg(calendar45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560452399999L + "'", long33 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinEndIndex();
//        int int5 = timePeriodValues1.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues7.addChangeListener(seriesChangeListener8);
//        timePeriodValues7.fireSeriesChanged();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues7.createCopy((int) (byte) 0, 100);
//        java.lang.String str14 = timePeriodValues7.getDescription();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        int int16 = year15.getYear();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year15, (double) 8);
//        timePeriodValues1.setKey((java.lang.Comparable) 8);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        int int21 = day20.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 1.0f);
//        long long24 = day20.getMiddleMillisecond();
//        java.lang.String str25 = day20.toString();
//        org.jfree.data.time.SerialDate serialDate26 = day20.getSerialDate();
//        boolean boolean27 = timePeriodValues1.equals((java.lang.Object) day20);
//        int int28 = day20.getMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560452399999L + "'", long24 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        long long39 = simpleTimePeriod38.getStartMillis();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timePeriodValues42.addChangeListener(seriesChangeListener43);
//        timePeriodValues42.fireSeriesChanged();
//        timePeriodValues42.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        int int49 = day48.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 1.0f);
//        long long52 = day48.getMiddleMillisecond();
//        timePeriodValues42.add((org.jfree.data.time.TimePeriod) day48, (double) 100L);
//        java.util.Date date55 = day48.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date55, timeZone56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.next();
//        boolean boolean60 = simpleTimePeriod38.equals((java.lang.Object) regularTimePeriod59);
//        long long61 = simpleTimePeriod38.getEndMillis();
//        java.util.Date date62 = simpleTimePeriod38.getEnd();
//        java.util.TimeZone timeZone63 = null;
//        try {
//            org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62, timeZone63);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560452399999L + "'", long52 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date62);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        long long2 = year0.getFirstMillisecond();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues5.addChangeListener(seriesChangeListener6);
//        timePeriodValues5.fireSeriesChanged();
//        timePeriodValues5.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 1.0f);
//        long long15 = day11.getMiddleMillisecond();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) day11, (double) 100L);
//        java.util.Date date18 = day11.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date18, timeZone19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18);
//        int int22 = year0.compareTo((java.lang.Object) day21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        int int25 = year24.getYear();
//        boolean boolean27 = year24.equals((java.lang.Object) 0.0f);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        int int29 = year28.getYear();
//        long long30 = year28.getLastMillisecond();
//        long long31 = year28.getSerialIndex();
//        long long32 = year28.getSerialIndex();
//        java.util.Date date33 = year28.getStart();
//        boolean boolean34 = year24.equals((java.lang.Object) year28);
//        boolean boolean35 = day21.equals((java.lang.Object) year24);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        int int15 = day7.getYear();
//        long long16 = day7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        java.lang.String str5 = timePeriodValues1.getDomainDescription();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues8.addChangeListener(seriesChangeListener9);
//        timePeriodValues8.fireSeriesChanged();
//        timePeriodValues8.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 1.0f);
//        long long18 = day14.getMiddleMillisecond();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day14, (double) 100L);
//        java.util.Date date21 = day14.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        java.lang.Class class25 = null;
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timePeriodValues28.addChangeListener(seriesChangeListener29);
//        timePeriodValues28.fireSeriesChanged();
//        timePeriodValues28.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 1.0f);
//        long long38 = day34.getMiddleMillisecond();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day34, (double) 100L);
//        java.util.Date date41 = day34.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date41, timeZone42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date41, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date21, timeZone44);
//        long long47 = day46.getLastMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day46, (double) 8);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        java.lang.String str51 = year50.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
//        timePeriodValues53.addChangeListener(seriesChangeListener54);
//        timePeriodValues53.fireSeriesChanged();
//        timePeriodValues53.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        int int60 = day59.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day59, (java.lang.Number) 1.0f);
//        long long63 = day59.getMiddleMillisecond();
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) day59, (double) 100L);
//        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day59, (java.lang.Number) 1);
//        java.lang.Object obj68 = timePeriodValue67.clone();
//        int int69 = year50.compareTo((java.lang.Object) timePeriodValue67);
//        int int70 = day46.compareTo((java.lang.Object) year50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year50.next();
//        int int72 = year50.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year50.previous();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560452399999L + "'", long38 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560495599999L + "'", long47 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019" + "'", str51.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560452399999L + "'", long63 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        java.lang.Class<?> wildcardClass9 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day3);
//        java.lang.String str5 = seriesChangeEvent4.toString();
//        java.lang.Object obj6 = seriesChangeEvent4.getSource();
//        java.lang.String str7 = seriesChangeEvent4.toString();
//        java.lang.String str8 = seriesChangeEvent4.toString();
//        java.lang.Object obj9 = seriesChangeEvent4.getSource();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//        org.junit.Assert.assertNotNull(obj9);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        boolean boolean9 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy((int) (short) -1, (int) (byte) 1);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues12.getMaxStartIndex();
        int int16 = timePeriodValues12.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        java.util.Date date39 = simpleTimePeriod38.getStart();
//        java.util.Date date40 = simpleTimePeriod38.getEnd();
//        long long41 = simpleTimePeriod38.getEndMillis();
//        java.util.Date date42 = simpleTimePeriod38.getStart();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560495599999L + "'", long41 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date42);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        int int6 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date14, timeZone19);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timePeriodValues23.addChangeListener(seriesChangeListener24);
//        timePeriodValues23.fireSeriesChanged();
//        timePeriodValues23.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 1.0f);
//        long long33 = day29.getMiddleMillisecond();
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day29, (double) 100L);
//        java.util.Date date36 = day29.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date36, timeZone37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date14, timeZone37);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year39);
//        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str43 = seriesException42.toString();
//        boolean boolean44 = year39.equals((java.lang.Object) seriesException42);
//        java.util.Calendar calendar45 = null;
//        try {
//            long long46 = year39.getLastMillisecond(calendar45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560452399999L + "'", long33 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1.0f);
        java.lang.Number number4 = timePeriodValue3.getValue();
        java.lang.Class<?> wildcardClass5 = timePeriodValue3.getClass();
        java.lang.Number number6 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0f + "'", number6.equals(1.0f));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.String str4 = seriesException3.toString();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.String str7 = seriesException6.toString();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.String str14 = seriesException13.toString();
        seriesException10.addSuppressed((java.lang.Throwable) seriesException13);
        java.lang.Throwable[] throwableArray16 = seriesException13.getSuppressed();
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("13-June-2019");
        seriesException13.addSuppressed((java.lang.Throwable) seriesException18);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException18);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException18);
        java.lang.String str22 = seriesException18.toString();
        java.lang.Throwable[] throwableArray23 = seriesException18.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str14.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str22.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setDescription("hi!");
        boolean boolean6 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("");
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues11.getMinEndIndex();
        int int15 = timePeriodValues11.getMinEndIndex();
        java.lang.String str16 = timePeriodValues11.getRangeDescription();
        boolean boolean17 = timePeriodValues1.equals((java.lang.Object) str16);
        int int18 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        timePeriodValues1.fireSeriesChanged();
//        timePeriodValues1.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 1.0f);
//        long long11 = day7.getMiddleMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day7, (double) 100L);
//        java.util.Date date14 = day7.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues21.addChangeListener(seriesChangeListener22);
//        timePeriodValues21.fireSeriesChanged();
//        timePeriodValues21.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        int int28 = day27.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 1.0f);
//        long long31 = day27.getMiddleMillisecond();
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) day27, (double) 100L);
//        java.util.Date date34 = day27.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date14, date34);
//        java.util.Date date39 = simpleTimePeriod38.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
//        timePeriodValues41.addChangeListener(seriesChangeListener42);
//        timePeriodValues41.fireSeriesChanged();
//        timePeriodValues41.setKey((java.lang.Comparable) 0);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        int int48 = day47.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue50 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day47, (java.lang.Number) 1.0f);
//        long long51 = day47.getMiddleMillisecond();
//        timePeriodValues41.add((org.jfree.data.time.TimePeriod) day47, (double) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day47.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod54);
//        boolean boolean56 = simpleTimePeriod38.equals((java.lang.Object) timePeriodValues55);
//        long long57 = simpleTimePeriod38.getStartMillis();
//        long long58 = simpleTimePeriod38.getStartMillis();
//        java.util.Date date59 = simpleTimePeriod38.getEnd();
//        java.util.Date date60 = simpleTimePeriod38.getEnd();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560452399999L + "'", long31 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560452399999L + "'", long51 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560495599999L + "'", long57 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560495599999L + "'", long58 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//    }
//}

