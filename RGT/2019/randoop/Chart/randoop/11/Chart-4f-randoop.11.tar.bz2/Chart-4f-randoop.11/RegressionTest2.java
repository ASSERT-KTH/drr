import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNull(axisSpace5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        java.awt.Stroke stroke20 = xYLineAndShapeRenderer7.getItemStroke(100, 3, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYLineAndShapeRenderer7.getSeriesPositiveItemLabelPosition((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-1.0f));
        xYBarRenderer1.setShadowYOffset(0.0d);
        double double4 = xYBarRenderer1.getBarAlignmentFactor();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D8 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D8.setBaseSeriesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer3D8.getSeriesToolTipGenerator((int) '#');
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot14.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextFillPaint();
        categoryPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis();
        logAxis19.setAutoRangeMinimumSize(4.0d, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo25.getChartArea();
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int30 = color29.getAlpha();
        java.awt.color.ColorSpace colorSpace31 = color29.getColorSpace();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis33);
        java.awt.Stroke stroke35 = combinedRangeXYPlot34.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot34);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int40 = combinedRangeXYPlot34.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer39);
        boolean boolean43 = xYLineAndShapeRenderer39.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        double double46 = categoryAxis3D45.getCategoryMargin();
        java.awt.Stroke stroke47 = categoryAxis3D45.getAxisLineStroke();
        xYLineAndShapeRenderer39.setSeriesStroke(1900, stroke47);
        barRenderer3D8.drawRangeLine(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) logAxis19, rectangle2D26, 2958465.0d, (java.awt.Paint) color29, stroke47);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis51);
        java.awt.Stroke stroke53 = combinedRangeXYPlot52.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot52);
        combinedRangeXYPlot52.setNotify(false);
        combinedRangeXYPlot52.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.axis.LogAxis logAxis59 = new org.jfree.chart.axis.LogAxis();
        boolean boolean60 = logAxis59.isVerticalTickLabels();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D62 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D62.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit66 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D62.setTickUnit(numberTickUnit66);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection68 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number69 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection68);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection68.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot70);
        try {
            xYBarRenderer1.drawItem(graphics2D5, xYItemRendererState7, rectangle2D26, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot52, (org.jfree.chart.axis.ValueAxis) logAxis59, (org.jfree.chart.axis.ValueAxis) numberAxis3D62, (org.jfree.data.xy.XYDataset) timeSeriesCollection68, 100, 0, true, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.2d + "'", double46 == 0.2d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(number69);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range8.intersects((double) 100.0f, (double) 2019L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 1900L, range1, lengthConstraintType6, (double) (byte) 100, range8, lengthConstraintType12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getHeightConstraintType();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot1.setRangeAxisLocation(4, axisLocation6, false);
        java.awt.Image image9 = null;
        combinedRangeXYPlot1.setBackgroundImage(image9);
        boolean boolean11 = combinedRangeXYPlot1.isDomainPannable();
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        chartRenderingInfo11.setEntityCollection(entityCollection12);
        chartRenderingInfo11.clear();
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart4.createBufferedImage((int) (byte) -1, 4, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (4) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2008, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2008, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.axis.TickType tickType5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType5, 0.0d, "org.jfree.data.general.SeriesException: {0}", textAnchor8, textAnchor9, 90.0d);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset12 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean14 = defaultPieDataset12.equals((java.lang.Object) xYStepAreaRenderer13);
        xYStepAreaRenderer13.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer13.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYStepAreaRenderer13.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor9, textAnchor20, (double) (byte) 0);
        org.jfree.chart.axis.TickType tickType24 = null;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.NumberTick numberTick30 = new org.jfree.chart.axis.NumberTick(tickType24, (double) 2958465, "VerticalAlignment.CENTER", textAnchor27, textAnchor28, (double) 60000L);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, 1.0f, (float) 100, textAnchor9, (double) (short) 10, textAnchor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setFixedDimension((double) 0.5f);
        double double3 = categoryAxis3D0.getCategoryMargin();
        java.awt.Paint paint4 = categoryAxis3D0.getAxisLinePaint();
        categoryAxis3D0.setUpperMargin((-2.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("[10.0, -1.0]");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int15 = combinedRangeXYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets16.calculateRightInset((double) 10.0f);
        combinedRangeXYPlot9.setInsets(rectangleInsets16, true);
        combinedRangeXYPlot4.setAxisOffset(rectangleInsets16);
        categoryAxis3D1.setLabelInsets(rectangleInsets16);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.lightGray;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        combinedRangeXYPlot4.setRenderer(xYItemRenderer5);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getDomainMinorGridlinePaint();
        boolean boolean8 = categoryPlot0.equals((java.lang.Object) paint7);
        java.awt.Stroke stroke9 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        xYDataItem2.setSelected(true);
        xYDataItem2.setY((double) 0.5f);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.clearSectionOutlineStrokes(false);
        java.lang.String str3 = piePlot3D0.getPlotType();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        piePlot3D0.setDataset(pieDataset4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie 3D Plot" + "'", str3.equals("Pie 3D Plot"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo7.getChartArea();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double13 = numberAxis3D1.java2DToValue((double) 0.5f, rectangle2D8, rectangleEdge12);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis3D1.getTickUnit();
        int int15 = numberTickUnit14.getMinorTickCount();
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        java.awt.Paint paint19 = xYLineAndShapeRenderer15.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Color color20 = java.awt.Color.darkGray;
        xYLineAndShapeRenderer15.setBaseItemLabelPaint((java.awt.Paint) color20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color24 = color23.darker();
        xYLineAndShapeRenderer15.setSeriesOutlinePaint(100, (java.awt.Paint) color23, false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.025d);
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        float float6 = periodAxis5.getMinorTickMarkOutsideLength();
        java.lang.Class class7 = periodAxis5.getMajorTickTimePeriodClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("{0}", class7);
        try {
            java.util.EventListener[] eventListenerArray10 = intervalMarker2.getListeners(class7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Day; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNull(uRL9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color3);
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme6.setPlotBackgroundPaint((java.awt.Paint) color7);
        java.lang.String str9 = standardChartTheme6.getName();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        combinedRangeXYPlot11.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = combinedRangeXYPlot11.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        combinedRangeXYPlot11.setRangeAxisLocation(4, axisLocation16, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot11.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.Color color21 = color19.darker();
        standardChartTheme6.setAxisLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle23 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        standardChartTheme6.setLabelLinkStyle(pieLabelLinkStyle23);
        standardChartTheme1.setLabelLinkStyle(pieLabelLinkStyle23);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle23);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("Time");
        double double2 = categoryAxis3D1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.025d);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = intervalMarker2.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        try {
            intervalMarker2.setLabelAnchor(rectangleAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean5 = range2.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range2);
        numberAxis3D1.setRangeWithMargins((org.jfree.data.Range) dateRange6, false, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand10);
        java.lang.Object obj12 = numberAxis3D1.clone();
        java.awt.Paint paint13 = numberAxis3D1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(900000L);
        boolean boolean7 = segmentedTimeline3.containsDomainValue((long) (byte) -1);
        long long8 = segmentedTimeline3.getSegmentsIncludedSize();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int17 = combinedRangeXYPlot11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer16);
        boolean boolean20 = xYLineAndShapeRenderer16.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer16.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = null;
        java.util.TimeZone timeZone28 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("", timeZone28);
        java.util.TimeZone timeZone31 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("", timeZone31);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection33 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection33);
        xYLineAndShapeRenderer16.drawItem(graphics2D23, xYItemRendererState24, rectangle2D25, xYPlot26, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.data.xy.XYDataset) timeSeriesCollection33, (int) (short) 0, 4, false, (int) '4');
        dateAxis32.setTickLabelsVisible(false);
        java.util.Date date42 = dateAxis32.getMaximumDate();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType43 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType43, (int) ' ');
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year46.next();
        long long48 = year46.getSerialIndex();
        int int49 = year46.getYear();
        long long50 = year46.getLastMillisecond();
        java.util.Date date51 = year46.getEnd();
        java.util.TimeZone timeZone52 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date53 = dateTickUnit45.rollDate(date51, timeZone52);
        boolean boolean54 = segmentedTimeline3.containsDomainRange(date42, date53);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 19000L + "'", long8 == 19000L);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(dateTickUnitType43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        java.awt.Paint paint3 = ringPlot0.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = ringPlot0.getSimpleLabelOffset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        ringPlot0.setLabelGenerator(pieSectionLabelGenerator5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int15 = combinedRangeXYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer14);
        java.awt.Shape shape17 = xYLineAndShapeRenderer14.getSeriesShape(10);
        boolean boolean19 = xYLineAndShapeRenderer14.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean21 = xYLineAndShapeRenderer14.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer14.clearSeriesStrokes(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str25 = categoryAxis3D24.getLabelURL();
        java.awt.Paint paint26 = categoryAxis3D24.getLabelPaint();
        xYLineAndShapeRenderer14.setBaseItemLabelPaint(paint26);
        ringPlot0.setLabelOutlinePaint(paint26);
        ringPlot0.setCircular(false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle3 = standardChartTheme2.getLabelLinkStyle();
        java.awt.Font font4 = standardChartTheme2.getLargeFont();
        java.awt.Color color5 = java.awt.Color.ORANGE;
        standardChartTheme2.setRangeGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.StandardChartTheme standardChartTheme8 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = standardChartTheme8.getLabelLinkStyle();
        java.awt.Font font10 = standardChartTheme8.getLargeFont();
        java.awt.Color color11 = java.awt.Color.ORANGE;
        standardChartTheme8.setRangeGridlinePaint((java.awt.Paint) color11);
        standardChartTheme2.setItemLabelPaint((java.awt.Paint) color11);
        java.awt.Color color14 = java.awt.Color.getColor("2,019", color11);
        int int15 = color14.getGreen();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 200 + "'", int15 == 200);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        combinedRangeXYPlot1.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("", timeZone11);
        org.jfree.data.Range range13 = combinedRangeXYPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.util.Date date14 = dateAxis12.getMaximumDate();
        dateAxis12.setFixedDimension((double) 10);
        java.text.DateFormat dateFormat17 = dateAxis12.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(dateFormat17);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        combinedRangeXYPlot8.setNotify(false);
        boolean boolean13 = tickUnits4.equals((java.lang.Object) combinedRangeXYPlot8);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType14 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType14, (int) ' ');
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        long long19 = year17.getSerialIndex();
        int int20 = year17.getYear();
        long long21 = year17.getLastMillisecond();
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date24 = dateTickUnit16.rollDate(date22, timeZone23);
        tickUnits4.add((org.jfree.chart.axis.TickUnit) dateTickUnit16);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnitType14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke7 = ringPlot6.getBaseSectionOutlineStroke();
        periodAxis1.setMinorTickMarkStroke(stroke7);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((-1), 0, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        combinedRangeXYPlot9.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        int int13 = combinedRangeXYPlot9.getRangeAxisIndex(valueAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        combinedRangeXYPlot15.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = combinedRangeXYPlot15.getLegendItems();
        combinedRangeXYPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot9.getRangeMarkers((int) '#', layer21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        double double24 = categoryAxis3D23.getCategoryMargin();
        java.awt.Stroke stroke25 = categoryAxis3D23.getAxisLineStroke();
        combinedRangeXYPlot9.setRangeMinorGridlineStroke(stroke25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis28);
        java.awt.Stroke stroke30 = combinedRangeXYPlot29.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot29);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int35 = combinedRangeXYPlot29.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer34);
        boolean boolean38 = xYLineAndShapeRenderer34.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer34.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        java.util.TimeZone timeZone46 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("", timeZone46);
        java.util.TimeZone timeZone49 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("", timeZone49);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection51 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection51);
        xYLineAndShapeRenderer34.drawItem(graphics2D41, xYItemRendererState42, rectangle2D43, xYPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.data.xy.XYDataset) timeSeriesCollection51, (int) (short) 0, 4, false, (int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D61 = chartRenderingInfo60.getChartArea();
        boolean boolean62 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D61, rectangleAnchor63);
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D61, 10.0d);
        dateAxis50.setAutoRangeMinimumSize(45.0d);
        double double69 = dateAxis50.getFixedDimension();
        java.util.TimeZone timeZone70 = null;
        try {
            dateAxis50.setTimeZone(timeZone70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D0.setTickUnit(numberTickUnit2, true, true);
        org.jfree.data.Range range6 = numberAxis3D0.getRange();
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        combinedRangeXYPlot3.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint6 = combinedRangeXYPlot3.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = combinedRangeXYPlot3.getDomainAxisIndex(valueAxis7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedRangeXYPlot3, "{0}");
        org.jfree.chart.plot.Plot plot11 = plotEntity10.getPlot();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot2);
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) "^0.48");
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot2.getDomainMarkers(layer6);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int19 = color18.getAlpha();
        java.awt.color.ColorSpace colorSpace20 = color18.getColorSpace();
        xYLineAndShapeRenderer7.setBaseOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator23 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        boolean boolean25 = standardXYToolTipGenerator23.equals((java.lang.Object) 255);
        java.lang.Object obj26 = standardXYToolTipGenerator23.clone();
        xYLineAndShapeRenderer7.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator23, false);
        java.awt.Shape shape29 = null;
        try {
            xYLineAndShapeRenderer7.setLegendLine(shape29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 100, false);
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries2.createCopy(0, 1900);
        org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries5.addOrUpdate((java.lang.Number) 200, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertNull(xYDataItem8);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setTickLabelsVisible(false);
        java.util.Date date33 = dateAxis23.getMaximumDate();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        java.lang.Object obj5 = combinedRangeXYPlot1.clone();
        java.awt.Image image6 = combinedRangeXYPlot1.getBackgroundImage();
        int int7 = combinedRangeXYPlot1.getRangeAxisCount();
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer7);
        combinedRangeXYPlot1.setDomainPannable(true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("Multiple Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Multiple Pie Plot");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) ' ');
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        long long5 = year3.getSerialIndex();
        int int6 = year3.getYear();
        long long7 = year3.getLastMillisecond();
        java.util.Date date8 = year3.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date10 = dateTickUnit2.rollDate(date8, timeZone9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date8);
        long long12 = month11.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1576526399999L + "'", long12 == 1576526399999L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        java.awt.Paint paint3 = ringPlot0.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = ringPlot0.getSimpleLabelOffset();
        double double5 = ringPlot0.getStartAngle();
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Stroke stroke8 = legendItem7.getLineStroke();
        java.awt.Stroke stroke9 = legendItem7.getLineStroke();
        ringPlot0.setLabelLinkStroke(stroke9);
        float float11 = ringPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = standardChartTheme1.getDrawingSupplier();
        java.awt.Color color4 = java.awt.Color.YELLOW;
        standardChartTheme1.setShadowPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer1.getBaseToolTipGenerator();
        boolean boolean4 = xYAreaRenderer1.getUseFillPaint();
        xYAreaRenderer1.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart8);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D11 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter12 = barRenderer3D11.getBarPainter();
        org.jfree.chart.StandardChartTheme standardChartTheme15 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = standardChartTheme15.getLabelLinkStyle();
        java.awt.Font font17 = standardChartTheme15.getLargeFont();
        java.awt.Paint paint18 = standardChartTheme15.getDomainGridlinePaint();
        java.awt.Paint paint19 = standardChartTheme15.getLabelLinkPaint();
        barRenderer3D11.setSeriesOutlinePaint(0, paint19);
        java.awt.Paint paint21 = barRenderer3D11.getBaseFillPaint();
        textTitle10.setPaint(paint21);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) textTitle10);
        java.lang.String str24 = textTitle10.getText();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(barPainter12);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        float float1 = logAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 0, (java.lang.Number) 100.0f);
        java.lang.Number number3 = xYDataItem2.getX();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer7.setBaseCreateEntities(true);
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer7.getBaseStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToDomainAxis(6, 0);
        boolean boolean4 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setTickLabelsVisible(false);
        java.util.Date date33 = dateAxis23.getMaximumDate();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType34 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType34, (int) ' ');
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.next();
        long long39 = year37.getSerialIndex();
        int int40 = year37.getYear();
        long long41 = year37.getLastMillisecond();
        java.util.Date date42 = year37.getEnd();
        java.util.TimeZone timeZone43 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date44 = dateTickUnit36.rollDate(date42, timeZone43);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline48 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean50 = segmentedTimeline48.containsDomainValue(900000L);
        long long51 = segmentedTimeline48.getSegmentSize();
        segmentedTimeline48.addException((long) 1900);
        long long55 = segmentedTimeline48.getTimeFromLong((long) 1);
        java.lang.Object obj56 = segmentedTimeline48.clone();
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot58 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis57);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        int int60 = combinedRangeXYPlot58.getDomainAxisIndex(valueAxis59);
        org.jfree.chart.plot.Marker marker61 = null;
        org.jfree.chart.util.Layer layer62 = null;
        boolean boolean63 = combinedRangeXYPlot58.removeDomainMarker(marker61, layer62);
        boolean boolean64 = combinedRangeXYPlot58.isDomainZoomable();
        combinedRangeXYPlot58.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone68 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("", timeZone68);
        org.jfree.data.Range range70 = combinedRangeXYPlot58.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis69);
        java.util.Date date71 = dateAxis69.getMaximumDate();
        segmentedTimeline48.addException(date71);
        java.lang.String str73 = dateTickUnit36.dateToString(date71);
        java.util.Date date74 = dateAxis23.calculateLowestVisibleTickValue(dateTickUnit36);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(dateTickUnitType34);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1900L + "'", long51 == 1900L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "12/31/69" + "'", str73.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date74);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = null;
        xYItemRendererState1.setSelectionState(xYDatasetSelectionState2);
        boolean boolean4 = xYItemRendererState1.getProcessVisibleItemsOnly();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYItemRendererState1.startSeriesPass(xYDataset5, (int) (byte) -1, (int) (short) 100, (int) (byte) 0, 8, 8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = xYItemRendererState1.getInfo();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(plotRenderingInfo12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot1.isDomainZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot14.getRenderer();
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis19);
        java.awt.Stroke stroke21 = combinedRangeXYPlot20.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot20);
        boolean boolean23 = jFreeChart22.getAntiAlias();
        jFreeChart22.setTitle("hi!");
        java.awt.Paint paint26 = jFreeChart22.getBackgroundPaint();
        categoryPlot14.setRangeMinorGridlinePaint(paint26);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.025d);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = intervalMarker30.getLabelOffset();
        boolean boolean32 = categoryPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker30);
        org.jfree.chart.util.Layer layer33 = null;
        try {
            combinedRangeXYPlot1.addDomainMarker(15, (org.jfree.chart.plot.Marker) intervalMarker30, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList5 = new org.jfree.chart.util.ShapeList();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) shapeList5);
        java.awt.Paint paint7 = ringPlot4.getLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 100, plotRenderingInfo9);
        ringPlot0.setIgnoreZeroValues(true);
        java.lang.Object obj13 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 0, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        jFreeChart4.setTitle("hi!");
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        java.awt.Color color9 = java.awt.Color.ORANGE;
        jFreeChart4.setBorderPaint((java.awt.Paint) color9);
        java.lang.Object obj11 = jFreeChart4.getTextAntiAlias();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560409200000L, seriesChangeInfo1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        boolean boolean8 = combinedRangeXYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace9.setTop((double) 12);
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace9, false);
        axisSpace9.setTop((double) 1.0f);
        org.jfree.chart.util.ShapeList shapeList16 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYSeries xYSeries18 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean20 = xYSeries18.equals((java.lang.Object) 10.0d);
        boolean boolean21 = shapeList16.equals((java.lang.Object) 10.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo27.getChartArea();
        boolean boolean29 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D28);
        boolean boolean30 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D28);
        shapeList16.setShape(10, (java.awt.Shape) rectangle2D28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D35 = chartRenderingInfo34.getChartArea();
        boolean boolean36 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D35, rectangleAnchor37);
        java.awt.geom.Rectangle2D rectangle2D39 = axisSpace9.expand(rectangle2D28, rectangle2D35);
        double double40 = axisSpace9.getLeft();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        boolean boolean1 = logAxis0.isVerticalTickLabels();
        logAxis0.setUpperBound(0.0d);
        double double5 = logAxis0.calculateLog(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getYear();
//        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("");
//        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = standardChartTheme5.getLabelLinkStyle();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = standardChartTheme5.getDrawingSupplier();
//        boolean boolean8 = day0.equals((java.lang.Object) drawingSupplier7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(pieLabelLinkStyle6);
//        org.junit.Assert.assertNotNull(drawingSupplier7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        combinedRangeXYPlot2.setRangeCrosshairValue((double) (short) 100);
        float float5 = combinedRangeXYPlot2.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.ShapeList shapeList7 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean11 = xYSeries9.equals((java.lang.Object) 10.0d);
        boolean boolean12 = shapeList7.equals((java.lang.Object) 10.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo18.getChartArea();
        boolean boolean20 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D19);
        boolean boolean21 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D19);
        shapeList7.setShape(10, (java.awt.Shape) rectangle2D19);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis24);
        java.awt.Stroke stroke26 = combinedRangeXYPlot25.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot25);
        combinedRangeXYPlot25.setNotify(false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection30);
        int int32 = combinedRangeXYPlot25.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection30);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues33 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list34 = defaultKeyedValues33.getKeys();
        org.jfree.data.Range range36 = timeSeriesCollection30.getDomainBounds(list34, true);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues37 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list38 = defaultKeyedValues37.getKeys();
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean42 = range39.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange43 = new org.jfree.data.time.DateRange(range39);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30, list38, range39, true);
        combinedRangeXYPlot2.drawRangeTickBands(graphics2D6, rectangle2D19, list38);
        try {
            boolean boolean47 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(range45);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        org.jfree.chart.plot.Plot plot7 = jFreeChart4.getPlot();
        jFreeChart4.setNotify(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        double double8 = barRenderer3D0.getShadowXOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer3D0.getSeriesToolTipGenerator(1);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        combinedRangeXYPlot1.setRangeCrosshairVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = combinedRangeXYPlot1.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNull(legendItemCollection14);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        boolean boolean8 = combinedRangeXYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace9.setTop((double) 12);
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace9, false);
        java.awt.Stroke stroke14 = combinedRangeXYPlot2.getRangeZeroBaselineStroke();
        org.jfree.chart.util.LogFormat logFormat19 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str21 = logFormat19.format((java.lang.Object) 3);
        logFormat19.setMaximumFractionDigits(2958465);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        java.awt.Stroke stroke27 = combinedRangeXYPlot26.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot26);
        float float29 = jFreeChart28.getBackgroundImageAlpha();
        java.util.List list30 = jFreeChart28.getSubtitles();
        java.util.Collection collection31 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list30);
        boolean boolean32 = logFormat19.equals((java.lang.Object) list30);
        try {
            combinedRangeXYPlot2.mapDatasetToDomainAxes((int) (byte) 0, list30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Indices must be Integer instances.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "^0.48" + "'", str21.equals("^0.48"));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D4.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D4.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint11 = barRenderer3D4.getShadowPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker17, rectangle2D21);
        int int26 = barRenderer3D0.getPassCount();
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        java.awt.Paint paint8 = barRenderer3D0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer3D0.getToolTipGenerator(1900, (int) (byte) 0, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection14.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot16);
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) "^0.48");
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot16.getDomainMarkers(8, layer21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot23.setFixedDomainAxisSpace(axisSpace25, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D28.setTickUnit(numberTickUnit30, true, true);
        java.awt.Shape shape34 = numberAxis3D28.getDownArrow();
        int int35 = categoryPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D41 = chartRenderingInfo40.getChartArea();
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D41);
        java.awt.Color color45 = java.awt.Color.WHITE;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis47);
        java.awt.Stroke stroke49 = combinedRangeXYPlot48.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot48);
        org.jfree.chart.axis.ValueAxis valueAxis52 = combinedRangeXYPlot48.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Stroke stroke53 = combinedRangeXYPlot48.getDomainGridlineStroke();
        barRenderer3D0.drawRangeLine(graphics2D13, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, rectangle2D41, (double) 19000L, (java.awt.Paint) color45, stroke53);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.CrosshairState crosshairState60 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState60.setAnchorX((double) 8);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot64 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis63);
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        int int66 = combinedRangeXYPlot64.getDomainAxisIndex(valueAxis65);
        org.jfree.chart.plot.Marker marker67 = null;
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean69 = combinedRangeXYPlot64.removeDomainMarker(marker67, layer68);
        java.awt.Font font71 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme73 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint74 = standardChartTheme73.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer76 = null;
        org.jfree.chart.text.TextBlock textBlock77 = org.jfree.chart.text.TextUtilities.createTextBlock("", font71, paint74, 0.0f, textMeasurer76);
        combinedRangeXYPlot64.setDomainTickBandPaint(paint74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot81 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color82 = java.awt.Color.lightGray;
        categoryPlot81.setDomainCrosshairPaint((java.awt.Paint) color82);
        categoryPlot81.setAnchorValue((double) 1L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo90 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D91 = chartRenderingInfo90.getChartArea();
        boolean boolean92 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D91);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor93 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D94 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D91, rectangleAnchor93);
        categoryPlot81.zoomDomainAxes((double) 100, plotRenderingInfo87, point2D94);
        combinedRangeXYPlot64.panRangeAxes((double) 1L, plotRenderingInfo80, point2D94);
        crosshairState60.setAnchor(point2D94);
        try {
            combinedDomainXYPlot55.zoomRangeAxes((double) 24231L, (double) 4, plotRenderingInfo58, point2D94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(textBlock77);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(rectangle2D91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor93);
        org.junit.Assert.assertNotNull(point2D94);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Font font10 = xYLineAndShapeRenderer7.lookupLegendTextFont(40);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset16 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset16);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset18 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Number number20 = defaultPieDataset18.getValue(0);
        ringPlot17.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset18);
        java.text.AttributedString attributedString23 = standardPieSectionLabelGenerator15.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset18, (java.lang.Comparable) 1577865599999L);
        java.text.NumberFormat numberFormat24 = standardPieSectionLabelGenerator15.getPercentFormat();
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertNull(attributedString23);
        org.junit.Assert.assertNotNull(numberFormat24);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        numberFormat0.setMinimumIntegerDigits(265);
        int int3 = numberFormat0.getMaximumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(40);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D4.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D4.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint11 = barRenderer3D4.getShadowPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker17, rectangle2D21);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot3.getRendererForDataset(categoryDataset26);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(categoryItemRenderer27);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
        java.lang.Boolean boolean5 = xYAreaRenderer3.getSeriesItemLabelsVisible((int) '4');
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        boolean boolean8 = combinedRangeXYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace9.setTop((double) 12);
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset15 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset15);
        java.util.List list17 = defaultPieDataset15.getKeys();
        try {
            combinedRangeXYPlot2.mapDatasetToRangeAxes(12, list17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.lightGray;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        boolean boolean7 = categoryPlot0.removeDomainMarker(255, marker5, layer6);
        int int8 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Color color6 = java.awt.Color.darkGray;
        xYLineAndShapeRenderer2.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color6);
        xYLineAndShapeRenderer2.setBaseSeriesVisible(false, false);
        boolean boolean12 = xYLineAndShapeRenderer2.isSeriesVisible(1900);
        xYLineAndShapeRenderer2.setSeriesLinesVisible(0, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setMinimumArcAngleToDraw((double) 86400000L);
        org.jfree.data.general.PieDataset pieDataset3 = ringPlot0.getDataset();
        org.junit.Assert.assertNull(pieDataset3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        categoryPlot0.setWeight((-1));
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        combinedRangeXYPlot14.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        combinedRangeXYPlot14.panDomainAxes((double) 0, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis21);
        combinedRangeXYPlot22.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder25 = combinedRangeXYPlot22.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        combinedRangeXYPlot22.setRangeAxisLocation(4, axisLocation27, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot22.setBackgroundPaint((java.awt.Paint) color30);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot33.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint36 = defaultDrawingSupplier35.getNextFillPaint();
        categoryPlot33.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot33.getDomainAxisLocation(1);
        combinedRangeXYPlot22.setDomainAxisLocation(2019, axisLocation39, true);
        combinedRangeXYPlot14.setDomainAxisLocation(axisLocation39, false);
        categoryPlot0.setRangeAxisLocation(0, axisLocation39, true);
        categoryPlot0.setAnchorValue((double) 4);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(seriesRenderingOrder25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = null;
        xYItemRendererState1.setSelectionState(xYDatasetSelectionState2);
        boolean boolean4 = xYItemRendererState1.getProcessVisibleItemsOnly();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        xYItemRendererState1.startSeriesPass(xYDataset5, (int) (byte) -1, (int) (short) 100, (int) (byte) 0, 8, 8);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState12 = xYItemRendererState1.getSelectionState();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDatasetSelectionState12);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat5.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        java.lang.StringBuffer stringBuffer11 = logFormat5.format((long) 1, stringBuffer9, fieldPosition10);
        boolean boolean12 = defaultDrawingSupplier0.equals((java.lang.Object) stringBuffer9);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D13.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = barRenderer3D13.getURLGenerator((int) '#', 1, false);
        double double20 = barRenderer3D13.getMinimumBarLength();
        java.awt.Paint paint21 = barRenderer3D13.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = barRenderer3D13.getToolTipGenerator(1900, (int) (byte) 0, true);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection27.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot29);
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) "^0.48");
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot29.getDomainMarkers(8, layer34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot36.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace38 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot36.setFixedDomainAxisSpace(axisSpace38, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D41.setTickUnit(numberTickUnit43, true, true);
        java.awt.Shape shape47 = numberAxis3D41.getDownArrow();
        int int48 = categoryPlot36.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D54 = chartRenderingInfo53.getChartArea();
        boolean boolean55 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D54);
        java.awt.geom.Point2D point2D56 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D54);
        java.awt.Color color58 = java.awt.Color.WHITE;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot61 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis60);
        java.awt.Stroke stroke62 = combinedRangeXYPlot61.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot61);
        org.jfree.chart.axis.ValueAxis valueAxis65 = combinedRangeXYPlot61.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Stroke stroke66 = combinedRangeXYPlot61.getDomainGridlineStroke();
        barRenderer3D13.drawRangeLine(graphics2D26, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, rectangle2D54, (double) 19000L, (java.awt.Paint) color58, stroke66);
        boolean boolean68 = defaultDrawingSupplier0.equals((java.lang.Object) numberAxis3D41);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stringBuffer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryURLGenerator19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(point2D56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(valueAxis65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = standardChartTheme3.getLabelLinkStyle();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = standardChartTheme3.getDrawingSupplier();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ", font7, paint8, (float) (byte) 1);
        java.awt.Font font11 = textFragment10.getFont();
        standardChartTheme3.setLargeFont(font11);
        barRenderer3D0.setSeriesItemLabelFont((int) (byte) 10, font11, false);
        double double15 = barRenderer3D0.getUpperClip();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            boolean boolean8 = categoryPlot0.removeAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("2,019", "VerticalAlignment.CENTER", "Combined Range XYPlot", "2,019", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getLibraries();
        java.lang.String str7 = basicProjectInfo5.getName();
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2,019" + "'", str7.equals("2,019"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        xYLineAndShapeRenderer2.setSeriesCreateEntities(40, (java.lang.Boolean) false, true);
        java.lang.Boolean boolean9 = xYLineAndShapeRenderer2.getSeriesLinesVisible(13);
        boolean boolean13 = xYLineAndShapeRenderer2.isItemLabelVisible(0, 0, false);
        xYLineAndShapeRenderer2.setDrawSeriesLineAsPath(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        java.util.Date date31 = dateAxis20.getMaximumDate();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        axisState0.cursorUp(1.0E-5d);
        axisState0.cursorLeft(0.025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedRangeXYPlot2.setRenderer(xYItemRenderer3);
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        combinedRangeXYPlot2.setNoDataMessageFont(font6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("{0}", font6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle9.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str13 = verticalAlignment12.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment12, (double) 4, 0.0d);
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment12, 45.0d, (double) 2958465);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "VerticalAlignment.CENTER" + "'", str13.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER_RIGHT");
        boolean boolean2 = legendItem1.isLineVisible();
        java.awt.Paint paint3 = legendItem1.getFillPaint();
        java.lang.String str4 = legendItem1.getLabel();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str4.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        intervalXYDelegate8.setIntervalPositionFactor(1.0d);
        org.jfree.data.Range range13 = intervalXYDelegate8.getDomainBounds(false);
        org.jfree.data.Range range15 = intervalXYDelegate8.getDomainBounds(true);
        double double17 = intervalXYDelegate8.getDomainLowerBound(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD");
        textTitle1.setURLText("{0}");
        textTitle1.setID("DomainOrder.ASCENDING");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        java.awt.Stroke stroke20 = xYLineAndShapeRenderer7.getItemStroke(100, 3, true);
        xYLineAndShapeRenderer7.setSeriesLinesVisible(40, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("DomainOrder.ASCENDING", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMinimumBarLength();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        barRenderer3D0.setWallPaint((java.awt.Paint) color2);
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme5.setPlotBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color6, true);
        boolean boolean10 = rendererChangeEvent9.getSeriesVisibilityChanged();
        boolean boolean11 = rendererChangeEvent9.getSeriesVisibilityChanged();
        barRenderer3D0.notifyListeners(rendererChangeEvent9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (-1.0f));
        xYBarRenderer1.setBarAlignmentFactor((double) 1560409200000L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.updateCrosshairY((double) (-4144960));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean4 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((-1), 0, false);
        java.awt.Shape shape10 = xYLineAndShapeRenderer2.getItemShape((int) '4', 6, false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot7.isDomainZoomable();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        java.awt.Stroke stroke17 = combinedRangeXYPlot16.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        float float19 = jFreeChart18.getBackgroundImageAlpha();
        java.awt.Stroke stroke20 = jFreeChart18.getBorderStroke();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) combinedRangeXYPlot7, jFreeChart18, chartChangeEventType21);
        combinedRangeXYPlot7.setNotify(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(900000L);
        long long6 = segmentedTimeline3.getSegmentSize();
        segmentedTimeline3.addException((long) 1900);
        int int9 = segmentedTimeline3.getGroupSegmentCount();
        long long11 = segmentedTimeline3.getTimeFromLong(1560409200000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1900L + "'", long6 == 1900L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 265 + "'", int9 == 265);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Font font3 = standardChartTheme1.getLargeFont();
        java.awt.Paint paint4 = standardChartTheme1.getDomainGridlinePaint();
        java.awt.Paint paint5 = standardChartTheme1.getChartBackgroundPaint();
        java.awt.Font font6 = standardChartTheme1.getLargeFont();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        combinedRangeXYPlot1.setDomainCrosshairVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot1.getRangeAxisEdge(0);
        java.lang.String str9 = combinedRangeXYPlot1.getPlotType();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Combined Range XYPlot" + "'", str9.equals("Combined Range XYPlot"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        int int2 = defaultPieDataset0.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER_RIGHT");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int10 = combinedRangeXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        java.awt.Shape shape12 = xYLineAndShapeRenderer9.getSeriesShape(10);
        boolean boolean14 = xYLineAndShapeRenderer9.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer9.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer9.clearSeriesStrokes(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str20 = categoryAxis3D19.getLabelURL();
        java.awt.Paint paint21 = categoryAxis3D19.getLabelPaint();
        xYLineAndShapeRenderer9.setBaseItemLabelPaint(paint21);
        boolean boolean23 = xYLineAndShapeRenderer9.getUseOutlinePaint();
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer9.getItemOutlineStroke(5, (int) ' ', false);
        boolean boolean28 = legendItem1.equals((java.lang.Object) stroke27);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D29.setFixedDimension((double) 0.5f);
        double double32 = categoryAxis3D29.getCategoryMargin();
        java.awt.Paint paint33 = categoryAxis3D29.getAxisLinePaint();
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis3D29.setTickMarkPaint((java.awt.Paint) color34);
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        float float40 = periodAxis39.getMinorTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D43.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D50 = chartRenderingInfo49.getChartArea();
        boolean boolean51 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double55 = numberAxis3D43.java2DToValue((double) 0.5f, rectangle2D50, rectangleEdge54);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis56);
        combinedRangeXYPlot57.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = combinedRangeXYPlot57.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation62 = null;
        combinedRangeXYPlot57.setRangeAxisLocation(4, axisLocation62, false);
        java.awt.Color color65 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot57.setBackgroundPaint((java.awt.Paint) color65);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer69 = categoryPlot68.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier70 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint71 = defaultDrawingSupplier70.getNextFillPaint();
        categoryPlot68.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier70);
        org.jfree.chart.axis.AxisLocation axisLocation74 = categoryPlot68.getDomainAxisLocation(1);
        combinedRangeXYPlot57.setDomainAxisLocation(2019, axisLocation74, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation77 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj78 = null;
        boolean boolean79 = plotOrientation77.equals(obj78);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation74, plotOrientation77);
        double double81 = periodAxis39.valueToJava2D((double) 10L, rectangle2D50, rectangleEdge80);
        org.jfree.chart.axis.ValueAxis valueAxis83 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot84 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis83);
        java.awt.Stroke stroke85 = combinedRangeXYPlot84.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart86 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot84);
        org.jfree.chart.axis.ValueAxis valueAxis88 = combinedRangeXYPlot84.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean89 = combinedRangeXYPlot84.isNotify();
        org.jfree.chart.StandardChartTheme standardChartTheme91 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle92 = standardChartTheme91.getLabelLinkStyle();
        java.awt.Font font93 = standardChartTheme91.getLargeFont();
        java.awt.Color color94 = java.awt.Color.ORANGE;
        standardChartTheme91.setRangeGridlinePaint((java.awt.Paint) color94);
        combinedRangeXYPlot84.setDomainCrosshairPaint((java.awt.Paint) color94);
        org.jfree.chart.util.RectangleEdge rectangleEdge97 = combinedRangeXYPlot84.getRangeAxisEdge();
        double double98 = categoryAxis3D29.getCategoryEnd(13, (int) (byte) -1, rectangle2D50, rectangleEdge97);
        legendItem1.setLine((java.awt.Shape) rectangle2D50);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.2d + "'", double32 == 0.2d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 2.0f + "'", float40 == 2.0f);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + Double.POSITIVE_INFINITY + "'", double55 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNull(categoryItemRenderer69);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertNotNull(plotOrientation77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNull(valueAxis88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle92);
        org.junit.Assert.assertNotNull(font93);
        org.junit.Assert.assertNotNull(color94);
        org.junit.Assert.assertNotNull(rectangleEdge97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        boolean boolean8 = combinedRangeXYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace9.setTop((double) 12);
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace9, false);
        java.awt.Stroke stroke14 = combinedRangeXYPlot2.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer16.removeAnnotations();
        combinedRangeXYPlot2.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer16);
        java.awt.Stroke stroke19 = xYAreaRenderer16.getBaseStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        xYSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection4);
        org.jfree.data.DomainOrder domainOrder7 = timeSeriesCollection4.getDomainOrder();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(domainOrder7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemCount((int) '#');
        org.jfree.data.xy.XYDataItem xYDataItem10 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number11 = xYDataItem10.getY();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(3, year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate(regularTimePeriod17, (double) 60000L);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries4.addAndOrUpdate(timeSeries12);
        timeSeries12.setMaximumItemAge((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0d) + "'", number11.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = java.awt.Color.yellow;
        float[] floatArray7 = new float[] { 2958465, 0.5f, 1900L, 10L, 0.0f };
        float[] floatArray8 = color1.getColorComponents(floatArray7);
        float[] floatArray9 = color0.getComponents(floatArray7);
        int int10 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        java.awt.Paint paint8 = barRenderer3D0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer3D0.getToolTipGenerator(1900, (int) (byte) 0, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection14.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot16);
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) "^0.48");
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot16.getDomainMarkers(8, layer21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot23.setFixedDomainAxisSpace(axisSpace25, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D28.setTickUnit(numberTickUnit30, true, true);
        java.awt.Shape shape34 = numberAxis3D28.getDownArrow();
        int int35 = categoryPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D41 = chartRenderingInfo40.getChartArea();
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D41);
        java.awt.Color color45 = java.awt.Color.WHITE;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis47);
        java.awt.Stroke stroke49 = combinedRangeXYPlot48.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot48);
        org.jfree.chart.axis.ValueAxis valueAxis52 = combinedRangeXYPlot48.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Stroke stroke53 = combinedRangeXYPlot48.getDomainGridlineStroke();
        barRenderer3D0.drawRangeLine(graphics2D13, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, rectangle2D41, (double) 19000L, (java.awt.Paint) color45, stroke53);
        org.jfree.chart.axis.PeriodAxis periodAxis56 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray57 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis56.setLabelInfo(periodAxisLabelInfoArray57);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year60.next();
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(3, year60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year60.next();
        periodAxis56.setLast(regularTimePeriod63);
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) regularTimePeriod63, true);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray57);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setAutoRangeMinimumSize(4.0d, true);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis0);
        combinedDomainXYPlot4.setGap(0.0d);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        combinedRangeXYPlot9.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = combinedRangeXYPlot9.getRangeMarkers(layer14);
        combinedDomainXYPlot4.remove((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot2);
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) "^0.48");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextFillPaint();
        categoryPlot2.setRangeMinorGridlinePaint(paint7);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint9 = xYLineAndShapeRenderer7.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Color color11 = java.awt.Color.darkGray;
        xYLineAndShapeRenderer7.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color11);
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace14 = color11.getColorSpace();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD");
        textTitle1.setURLText("{0}");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getPadding();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.awt.Paint paint2 = ringPlot1.getBaseSectionPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot1.getSimpleLabelOffset();
        java.awt.Paint paint4 = ringPlot1.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        float float6 = jFreeChart5.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = jFreeChart5.getPadding();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) 1, jFreeChart5, 1, (int) (byte) 1);
        jFreeChart5.setBackgroundImageAlpha((float) 15);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        combinedRangeXYPlot14.setRenderer(xYItemRenderer15);
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("", font18);
        combinedRangeXYPlot14.setNoDataMessageFont(font18);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        combinedRangeXYPlot14.setRangeAxis(12, valueAxis22, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean29 = xYLineAndShapeRenderer28.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot14.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer28);
        java.awt.Paint paint32 = xYLineAndShapeRenderer28.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Color color33 = java.awt.Color.darkGray;
        xYLineAndShapeRenderer28.setBaseItemLabelPaint((java.awt.Paint) color33);
        jFreeChart5.setBackgroundPaint((java.awt.Paint) color33);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        int int5 = timeSeries4.getMaximumItemCount();
        timeSeries4.setDomainDescription("VerticalAlignment.CENTER");
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Last");
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoTickUnitSelection(false, false);
        numberAxis1.configure();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.awt.Font font1 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint4, 0.0f, textMeasurer6);
        java.awt.Font font9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.StandardChartTheme standardChartTheme11 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme11.setErrorIndicatorPaint(paint12);
        java.awt.Paint paint14 = standardChartTheme11.getTickLabelPaint();
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme11.setSubtitlePaint(paint15);
        textBlock7.addLine("", font9, paint15);
        org.jfree.chart.text.TextLine textLine18 = null;
        textBlock7.addLine(textLine18);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot1.setRangeAxisLocation(4, axisLocation6, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot1.setBackgroundPaint((java.awt.Paint) color9);
        int int11 = color9.getGreen();
        java.awt.Color color12 = java.awt.Color.yellow;
        float[] floatArray18 = new float[] { 2958465, 0.5f, 1900L, 10L, 0.0f };
        float[] floatArray19 = color12.getColorComponents(floatArray18);
        float[] floatArray20 = color9.getRGBColorComponents(floatArray18);
        int int21 = color9.getBlue();
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        boolean boolean8 = combinedRangeXYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace9.setTop((double) 12);
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace9, false);
        java.lang.String str14 = axisSpace9.toString();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot0.setRangeAxis(valueAxis10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        xYItemRendererState1.setProcessVisibleItemsOnly(false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        boolean boolean2 = categoryAxis3D0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.025d);
        double double3 = intervalMarker2.getEndValue();
        java.awt.Paint paint4 = intervalMarker2.getPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.025d + "'", double3 == 0.025d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem8 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number9 = xYDataItem8.getY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem8);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.addAndOrUpdate(timeSeries10);
        org.jfree.data.xy.XYDataItem xYDataItem14 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number15 = xYDataItem14.getY();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem14);
        long long17 = timeSeries16.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem20 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number21 = xYDataItem20.getY();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem20);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries16.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.addAndOrUpdate(timeSeries22);
        timeSeries4.removeAgedItems(true);
        org.jfree.data.xy.XYDataItem xYDataItem29 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number30 = xYDataItem29.getY();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem29);
        long long32 = timeSeries31.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem35 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number36 = xYDataItem35.getY();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem35);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries31.addAndOrUpdate(timeSeries37);
        org.jfree.data.xy.XYDataItem xYDataItem41 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number42 = xYDataItem41.getY();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem41);
        long long44 = timeSeries43.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem47 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number48 = xYDataItem47.getY();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem47);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries43.addAndOrUpdate(timeSeries49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries31.addAndOrUpdate(timeSeries49);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries4.addAndOrUpdate(timeSeries49);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1.0d) + "'", number15.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1.0d) + "'", number21.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (-1.0d) + "'", number30.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (-1.0d) + "'", number36.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (-1.0d) + "'", number42.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0d) + "'", number48.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries52);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        double double8 = barRenderer3D0.getShadowXOffset();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            barRenderer3D0.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint7 = standardChartTheme6.getThermometerPaint();
        ringPlot3.setLabelShadowPaint(paint7);
        labelBlock2.setPaint(paint7);
        java.lang.Object obj10 = labelBlock2.clone();
        labelBlock2.setWidth((double) 10);
        java.awt.Font font13 = null;
        try {
            labelBlock2.setFont(font13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer3D0.getSeriesToolTipGenerator((int) '#');
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot6.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextFillPaint();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier8);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis();
        logAxis11.setAutoRangeMinimumSize(4.0d, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo17.getChartArea();
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int22 = color21.getAlpha();
        java.awt.color.ColorSpace colorSpace23 = color21.getColorSpace();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis25);
        java.awt.Stroke stroke27 = combinedRangeXYPlot26.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot26);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int32 = combinedRangeXYPlot26.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer31);
        boolean boolean35 = xYLineAndShapeRenderer31.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        double double38 = categoryAxis3D37.getCategoryMargin();
        java.awt.Stroke stroke39 = categoryAxis3D37.getAxisLineStroke();
        xYLineAndShapeRenderer31.setSeriesStroke(1900, stroke39);
        barRenderer3D0.drawRangeLine(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) logAxis11, rectangle2D18, 2958465.0d, (java.awt.Paint) color21, stroke39);
        barRenderer3D0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.2d + "'", double38 == 0.2d);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(900000L);
        boolean boolean7 = segmentedTimeline3.containsDomainValue((long) (byte) -1);
        long long8 = segmentedTimeline3.getSegmentsIncludedSize();
        segmentedTimeline3.addException(86400000L);
        boolean boolean11 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 19000L + "'", long8 == 19000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        java.awt.Paint paint8 = barRenderer3D0.getShadowPaint();
        boolean boolean9 = barRenderer3D0.getIncludeBaseInRange();
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        double double5 = axisSpace2.getTop();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.lightGray;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color1);
        categoryPlot0.setAnchorValue((double) 1L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo9.getChartArea();
        boolean boolean11 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor12);
        categoryPlot0.zoomDomainAxes((double) 100, plotRenderingInfo6, point2D13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(point2D13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(900000L);
        long long6 = segmentedTimeline3.getSegmentSize();
        java.lang.Object obj7 = segmentedTimeline3.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1900L + "'", long6 == 1900L);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Stroke stroke7 = xYAreaRenderer1.getItemStroke(1, 1, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = null;
        xYAreaRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator8, false);
        boolean boolean11 = xYAreaRenderer1.getPlotArea();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean11);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = seriesChangeEvent12.getSummary();
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(seriesChangeInfo15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke7 = ringPlot6.getBaseSectionOutlineStroke();
        boolean boolean8 = tickUnits4.equals((java.lang.Object) stroke7);
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit10 = polarPlot9.getAngleTickUnit();
        tickUnits4.add(tickUnit10);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tickUnit10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.TickUnit tickUnit1 = polarPlot0.getAngleTickUnit();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        polarPlot0.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((-1), 0, false);
        polarPlot0.setAngleGridlineStroke(stroke10);
        org.junit.Assert.assertNotNull(tickUnit1);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer3D0.setSeriesCreateEntities(10, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme7 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = standardChartTheme7.getLabelLinkStyle();
        java.awt.Font font9 = standardChartTheme7.getLargeFont();
        java.awt.Paint paint10 = standardChartTheme7.getDomainGridlinePaint();
        java.awt.Paint paint11 = standardChartTheme7.getChartBackgroundPaint();
        try {
            combinedRangeXYPlot1.setQuadrantPaint((-1), paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D0.setTickUnit(numberTickUnit2, true, true);
        java.awt.Shape shape6 = numberAxis3D0.getDownArrow();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int15 = combinedRangeXYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer14);
        java.awt.Shape shape17 = xYLineAndShapeRenderer14.getSeriesShape(10);
        xYLineAndShapeRenderer14.setSeriesShapesVisible((int) (short) 1, (java.lang.Boolean) false);
        boolean boolean21 = numberAxis3D0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        java.lang.Boolean boolean12 = xYLineAndShapeRenderer7.getSeriesShapesVisible((int) (short) 100);
        xYLineAndShapeRenderer7.setAutoPopulateSeriesShape(false);
        boolean boolean15 = xYLineAndShapeRenderer7.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1900, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
        java.awt.Font font7 = xYAreaRenderer3.getItemLabelFont(8, 0, false);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9, true);
        combinedRangeXYPlot2.setDomainCrosshairLockedOnData(false);
        java.lang.String str14 = combinedRangeXYPlot2.getPlotType();
        java.awt.Stroke stroke15 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.025d);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = intervalMarker18.getLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        intervalMarker18.notifyListeners(markerChangeEvent20);
        org.jfree.chart.util.Layer layer22 = null;
        combinedRangeXYPlot2.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer22);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Time", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        double double6 = timeSeriesCollection3.getDomainLowerBound(true);
        timeSeriesCollection3.removeAllSeries();
        int int8 = timeSeriesCollection3.getSeriesCount();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter6 = barRenderer3D5.getBarPainter();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D9.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer3D9.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint16 = barRenderer3D9.getShadowPaint();
        categoryPlot8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D9);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D19.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo25.getChartArea();
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor28);
        barRenderer3D5.drawRangeMarker(graphics2D7, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, marker22, rectangle2D26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState33 = null;
        boolean boolean34 = categoryPlot0.render(graphics2D4, rectangle2D26, 8, plotRenderingInfo32, categoryCrosshairState33);
        boolean boolean35 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(barPainter6);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = combinedRangeXYPlot9.getDomainAxisIndex(valueAxis10);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = combinedRangeXYPlot9.removeDomainMarker(marker12, layer13);
        boolean boolean15 = combinedRangeXYPlot9.isDomainZoomable();
        combinedRangeXYPlot9.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        org.jfree.data.Range range21 = combinedRangeXYPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.Range range22 = combinedRangeXYPlot2.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        dateAxis20.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str5 = logFormat3.format((java.lang.Object) 3);
        logFormat3.setMaximumFractionDigits(2958465);
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Object obj10 = logFormat3.parseObject("ClassContext", parsePosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str16 = logFormat14.format((java.lang.Object) 3);
        logFormat3.setExponentFormat((java.text.NumberFormat) logFormat14);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "^0.48" + "'", str5.equals("^0.48"));
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "^0.48" + "'", str16.equals("^0.48"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "org.jfree.data.general.SeriesException: {0}", textAnchor3, textAnchor4, 90.0d);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset7 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean9 = defaultPieDataset7.equals((java.lang.Object) xYStepAreaRenderer8);
        xYStepAreaRenderer8.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYStepAreaRenderer8.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYStepAreaRenderer8.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getRotationAnchor();
        boolean boolean16 = numberTick6.equals((java.lang.Object) textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (byte) 0, (double) 2.0f);
        double double3 = dateRange2.getLowerBound();
        java.util.Date date4 = dateRange2.getUpperDate();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Pie 3D Plot");
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        jFreeChart4.setTitle("hi!");
        float float8 = jFreeChart4.getBackgroundImageAlpha();
        int int9 = jFreeChart4.getBackgroundImageAlignment();
        java.awt.RenderingHints renderingHints10 = jFreeChart4.getRenderingHints();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(renderingHints10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.trimHeight(0.0d);
        periodAxis1.setLabelInsets(rectangleInsets6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = periodAxis1.getFirst();
        java.awt.Font font11 = periodAxis1.getLabelFont();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = periodAxis1.getLast();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((double) (byte) 0, (double) 2.0f);
        double double16 = dateRange15.getLowerBound();
        periodAxis1.setRange((org.jfree.data.Range) dateRange15, false, true);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        periodAxis1.setLast(regularTimePeriod8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) periodAxis1);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) 2.0f, plotRenderingInfo9, point2D10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = combinedRangeXYPlot2.getFixedRangeAxisSpace();
        combinedRangeXYPlot2.setNotify(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        categoryPlot0.setDrawSharedDomainAxis(false);
        boolean boolean4 = categoryPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle8.getItemContainer();
        double double10 = blockContainer9.getContentYOffset();
        java.lang.Object obj11 = blockContainer9.clone();
        blockContainer9.clear();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertNotNull(blockContainer9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Paint paint2 = barRenderer3D0.getLegendTextPaint((int) (short) 1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        barRenderer3D0.setBaseStroke(stroke3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot8.getRenderer();
        categoryPlot8.setDrawSharedDomainAxis(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D13 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer3D13.getBarPainter();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D17 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D17.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = barRenderer3D17.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint24 = barRenderer3D17.getShadowPaint();
        categoryPlot16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D17);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D27.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo33.getChartArea();
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D37 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor36);
        barRenderer3D13.drawRangeMarker(graphics2D15, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, marker30, rectangle2D34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState41 = null;
        boolean boolean42 = categoryPlot8.render(graphics2D12, rectangle2D34, 8, plotRenderingInfo40, categoryCrosshairState41);
        boolean boolean43 = categoryPlot8.isRangeCrosshairLockedOnData();
        categoryPlot8.setDomainCrosshairVisible(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource48 = null;
        chartRenderingInfo47.setRenderingSource(renderingSource48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = chartRenderingInfo47.getPlotInfo();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState51 = barRenderer3D0.initialise(graphics2D5, rectangle2D7, categoryPlot8, 4, plotRenderingInfo50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(point2D37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo50);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        numberFormat0.setMinimumIntegerDigits(265);
        java.text.ParsePosition parsePosition4 = null;
        try {
            java.lang.Object obj5 = numberFormat0.parseObject("", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0, timeZone1);
        timeSeriesCollection2.validateObject();
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.data.xy.XYDataItem xYDataItem10 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number11 = xYDataItem10.getY();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem10);
        long long13 = timeSeries12.getMaximumItemAge();
        timeSeries12.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        timeSeries12.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection17);
        combinedRangeXYPlot2.setDataset(255, (org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        java.awt.Stroke stroke21 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme23 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint24 = standardChartTheme23.getThermometerPaint();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_YELLOW;
        standardChartTheme23.setLegendItemPaint((java.awt.Paint) color25);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint31 = xYLineAndShapeRenderer29.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Color color33 = java.awt.Color.darkGray;
        xYLineAndShapeRenderer29.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color33);
        standardChartTheme23.setLegendItemPaint((java.awt.Paint) color33);
        java.awt.Paint paint36 = standardChartTheme23.getWallPaint();
        combinedRangeXYPlot2.setDomainGridlinePaint(paint36);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0d) + "'", number11.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (byte) 10, (double) (short) 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1576526399999L, 0L, 1L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1576526399999L, 0L, 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1576526399999L, 0L, 1L };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1576526399999L, 0L, 1L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1576526399999L, 0L, 1L };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 1576526399999L, 0L, 1L };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Polar Plot", numberArray26);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        java.awt.Paint paint18 = null;
        xYLineAndShapeRenderer7.setSeriesFillPaint(1, paint18, true);
        xYLineAndShapeRenderer7.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (byte) 0, (double) 2.0f);
        double double3 = dateRange2.getLowerBound();
        boolean boolean5 = dateRange2.contains((double) 19000L);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.util.Date date7 = dateRange6.getLowerDate();
        org.jfree.data.Range range8 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.025d);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = intervalMarker2.getLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        intervalMarker2.notifyListeners(markerChangeEvent4);
        java.lang.Object obj6 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedRangeXYPlot1.zoomRangeAxes(Double.NaN, plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot12.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint15 = defaultDrawingSupplier14.getNextFillPaint();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier14);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        combinedRangeXYPlot1.setRangeAxisLocation(axisLocation18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot22.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot22);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int28 = combinedRangeXYPlot22.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer27);
        java.awt.Shape shape30 = xYLineAndShapeRenderer27.getSeriesShape(10);
        boolean boolean32 = xYLineAndShapeRenderer27.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean34 = xYLineAndShapeRenderer27.getSeriesLinesVisible((int) (short) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator36 = xYLineAndShapeRenderer27.getSeriesURLGenerator((int) (byte) 100);
        org.jfree.chart.LegendItem legendItem39 = xYLineAndShapeRenderer27.getLegendItem(4, 0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer41 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        java.awt.Color color43 = java.awt.Color.LIGHT_GRAY;
        xYAreaRenderer41.setSeriesOutlinePaint(0, (java.awt.Paint) color43);
        xYLineAndShapeRenderer27.setBaseLegendTextPaint((java.awt.Paint) color43);
        combinedRangeXYPlot1.setRangeCrosshairPaint((java.awt.Paint) color43);
        int int47 = color43.getBlue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(boolean34);
        org.junit.Assert.assertNull(xYURLGenerator36);
        org.junit.Assert.assertNull(legendItem39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 192 + "'", int47 == 192);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumFractionDigits((int) (byte) -1);
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, dateFormat7);
        int int9 = logFormat4.getMaximumIntegerDigits();
        java.text.ParsePosition parsePosition11 = null;
        java.lang.Object obj12 = logFormat4.parseObject("{0}", parsePosition11);
        java.math.RoundingMode roundingMode13 = null;
        try {
            logFormat4.setRoundingMode(roundingMode13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 40 + "'", int9 == 40);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumFractionDigits((int) (byte) -1);
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, dateFormat7);
        int int9 = logFormat4.getMaximumIntegerDigits();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year11);
        java.text.AttributedCharacterIterator attributedCharacterIterator14 = logFormat4.formatToCharacterIterator((java.lang.Object) 3);
        int int15 = logFormat4.getMaximumIntegerDigits();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 40 + "'", int9 == 40);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(attributedCharacterIterator14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 40 + "'", int15 == 40);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = combinedRangeXYPlot1.getInsets();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo10.getChartArea();
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D11);
        boolean boolean13 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = combinedRangeXYPlot15.getDomainAxisIndex(valueAxis16);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = combinedRangeXYPlot15.removeDomainMarker(marker18, layer19);
        java.awt.Font font22 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint25 = standardChartTheme24.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, paint25, 0.0f, textMeasurer27);
        combinedRangeXYPlot15.setDomainTickBandPaint(paint25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color33 = java.awt.Color.lightGray;
        categoryPlot32.setDomainCrosshairPaint((java.awt.Paint) color33);
        categoryPlot32.setAnchorValue((double) 1L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D42 = chartRenderingInfo41.getChartArea();
        boolean boolean43 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D42);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D45 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor44);
        categoryPlot32.zoomDomainAxes((double) 100, plotRenderingInfo38, point2D45);
        combinedRangeXYPlot15.panRangeAxes((double) 1L, plotRenderingInfo31, point2D45);
        org.jfree.chart.plot.PlotState plotState48 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            combinedRangeXYPlot1.draw(graphics2D5, rectangle2D11, point2D45, plotState48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(point2D45);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D4.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D4.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint11 = barRenderer3D4.getShadowPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker17, rectangle2D21);
        barRenderer3D0.setItemMargin((double) 9223372036854775807L);
        java.awt.Paint paint29 = barRenderer3D0.getSeriesPaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState2 = xYItemRendererState1.getCrosshairState();
        java.awt.geom.Line2D line2D3 = null;
        xYItemRendererState1.workingLine = line2D3;
        org.junit.Assert.assertNull(xYCrosshairState2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo7.getChartArea();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double13 = numberAxis3D1.java2DToValue((double) 0.5f, rectangle2D8, rectangleEdge12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        java.awt.Stroke stroke17 = combinedRangeXYPlot16.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        boolean boolean19 = jFreeChart18.getAntiAlias();
        jFreeChart18.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity23 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape) rectangle2D8, jFreeChart18, "ClassContext");
        java.lang.Object obj24 = jFreeChartEntity23.clone();
        java.lang.String str25 = jFreeChartEntity23.toString();
        java.lang.String str26 = jFreeChartEntity23.getShapeType();
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "JFreeChartEntity: tooltip = ClassContext" + "'", str25.equals("JFreeChartEntity: tooltip = ClassContext"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "rect" + "'", str26.equals("rect"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesCollection6);
        try {
            double double12 = timeSeriesCollection6.getYValue(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D3.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo9.getChartArea();
        boolean boolean11 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double15 = numberAxis3D3.java2DToValue((double) 0.5f, rectangle2D10, rectangleEdge14);
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1884.0d, (double) 1900L, rectangle2D10);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(point2D13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        boolean boolean8 = combinedRangeXYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace9.setTop((double) 12);
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace9, false);
        axisSpace9.setTop((double) 1.0f);
        java.awt.Color color16 = java.awt.Color.yellow;
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D22 = chartRenderingInfo21.getChartArea();
        boolean boolean23 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor24);
        java.awt.geom.AffineTransform affineTransform26 = null;
        java.awt.RenderingHints renderingHints27 = null;
        java.awt.PaintContext paintContext28 = color16.createContext(colorModel17, rectangle18, rectangle2D22, affineTransform26, renderingHints27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D30 = chartRenderingInfo29.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D31 = chartRenderingInfo29.getChartArea();
        java.awt.geom.Rectangle2D rectangle2D32 = axisSpace9.shrink(rectangle2D22, rectangle2D31);
        java.lang.String str33 = axisSpace9.toString();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(paintContext28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.XYDataItem xYDataItem6 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number7 = xYDataItem6.getY();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem6);
        long long9 = timeSeries8.getMaximumItemAge();
        org.jfree.data.xy.XYDataItem xYDataItem12 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number13 = xYDataItem12.getY();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem12);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries8.addAndOrUpdate(timeSeries14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        timeSeriesCollection0.addSeries(timeSeries15);
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 100);
        defaultKeyedValues0.setValue((java.lang.Comparable) year2, (java.lang.Number) (-1.0f));
        org.jfree.data.general.DefaultPieDataset defaultPieDataset5 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean7 = defaultPieDataset5.equals((java.lang.Object) xYStepAreaRenderer6);
        xYStepAreaRenderer6.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false);
        boolean boolean11 = defaultKeyedValues0.equals((java.lang.Object) (byte) 1);
        java.lang.Comparable comparable13 = defaultKeyedValues0.getKey(0);
        try {
            java.lang.Comparable comparable15 = defaultKeyedValues0.getKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(comparable13);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer3D1.getBaseItemLabelGenerator();
        boolean boolean11 = barRenderer3D1.getShadowsVisible();
        double double12 = barRenderer3D1.getLowerClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer3D1.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer3D1.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        boolean boolean4 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor5);
        java.lang.Class<?> wildcardClass7 = rectangle2D3.getClass();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(point2D6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat5.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer9 = null;
        java.text.FieldPosition fieldPosition10 = null;
        java.lang.StringBuffer stringBuffer11 = logFormat5.format((long) 1, stringBuffer9, fieldPosition10);
        boolean boolean12 = defaultDrawingSupplier0.equals((java.lang.Object) stringBuffer9);
        java.awt.Stroke stroke13 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stringBuffer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("org.jfree.data.general.SeriesChangeEvent[source=10]", "[10.0, -1.0]", "DomainOrder.NONE", "TextBlockAnchor.CENTER_RIGHT");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        combinedRangeXYPlot1.setRenderer(0, xYItemRenderer9, true);
        java.awt.Stroke stroke12 = combinedRangeXYPlot1.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        combinedRangeXYPlot14.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = combinedRangeXYPlot14.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        combinedRangeXYPlot14.setRangeAxisLocation(4, axisLocation19, false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot14.setBackgroundPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot25.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextFillPaint();
        categoryPlot25.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot25.getDomainAxisLocation(1);
        combinedRangeXYPlot14.setDomainAxisLocation(2019, axisLocation31, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj35 = null;
        boolean boolean36 = plotOrientation34.equals(obj35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation31, plotOrientation34);
        java.lang.String str38 = plotOrientation34.toString();
        combinedRangeXYPlot1.setOrientation(plotOrientation34);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(categoryItemRenderer26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str38.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        java.awt.Stroke stroke11 = jFreeChart9.getBorderStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) year3, stroke11);
        ringPlot0.setNotify(true);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset16 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset16);
        java.awt.Stroke stroke18 = ringPlot17.getLabelOutlineStroke();
        try {
            ringPlot0.setSectionOutlineStroke((java.lang.Comparable) "NO_CHANGE", stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to java.lang.String");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues2 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 100);
        defaultKeyedValues2.setValue((java.lang.Comparable) year4, (java.lang.Number) (-1.0f));
        defaultKeyedValues2.setValue((java.lang.Comparable) "2,019", (double) 8);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset10 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Object obj11 = defaultPieDataset10.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot12.getColumnRenderingOrder();
        defaultPieDataset10.sortByKeys(sortOrder13);
        defaultKeyedValues2.sortByValues(sortOrder13);
        defaultKeyedValues0.sortByValues(sortOrder13);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("^0.48");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ^0.48, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        java.awt.Paint paint8 = barRenderer3D0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = barRenderer3D0.getToolTipGenerator(1900, (int) (byte) 0, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection14.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot16);
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) "^0.48");
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot16.getDomainMarkers(8, layer21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot23.setFixedDomainAxisSpace(axisSpace25, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D28.setTickUnit(numberTickUnit30, true, true);
        java.awt.Shape shape34 = numberAxis3D28.getDownArrow();
        int int35 = categoryPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D41 = chartRenderingInfo40.getChartArea();
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D41);
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D41);
        java.awt.Color color45 = java.awt.Color.WHITE;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis47);
        java.awt.Stroke stroke49 = combinedRangeXYPlot48.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot48);
        org.jfree.chart.axis.ValueAxis valueAxis52 = combinedRangeXYPlot48.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Stroke stroke53 = combinedRangeXYPlot48.getDomainGridlineStroke();
        barRenderer3D0.drawRangeLine(graphics2D13, categoryPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, rectangle2D41, (double) 19000L, (java.awt.Paint) color45, stroke53);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot55 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis56);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        combinedRangeXYPlot57.setRenderer(xYItemRenderer58);
        java.awt.Font font61 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock62 = new org.jfree.chart.block.LabelBlock("", font61);
        combinedRangeXYPlot57.setNoDataMessageFont(font61);
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        combinedRangeXYPlot57.setRangeAxis(12, valueAxis65, true);
        combinedDomainXYPlot55.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot57, 32);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font61);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setTickLabelsVisible(false);
        java.util.Date date33 = dateAxis23.getMaximumDate();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year34.getLastMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.lightGray;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = categoryPlot0.getDomainAxis((int) (short) 10);
        java.awt.Stroke stroke5 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(categoryAxis4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot1.panDomainAxes((double) 0, plotRenderingInfo5, point2D6);
        float float8 = combinedRangeXYPlot1.getForegroundAlpha();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = combinedRangeXYPlot1.getRenderer();
        combinedRangeXYPlot1.configureDomainAxes();
        java.awt.Stroke stroke11 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint7 = barRenderer3D0.getShadowPaint();
        java.awt.Paint paint11 = barRenderer3D0.getItemPaint(0, 192, false);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D5.setTickUnit(numberTickUnit7, true, true);
        java.awt.Shape shape11 = numberAxis3D5.getDownArrow();
        int int12 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D5);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        java.util.Date date14 = dateRange13.getLowerDate();
        boolean boolean15 = categoryPlot0.equals((java.lang.Object) date14);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setRangeAxes(valueAxisArray12);
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray16 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis15.setLabelInfo(periodAxisLabelInfoArray16);
        org.jfree.chart.axis.TickUnits tickUnits18 = new org.jfree.chart.axis.TickUnits();
        periodAxis15.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits18);
        int int20 = combinedRangeXYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis15);
        java.lang.Object obj21 = periodAxis15.clone();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D22 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D22.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = barRenderer3D22.getURLGenerator((int) '#', 1, false);
        double double29 = barRenderer3D22.getMinimumBarLength();
        java.awt.Paint paint30 = barRenderer3D22.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = barRenderer3D22.getToolTipGenerator(1900, (int) (byte) 0, true);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection36 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        timeSeriesCollection36.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot38);
        categoryPlot38.setDomainCrosshairRowKey((java.lang.Comparable) "^0.48");
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = categoryPlot38.getDomainMarkers(8, layer43);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot45.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace47 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot45.setFixedDomainAxisSpace(axisSpace47, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit52 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D50.setTickUnit(numberTickUnit52, true, true);
        java.awt.Shape shape56 = numberAxis3D50.getDownArrow();
        int int57 = categoryPlot45.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D50);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D63 = chartRenderingInfo62.getChartArea();
        boolean boolean64 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D63);
        java.awt.geom.Point2D point2D65 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D63);
        java.awt.Color color67 = java.awt.Color.WHITE;
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot70 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis69);
        java.awt.Stroke stroke71 = combinedRangeXYPlot70.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart72 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot70);
        org.jfree.chart.axis.ValueAxis valueAxis74 = combinedRangeXYPlot70.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Stroke stroke75 = combinedRangeXYPlot70.getDomainGridlineStroke();
        barRenderer3D22.drawRangeLine(graphics2D35, categoryPlot38, (org.jfree.chart.axis.ValueAxis) numberAxis3D50, rectangle2D63, (double) 19000L, (java.awt.Paint) color67, stroke75);
        periodAxis15.setLeftArrow((java.awt.Shape) rectangle2D63);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(categoryURLGenerator28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(point2D65);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNull(valueAxis74);
        org.junit.Assert.assertNotNull(stroke75);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("org.jfree.data.general.SeriesException: {0}", paint8);
        java.awt.Stroke stroke10 = legendItem9.getOutlineStroke();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        combinedRangeXYPlot1.setDomainCrosshairVisible(true);
        combinedRangeXYPlot1.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        try {
            combinedRangeXYPlot1.setDomainAxisLocation(0, axisLocation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Paint paint2 = barRenderer3D0.getLegendTextPaint((int) (short) 1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        barRenderer3D0.setBaseStroke(stroke3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = java.awt.Color.lightGray;
        categoryPlot5.setDomainCrosshairPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        combinedRangeXYPlot9.setRenderer(xYItemRenderer10);
        java.awt.Paint paint12 = combinedRangeXYPlot9.getDomainMinorGridlinePaint();
        boolean boolean13 = categoryPlot5.equals((java.lang.Object) paint12);
        java.awt.Stroke stroke14 = categoryPlot5.getRangeZeroBaselineStroke();
        barRenderer3D0.setBaseOutlineStroke(stroke14, false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        org.jfree.chart.StandardChartTheme standardChartTheme4 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = standardChartTheme4.getLabelLinkStyle();
        java.awt.Font font6 = standardChartTheme4.getLargeFont();
        java.awt.Paint paint7 = standardChartTheme4.getDomainGridlinePaint();
        java.awt.Paint paint8 = standardChartTheme4.getLabelLinkPaint();
        barRenderer3D0.setSeriesOutlinePaint(0, paint8);
        double double10 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator11);
        barRenderer3D0.setShadowVisible(false);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(4);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean11 = xYLineAndShapeRenderer7.getAutoPopulateSeriesShape();
        boolean boolean12 = xYLineAndShapeRenderer7.getAutoPopulateSeriesShape();
        boolean boolean13 = xYLineAndShapeRenderer7.getBaseShapesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        xYLineAndShapeRenderer7.setSeriesShapesVisible((int) (short) 1, (java.lang.Boolean) false);
        java.awt.Paint paint14 = xYLineAndShapeRenderer7.getBaseFillPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        java.awt.Stroke stroke15 = combinedRangeXYPlot14.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot14);
        float float17 = jFreeChart16.getBackgroundImageAlpha();
        java.awt.Paint paint18 = jFreeChart16.getBackgroundPaint();
        int int19 = jFreeChart16.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart16.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle20.getItemLabelPadding();
        categoryPlot0.setAxisOffset(rectangleInsets21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        int int27 = combinedRangeXYPlot25.getDomainAxisIndex(valueAxis26);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean30 = combinedRangeXYPlot25.removeDomainMarker(marker28, layer29);
        boolean boolean31 = combinedRangeXYPlot25.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        combinedRangeXYPlot25.zoomRangeAxes(Double.NaN, plotRenderingInfo33, point2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot36.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint39 = defaultDrawingSupplier38.getNextFillPaint();
        categoryPlot36.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot36.getDomainAxisLocation(1);
        combinedRangeXYPlot25.setRangeAxisLocation(axisLocation42);
        categoryPlot0.setDomainAxisLocation((int) '4', axisLocation42);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int10 = combinedRangeXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        boolean boolean13 = xYLineAndShapeRenderer9.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        double double16 = categoryAxis3D15.getCategoryMargin();
        java.awt.Stroke stroke17 = categoryAxis3D15.getAxisLineStroke();
        xYLineAndShapeRenderer9.setSeriesStroke(1900, stroke17);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = xYLineAndShapeRenderer9.getLegendItemLabelGenerator();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int21 = color20.getAlpha();
        java.awt.color.ColorSpace colorSpace22 = color20.getColorSpace();
        xYLineAndShapeRenderer9.setBaseOutlinePaint((java.awt.Paint) color20);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator25 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        boolean boolean27 = standardXYToolTipGenerator25.equals((java.lang.Object) 255);
        java.lang.Object obj28 = standardXYToolTipGenerator25.clone();
        xYLineAndShapeRenderer9.setSeriesToolTipGenerator((int) (byte) 100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator25, false);
        java.text.DateFormat dateFormat31 = standardXYToolTipGenerator25.getXDateFormat();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 32, dateFormat31);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType33 = dateTickUnit32.getUnitType();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(dateFormat31);
        org.junit.Assert.assertNotNull(dateTickUnitType33);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeries4.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        timeSeries4.setDomainDescription("ClassContext");
        boolean boolean14 = timeSeries4.isEmpty();
        timeSeries4.clear();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedRangeXYPlot2.setRenderer(xYItemRenderer3);
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        combinedRangeXYPlot2.setNoDataMessageFont(font6);
        java.awt.Paint paint9 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font6, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.trimHeight(0.0d);
        periodAxis1.setLabelInsets(rectangleInsets6);
        periodAxis1.resizeRange((double) 1.0f);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((-1), 0, false);
        boolean boolean7 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        boolean boolean9 = xYLineAndShapeRenderer2.removeAnnotation(xYAnnotation8);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Last");
        numberAxis1.setTickMarkOutsideLength((float) 19000L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        xYDataItem2.setSelected(true);
        double double7 = xYDataItem2.getXValue();
        xYDataItem2.setY((java.lang.Number) 15);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = xYLineAndShapeRenderer2.getLegendItemToolTipGenerator();
        xYLineAndShapeRenderer2.setBaseShapesFilled(false);
        boolean boolean10 = xYLineAndShapeRenderer2.getItemShapeFilled((int) (byte) -1, (int) '4');
        xYLineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) ' ');
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) ' ');
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot0.removeDomainMarker(0, marker11, layer12);
        java.awt.Paint paint14 = categoryPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setTickLabelsVisible(false);
        java.util.Date date33 = dateAxis23.getMaximumDate();
        dateAxis23.setAxisLineVisible(false);
        java.awt.Shape shape36 = dateAxis23.getRightArrow();
        java.io.ObjectOutputStream objectOutputStream37 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape36, objectOutputStream37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = combinedRangeXYPlot9.getDomainAxisIndex(valueAxis10);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = combinedRangeXYPlot9.removeDomainMarker(marker12, layer13);
        boolean boolean15 = combinedRangeXYPlot9.isDomainZoomable();
        combinedRangeXYPlot9.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        org.jfree.data.Range range21 = combinedRangeXYPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.data.Range range22 = combinedRangeXYPlot2.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        combinedRangeXYPlot2.clearDomainMarkers(2958465);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setFixedDimension((double) 0.5f);
        double double3 = categoryAxis3D0.getCategoryMargin();
        java.awt.Paint paint4 = categoryAxis3D0.getAxisLinePaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis3D0.setTickMarkPaint((java.awt.Paint) color5);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        float float11 = periodAxis10.getMinorTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double26 = numberAxis3D14.java2DToValue((double) 0.5f, rectangle2D21, rectangleEdge25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis27);
        combinedRangeXYPlot28.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder31 = combinedRangeXYPlot28.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation33 = null;
        combinedRangeXYPlot28.setRangeAxisLocation(4, axisLocation33, false);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot28.setBackgroundPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot39.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint42 = defaultDrawingSupplier41.getNextFillPaint();
        categoryPlot39.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier41);
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot39.getDomainAxisLocation(1);
        combinedRangeXYPlot28.setDomainAxisLocation(2019, axisLocation45, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj49 = null;
        boolean boolean50 = plotOrientation48.equals(obj49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation45, plotOrientation48);
        double double52 = periodAxis10.valueToJava2D((double) 10L, rectangle2D21, rectangleEdge51);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot55 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis54);
        java.awt.Stroke stroke56 = combinedRangeXYPlot55.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot55);
        org.jfree.chart.axis.ValueAxis valueAxis59 = combinedRangeXYPlot55.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean60 = combinedRangeXYPlot55.isNotify();
        org.jfree.chart.StandardChartTheme standardChartTheme62 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle63 = standardChartTheme62.getLabelLinkStyle();
        java.awt.Font font64 = standardChartTheme62.getLargeFont();
        java.awt.Color color65 = java.awt.Color.ORANGE;
        standardChartTheme62.setRangeGridlinePaint((java.awt.Paint) color65);
        combinedRangeXYPlot55.setDomainCrosshairPaint((java.awt.Paint) color65);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = combinedRangeXYPlot55.getRangeAxisEdge();
        double double69 = categoryAxis3D0.getCategoryEnd(13, (int) (byte) -1, rectangle2D21, rectangleEdge68);
        org.jfree.chart.util.LogFormat logFormat74 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat74.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer78 = null;
        java.text.FieldPosition fieldPosition79 = null;
        java.lang.StringBuffer stringBuffer80 = logFormat74.format((long) 1, stringBuffer78, fieldPosition79);
        org.jfree.chart.util.LogFormat logFormat84 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator85 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", (java.text.NumberFormat) logFormat74, (java.text.NumberFormat) logFormat84);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset86 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot87 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset86);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset88 = new org.jfree.data.general.DefaultPieDataset();
        java.lang.Number number90 = defaultPieDataset88.getValue(0);
        ringPlot87.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset88);
        java.text.AttributedString attributedString93 = standardPieSectionLabelGenerator85.generateAttributedSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset88, (java.lang.Comparable) 1577865599999L);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity99 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D21, (org.jfree.data.general.PieDataset) defaultPieDataset88, 9, (int) (short) 100, (java.lang.Comparable) 24231L, "Pie 3D Plot", "ThreadContext");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(seriesRenderingOrder31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNull(valueAxis59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle63);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(stringBuffer80);
        org.junit.Assert.assertNull(number90);
        org.junit.Assert.assertNull(attributedString93);
    }
}

