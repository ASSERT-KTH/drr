import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { (byte) -1, (-1.0d), "hi!", (short) 1 };
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] { 1L, 0.0f, (byte) 0, 1 };
        double[] doubleArray14 = new double[] { 0.0d, 1.0f, 100, 10L };
        double[] doubleArray19 = new double[] { 0.0d, 1.0f, 100, 10L };
        double[] doubleArray24 = new double[] { 0.0d, 1.0f, 100, 10L };
        double[][] doubleArray25 = new double[][] { doubleArray14, doubleArray19, doubleArray24 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray9, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getOutlineStroke();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            combinedRangeXYPlot1.addDomainMarker(marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme10 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint11 = standardChartTheme10.getThermometerPaint();
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "", shape4, paint5, stroke8, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Font font3 = null;
        try {
            standardChartTheme1.setSmallFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.magenta;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font1, (java.awt.Paint) color2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        try {
            timeSeriesCollection6.setSelected((int) ' ', (int) (short) 1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (32).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = null;
        try {
            standardChartTheme1.setDrawingSupplier(drawingSupplier3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'supplier' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = null;
        try {
            timeSeriesCollection1.setGroup(datasetGroup2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            combinedRangeXYPlot1.zoomDomainAxes(0.0d, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot1.panDomainAxes((double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            combinedRangeXYPlot1.zoomDomainAxes((double) (short) 1, plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            jFreeChart4.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.util.List list1 = null;
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        try {
            org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, list1, range2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = null;
        try {
            legendItem1.setLine(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setTickMarksVisible(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double7 = categoryAxis3D0.getCategoryEnd(1, 1900, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setTickMarksVisible(true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double8 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor3, 1, (int) '4', rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        try {
            combinedRangeXYPlot1.setRangeAxisLocation(axisLocation4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        try {
            xYLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            combinedRangeXYPlot2.addRangeMarker(marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "{0}");
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        jFreeChart4.setBorderVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Shape shape1 = null;
        try {
            ringPlot0.setLegendItemShape(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setFixedDimension((double) 0.5f);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double8 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor3, (int) (short) 10, (int) (byte) -1, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries1.remove((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            boolean boolean4 = timeSeriesCollection0.isSelected(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        try {
            combinedRangeXYPlot1.setDomainAxisLocation(0, axisLocation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat3.setMinimumIntegerDigits((int) (short) -1);
        logFormat3.setMaximumFractionDigits(0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        try {
            combinedRangeXYPlot1.zoomDomainAxes((double) 0.0f, plotRenderingInfo6, point2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Shape shape0 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme2.setErrorIndicatorPaint(paint3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int13 = combinedRangeXYPlot7.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        java.awt.Paint paint14 = combinedRangeXYPlot7.getRangeZeroBaselinePaint();
        standardChartTheme2.setItemLabelPaint(paint14);
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape0, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart4.createBufferedImage(0, (int) (byte) 1, 0, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        java.awt.Font font5 = null;
        try {
            combinedRangeXYPlot1.setNoDataMessageFont(font5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        boolean boolean3 = shapeList0.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.util.List list5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double8 = categoryAxis3D0.getCategoryMiddle((java.lang.Comparable) 10L, list5, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) '4', (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1900);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) (byte) 100, (double) '4', rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        timeSeriesCollection1.seriesChanged(seriesChangeEvent2);
        try {
            double double6 = timeSeriesCollection1.getXValue((int) (short) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        java.util.Locale locale3 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("{0}", timeZone1, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        int int1 = defaultPieDataset0.getItemCount();
        try {
            defaultPieDataset0.remove((java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (100) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.util.List list2 = null;
        try {
            org.jfree.data.Range range4 = timeSeriesCollection0.getDomainBounds(list2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultPieDataset0.sortByKeys(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYLineAndShapeRenderer2.drawAnnotations(graphics2D5, rectangle2D6, valueAxis7, valueAxis8, layer9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) 100L, (double) 4, 0);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        boolean boolean10 = jFreeChart9.getAntiAlias();
        boolean boolean11 = defaultPieDataset0.equals((java.lang.Object) jFreeChart9);
        org.jfree.chart.util.SortOrder sortOrder12 = null;
        try {
            defaultPieDataset0.sortByKeys(sortOrder12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        java.lang.String str5 = combinedRangeXYPlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Shape shape0 = null;
        org.jfree.chart.title.Title title1 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity4 = new org.jfree.chart.entity.TitleEntity(shape0, title1, "", "^0.48");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '4', 10.0d);
        columnArrangement4.clear();
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) '4', 10.0d);
        columnArrangement4.add((org.jfree.chart.block.Block) labelBlock8, (java.lang.Object) '4');
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            labelBlock8.setBounds(rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.text.NumberFormat numberFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}", numberFormat1, (java.text.NumberFormat) logFormat5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        try {
            xYAreaRenderer1.setBaseNegativeItemLabelPosition(itemLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) '#', (double) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme3 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint4 = standardChartTheme3.getThermometerPaint();
        ringPlot0.setLabelShadowPaint(paint4);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList7 = new org.jfree.chart.util.ShapeList();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) shapeList7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        java.awt.Stroke stroke14 = combinedRangeXYPlot13.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        float float16 = jFreeChart15.getBackgroundImageAlpha();
        java.awt.Stroke stroke17 = jFreeChart15.getBorderStroke();
        ringPlot6.setSectionOutlineStroke((java.lang.Comparable) year9, stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder(paint4, stroke17, rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            combinedRangeXYPlot2.setRangeAxisLocation(axisLocation12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", font2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            textLine4.draw(graphics2D5, (float) 'a', 10.0f, textAnchor8, (float) (-1L), 0.0f, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        try {
            defaultKeyedValues0.insertValue(1, (java.lang.Comparable) (short) 1, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot1.setRangeAxisLocation(4, axisLocation6, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot1.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            combinedRangeXYPlot1.addDomainMarker((int) (short) 100, marker12, layer13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean5 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            xYLineAndShapeRenderer2.addAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYStepAreaRenderer1.getToolTipGenerator((int) 'a', (int) (byte) 100, true);
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            xYStepAreaRenderer1.setSeriesItemLabelPaint((-1), paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            combinedRangeXYPlot2.addDomainMarker(marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, 0.05d, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYStepAreaRenderer1.getToolTipGenerator((int) 'a', (int) (byte) 100, true);
        java.lang.Boolean boolean8 = xYStepAreaRenderer1.getSeriesVisible((int) (short) -1);
        xYStepAreaRenderer1.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle6 = null;
        try {
            jFreeChart4.addLegend(legendTitle6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            tickUnits0.add(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'unit' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(3, year5);
        long long8 = month7.getSerialIndex();
        try {
            org.jfree.data.xy.XYDataset xYDataset9 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 45.0d, (double) 3, 255, (java.lang.Comparable) long8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24231L + "'", long8 == 24231L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        int int2 = timeSeriesCollection0.getSeriesCount();
        timeSeriesCollection0.validateObject();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color1 = java.awt.Color.getColor("Combined Range XYPlot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str5 = logFormat3.format((java.lang.Object) 3);
        logFormat3.setMaximumFractionDigits(2958465);
        try {
            java.util.Currency currency8 = logFormat3.getCurrency();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "^0.48" + "'", str5.equals("^0.48"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint3 = standardChartTheme2.getThermometerPaint();
        try {
            org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int19 = color18.getAlpha();
        java.awt.color.ColorSpace colorSpace20 = color18.getColorSpace();
        xYLineAndShapeRenderer7.setBaseOutlinePaint((java.awt.Paint) color18);
        boolean boolean22 = xYLineAndShapeRenderer7.getAutoPopulateSeriesPaint();
        try {
            xYLineAndShapeRenderer7.setSeriesShapesVisible((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.DAY;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) ' ', dateTickUnitType2, (int) '4', dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint7 = standardChartTheme6.getThermometerPaint();
        ringPlot3.setLabelShadowPaint(paint7);
        labelBlock2.setPaint(paint7);
        java.lang.Object obj10 = labelBlock2.clone();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = labelBlock2.arrange(graphics2D11, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("VerticalAlignment.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double3 = range2.getUpperBound();
        try {
            org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, list1, range2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(1, year1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        double double11 = intervalXYDelegate8.getDomainUpperBound(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2019, 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        ringPlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        try {
            combinedRangeXYPlot7.zoomDomainAxes(0.05d, plotRenderingInfo13, point2D14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Stroke stroke6 = jFreeChart4.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart4.createBufferedImage((int) (short) 0, (int) (short) -1, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str16 = logFormat14.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        java.lang.Object obj18 = standardPieToolTipGenerator17.clone();
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "^0.48" + "'", str16.equals("^0.48"));
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(0.0d, (double) (byte) 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        xYLineAndShapeRenderer2.clearSeriesStrokes(false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = xYLineAndShapeRenderer2.getToolTipGenerator((int) 'a', (int) (byte) 0, true);
        org.junit.Assert.assertNull(xYToolTipGenerator8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        try {
            jFreeChart4.draw(graphics2D7, rectangle2D8, point2D9, chartRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.clearSectionOutlinePaints(true);
        java.awt.Shape shape3 = null;
        try {
            ringPlot0.setLegendItemShape(shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '4', 10.0d);
        columnArrangement4.clear();
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) '4', 10.0d);
        columnArrangement4.add((org.jfree.chart.block.Block) labelBlock8, (java.lang.Object) '4');
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = labelBlock8.arrange(graphics2D15, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("{0}");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ", font1, paint2, (float) (byte) 1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            textFragment4.draw(graphics2D5, (float) 4, (float) 10, textAnchor8, (float) (byte) 100, 0.0f, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            combinedRangeXYPlot1.addRangeMarker((int) (short) 0, marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint7 = standardChartTheme6.getThermometerPaint();
        ringPlot3.setLabelShadowPaint(paint7);
        labelBlock2.setPaint(paint7);
        double double10 = labelBlock2.getContentYOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        int int9 = combinedRangeXYPlot2.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            combinedRangeXYPlot2.addRangeMarker(255, marker11, layer12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str16 = logFormat14.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        java.awt.Font font19 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font19);
        try {
            java.lang.String str21 = logFormat4.format((java.lang.Object) labelBlock20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "^0.48" + "'", str16.equals("^0.48"));
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot1.setRangeAxisLocation(4, axisLocation6, false);
        java.awt.geom.Point2D point2D9 = null;
        try {
            combinedRangeXYPlot1.setQuadrantOrigin(point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.lang.Boolean boolean10 = xYLineAndShapeRenderer7.getSeriesLinesVisible((-1));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds(xYDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            double double5 = timeSeriesCollection1.getEndYValue((int) (byte) 10, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int9 = combinedRangeXYPlot3.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer8);
        boolean boolean12 = xYLineAndShapeRenderer8.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer8.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        java.util.TimeZone timeZone20 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("", timeZone20);
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("", timeZone23);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection25);
        xYLineAndShapeRenderer8.drawItem(graphics2D15, xYItemRendererState16, rectangle2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.data.xy.XYDataset) timeSeriesCollection25, (int) (short) 0, 4, false, (int) '4');
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend32 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) dateAxis24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(number26);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        boolean boolean6 = jFreeChart4.getAntiAlias();
        java.awt.RenderingHints renderingHints7 = null;
        try {
            jFreeChart4.setRenderingHints(renderingHints7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList9 = new org.jfree.chart.util.ShapeList();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) shapeList9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        java.awt.Stroke stroke19 = jFreeChart17.getBorderStroke();
        ringPlot8.setSectionOutlineStroke((java.lang.Comparable) year11, stroke19);
        combinedRangeXYPlot2.setDomainGridlineStroke(stroke19);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        try {
            boolean boolean26 = combinedRangeXYPlot2.removeRangeMarker(3, marker23, layer24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(255, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint8 = xYLineAndShapeRenderer2.getItemPaint(12, 3, true);
        java.awt.Paint paint10 = xYLineAndShapeRenderer2.lookupSeriesPaint(0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Shape shape0 = null;
        org.jfree.chart.title.Title title1 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity4 = new org.jfree.chart.entity.TitleEntity(shape0, title1, "", "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        xYDataItem2.setY((java.lang.Number) 4.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        boolean boolean5 = combinedRangeXYPlot1.equals((java.lang.Object) ' ');
        combinedRangeXYPlot1.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double6 = dateAxis2.lengthToJava2D((double) (byte) 1, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        xYSeries1.setDescription("{0}");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        int int8 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart4.createBufferedImage(100, (int) '4', chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = xYLineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = xYLineAndShapeRenderer2.getToolTipGenerator(100, (int) '#', true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator5);
        org.junit.Assert.assertNull(xYToolTipGenerator9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            java.lang.Number number5 = timeSeriesCollection0.getStartY((int) (byte) 1, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList9 = new org.jfree.chart.util.ShapeList();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) shapeList9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        float float18 = jFreeChart17.getBackgroundImageAlpha();
        java.awt.Stroke stroke19 = jFreeChart17.getBorderStroke();
        ringPlot8.setSectionOutlineStroke((java.lang.Comparable) year11, stroke19);
        combinedRangeXYPlot2.setDomainGridlineStroke(stroke19);
        java.util.List list23 = null;
        try {
            combinedRangeXYPlot2.mapDatasetToRangeAxes((int) (short) 100, list23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setFixedDimension((double) 0.5f);
        double double3 = categoryAxis3D0.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.trimHeight(0.0d);
        categoryAxis3D0.setLabelInsets(rectangleInsets4, false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo11.getChartArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.axis.AxisState axisState17 = categoryAxis3D0.draw(graphics2D9, (double) 900000L, rectangle2D12, rectangle2D14, rectangleEdge15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, (java.awt.Shape) rectangle2D2, 100.0d, (float) '4', (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYStepAreaRenderer1.getToolTipGenerator((int) 'a', (int) (byte) 100, true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator9 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator9, xYURLGenerator10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        combinedRangeXYPlot14.setRenderer(xYItemRenderer15);
        java.awt.Paint paint17 = combinedRangeXYPlot14.getDomainMinorGridlinePaint();
        xYAreaRenderer11.setSeriesOutlinePaint((int) (byte) 0, paint17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        combinedRangeXYPlot22.setRenderer(xYItemRenderer23);
        java.awt.Paint paint25 = combinedRangeXYPlot22.getDomainMinorGridlinePaint();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean29 = xYSeries27.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection30);
        xYSeries27.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeriesCollection30.getSeries((java.lang.Comparable) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState36 = xYAreaRenderer11.initialise(graphics2D19, rectangle2D20, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot22, (org.jfree.data.xy.XYDataset) timeSeriesCollection30, plotRenderingInfo35);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis38);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        combinedRangeXYPlot39.setRenderer(xYItemRenderer40);
        java.awt.Font font43 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("", font43);
        combinedRangeXYPlot39.setNoDataMessageFont(font43);
        double double46 = combinedRangeXYPlot39.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace47 = combinedRangeXYPlot39.getFixedRangeAxisSpace();
        java.util.TimeZone timeZone49 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("", timeZone49);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit53 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f));
        numberAxis3D51.setTickUnit(numberTickUnit53, true, true);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot59 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis58);
        java.awt.Stroke stroke60 = combinedRangeXYPlot59.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart61 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot59);
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection63 = new org.jfree.data.time.TimeSeriesCollection(timeZone62);
        combinedRangeXYPlot59.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection63);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate65 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection63);
        try {
            xYStepAreaRenderer1.drawItem(graphics2D7, xYItemRendererState36, rectangle2D37, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot39, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, (org.jfree.data.xy.XYDataset) timeSeriesCollection63, 1900, 1900, false, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1900).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNull(timeSeries34);
        org.junit.Assert.assertNotNull(xYItemRendererState36);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(axisSpace47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        strokeList0.clear();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        boolean boolean2 = domainOrder0.equals((java.lang.Object) 10.0f);
        java.lang.String str3 = domainOrder0.toString();
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DomainOrder.NONE" + "'", str3.equals("DomainOrder.NONE"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot1.isDomainZoomable();
        int int13 = combinedRangeXYPlot1.getRendererCount();
        java.awt.Paint paint14 = null;
        try {
            combinedRangeXYPlot1.setNoDataMessagePaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        double double1 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        try {
            timeSeriesCollection24.removeSeries(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (3).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Stroke stroke7 = xYAreaRenderer1.getItemStroke(1, 1, false);
        xYAreaRenderer1.setSeriesCreateEntities((int) ' ', (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color2);
        java.lang.Object obj4 = null;
        boolean boolean5 = standardChartTheme1.equals(obj4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        double double5 = intervalXYDelegate3.getDomainLowerBound(false);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer7.setDrawSeriesLineAsPath(true);
        double double17 = xYLineAndShapeRenderer7.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        boolean boolean5 = combinedRangeXYPlot1.isNotify();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = combinedRangeXYPlot1.removeDomainMarker(10, marker7, layer8);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        java.awt.Paint paint19 = xYLineAndShapeRenderer15.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Color color20 = java.awt.Color.darkGray;
        xYLineAndShapeRenderer15.setBaseItemLabelPaint((java.awt.Paint) color20);
        float[] floatArray23 = new float[] { 1.0f };
        try {
            float[] floatArray24 = color20.getComponents(floatArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.lang.Object obj2 = standardChartTheme1.clone();
        boolean boolean3 = standardChartTheme1.isShadowVisible();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str1 = categoryAxis3D0.getLabelURL();
        java.awt.Paint paint2 = categoryAxis3D0.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        float float8 = jFreeChart7.getBackgroundImageAlpha();
        boolean boolean9 = categoryAxis3D0.hasListener((java.util.EventListener) jFreeChart7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.RenderingSource renderingSource14 = null;
        chartRenderingInfo13.setRenderingSource(renderingSource14);
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart7.createBufferedImage(4, 1900, (int) (short) -1, chartRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYLineAndShapeRenderer15.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem20 = legendItemCollection18.get((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(legendItemCollection18);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        java.awt.Shape shape2 = null;
        try {
            ringPlot0.setLegendItemShape(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        xYLineAndShapeRenderer15.setBaseURLGenerator(xYURLGenerator18);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 1900, (int) (byte) 10, 255);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(900000L);
        boolean boolean6 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        long long5 = year1.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.axis.ValueAxis valueAxis13 = combinedRangeXYPlot9.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Stroke stroke14 = combinedRangeXYPlot9.getDomainGridlineStroke();
        combinedRangeXYPlot2.setRangeMinorGridlineStroke(stroke14);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int10 = combinedRangeXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer9);
        boolean boolean13 = xYLineAndShapeRenderer9.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        double double16 = categoryAxis3D15.getCategoryMargin();
        java.awt.Stroke stroke17 = categoryAxis3D15.getAxisLineStroke();
        xYLineAndShapeRenderer9.setSeriesStroke(1900, stroke17);
        strokeList0.setStroke(100, stroke17);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        try {
            xYSeries1.update((java.lang.Number) 255, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 255");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        xYSeries1.add((double) 10, (double) 1L, true);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.remove((java.lang.Number) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        boolean boolean2 = standardXYToolTipGenerator0.equals((java.lang.Object) 255);
        java.lang.Object obj3 = standardXYToolTipGenerator0.clone();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        try {
            java.lang.String str9 = standardXYToolTipGenerator0.generateToolTip((org.jfree.data.xy.XYDataset) timeSeriesCollection4, 4, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.jfree.data.xy.XYDataItem xYDataItem6 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number7 = xYDataItem6.getY();
        double double8 = xYDataItem6.getXValue();
        java.lang.String str9 = xYDataItem6.toString();
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] { 0.08d, "org.jfree.data.UnknownKeyException: ", xYDataItem6 };
        double[] doubleArray17 = new double[] { 0.5d, 3, 0.0f, (byte) 100, 0.0f, 2.0f };
        double[] doubleArray24 = new double[] { 0.5d, 3, 0.0f, (byte) 100, 0.0f, 2.0f };
        double[][] doubleArray25 = new double[][] { doubleArray17, doubleArray24 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray1, comparableArray10, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[10.0, -1.0]" + "'", str9.equals("[10.0, -1.0]"));
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D1.setMinorTickCount((-1));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.lang.Object obj9 = labelBlock8.clone();
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock8.getBounds();
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font12);
        java.lang.Object obj14 = labelBlock13.clone();
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock13.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            org.jfree.chart.axis.AxisState axisState18 = numberAxis3D1.draw(graphics2D4, 10.0d, rectangle2D10, rectangle2D15, rectangleEdge16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        boolean boolean4 = xYSeries1.getAutoSort();
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate((double) 1900, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataItem7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer7.clearSeriesStrokes(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        xYLineAndShapeRenderer7.setBaseURLGenerator(xYURLGenerator17, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.awt.Paint paint14 = xYLineAndShapeRenderer7.lookupSeriesPaint(1900);
        java.awt.Stroke stroke16 = xYLineAndShapeRenderer7.getSeriesStroke((int) (short) 100);
        java.lang.Object obj17 = xYLineAndShapeRenderer7.clone();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "org.jfree.data.UnknownKeyException: ", "org.jfree.data.general.SeriesChangeEvent[source=10]", "DomainOrder.NONE");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = null;
        try {
            ringPlot0.setLabelLinkStyle(pieLabelLinkStyle2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot2.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean7 = combinedRangeXYPlot2.isNotify();
        org.jfree.chart.StandardChartTheme standardChartTheme9 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle10 = standardChartTheme9.getLabelLinkStyle();
        java.awt.Font font11 = standardChartTheme9.getLargeFont();
        java.awt.Color color12 = java.awt.Color.ORANGE;
        standardChartTheme9.setRangeGridlinePaint((java.awt.Paint) color12);
        combinedRangeXYPlot2.setDomainCrosshairPaint((java.awt.Paint) color12);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            boolean boolean17 = combinedRangeXYPlot2.removeAnnotation(xYAnnotation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.title.LegendTitle legendTitle5 = null;
        try {
            jFreeChart4.addLegend(legendTitle5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean12 = xYLineAndShapeRenderer7.isSeriesVisibleInLegend(1);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer7.getSeriesVisibleInLegend((int) (short) 10);
        xYLineAndShapeRenderer7.clearSeriesStrokes(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str18 = categoryAxis3D17.getLabelURL();
        java.awt.Paint paint19 = categoryAxis3D17.getLabelPaint();
        xYLineAndShapeRenderer7.setBaseItemLabelPaint(paint19);
        int int21 = xYLineAndShapeRenderer7.getPassCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            double double6 = timeSeriesCollection0.getEndYValue((int) ' ', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        double double10 = intervalXYDelegate8.getIntervalWidth();
        try {
            double double13 = intervalXYDelegate8.getEndXValue(1900, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.Object obj1 = null;
        boolean boolean2 = verticalAlignment0.equals(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList6 = new org.jfree.chart.util.ShapeList();
        boolean boolean7 = ringPlot5.equals((java.lang.Object) shapeList6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        float float15 = jFreeChart14.getBackgroundImageAlpha();
        java.awt.Stroke stroke16 = jFreeChart14.getBorderStroke();
        ringPlot5.setSectionOutlineStroke((java.lang.Comparable) year8, stroke16);
        java.awt.Paint paint18 = ringPlot5.getLabelPaint();
        xYAreaRenderer3.setLegendTextPaint(1900, paint18);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint7 = standardChartTheme6.getThermometerPaint();
        ringPlot3.setLabelShadowPaint(paint7);
        labelBlock2.setPaint(paint7);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font12);
        java.lang.Object obj14 = labelBlock13.clone();
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock13.getBounds();
        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("", timeZone17);
        try {
            java.lang.Object obj19 = labelBlock2.draw(graphics2D10, rectangle2D15, (java.lang.Object) timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(3, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate(regularTimePeriod9, (double) 60000L);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(3, year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year13.next();
        try {
            timeSeries4.add(regularTimePeriod16, Double.NaN);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2020 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean4 = xYSeries2.equals((java.lang.Object) 10.0d);
        boolean boolean5 = shapeList0.equals((java.lang.Object) 10.0d);
        int int6 = shapeList0.size();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        combinedRangeXYPlot1.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        double double6 = timeSeriesCollection3.getDomainLowerBound(true);
        try {
            double double9 = timeSeriesCollection3.getStartXValue((int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = chartRenderingInfo0.getChartArea();
        org.jfree.chart.title.Title title2 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity5 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape) rectangle2D1, title2, "SeriesRenderingOrder.REVERSE", "org.jfree.data.general.SeriesChangeEvent[source=10]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ", font2, paint3, (float) (byte) 1);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.data.general.SeriesChangeEvent[source=10]", font2, (java.awt.Paint) color6, (float) 2, 0, textMeasurer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedRangeXYPlot2.setRenderer(xYItemRenderer3);
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        combinedRangeXYPlot2.setNoDataMessageFont(font6);
        org.jfree.chart.plot.Plot plot9 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("DomainOrder.NONE", font6, plot9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            categoryPlot0.addRangeMarker(0, marker3, layer4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day5, regularTimePeriod6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str16 = logFormat14.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat4.parseObject("2,019", parsePosition19);
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "^0.48" + "'", str16.equals("^0.48"));
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = combinedRangeXYPlot1.getSeriesRenderingOrder();
        java.lang.Object obj5 = combinedRangeXYPlot1.clone();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = combinedRangeXYPlot1.getDrawingSupplier();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        boolean boolean11 = combinedRangeXYPlot1.removeDomainMarker((int) (byte) 1, marker8, layer9, false);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            boolean boolean16 = combinedRangeXYPlot1.removeRangeMarker((int) (short) -1, marker13, layer14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ", font1, paint2, (float) (byte) 1);
        float float5 = textFragment4.getBaselineOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        int int1 = defaultPieDataset0.getItemCount();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        try {
            java.lang.Number number4 = defaultPieDataset0.getValue((java.lang.Comparable) year2);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 2019");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Stroke stroke2 = legendItem1.getLineStroke();
        java.awt.Stroke stroke3 = legendItem1.getLineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        boolean boolean9 = jFreeChart8.getAntiAlias();
        jFreeChart8.setTitle("hi!");
        java.awt.Paint paint12 = jFreeChart8.getBackgroundPaint();
        legendItem1.setFillPaint(paint12);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = xYAreaRenderer1.getBaseToolTipGenerator();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            xYAreaRenderer1.setSeriesOutlinePaint((int) (short) -1, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Object obj2 = multiplePiePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = multiplePiePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        int int9 = combinedRangeXYPlot2.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues10 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list11 = defaultKeyedValues10.getKeys();
        org.jfree.data.Range range12 = null;
        try {
            org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, list11, range12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xRange' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = null;
        timeSeriesCollection2.seriesChanged(seriesChangeEvent3);
        try {
            java.lang.String str7 = standardXYToolTipGenerator0.generateToolTip((org.jfree.data.xy.XYDataset) timeSeriesCollection2, 255, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (255).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        try {
            int[] intArray34 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 1, (double) 2, (double) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D7);
        try {
            barRenderer3D0.drawOutline(graphics2D2, categoryPlot3, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Object obj2 = multiplePiePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        java.awt.Shape shape4 = multiplePiePlot1.getLegendItemShape();
        org.jfree.chart.title.Title title5 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity8 = new org.jfree.chart.entity.TitleEntity(shape4, title5, "org.jfree.data.UnknownKeyException: ", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeries4.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setTickMarksVisible(true);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedRangeXYPlot9.getDomainAxisEdge((int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.axis.AxisState axisState14 = categoryAxis3D0.draw(graphics2D3, (double) (byte) 1, rectangle2D5, rectangle2D7, rectangleEdge12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat4.format((long) 1, stringBuffer8, fieldPosition9);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str16 = logFormat14.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat4, (java.text.NumberFormat) logFormat14);
        java.text.ParsePosition parsePosition19 = null;
        java.lang.Object obj20 = logFormat14.parseObject("ClassContext", parsePosition19);
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "^0.48" + "'", str16.equals("^0.48"));
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getDomainCrosshairPaint();
        java.awt.Paint paint5 = combinedRangeXYPlot1.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        java.awt.Paint paint4 = combinedRangeXYPlot1.getRangeMinorGridlinePaint();
        combinedRangeXYPlot1.setDomainCrosshairVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = null;
        try {
            combinedRangeXYPlot1.setDatasetRenderingOrder(datasetRenderingOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean11 = xYLineAndShapeRenderer7.getAutoPopulateSeriesShape();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        combinedRangeXYPlot14.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = combinedRangeXYPlot14.getLegendItems();
        boolean boolean18 = combinedRangeXYPlot14.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        java.awt.Font font21 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("", font21);
        java.lang.Object obj23 = labelBlock22.clone();
        java.awt.geom.Rectangle2D rectangle2D24 = labelBlock22.getBounds();
        try {
            xYLineAndShapeRenderer7.fillRangeGridBand(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, valueAxis19, rectangle2D24, (double) 10.0f, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Object obj2 = multiplePiePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot1.getDataset();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.lang.Object obj9 = labelBlock8.clone();
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock8.getBounds();
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            multiplePiePlot1.draw(graphics2D5, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 24231L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        xYSeries1.removePropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        xYLineAndShapeRenderer7.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = null;
        shapeList0.setShape((int) (short) 0, shape2);
        boolean boolean5 = shapeList0.equals((java.lang.Object) "VerticalAlignment.CENTER");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = chartRenderingInfo0.getChartArea();
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape((java.awt.Shape) rectangle2D1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot2.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot11.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextFillPaint();
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot11.getDomainAxisLocation(1);
        combinedRangeXYPlot2.setDomainAxisLocation((int) ' ', axisLocation17, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1560409200000L, (double) 'a', (double) (short) 0, 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            java.lang.Number number6 = timeSeriesCollection0.getX(2, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMinimumBarLength();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock6.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot9.getRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextFillPaint();
        categoryPlot9.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot9.getDomainAxisLocation(1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        double double17 = categoryAxis3D16.getCategoryMargin();
        int int18 = categoryAxis3D16.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        try {
            barRenderer3D0.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D8, categoryPlot9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, valueAxis19, categoryDataset20, 3, 0, false, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("^0.48", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setRangeCrosshairLockedOnData(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo10.getChartArea();
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D11);
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.plot.PlotState plotState14 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            combinedRangeXYPlot2.draw(graphics2D7, rectangle2D11, point2D13, plotState14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int9 = combinedRangeXYPlot3.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer8);
        boolean boolean12 = xYLineAndShapeRenderer8.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer8.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        java.util.TimeZone timeZone20 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("", timeZone20);
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("", timeZone23);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection25 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection25);
        xYLineAndShapeRenderer8.drawItem(graphics2D15, xYItemRendererState16, rectangle2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.data.xy.XYDataset) timeSeriesCollection25, (int) (short) 0, 4, false, (int) '4');
        java.lang.Object obj32 = null;
        boolean boolean33 = dateAxis24.equals(obj32);
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend34 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) dateAxis24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str1 = categoryAxis3D0.getLabelURL();
        java.awt.Paint paint2 = categoryAxis3D0.getLabelPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        java.lang.Object obj8 = labelBlock7.clone();
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock7.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo12.getChartArea();
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            org.jfree.chart.axis.AxisState axisState17 = categoryAxis3D0.draw(graphics2D3, (double) 2019, rectangle2D9, rectangle2D13, rectangleEdge15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        boolean boolean2 = categoryAxis3D0.isTickLabelsVisible();
        java.awt.Paint paint4 = categoryAxis3D0.getTickLabelPaint((java.lang.Comparable) 0.2d);
        categoryAxis3D0.setCategoryMargin((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) 100L, (double) 4, 0);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        boolean boolean10 = jFreeChart9.getAntiAlias();
        boolean boolean11 = defaultPieDataset0.equals((java.lang.Object) jFreeChart9);
        java.lang.Object obj12 = jFreeChart9.getTextAntiAlias();
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color2);
        java.lang.String str4 = standardChartTheme1.getName();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        combinedRangeXYPlot6.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = combinedRangeXYPlot6.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        combinedRangeXYPlot6.setRangeAxisLocation(4, axisLocation11, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot6.setBackgroundPaint((java.awt.Paint) color14);
        java.awt.Color color16 = color14.darker();
        standardChartTheme1.setAxisLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        standardChartTheme1.setLabelLinkStyle(pieLabelLinkStyle18);
        java.lang.String str20 = pieLabelLinkStyle18.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str20.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.zoomRange((double) (short) 0, (double) (byte) 10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = null;
        try {
            java.util.Date date35 = dateAxis23.calculateLowestVisibleTickValue(dateTickUnit34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot1.panDomainAxes((double) 0, plotRenderingInfo5, point2D6);
        java.awt.Font font8 = combinedRangeXYPlot1.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D1.setMinorTickCount((-1));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.lang.Object obj9 = labelBlock8.clone();
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock8.getBounds();
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font12);
        java.lang.Object obj14 = labelBlock13.clone();
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock13.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot17.getOutlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = combinedRangeXYPlot17.getDomainAxisEdge((int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = numberAxis3D1.draw(graphics2D4, (double) (byte) 0, rectangle2D10, rectangle2D15, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint3 = standardChartTheme1.getLegendBackgroundPaint();
        java.awt.Paint paint4 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = null;
        try {
            standardChartTheme1.setLabelLinkStyle(pieLabelLinkStyle5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        xYDataItem2.setSelected(true);
        java.lang.String str7 = xYDataItem2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[10.0, -1.0]" + "'", str7.equals("[10.0, -1.0]"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.lightGray;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color1);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            categoryPlot0.addDomainMarker((int) '4', categoryMarker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        double double2 = categoryAxis3D0.getLowerMargin();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedRangeXYPlot7.getDomainAxisEdge((int) (byte) 100);
        try {
            double double11 = categoryAxis3D0.getCategoryMiddle(8, 0, rectangle2D5, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.calculateRightInset((double) 10.0f);
        combinedRangeXYPlot2.setInsets(rectangleInsets9, true);
        double double15 = rectangleInsets9.calculateRightInset(45.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        combinedRangeXYPlot1.zoomRangeAxes(Double.NaN, plotRenderingInfo9, point2D10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = combinedRangeXYPlot1.getRangeAxisEdge((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        combinedRangeXYPlot1.setRangeAxis(12, valueAxis9, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesFillPaint();
        combinedRangeXYPlot1.setRenderer(1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        java.awt.Paint paint19 = xYLineAndShapeRenderer15.getSeriesItemLabelPaint((int) (byte) 10);
        try {
            xYLineAndShapeRenderer15.setSeriesItemLabelsVisible((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((-1), 0, false);
        xYLineAndShapeRenderer2.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 24231L);
        org.jfree.data.xy.XYDataItem xYDataItem4 = xYSeries1.addOrUpdate((double) 24231L, (double) (byte) 1);
        org.junit.Assert.assertNull(xYDataItem4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color2);
        java.lang.String str4 = standardChartTheme1.getName();
        java.awt.Paint paint5 = null;
        try {
            standardChartTheme1.setSubtitlePaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setPieIndex((int) (short) 100);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        xYLineAndShapeRenderer7.setUseOutlinePaint(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        combinedRangeXYPlot9.setRangeCrosshairValue((double) (short) 100);
        float float12 = combinedRangeXYPlot9.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = combinedRangeXYPlot9.getRangeAxisEdge(3);
        try {
            double double15 = categoryAxis3D0.getCategorySeriesMiddle((java.lang.Comparable) 2019L, (java.lang.Comparable) true, categoryDataset4, 0.05d, rectangle2D7, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        java.lang.Number number4 = defaultPieDataset0.getValue((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        jFreeChart4.setTitle("hi!");
        java.awt.Paint paint8 = jFreeChart4.getBackgroundPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart4.createBufferedImage(1, 0, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomDomainAxes((double) 1900L, plotRenderingInfo2, point2D3, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = combinedRangeXYPlot1.getRangeMarkers((int) '#', layer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        combinedRangeXYPlot1.zoomRangeAxes((-1.0d), 0.08d, plotRenderingInfo17, point2D18);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        try {
            combinedRangeXYPlot1.addAnnotation(xYAnnotation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem2);
        long long5 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeries4.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        java.util.Collection collection12 = timeSeries4.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            timeSeries4.add(regularTimePeriod15, (java.lang.Number) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) '4', 10.0d);
        columnArrangement4.clear();
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) '4', 10.0d);
        columnArrangement4.add((org.jfree.chart.block.Block) labelBlock8, (java.lang.Object) '4');
        org.jfree.data.general.DefaultPieDataset defaultPieDataset15 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset15, (java.lang.Comparable) 100L, (double) 4, 0);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot22.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot22);
        boolean boolean25 = jFreeChart24.getAntiAlias();
        boolean boolean26 = defaultPieDataset15.equals((java.lang.Object) jFreeChart24);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(1, year28);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer31 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.data.general.Dataset) defaultPieDataset15, (java.lang.Comparable) month30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = null;
        try {
            legendItemBlockContainer31.setPadding(rectangleInsets32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D1.setMinorTickCount((int) (byte) 0);
        numberAxis3D1.setRangeWithMargins(0.0d, (double) 10);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) -1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYStepAreaRenderer1.setSeriesURLGenerator(1, xYURLGenerator3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator7, xYURLGenerator8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        combinedRangeXYPlot12.setRenderer(xYItemRenderer13);
        java.awt.Paint paint15 = combinedRangeXYPlot12.getDomainMinorGridlinePaint();
        xYAreaRenderer9.setSeriesOutlinePaint((int) (byte) 0, paint15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        combinedRangeXYPlot20.setRenderer(xYItemRenderer21);
        java.awt.Paint paint23 = combinedRangeXYPlot20.getDomainMinorGridlinePaint();
        org.jfree.data.xy.XYSeries xYSeries25 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean27 = xYSeries25.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection28);
        xYSeries25.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection28);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeriesCollection28.getSeries((java.lang.Comparable) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState34 = xYAreaRenderer9.initialise(graphics2D17, rectangle2D18, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.data.xy.XYDataset) timeSeriesCollection28, plotRenderingInfo33);
        java.awt.Font font36 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("", font36);
        java.lang.Object obj38 = labelBlock37.clone();
        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock37.getBounds();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis41);
        java.awt.Stroke stroke43 = combinedRangeXYPlot42.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot42);
        org.jfree.chart.axis.ValueAxis valueAxis46 = combinedRangeXYPlot42.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Stroke stroke47 = combinedRangeXYPlot42.getDomainGridlineStroke();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D51.setMinorTickCount((-1));
        org.jfree.data.xy.XYDataItem xYDataItem56 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number57 = xYDataItem56.getY();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) xYDataItem56);
        long long59 = timeSeries58.getMaximumItemAge();
        timeSeries58.setMaximumItemCount((int) '#');
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection63 = new org.jfree.data.time.TimeSeriesCollection(timeZone62);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection63);
        timeSeries58.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection63);
        try {
            xYStepAreaRenderer1.drawItem(graphics2D5, xYItemRendererState34, rectangle2D39, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot42, (org.jfree.chart.axis.ValueAxis) numberAxis3D49, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, (org.jfree.data.xy.XYDataset) timeSeriesCollection63, 100, (int) 'a', false, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator7);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNull(timeSeries32);
        org.junit.Assert.assertNotNull(xYItemRendererState34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-1.0d) + "'", number57.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 9223372036854775807L + "'", long59 == 9223372036854775807L);
        org.junit.Assert.assertNull(range64);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getLength();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str1 = categoryAxis3D0.getLabelURL();
        java.awt.Paint paint2 = categoryAxis3D0.getLabelPaint();
        int int3 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        int int9 = combinedRangeXYPlot2.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection7);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues10 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list11 = defaultKeyedValues10.getKeys();
        org.jfree.data.Range range13 = timeSeriesCollection7.getDomainBounds(list11, true);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection7, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str1 = categoryAxis3D0.getLabelURL();
        java.awt.Paint paint2 = categoryAxis3D0.getLabelPaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo7.getChartArea();
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor17);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D15, (double) 0L, (float) 40, (float) (short) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = categoryAxis3D0.draw(graphics2D3, (double) 12, rectangle2D8, rectangle2D15, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme2.setPlotBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart9);
        boolean boolean11 = dateTickUnitType0.equals((java.lang.Object) jFreeChart9);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        boolean boolean8 = barRenderer3D0.removeAnnotation(categoryAnnotation7);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("2,019", "VerticalAlignment.CENTER", "Combined Range XYPlot", "2,019", "");
        basicProjectInfo5.addOptionalLibrary("AxisLocation.TOP_OR_RIGHT");
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 0, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator3, xYURLGenerator4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        combinedRangeXYPlot8.setRenderer(xYItemRenderer9);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getDomainMinorGridlinePaint();
        xYAreaRenderer5.setSeriesOutlinePaint((int) (byte) 0, paint11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        combinedRangeXYPlot16.setRenderer(xYItemRenderer17);
        java.awt.Paint paint19 = combinedRangeXYPlot16.getDomainMinorGridlinePaint();
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean23 = xYSeries21.equals((java.lang.Object) 10.0d);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYSeries21.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeriesCollection24.getSeries((java.lang.Comparable) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState30 = xYAreaRenderer5.initialise(graphics2D13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, plotRenderingInfo29);
        try {
            java.lang.String str32 = standardXYSeriesLabelGenerator1.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (52).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(timeSeries28);
        org.junit.Assert.assertNotNull(xYItemRendererState30);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str1 = categoryAxis3D0.getLabelURL();
        java.awt.Paint paint2 = categoryAxis3D0.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        float float8 = jFreeChart7.getBackgroundImageAlpha();
        boolean boolean9 = categoryAxis3D0.hasListener((java.util.EventListener) jFreeChart7);
        java.awt.Paint paint10 = jFreeChart7.getBackgroundPaint();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot11 = jFreeChart7.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CombinedRangeXYPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.trimHeight(0.0d);
        double double7 = rectangleInsets3.calculateRightInset(1.0d);
        ringPlot0.setLabelPadding(rectangleInsets3);
        double double10 = rectangleInsets3.calculateRightOutset((double) 2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        xYSeries1.add((double) 10, (double) 1L, true);
        try {
            java.lang.Number number7 = xYSeries1.getX((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        boolean boolean7 = combinedRangeXYPlot1.isDomainZoomable();
        combinedRangeXYPlot1.setRangeMinorGridlinesVisible(true);
        java.util.TimeZone timeZone11 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("", timeZone11);
        org.jfree.data.Range range13 = combinedRangeXYPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str16 = categoryAxis3D15.getLabelURL();
        java.awt.Paint paint17 = categoryAxis3D15.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis19);
        java.awt.Stroke stroke21 = combinedRangeXYPlot20.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot20);
        float float23 = jFreeChart22.getBackgroundImageAlpha();
        boolean boolean24 = categoryAxis3D15.hasListener((java.util.EventListener) jFreeChart22);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D30 = chartRenderingInfo29.getChartArea();
        boolean boolean31 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState33 = null;
        categoryAxis3D15.drawTickMarks(graphics2D25, 45.0d, rectangle2D30, rectangleEdge32, axisState33);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D38 = chartRenderingInfo37.getChartArea();
        boolean boolean39 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor40);
        org.jfree.chart.plot.PlotState plotState42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        try {
            combinedRangeXYPlot1.draw(graphics2D14, rectangle2D30, point2D41, plotState42, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(point2D41);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "org.jfree.data.general.SeriesException: {0}", textAnchor3, textAnchor4, 90.0d);
        java.lang.Number number7 = numberTick6.getNumber();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        java.awt.Paint paint8 = barRenderer3D0.getShadowPaint();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        double double13 = categoryAxis3D12.getCategoryMargin();
        boolean boolean14 = categoryAxis3D12.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = range17.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange(range17);
        numberAxis3D16.setRangeWithMargins((org.jfree.data.Range) dateRange21, false, false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis3D16.setMarkerBand(markerAxisBand25);
        java.lang.Object obj27 = numberAxis3D16.clone();
        org.jfree.chart.util.Layer layer28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            barRenderer3D0.drawAnnotations(graphics2D9, rectangle2D11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D12, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, layer28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("DomainOrder.NONE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.clear();
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Stroke stroke15 = categoryAxis3D13.getAxisLineStroke();
        xYLineAndShapeRenderer7.setSeriesStroke(1900, stroke15);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = xYLineAndShapeRenderer7.getLegendItemLabelGenerator();
        boolean boolean18 = xYLineAndShapeRenderer7.getBaseShapesFilled();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title6 = null;
        jFreeChart4.removeSubtitle(title6);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        try {
            periodAxis1.setRangeWithMargins((double) 100, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (32.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        combinedRangeXYPlot2.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = combinedRangeXYPlot2.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        combinedRangeXYPlot2.setRangeAxisLocation(4, axisLocation7, false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot2.setBackgroundPaint((java.awt.Paint) color10);
        java.awt.Color color12 = color10.darker();
        java.awt.Color color13 = java.awt.Color.getColor("Combined Range XYPlot", color10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot1.panDomainAxes((double) 0, plotRenderingInfo5, point2D6);
        float float8 = combinedRangeXYPlot1.getForegroundAlpha();
        java.awt.Paint paint9 = combinedRangeXYPlot1.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = java.awt.Color.lightGray;
        categoryPlot2.setDomainCrosshairPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        combinedRangeXYPlot6.setRenderer(xYItemRenderer7);
        java.awt.Paint paint9 = combinedRangeXYPlot6.getDomainMinorGridlinePaint();
        boolean boolean10 = categoryPlot2.equals((java.lang.Object) paint9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            barRenderer3D0.drawOutline(graphics2D1, categoryPlot2, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.lang.Boolean boolean2 = barRenderer3D0.getSeriesCreateEntities((-1));
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        boolean boolean3 = xYSeries1.equals((java.lang.Object) 10.0d);
        boolean boolean4 = xYSeries1.getAutoSort();
        xYSeries1.clear();
        java.lang.Number number7 = null;
        xYSeries1.add((java.lang.Number) 10.0f, number7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getSerialIndex();
        int int4 = year1.getYear();
        long long5 = year1.getLastMillisecond();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis7);
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        java.util.List list12 = jFreeChart10.getSubtitles();
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        java.lang.Object obj16 = labelBlock15.clone();
        java.awt.geom.Rectangle2D rectangle2D17 = labelBlock15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double19 = categoryAxis3D0.getCategoryMiddle((java.lang.Comparable) long5, list12, rectangle2D17, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList3 = new org.jfree.chart.util.ShapeList();
        boolean boolean4 = ringPlot2.equals((java.lang.Object) shapeList3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        float float12 = jFreeChart11.getBackgroundImageAlpha();
        java.awt.Stroke stroke13 = jFreeChart11.getBorderStroke();
        ringPlot2.setSectionOutlineStroke((java.lang.Comparable) year5, stroke13);
        java.awt.Stroke stroke15 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) year5);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator16);
        double double18 = ringPlot0.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.025d + "'", double18 == 0.025d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = null;
        shapeList0.setShape((int) (short) 0, shape2);
        java.lang.Object obj4 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        double double1 = logAxis0.getFixedDimension();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = logAxis0.getLabelInsets();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo4.getChartArea();
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D5);
        boolean boolean7 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D5);
        org.jfree.chart.axis.Axis axis8 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity9 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D5, axis8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color3);
        java.awt.Paint paint5 = standardChartTheme1.getChartBackgroundPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint7 = barRenderer3D0.getShadowPaint();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.String str10 = categoryAxis3D9.getLabelURL();
        java.awt.Paint paint11 = categoryAxis3D9.getLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis13);
        java.awt.Stroke stroke15 = combinedRangeXYPlot14.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot14);
        float float17 = jFreeChart16.getBackgroundImageAlpha();
        boolean boolean18 = categoryAxis3D9.hasListener((java.util.EventListener) jFreeChart16);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D24 = chartRenderingInfo23.getChartArea();
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisState axisState27 = null;
        categoryAxis3D9.drawTickMarks(graphics2D19, 45.0d, rectangle2D24, rectangleEdge26, axisState27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color30 = java.awt.Color.lightGray;
        categoryPlot29.setDomainCrosshairPaint((java.awt.Paint) color30);
        categoryPlot29.setAnchorValue((double) 1L);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = barRenderer3D0.initialise(graphics2D8, rectangle2D24, categoryPlot29, 4, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke4 = ringPlot3.getBaseSectionOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint7 = standardChartTheme6.getThermometerPaint();
        ringPlot3.setLabelShadowPaint(paint7);
        labelBlock2.setPaint(paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            labelBlock2.setPadding(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray2 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] {};
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray2);
        java.lang.Class class4 = null;
        try {
            periodAxis1.setMinorTickTimePeriodClass(class4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setRangeAxes(valueAxisArray12);
        boolean boolean14 = combinedRangeXYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis15 = combinedRangeXYPlot2.getRangeAxis();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        double double2 = categoryAxis3D0.getFixedDimension();
        org.jfree.chart.plot.Plot plot3 = categoryAxis3D0.getPlot();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.text.AttributedString attributedString0 = null;
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        java.lang.Object obj7 = labelBlock6.clone();
        java.awt.geom.Rectangle2D rectangle2D8 = labelBlock6.getBounds();
        java.awt.Paint paint9 = null;
        try {
            org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem(attributedString0, "VerticalAlignment.CENTER", "Multiple Pie Plot", "", (java.awt.Shape) rectangle2D8, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer3D0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList5 = new org.jfree.chart.util.ShapeList();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) shapeList5);
        java.awt.Paint paint7 = ringPlot4.getLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 100, plotRenderingInfo9);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer19 = null;
        java.text.FieldPosition fieldPosition20 = null;
        java.lang.StringBuffer stringBuffer21 = logFormat15.format((long) 1, stringBuffer19, fieldPosition20);
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str27 = logFormat25.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator28 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat25);
        ringPlot4.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator28);
        java.awt.Paint paint30 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        ringPlot4.setBaseSectionOutlinePaint(paint30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "^0.48" + "'", str27.equals("^0.48"));
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            timeSeriesCollection0.setSelected(8, (int) '4', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (8).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Paint paint2 = ringPlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) -1);
        xYSeries1.add((double) 10, (double) 1L, true);
        boolean boolean6 = xYSeries1.getNotify();
        java.lang.Number number8 = xYSeries1.getX(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0d + "'", number8.equals(10.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9, true);
        combinedRangeXYPlot2.mapDatasetToDomainAxis((int) (byte) 100, 1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate8 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        double double9 = intervalXYDelegate8.getFixedIntervalWidth();
        double double10 = intervalXYDelegate8.getIntervalWidth();
        org.jfree.data.Range range12 = intervalXYDelegate8.getDomainBounds(false);
        double double13 = intervalXYDelegate8.getFixedIntervalWidth();
        double double14 = intervalXYDelegate8.getFixedIntervalWidth();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.StandardChartTheme standardChartTheme4 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint5 = standardChartTheme4.getThermometerPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        standardChartTheme4.setLegendItemPaint((java.awt.Paint) color6);
        java.awt.Paint paint8 = standardChartTheme4.getTitlePaint();
        textTitle1.setBackgroundPaint(paint8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str2.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100);
        xYAreaRenderer1.removeAnnotations();
        java.awt.Shape shape3 = xYAreaRenderer1.getBaseShape();
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("2,019");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key 2,019");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number3 = xYDataItem2.getY();
        double double4 = xYDataItem2.getXValue();
        java.lang.String str5 = xYDataItem2.toString();
        java.lang.Number number6 = xYDataItem2.getY();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[10.0, -1.0]" + "'", str5.equals("[10.0, -1.0]"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo8.getChartArea();
        boolean boolean10 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D9);
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1577865599999L, (double) 0.0f, rectangle2D9);
        try {
            combinedRangeXYPlot1.zoomDomainAxes((double) 10, plotRenderingInfo3, point2D11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(point2D11);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color3);
        java.awt.Font font5 = standardChartTheme1.getExtraLargeFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        combinedRangeXYPlot1.setWeight(40);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.lightGray;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis4);
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        jFreeChart7.setTitle("hi!");
        java.awt.Paint paint11 = jFreeChart7.getBackgroundPaint();
        categoryPlot0.setRangeGridlinePaint(paint11);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset((int) (short) 0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        boolean boolean11 = xYLineAndShapeRenderer7.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer7.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = null;
        java.util.TimeZone timeZone19 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection24);
        xYLineAndShapeRenderer7.drawItem(graphics2D14, xYItemRendererState15, rectangle2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.data.xy.XYDataset) timeSeriesCollection24, (int) (short) 0, 4, false, (int) '4');
        dateAxis23.setTickLabelsVisible(false);
        boolean boolean33 = dateAxis23.isNegativeArrowVisible();
        java.awt.Stroke stroke34 = dateAxis23.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) shapeList1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        float float10 = jFreeChart9.getBackgroundImageAlpha();
        java.awt.Stroke stroke11 = jFreeChart9.getBorderStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) year3, stroke11);
        ringPlot0.setNotify(true);
        boolean boolean15 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot1.getDomainAxisIndex(valueAxis2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = combinedRangeXYPlot1.removeDomainMarker(marker4, layer5);
        java.lang.String str7 = combinedRangeXYPlot1.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo12.getChartArea();
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D16 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor15);
        try {
            combinedRangeXYPlot1.zoomDomainAxes((double) 1900, plotRenderingInfo9, point2D16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Combined Range XYPlot" + "'", str7.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(point2D16);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        float float3 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        float float5 = jFreeChart4.getBackgroundImageAlpha();
        java.awt.Paint paint6 = jFreeChart4.getBackgroundPaint();
        int int7 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart4.getLegend();
        boolean boolean9 = legendTitle8.visible;
        legendTitle8.setVisible(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendTitle8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("2,019", "VerticalAlignment.CENTER", "Combined Range XYPlot", "2,019", "");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedRangeXYPlot7.getSeriesRenderingOrder();
        java.lang.Object obj11 = combinedRangeXYPlot7.clone();
        boolean boolean12 = basicProjectInfo5.equals((java.lang.Object) combinedRangeXYPlot7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        try {
            defaultPieDataset0.insertValue(2019, (java.lang.Comparable) 1900, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        boolean boolean4 = combinedRangeXYPlot1.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedRangeXYPlot2.setRenderer(xYItemRenderer3);
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        combinedRangeXYPlot2.setNoDataMessageFont(font6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("{0}", font6);
        textTitle9.setMaximumLinesToDisplay((int) (short) 100);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 1L, 90.0d, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.lang.Object obj3 = labelBlock2.clone();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = labelBlock2.getContentAlignmentPoint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 3, (double) (short) 1, 90.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Object obj2 = multiplePiePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        java.awt.Shape shape4 = multiplePiePlot1.getLegendItemShape();
        java.lang.String str5 = multiplePiePlot1.getPlotType();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo10.getChartArea();
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D14 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor13);
        org.jfree.chart.plot.PlotState plotState15 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            multiplePiePlot1.draw(graphics2D6, rectangle2D7, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Multiple Pie Plot" + "'", str5.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(point2D14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat4.setMinimumFractionDigits((int) (byte) -1);
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat4, dateFormat7);
        int int9 = logFormat4.getMaximumIntegerDigits();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year11);
        java.text.AttributedCharacterIterator attributedCharacterIterator14 = logFormat4.formatToCharacterIterator((java.lang.Object) 3);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = java.awt.Color.lightGray;
        categoryPlot15.setDomainCrosshairPaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        combinedRangeXYPlot19.setRenderer(xYItemRenderer20);
        java.awt.Paint paint22 = combinedRangeXYPlot19.getDomainMinorGridlinePaint();
        boolean boolean23 = categoryPlot15.equals((java.lang.Object) paint22);
        java.lang.StringBuffer stringBuffer24 = null;
        java.text.FieldPosition fieldPosition25 = null;
        try {
            java.lang.StringBuffer stringBuffer26 = logFormat4.format((java.lang.Object) paint22, stringBuffer24, fieldPosition25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 40 + "'", int9 == 40);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(attributedCharacterIterator14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100.0f, (double) 2019L);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range8.intersects((double) 100.0f, (double) 2019L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 1900L, range1, lengthConstraintType6, (double) (byte) 100, range8, lengthConstraintType12);
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude(range8, 0.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        java.awt.Paint paint8 = combinedRangeXYPlot1.getBackgroundPaint();
        java.awt.Stroke stroke9 = null;
        try {
            combinedRangeXYPlot1.setDomainZeroBaselineStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot1.panDomainAxes((double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = combinedRangeXYPlot1.getRangeMarkers((int) (byte) 0, layer9);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        combinedRangeXYPlot1.setRenderer(xYItemRenderer2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        combinedRangeXYPlot1.setNoDataMessageFont(font5);
        double double8 = combinedRangeXYPlot1.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace9 = combinedRangeXYPlot1.getFixedRangeAxisSpace();
        combinedRangeXYPlot1.setDomainCrosshairValue(0.0d);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            combinedRangeXYPlot1.addRangeMarker((int) (byte) 10, marker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(axisSpace9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        combinedRangeXYPlot2.setRenderer(xYItemRenderer3);
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        combinedRangeXYPlot2.setNoDataMessageFont(font6);
        org.jfree.chart.plot.Plot plot9 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ", font6, plot9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        try {
            defaultKeyedValues0.insertValue((int) (short) 100, (java.lang.Comparable) "VerticalAlignment.CENTER", (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("PieLabelLinkStyle.STANDARD");
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint8 = xYLineAndShapeRenderer2.getItemPaint(12, 3, true);
        xYLineAndShapeRenderer2.setUseOutlinePaint(false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList5 = new org.jfree.chart.util.ShapeList();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) shapeList5);
        java.awt.Paint paint7 = ringPlot4.getLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = ringPlot0.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.PiePlot) ringPlot4, (java.lang.Integer) 100, plotRenderingInfo9);
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        logFormat15.setMinimumIntegerDigits((int) (short) -1);
        java.lang.StringBuffer stringBuffer19 = null;
        java.text.FieldPosition fieldPosition20 = null;
        java.lang.StringBuffer stringBuffer21 = logFormat15.format((long) 1, stringBuffer19, fieldPosition20);
        org.jfree.chart.util.LogFormat logFormat25 = new org.jfree.chart.util.LogFormat((double) (byte) 10, "", true);
        java.lang.String str27 = logFormat25.format((java.lang.Object) 3);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator28 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Combined Range XYPlot", (java.text.NumberFormat) logFormat15, (java.text.NumberFormat) logFormat25);
        ringPlot4.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator28);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor30 = null;
        try {
            ringPlot4.setLabelDistributor(abstractPieLabelDistributor30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(piePlotState10);
        org.junit.Assert.assertNotNull(stringBuffer21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "^0.48" + "'", str27.equals("^0.48"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer3D0.getURLGenerator((int) '#', 1, false);
        double double7 = barRenderer3D0.getMinimumBarLength();
        java.awt.Paint paint8 = barRenderer3D0.getShadowPaint();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            barRenderer3D0.drawBackground(graphics2D9, categoryPlot10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(Double.POSITIVE_INFINITY, (double) 'a');
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.awt.Paint paint2 = ringPlot1.getBaseSectionPaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        combinedRangeXYPlot4.setRenderer(xYItemRenderer5);
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font8);
        combinedRangeXYPlot4.setNoDataMessageFont(font8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        combinedRangeXYPlot4.setRenderer(0, xYItemRenderer12, true);
        java.awt.Stroke stroke15 = combinedRangeXYPlot4.getRangeCrosshairStroke();
        ringPlot1.setLabelLinkStroke(stroke15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.awt.Paint paint2 = ringPlot1.getBaseSectionPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot1.getSimpleLabelOffset();
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot1.setLabelOutlinePaint(paint4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        boolean boolean1 = logAxis0.isVerticalTickLabels();
        double double3 = logAxis0.calculateLog((double) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.lightGray;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        combinedRangeXYPlot4.setRenderer(xYItemRenderer5);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getDomainMinorGridlinePaint();
        boolean boolean8 = categoryPlot0.equals((java.lang.Object) paint7);
        org.jfree.chart.plot.Marker marker9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeRangeMarker(marker9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        combinedRangeXYPlot2.setNotify(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot2.zoomRangeAxes((double) (short) 1, plotRenderingInfo8, point2D9, true);
        combinedRangeXYPlot2.setDomainCrosshairLockedOnData(false);
        java.lang.String str14 = combinedRangeXYPlot2.getPlotType();
        java.awt.Stroke stroke15 = combinedRangeXYPlot2.getRangeGridlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextFillPaint();
        combinedRangeXYPlot2.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("2,019", "VerticalAlignment.CENTER", "Combined Range XYPlot", "2,019", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getLibraries();
        java.lang.String str7 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2,019" + "'", str7.equals("2,019"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Paint paint6 = xYLineAndShapeRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        paintMap0.put((java.lang.Comparable) "org.jfree.data.UnknownKeyException: ", paint6);
        boolean boolean9 = paintMap0.containsKey((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D4.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D4.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint11 = barRenderer3D4.getShadowPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker17, rectangle2D21);
        boolean boolean26 = numberAxis3D14.isInverted();
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYStepAreaRenderer1.getToolTipGenerator((int) 'a', (int) (byte) 100, true);
        xYStepAreaRenderer1.removeAnnotations();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D1 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer3D1.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint8 = barRenderer3D1.getShadowPaint();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D1);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot0.setRangeAxis(valueAxis10);
        int int12 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D2.setFixedDimension((double) 0.5f);
        double double5 = categoryAxis3D2.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.trimHeight(0.0d);
        categoryAxis3D2.setLabelInsets(rectangleInsets6, false);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList12 = new org.jfree.chart.util.ShapeList();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) shapeList12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis17);
        java.awt.Stroke stroke19 = combinedRangeXYPlot18.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        float float21 = jFreeChart20.getBackgroundImageAlpha();
        java.awt.Stroke stroke22 = jFreeChart20.getBorderStroke();
        ringPlot11.setSectionOutlineStroke((java.lang.Comparable) year14, stroke22);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator24 = ringPlot11.getToolTipGenerator();
        org.jfree.data.xy.XYDataItem xYDataItem27 = new org.jfree.data.xy.XYDataItem((double) 10L, (double) (byte) -1);
        java.lang.Number number28 = xYDataItem27.getY();
        double double29 = xYDataItem27.getXValue();
        java.awt.Paint paint30 = ringPlot11.getSectionPaint((java.lang.Comparable) double29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D35 = chartRenderingInfo34.getChartArea();
        boolean boolean36 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D35, rectangleAnchor37);
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot();
        ringPlot39.clearSectionOutlinePaints(true);
        double double42 = ringPlot39.getInnerSeparatorExtension();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.PiePlotState piePlotState45 = ringPlot11.initialise(graphics2D31, rectangle2D35, (org.jfree.chart.plot.PiePlot) ringPlot39, (java.lang.Integer) 6, plotRenderingInfo44);
        rectangleInsets6.trim(rectangle2D35);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D50 = chartRenderingInfo49.getChartArea();
        boolean boolean51 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor52);
        org.jfree.chart.plot.PlotState plotState54 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        try {
            piePlot3D0.draw(graphics2D1, rectangle2D35, point2D53, plotState54, plotRenderingInfo55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(pieToolTipGenerator24);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.0d + "'", double29 == 10.0d);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.2d + "'", double42 == 0.2d);
        org.junit.Assert.assertNotNull(piePlotState45);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D53);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.lang.Comparable comparable3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        double double6 = categoryAxis3D5.getCategoryMargin();
        double double7 = categoryAxis3D5.getLowerMargin();
        float float8 = categoryAxis3D5.getTickMarkOutsideLength();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo13.getChartArea();
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D14);
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D14);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D18.setAutoRangeStickyZero(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo24.getChartArea();
        boolean boolean26 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double30 = numberAxis3D18.java2DToValue((double) 0.5f, rectangle2D25, rectangleEdge29);
        try {
            double double31 = barRenderer3D0.getItemMiddle((java.lang.Comparable) 4.0d, comparable3, categoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, rectangle2D14, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke2 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke3 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot0.getRangeMarkers(layer4);
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        boolean boolean5 = jFreeChart4.getAntiAlias();
        jFreeChart4.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean8 = jFreeChart4.isBorderVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) (-1L), (float) (-1L), (float) 1);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 100, false);
        try {
            xYSeries2.delete(0, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 256");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int8 = combinedRangeXYPlot2.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer7);
        java.awt.Shape shape10 = xYLineAndShapeRenderer7.getSeriesShape(10);
        boolean boolean11 = xYLineAndShapeRenderer7.getAutoPopulateSeriesShape();
        xYLineAndShapeRenderer7.setBaseShapesVisible(false);
        java.awt.Shape shape15 = xYLineAndShapeRenderer7.getLegendShape((-1));
        java.awt.Font font17 = null;
        org.jfree.chart.StandardChartTheme standardChartTheme19 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint20 = standardChartTheme19.getThermometerPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("", font17, paint20, 0.0f, textMeasurer22);
        java.awt.Font font25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.StandardChartTheme standardChartTheme27 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint28 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme27.setErrorIndicatorPaint(paint28);
        java.awt.Paint paint30 = standardChartTheme27.getTickLabelPaint();
        java.awt.Paint paint31 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme27.setSubtitlePaint(paint31);
        textBlock23.addLine("", font25, paint31);
        xYLineAndShapeRenderer7.setBaseItemLabelFont(font25);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(shape15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Stroke stroke2 = legendItem1.getLineStroke();
        java.text.AttributedString attributedString3 = legendItem1.getAttributedLabel();
        legendItem1.setLineVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(attributedString3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = defaultPieDataset0.equals((java.lang.Object) xYStepAreaRenderer1);
        xYStepAreaRenderer1.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYStepAreaRenderer1.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.ShapeList shapeList8 = new org.jfree.chart.util.ShapeList();
        boolean boolean9 = ringPlot7.equals((java.lang.Object) shapeList8);
        java.awt.Paint paint10 = ringPlot7.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = ringPlot7.getSimpleLabelOffset();
        double double12 = ringPlot7.getStartAngle();
        boolean boolean13 = xYStepAreaRenderer1.hasListener((java.util.EventListener) ringPlot7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot1.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem6 = legendItemCollection4.get(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = standardChartTheme1.getLabelLinkStyle();
        java.awt.Font font3 = standardChartTheme1.getLargeFont();
        java.awt.Color color4 = java.awt.Color.ORANGE;
        standardChartTheme1.setRangeGridlinePaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = standardChartTheme1.getAxisLabelPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme1.setErrorIndicatorPaint(paint2);
        java.awt.Paint paint4 = standardChartTheme1.getTickLabelPaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        standardChartTheme1.setSubtitlePaint(paint5);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        double double8 = categoryAxis3D7.getCategoryMargin();
        double double9 = categoryAxis3D7.getFixedDimension();
        boolean boolean10 = standardChartTheme1.equals((java.lang.Object) double9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D4.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D4.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint11 = barRenderer3D4.getShadowPaint();
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("Combined Range XYPlot");
        numberAxis3D14.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor23);
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, marker17, rectangle2D21);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D33 = chartRenderingInfo32.getChartArea();
        boolean boolean34 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D33);
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) 255, rectangle2D33);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D37 = chartRenderingInfo36.getChartArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot38.getRenderer();
        org.jfree.chart.StandardChartTheme standardChartTheme41 = new org.jfree.chart.StandardChartTheme("");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle42 = standardChartTheme41.getLabelLinkStyle();
        java.awt.Font font43 = standardChartTheme41.getLargeFont();
        java.awt.Color color44 = java.awt.Color.ORANGE;
        standardChartTheme41.setRangeGridlinePaint((java.awt.Paint) color44);
        categoryPlot38.setRangeCrosshairPaint((java.awt.Paint) color44);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot38.getDomainAxisEdge(100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            org.jfree.chart.axis.AxisState axisState50 = numberAxis3D14.draw(graphics2D26, (double) 10, rectangle2D33, rectangle2D37, rectangleEdge48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            categoryPlot0.addRangeMarker(0, marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        timeSeriesCollection0.removeAllSeries();
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        standardChartTheme1.setPlotBackgroundPaint((java.awt.Paint) color2);
        java.lang.String str4 = standardChartTheme1.getName();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        combinedRangeXYPlot6.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = combinedRangeXYPlot6.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        combinedRangeXYPlot6.setRangeAxisLocation(4, axisLocation11, false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        combinedRangeXYPlot6.setBackgroundPaint((java.awt.Paint) color14);
        java.awt.Color color16 = color14.darker();
        standardChartTheme1.setAxisLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D18.setFixedDimension((double) 0.5f);
        double double21 = categoryAxis3D18.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.trimHeight(0.0d);
        categoryAxis3D18.setLabelInsets(rectangleInsets22, false);
        standardChartTheme1.setAxisOffset(rectangleInsets22);
        double double29 = rectangleInsets22.extendWidth((double) (-1L));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(seriesRenderingOrder9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.0d) + "'", double29 == (-1.0d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesVisible();
        boolean boolean5 = xYLineAndShapeRenderer2.isSeriesVisible((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: " + "'", str2.equals("org.jfree.data.UnknownKeyException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getAutoPopulateSectionPaint();
        boolean boolean2 = ringPlot0.getSectionOutlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.trimHeight(0.0d);
        double double7 = rectangleInsets3.calculateRightInset(1.0d);
        ringPlot0.setLabelPadding(rectangleInsets3);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        java.awt.Paint paint10 = ringPlot0.getLabelOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year1);
        long long4 = month3.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24231L + "'", long4 == 24231L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis1);
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot2);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        boolean boolean8 = combinedRangeXYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace9.setTop((double) 12);
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace9, false);
        java.lang.String str14 = combinedRangeXYPlot2.getPlotType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.Object obj2 = multiplePiePlot1.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot1.getLegendItems();
        java.awt.Shape shape4 = multiplePiePlot1.getLegendItemShape();
        java.lang.String str5 = multiplePiePlot1.getPlotType();
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Multiple Pie Plot" + "'", str5.equals("Multiple Pie Plot"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((-1), 0, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        combinedRangeXYPlot9.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        int int13 = combinedRangeXYPlot9.getRangeAxisIndex(valueAxis12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis14);
        combinedRangeXYPlot15.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = combinedRangeXYPlot15.getLegendItems();
        combinedRangeXYPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot9.getRangeMarkers((int) '#', layer21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        double double24 = categoryAxis3D23.getCategoryMargin();
        java.awt.Stroke stroke25 = categoryAxis3D23.getAxisLineStroke();
        combinedRangeXYPlot9.setRangeMinorGridlineStroke(stroke25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis28);
        java.awt.Stroke stroke30 = combinedRangeXYPlot29.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot29);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        int int35 = combinedRangeXYPlot29.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer34);
        boolean boolean38 = xYLineAndShapeRenderer34.getItemShapeFilled((int) (byte) 1, (int) (short) 1);
        xYLineAndShapeRenderer34.setUseOutlinePaint(true);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        java.util.TimeZone timeZone46 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("", timeZone46);
        java.util.TimeZone timeZone49 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("", timeZone49);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection51 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection51);
        xYLineAndShapeRenderer34.drawItem(graphics2D41, xYItemRendererState42, rectangle2D43, xYPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.data.xy.XYDataset) timeSeriesCollection51, (int) (short) 0, 4, false, (int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D61 = chartRenderingInfo60.getChartArea();
        boolean boolean62 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 12, (double) (byte) -1, rectangle2D61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D61, rectangleAnchor63);
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis50, rectangle2D61, 10.0d);
        dateAxis50.zoomRange((double) (-1), 0.0d);
        java.awt.Graphics2D graphics2D70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator78 = barRenderer3D72.getURLGenerator((int) '#', 1, false);
        java.awt.Paint paint79 = barRenderer3D72.getShadowPaint();
        categoryPlot71.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = categoryPlot71.getDomainAxisForDataset(2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo83 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D84 = chartRenderingInfo83.getChartArea();
        org.jfree.chart.axis.ValueAxis valueAxis85 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot86 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis85);
        java.awt.Stroke stroke87 = combinedRangeXYPlot86.getOutlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = combinedRangeXYPlot86.getDomainAxisEdge((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace90 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace91 = dateAxis50.reserveSpace(graphics2D70, (org.jfree.chart.plot.Plot) categoryPlot71, rectangle2D84, rectangleEdge89, axisSpace90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(point2D64);
        org.junit.Assert.assertNull(categoryURLGenerator78);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNull(categoryAxis82);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(rectangleEdge89);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        combinedRangeXYPlot1.setRangeCrosshairValue((double) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = combinedRangeXYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        combinedRangeXYPlot7.setRangeCrosshairValue((double) 100L);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot7.getLegendItems();
        combinedRangeXYPlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot1.isDomainZoomable();
        int int13 = combinedRangeXYPlot1.getRendererCount();
        java.awt.Stroke stroke14 = combinedRangeXYPlot1.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(stroke14);
    }
}

